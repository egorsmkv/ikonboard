# Pointless module to keep iB quiet until the last MemberTitle calls have
# been weeded out.

1;
