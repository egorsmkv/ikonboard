package ForwardWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'logged_in'             => q!Logged in as:!,
        'message'               => q!Message!,
        'redirect'              => q!The email has been sent!,
        'send_text'             => q!I thought you might be interested in reading this web page: <#THE LINK#>

From,

<#USER NAME#>!,
        'subject'               => q!Subject!,
        'submit_send'           => q!Send Email!,
        'title'                 => q!Send a page to a friend!,
        'to_email'              => q!Send to (Email Address):!,
        'to_name'               => q!Send to (Person's Name):!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
