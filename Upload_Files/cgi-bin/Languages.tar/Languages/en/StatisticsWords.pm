package StatisticsWords;

  sub new {
    my $pkg = shift;
    my $obj = {

        'hack_title'                            => q!Extended Statistics!,
        'moment_title'                          => q!Members of the moment!,
        'hall_of_lame'                          => q!Hall of Fame !,
        'member_info'                           => q!Members !,
        'stats'                                 => q!Statistics!,
        'stat_results'                          => q!Results!,
        'top_newest_members'                    => q!Top Ten Newest members!,
        'top_posters'                           => q!Top Ten Posters !,
        'top_login'                             => q!Top Ten Last Login !,
        'top_topics'                            => q!Top Ten Topics by Replies !,
        'topic_view_no_permission'              => q!Mission impossible III!,
        'total_members'                         => q!Extensive information !,
        'total_members_aolname'                 => q!Total members who have AOL: !,
        'total_members_female'                  => q!Total female members: !,
        'total_members_icqnumber'               => q!Total members who have ICQ: !,
        'total_members_male'                    => q!Total male members: !,
        'total_members_noavatar'                => q!Total members who have no avatar: !,
        'total_members_nosex'                   => q!Total members whose sex is unknown: !,
        'total_members_num'                     => q!Total members:!,
        'total_members_posted'                  => q!Total members who have posted: !,
        'total_members_realname'                => q!Total members who entered a real name: !,
        'total_members_sign'                    => q!Total members who have signation: !,
        'total_members_yahooname'               => q!Total members who have YIM: !,

#Upgraded language in 2004-24-10 by Method

       'member_group'                => q!Group:!,
       'member_id'                   => q!Member-Id:!,
       'member_joined'               => q!Joined:!,
       'member_posts'                => q!Posts:!,
       'member_photo'                => q!Photo:!,
       'member_aol'                  => q!AOL-Name:!,
       'member_icq'                  => q!ICQ-Number:!,
       'member_loc'                  => q!Location:!,
       'member_sig'                  => q!Signature:!,
       'member_website'              => q!Homepage:!,
       'member_yahoo'                => q!Yahoo-Name:!,
       'member_title'                => q!Title:!,
       'member_rname'                => q!Real Name:!,

    };
    bless $obj, $pkg;
    return $obj;
 }

 1;