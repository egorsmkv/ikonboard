package TsearchWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'num_dl'                => q!Number of downloads:!,
        'pages'                 => q!Pages:!,
        'posted_by'             => q!Posted By!,
        'replies'               => q!Replies:!,
        'search_results'        => q!Search results for keywords &quot;<#KEYWORDS#>&quot; in topic <#TOPIC#> in forum <#FORUM#>!,
        'showing_results'       => q!Showing results <#FIRST#> to <#LAST#> of <#NUM#>!,
        'topic_rating'          => q!Rated <#TITLE#> <#NUM#> stars!,
        'views'                 => q!Views:!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
