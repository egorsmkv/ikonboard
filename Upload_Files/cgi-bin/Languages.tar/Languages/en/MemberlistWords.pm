package MemberlistWords;

  sub new {
    my $pkg = shift;
    my $obj = {
        'ascending_order'       => q!Ascending Order!,
        'descending_order'      => q!Descending Order!,
        'error_back'            => q!Go Back!,
        'member_aol'            => q!AOL!,
        'member_email'          => q!Email!,
        'member_group'          => q!Group!,
        'member_icq'            => q!ICQ!,
        'member_joined'         => q!Joined!,
        'member_level'          => q!Level!,
        'member_msn'            => q!MSN!,
        'member_name'           => q!Name!,
        'member_posts'          => q!Posts!,
        'member_yim'            => q!YIM!,
        'multi_pages'           => q!Multiple Pages!,
        'no_results'            => q!Sorry, no matches found.!,
        'page_title'            => q!Member List!,
        'show_admin'            => q!Administrators!,
        'show_all'              => q!All Members!,
        'show_staff'            => q!Board Staff!,
        'sort_by_joined'        => q!Join Date!,
        'sort_by_level'         => q!Member Level!,
        'sort_by_name'          => q!Member Name!,
        'sort_by_posts'         => q!Total Posts!,
        'sort_submit'           => q!Go&#33;!,
        'sorting_text'          => q!Showing <#FILTER#> by <#SORT_KEY#> in <#SORT_ORDER#> with <#MAX_RESULTS#> results per page!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;