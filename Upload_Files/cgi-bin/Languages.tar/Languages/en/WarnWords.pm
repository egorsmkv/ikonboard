package WarnWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'curr_level'            => q!Current Warning Level!,
        'inc_level'             => q!Increment this user's warning level?!,
        'message'               => q!Enter a message to be sent to this member!,
        'msg_std'               => q!You have been warned by a staff member.  Your warning level has not been incremented, however, this is a possibility for the future.[br]You have been warned from the following post: <#POST#>!,
        'msg_up'                => q!You have been warned by a staff member.  Your warning level has been increased, and this will be viewable to all members.  Once you have reached the maximum warning level, your posting permissions will be revoked.[br]You have been warned from the following post: <#POST#>!,
        'redirect'              => q!Member warned, taking you back to the post.!,
        'send'                  => q!Warn!,
        'subject'               => q!You have been warned&#33;!,
        'title'                 => q!Privately warn a member!,
        'warn'                  => q!Privately warning a member is serious, especially if their level is being raised.  Do NOT abuse this feature.!,
        'warned'                => q!Member has been warned!,
        'warned_txt'            => q!has been warned!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
