package PrintpageWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'by'                    => q!Posted by!,
        'end'                   => q!end!,
        'forum'                 => q!Forum!,
        'from'                  => q!Message From: !,
        'message_title'         => q!Printable Version of a Private Message!,
        'on'                    => q!on!,
        'start'                 => q!started by!,
        'subject'               => q!Message Subject: !,
        'title'                 => q!Printable Version of Topic!,
        'topic'                 => q!Topic!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
