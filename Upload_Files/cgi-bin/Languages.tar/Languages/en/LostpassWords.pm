package LostpassWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'dont_email'            => q!Please don't email the board administrator requesting to email you your password!,
        'email_subject'         => q!Request Login Details (Part One)!,
        'email_subject_b'       => q!Request Login Details (Part Two)!,
        'first_email'           => q!The first email has been sent!,
        'first_email_txt'       => q!The email has been sent containing the link that will validate your request. Please check your email account now before proceeding!,
        'nav_title'             => q!Request log in details!,
        'second_email'          => q!Your details have been sent&#33;!,
        'second_email_txt'      => q!The validation process was successful. An email has been sent containing your new password and original username.!,
        'step_a'                => q!Enter the username you registered with now!,
        'step_a_txt'            => q!Your registered username!,
        'step_b'                => q!Check your email!,
        'step_b_txt'            => q!An email will be sent asking for confirmation to reset your password. This is a security measure to make sure that no one is trying to gain access to your account.!,
        'step_c'                => q!Validate the email!,
        'step_c_txt'            => q!In the email you will receive a link and code to cut and paste into a form to validate the request.!,
        'step_d'                => q!Check your email, again!,
        'step_d_txt'            => q!If the unlock code validates, you will be emailed your username and your new password. After this step, you may change your password in your control panel under "Modify Account."!,
        'submit_b'              => q!Process!,
        'submit_form'           => q!Send the confirmation email!,
        'text_a'                => q!As this bulletin board encrypts all passwords upon registration, no one apart from you knows your 'real' password. Therefore you must follow these steps to have your password reset and emailed to you.!,
        'title'                 => q!Please read the following instructions carefully!,
        'unlock_text'           => q!Please enter the unlock code you received in the email!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
