package LoginWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'add_name'              => q!Yes, add my name to the active users list!,
        'admin_force_log_in'    => q!The board administrator requires all members to log in!,
        'anon_name'             => q!Don't add me to the active users list!,
        'blank_fields'          => q!Please enter your username and password before continuing!,
        'cookie_no'             => q!No!,
        'cookie_yes'            => q!Yes!,
        'cookies'               => q!<b>Remember my log in details?</b><br>If enabled, you will be automatically logged in again when you visit!,
        'enter_name'            => q!Please enter your username!,
        'enter_pass'            => q!Please enter your password!,
        'errors_found'          => q!The following errors were found:!,
        'force_login'           => q!The board administrator requires that all members log in before viewing the board!,
        'forgot_pass'           => q!Forgotten your password and/or log in details?!,
        'log_in'                => q!Log In!,
        'log_in_submit'         => q!Log me in!,
        'log_out'               => q!Log Out!,
        'log_out_submit'        => q!Log me out!,
        'log_out_txt'           => q!Logging out will remove you from the active users list (if you are not anonymous). It will also remove any cookies set by this board, so you will have to log back in on your next visit.!,
        'not_registered'        => q!Not Registered? !,
        'options'               => q!Options!,
        'pass_link'             => q!Click here&#33;!,
        'please_log_in'         => q!Please enter your details below to log in!,
        'privacy'               => q!<b>Privacy:</b> do you want to appear in the active users list?!,
        'reg_link'              => q!Register Now&#33;!,
        'sess_interupt'         => q!Your session has been interrupted. Please log back in!,
        'thanks_for_login'      => q!You are now logged in&#33;!,
        'thanks_for_logout'     => q!You are now logged out!,
        'wrong_name'            => q!Sorry, we could not find a member called <#NAME#>. Are you sure it's correct?!,
        'wrong_pass'            => q!Sorry, that password is wrong. All passwords are case sensitive.!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
