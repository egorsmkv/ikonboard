package PagerWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'aol_title'             => q!AOL Pager!,
        'email'                 => q!Your Email!,
        'icq_title'             => q!ICQ Pager!,
        'msg'                   => q!Enter your message!,
        'msn'                   => q!Click on the icon to activate it.!,
        'msnbox'                => q!Press "OK" below to send an MSN IM to <#MEMBER_NAME#>, or press "Cancel" to add them to your MSN Contacts list.\n\nYou must have MSN Messenger installed and be signed on for these options to work properly.!,
        'name'                  => q!Your Name!,
        'submit'                => q!Send this message!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
