package PostersWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'close_win'             => q!Close this Window and Open the Topic!,
        'poster'                => q!Poster!,
        'posts'                 => q!Posts!,
        'who_post'              => q!Who Posted In: !,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
