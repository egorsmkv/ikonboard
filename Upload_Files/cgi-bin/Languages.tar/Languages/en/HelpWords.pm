package HelpWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'choose_file'           => q!Choose a topic!,
        'help_topic'            => q!Help Topic!,
        'help_topics'           => q!Help Topics!,
        'help_txt'              => q!Welcome to the Ikonboard help database. Simply choose from one of the titles to learn more about how Ikonboard works, or search for help files.!,
        'no_results'            => q!We could not find any help topics that matched your search criteria. Please try again.!,
        'page_title'            => q!Ikonboard Help Files!,
        'results_title'         => q!Your Search Results!,
        'results_txt'           => q!Here are the results of the search you performed.!,
        'search_results'        => q!Search Results!,
        'search_txt'            => q!Enter keywords to search for!,
        'submit'                => q!Search&#33;!,
        'topic_text'            => q!Here is the topic you chose to view!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
