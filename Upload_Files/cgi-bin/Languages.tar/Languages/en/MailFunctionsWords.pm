package MailFunctionsWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'invite_redirect'       => q!The email has been sent to !,
        'invite_subject'        => q!<#MEMBER_NAME#> thought you would like to see this!,
        'sub_added'             => q!Your subscription has been added!,
        'subs_redirect'         => q!You have subscribed to this topic!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
