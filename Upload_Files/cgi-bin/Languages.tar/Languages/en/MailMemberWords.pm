package MailMemberWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'email_sent'            => q!The email has been sent!,
        'email_sent_txt'        => q!The email has been successfully sent to!,
        'member_address_title'  => q!Member's Email Address!,
        'message'               => q!Message!,
        'msg_txt'               => q!Note: by using this form, the recipient will be able to view your email address!,
        'send_email_to'         => q!Send an email to!,
        'send_header'           => q!, please fill in this form fully to send an email to!,
        'send_title'            => q!Email Form!,
        'show_address_text'     => q!You can send this member an email by clicking on the link below. Ikonboard does not show email addresses in the HTML code to prevent email addresses being harvested by "spam bots."!,
        'subject'               => q!Subject!,
        'submit_send'           => q!Send Email!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
