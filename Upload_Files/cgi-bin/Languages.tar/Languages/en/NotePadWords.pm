package NotePadWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'back_to_usercp'        => q!Back to your Control Panel!,
        'note_pad_description'  => q!Every member gets his or her own personal notepad. You can use it to keep track of your thoughts and opinions, to write a note to yourself, or just to fool around with.!,
        'notes'                 => q!Your Notes!,
        'page_title'            => q!Your Notepad!,
        's_mess'                => q!Your Saved Private Message!,
        's_post'                => q!Your Saved Post!,
        'save_successful'       => q!your notepad has been saved!,
        'saved_mess'            => q!This is a private message that you saved!,
        'saved_post'            => q!This is a post that you saved!,
        'submit'                => q!Save!,
        'your_note_pad'         => q!Welcome to your Notepad!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
