package LegendsWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'B'                     => q!Bold Text!,
        'COLOR'                 => q!red!,
        'COLOR2'                => q!Font Color!,
        'FONT'                  => q!Font Face!,
        'I'                     => q!Italic Text!,
        'ME'                    => q!runs&#33;!,
        'QUOTE'                 => q!Quoting text...!,
        'S'                     => q!Strikethrough Text!,
        'SIZE'                  => q!Font Size (1-10)!,
        'U'                     => q!Underlined Text!,
        'avatar_img'            => q!Avatar Image!,
        'avatar_text'           => q!These are all the avatars currently installed!,
        'avatar_title'          => q!Currently Installed Avatars!,
        'avatar_type'           => q!Avatar Name!,
        'emo_text'              => q!Emoticons are used to express emotions when posting. They are a graphical representation of the classic web "emoticon," such as <b>:-)</b>!,
        'emo_title'             => q!Emoticons!,
        'emo_type'              => q!You Type!,
        'emo_used'              => q!Converted Emoticon!,
        'help_card'             => q!Help Card: !,
        'ibc_text'              => q!iB Code is just like posting HTML. Instead, square brackets are used and certain tags invoke special features.!,
        'ibc_title'             => q!iB Code!,
        'ibc_type'              => q!You Type!,
        'ibc_used'              => q!Converted Text!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
