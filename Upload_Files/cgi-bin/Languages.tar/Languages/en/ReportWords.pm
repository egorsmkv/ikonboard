package ReportWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'email'                 => q!Your email!,
        'ibauto'                => q!Ikonboard Bot!,
        'in_forum'              => q!Reported in forum!,
        'in_topic'              => q!Topic Title!,
        'message'               => q!Your message!,
        'name'                  => q!Your name!,
        'redirect'              => q!Report sent, returning you to the topic you came from!,
        'send'                  => q!Send report now!,
        'subject'               => q!Mailer from Ikonboard: Reporting post!,
        'title'                 => q!Report a post to a moderator!,
        'warn'                  => q!This page is for reporting abusive behaviour (spamming, rude posts, etc.) ONLY.<br>DO NOT use this form just to contact a moderator - these messages will be ignored&#33;!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
