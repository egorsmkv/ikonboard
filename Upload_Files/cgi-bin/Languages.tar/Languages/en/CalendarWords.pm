package CalendarWords;
  
  sub new {
    my $pkg = shift;
    my $obj = {
        'fri'                   => q!Friday!,
        'mon'                   => q!Monday!,
        'next'                  => q!Next Month!,
        'page_title'            => q!Welcome to the Board Calendar!,
        'page_titles'           => q!Board Calendar!,
        'prev'                  => q!Previous Month!,
        'sat'                   => q!Saturday!,
        'show'                  => q!Show!,
        'sun'                   => q!Sunday!,
        'thu'                   => q!Thursday!,
        'tue'                   => q!Tuesday!,
        'wed'                   => q!Wednesday!,
    };
    bless $obj, $pkg;
    return $obj;
 }

 1;
