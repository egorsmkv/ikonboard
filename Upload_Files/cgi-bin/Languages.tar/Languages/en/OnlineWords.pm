package OnlineWords;

sub new {
    my $pkg = shift;
    my $obj = {
        'WHERE_Attach'         => q!Downloading an attachment in:!,
        'WHERE_Calendar'        => q!Viewing the calendar!,
        'WHERE_Forward'         => q!Forwarding a post to a friend in:!,
        'WHERE_Help'            => q!Viewing the help files!,
        'WHERE_Invite'         => q!Inviting a friend to the board!,
        'WHERE_Login'         => q!Logging in/out!,
        'WHERE_Members'         => q!Viewing the member list!,
        'WHERE_Online'         => q!Viewing: who's online!,
        'WHERE_Poll'            => q!Posting a poll in:!,
        'WHERE_Post'            => q!Posting in forum:!,
        'WHERE_Print'         => q!Printing a topic in:!,
        'WHERE_Profile'         => q!Viewing a member's profile!,
        'WHERE_SC'             => q!Viewing category:!,
        'WHERE_SF'             => q!Viewing forum:!,
        'WHERE_SR'             => q!Viewing forum rules:!,
        'WHERE_ST'             => q!Viewing a topic in:!,
        'WHERE_Search'         => q!Searching!,
        'WHERE_Subs'            => q!Subscribing to a topic in:!,
        'board_index'         => q!Viewing board index!,
        'guest'                 => q!Guest!,
        'member_name'         => q!Username!,
        'n_a'                 => q![ N/A ]!,
        'page_title'            => q!Online Users!,
        'pages'                 => q!Pages:!,
        'pm'                    => q!PM!,
        'profile'             => q!Profile!,
        'time'                 => q!Time!,
        'total'                => q!Total Users!,
        'user_ops'             => q!Options!,
        'where'                 => q!Location!,
    };
    bless $obj, $pkg;
    return $obj;
}

1;