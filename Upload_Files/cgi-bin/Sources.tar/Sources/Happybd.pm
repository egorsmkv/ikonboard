package Happybd;
use strict;
use Time::localtime;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
# Happybd: Sends a PM at the members birthday with a message editor.
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
}

my $output      = FUNC::Output->new();
my $mem         = FUNC::Member->new();
my $std         = FUNC::STD->new();
my $txt         = iTextparser->new();
$ModCP::lang    = $std->LoadLanguage('ModCPWords');


sub new {
    my $pkg = shift;
    my $obj = { 'html' => undef, 'MESS' => 0 };
    bless $obj, $pkg;
    return $obj;
}


sub splash {
    my ($obj, $db) = @_;

    $obj->{html} = ModCPView::startcp_set($ModCP::lang->{'birthday_prefs_hed'});
        $obj->_settings_splash($db);
    $obj->{html} .= ModCPView::endcp();
}

sub _settings_splash {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'moderate_no_permission'
               ) unless ($obj->{type} eq 'all');

    my $set  = $db->select( TABLE => 'templates',
                            KEY   => 'birthday',
                           );

    unless ($set) {
        my $new_id = $db->insert(   TABLE  => 'templates',
                                    VALUES => { ID => 'birthday',
                                                TEMPLATE  => 'New',
                                                NAME => '',
                                                },
                                    ) || die $db->{'error'};

        my $set  = $db->select( TABLE => 'templates',
                                KEY   => 'birthday',
                               );

    }
    $set->{'TEMPLATE'}  = $txt->Convert_for_db( TEXT    => $set->{'TEMPLATE'},
                                                SMILIES => 1,
                                                IB_CODE => 1,
                                                HTML    => 0,
                                                );

    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $ModCP::lang->{'welcome_preview'} = $ModCP::lang->{'happybd_preview'};
    $obj->{html} .= ModCPView::preview($set->{'TEMPLATE'});
}

sub edit {
    my ($obj, $db) = @_;
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless ($obj->{type} eq 'all');

    my $set  = $db->select( TABLE => 'templates',
                            KEY   => 'birthday',
                           );
    unless ($set) {
        my $new_id = $db->insert(   TABLE  => 'templates',
                                    VALUES => { ID => 'birthday',
                                                TEMPLATE  => 'New',
                                                NAME => '',
                                                },
                                ) || die $db->{'error'};

        my $set  = $db->select( TABLE => 'templates',
                                KEY   => 'birthday',
                               );

    }
    $ModCP::lang->{'edit_notifi'} = $ModCP::lang->{'edit_birthday'};
    $ModCP::lang->{'edit_tags'} = $ModCP::lang->{'edit_tags_bth'};
    $obj->{html} = ModCPView::startcp_set($ModCP::lang->{'birthday_prefs_hed'});
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::edit_happybd_header($set->{'ID'});
    $obj->{html} .= ModCPView::message_box($set->{'TEMPLATE'});
    $ModCP::lang->{'process_records'} = $ModCP::lang->{'submit'};
    $obj->{html} .= ModCPView::topic_footer();
    $obj->{html} .= ModCPView::endcp();

}


sub do_edit {
    my ($obj, $db) = @_;

        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless ($obj->{type} eq 'all');
    my $edit = $iB::IN{'i'};

    $db->update( TABLE  => 'templates',
                 KEY    => 'birthday',
                 VALUES => {
                 TEMPLATE => $iB::IN{'Post'},
                        },
               ) || die $db->{'error'};
    $output->pure_redirect( URL => "act=Happybd;f=$iB::IN{'f'}");
}

sub sender {
    my ($obj, $data) = @_;

    my $db       = $data->{'DB'};
    my $mem_name = $data->{'MEMBER_NAME'};
    my $mem_id   = $data->{'MEMBER_ID'};
    my $age      = $data->{'AGE'};
    my $date = $std->get_date( TIME => time, METHOD => 'LONG' );
    my $template  = $db->select( TABLE => 'templates',
                                 KEY   => 'birthday',
                                );

    $db->update( TABLE => 'calendar',
                 KEY   => $mem_id,
                 VALUES => { UTIME => time },
                );
# send to new member the welcome PM

    my $message = $template->{'TEMPLATE'};
    $message =~ s!NAMEMEM!$mem_name!g;
    $message =~ s!AGE!$age!g;
    $message =~ s!DATE!$date!g;
    $message  = $txt->Convert_for_db(   TEXT    => $message,
                                        SMILIES => 1,
                                        IB_CODE => 1,
                                        HTML    => 0,
                                    );

    my $new_id = $db->insert(   TABLE  => 'message_data',
                                ID     => $mem_id,
                                VALUES => { DATE              => time,
                                            READ_STATE        => 0,
                                            TITLE             => $ModCP::lang->{'birth_subj'},
                                            MESSAGE           => $message,
                                            MESSAGE_ICON      => 6,
                                            FROM_ID           => '001',
                                            FROM_NAME         => $iB::INFO->{'BOARD_NAME'},
                                            REPLY             => '',
                                            REPLY_DATE        => '',
                                            VIRTUAL_DIR       => 'in',
                                            MEMBER_ID         => $mem_id,
                                            RECIPIENT_ID      => $mem_id,
                                            RECIPIENT_NAME    => $mem_name
                                        }
                             );
    my $msg_stats = { };

    $msg_stats = $db->select( TABLE  => 'message_stats',
                              ID     => $mem_id,
                              KEY    => $mem_id,
                            );

    if ($msg_stats->{'MEMBER_ID'}) {
            $msg_stats->{'TOTAL_MESSAGES'}++;
            $msg_stats->{'NEW_MESSAGES'}++;

            $db->update(  TABLE  => 'message_stats',
                          ID     => $mem_id,
                          KEY    => $mem_id,
                          VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'},
                                      NEW_MESSAGES   => $msg_stats->{'NEW_MESSAGES'},
                                      LAST_FROM_NAME => $iB::INFO->{'BOARD_NAME'},
                                      LAST_FROM_ID   => '001',
                                      LAST_SENT      => time,
                                      LAST_MSG_ID    => $new_id,
                                      LAST_MSG_TITLE => $ModCP::lang->{'birth_subj'},
                                      SHOW_POPUP     => 1,
                                    }
                       );

        } else {
            $db->insert(  TABLE  => 'message_stats',
                          ID     =>  $mem_id,
                          VALUES => { MEMBER_ID         => $mem_id,
                                      LAST_READ         => '',
                                      NEW_MESSAGES      => 1,
                                      LAST_FROM_NAME    => $iB::INFO->{'BOARD_NAME'},
                                      LAST_FROM_ID      => '001',
                                      LAST_MSG_ID       => $new_id,
                                      LAST_MSG_TITLE    => $ModCP::lang->{'birth_subj'},
                                      LAST_SENT         => time,
                                      TOTAL_MESSAGES    => 1,
                                      VIRTUAL_DIR       => "in:Inbox|sent:Sent Items|",
                                      SHOW_POPUP        => 1,
                                }
                            );
        }
}# close sub


sub Process {
    my ($obj, $db) = @_;

    require "$iB::SKIN->{'DIR'}" . '/ModCPView.pm';
    $obj->SetSession($db);
    my $CodeNo = $iB::IN{'CODE'};

    my %Mode = (
                    'edit'    => \&edit,
                    'do_edit' => \&do_edit,
                    'sender'  => \&sender,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : splash($obj, $db);

    unless ($obj->{bypass}) {
        $output->print_ikonboard( DB           => $db,
                                  STD          => $std,
                                  OUTPUT       => $obj->{html},
                                  NAV          => [ qq!<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP'>$ModCP::lang->{'home'}</a>! ],
                                  TITLE        => "iB::" . "$ModCP::lang->{'title'}"
                                );
    }

}

sub SetSession {
    my ($obj, $db) = @_;

    # As our Russian friends might say to non members trying
    # to gain access to our moderators CP: Pisky Ofsky.
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'moderate_no_permission'
               ) unless $iB::MEMBER->{'MEMBER_ID'};

    # Set the default moderator type to none
    $obj->{type} = 'n';

    if ($iB::MEMBER->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}) {
        $obj->{type} = 'all';
        return;
    }

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'moderate_no_permission'
               ) if $obj->{type} eq 'n';
}

1;

