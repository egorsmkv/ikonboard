package Warn;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Warn: Member warning functions
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
}
require $iB::SKIN->{'DIR'} . '/WarnView.pm' or die $!;

my $mail       = FUNC::Mailer->new();
my $std        = FUNC::STD->new();
my $mem        = FUNC::Member->new();
my $output     = FUNC::Output->new();
$Warn::lang    = $std->LoadLanguage('WarnWords');
my $txt        = iTextparser->new();

sub new {
    my $pkg = shift;
    my $obj = { '.can_warn' => 0 };
    bless $obj, $pkg;
    return $obj;
}

sub WarnForm {
    my ($obj, $db) = @_;

    return unless defined $iB::IN{'MID'};

    $obj->{'MEMBER'} = $mem->LoadMember(DB => $db, KEY => $iB::IN{'MID'}, METHOD => 'by id');

    my $print .= WarnView::Header($obj);

    $print .= WarnView::Body();

    $print .= WarnView::Footer();

    $output->print_ikonboard( DB => $db, STD => $std, OUTPUT  => $print, TITLE => $iB::INFO->{'BOARDNAME'}, NAV => [ $Warn::lang->{'title'} ]);

}

sub do_warn {
    my ($obj, $db) = @_;

    return unless defined $iB::IN{'MID'};

    $obj->{'MEMBER'} = $mem->LoadMember(DB => $db, KEY => $iB::IN{'MID'}, METHOD => 'by id');
    my $upLevel = $iB::IN{'inc'};

    if ($upLevel eq 'on') {
        $obj->{'MEMBER'}->{'WARN_LEVEL'} < 5 ? $obj->{'MEMBER'}->{'WARN_LEVEL'}++ : '';
    }
    if ($obj->{'MEMBER'}->{'WARN_LEVEL'}  == 5) {
        $obj->{'MEMBER'}->{'ALLOW_POST'} = 0;
    }
    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { WARN_LEVEL   => $obj->{'MEMBER'}->{'WARN_LEVEL'},
                               ALLOW_POST   => $obj->{'MEMBER'}->{'ALLOW_POST'}
                             }
               );

    $db->insert(  TABLE  => 'moderator_logs',
                  VALUES => { FORUM_ID     => $iB::IN{'f'},
                              TOPIC_ID     => $iB::IN{'t'},
                              POST_ID      => $iB::IN{'p'},
                              MEMBER_ID    => $iB::MEMBER->{'MEMBER_ID'},
                              MEMBER_NAME  => $iB::MEMBER->{'MEMBER_NAME'},
                              REMOTE_ADDR  => $iB::IN{'IP_ADDRESS'},
                              HTTP_REFERER => $ENV{'HTTP_REFERER'},
                              TIME         => time,
                              TOPIC_TITLE  => undef,
                              ACTION       => "Warned $obj->{'MEMBER'}->{'MEMBER_NAME'}",
                              QUERY_STRING => $ENV{'QUERY_STRING'},
                            },
               );



    my $pm_msg = ($upLevel eq 'on') ? $Warn::lang->{'msg_up'} : $Warn::lang->{'msg_std'};
    $pm_msg =~ s!<#POST#>!\[url\]$iB::INFO->{'BOARD_URL'}/ikonboard\.$iB::INFO->{'CGI_EXT'}?act=ST;f=$iB::IN{'f'};t=$iB::IN{'t'}#entry$iB::IN{p}\[/url\]!ig;
    $pm_msg .= ' ' . $txt->Convert_for_db( TEXT    => ('[br][br]'.$iB::IN{'Message'}),
                                           SMILIES => 1,
                                           IB_CODE => 1,
                                           HTML    => 0
                                         );

    my $show_popup = (split/&/, $obj->{'MEMBER'}->{'PM_REMINDER'})[1];

    my $new_id = $db->insert( TABLE  => 'message_data',
                              ID     => $obj->{'MEMBER'}->{'MEMBER_ID'},
                              VALUES => { DATE              => time,
                                          READ_STATE        => 0,
                                          TITLE             => $Warn::lang->{subject},
                                          MESSAGE           => $pm_msg,
                                          MESSAGE_ICON      => 10,
                                          FROM_ID           => '001',
                                          FROM_NAME         => $iB::INFO->{'BOARD_NAME'},
                                          REPLY             => '',
                                          REPLY_DATE        => '',
                                          VIRTUAL_DIR       => 'in',
                                          MEMBER_ID         => $obj->{'MEMBER'}->{'MEMBER_ID'},
                                          RECIPIENT_ID      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                                          RECIPIENT_NAME    => $obj->{'MEMBER'}->{'MEMBER_NAME'}
                                        }
                             );

    my $msg_stats = { };

    $msg_stats = $db->select( TABLE  => 'message_stats',
                              ID     => $obj->{'MEMBER'}->{'MEMBER_ID'},
                              KEY    => $obj->{'MEMBER'}->{'MEMBER_ID'},
                            );

    if ($msg_stats->{'MEMBER_ID'}) {
        $msg_stats->{'TOTAL_MESSAGES'}++;
        $msg_stats->{'NEW_MESSAGES'}++;

        $db->update(  TABLE  => 'message_stats',
                      ID     => $obj->{'MEMBER'}->{'MEMBER_ID'},
                      KEY    => $obj->{'MEMBER'}->{'MEMBER_ID'},
                      VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'},
                                  NEW_MESSAGES   => $msg_stats->{'NEW_MESSAGES'},
                                  LAST_FROM_NAME => $iB::INFO->{'BOARD_NAME'},
                                  LAST_FROM_ID   => '001',
                                  LAST_SENT      => time,
                                  LAST_MSG_ID    => $new_id,
                                  LAST_MSG_TITLE => $Warn::lang->{subject},
                                  SHOW_POPUP     => $show_popup,
                                }
                   );
    } else {
        $db->insert(  TABLE  => 'message_stats',
                      ID     =>  $obj->{'MEMBER'}->{'MEMBER_ID'},
                      VALUES => { MEMBER_ID          => $obj->{'MEMBER'}->{'MEMBER_ID'},
                                  LAST_READ          => '',
                                  NEW_MESSAGES       => 1,
                                  LAST_FROM_NAME     => $iB::INFO->{'BOARD_NAME'},
                                  LAST_FROM_ID       => '001',
                                  LAST_MSG_ID        => $new_id,
                                  LAST_MSG_TITLE     => $Warn::lang->{subject},
                                  LAST_SENT          => time,
                                  TOTAL_MESSAGES     => 1,
                                  VIRTUAL_DIR        => "in:Inbox|sent:Sent Items|",
                                  SHOW_POPUP         => $show_popup,
                                 }
                    );
    }
    $output->redirect_screen( TEXT => $Warn::lang->{'redirect'}, URL => "act=ST;f=$iB::IN{'f'};t=$iB::IN{'t'}#entry$iB::IN{p}");
}


sub Process {
    my ($obj, $db) = @_;
    
    unless( (!$iB::MEMBER->{'MEMBER_ID'}) or ($iB::MEMBER_GROUP->{'IS_SUPMOD'}) ) {
        $obj->{'moderator'} = { };

        $obj->{'moderator'} = $db->query( TABLE      => 'forum_moderators',
                                          MATCH      => 'ONE',
                                          WHERE      => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!
                                        );
    }

    $std->Error( DB      => $db,
                 LEVEL   => '5',
                 MESSAGE => 'cant_use_feature') unless ($iB::MEMBER->{'MEMBER_ID'} and ($iB::MEMBER_GROUP->{'IS_SUPMOD'} or $obj->{'moderator'}->{'ALLOW_WARN'}));
    
    my $CodeNo = $iB::IN{'CODE'};


    my %Mode = ( '00'       => \&WarnForm,
                 '01'       => \&do_warn,
                 ''         => \&WarnForm,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj,$db) : FatalError();
}

sub FatalError { die "I'm working on it!" }

1;
__END__
