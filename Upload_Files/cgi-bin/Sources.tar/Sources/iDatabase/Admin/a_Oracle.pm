package iDatabase::Admin::SQL;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# a_Oracle: Oracle administrative functions
#
#################################################################################

use vars qw/$SQL @ISA/;

require iDatabase::Admin::a_base;
@ISA = qw(iDatabase::Admin::a_base);

BEGIN { 
        if (eval "require DBI") {
            $SQL->{DBI} = 'Yes';
            require DBI;
        }
        use CGI::Carp "fatalsToBrowser";
 }


#-----------------------------------------------
# Our constructor
#-----------------------------------------------

sub new {
    my $pkg = shift;
    my $obj = { '_output' => undef, errors => [], success => 0 };
    bless $obj, $pkg;
    return $obj;
}

#-----------------------------------------------
# Check and create tables.
# 
# 'success'  => 1 or 0
# 'errors'   => [ @errors ]  An array of errors
#-----------------------------------------------


sub install_database {

    # Stop Ikonboard from forcing a die
    
    local $@;
    local $SIG{__DIE__};


    my $obj = shift;
    my $IN  = { 'schema_dir' => "",   # Path to the directory containing the table schema
                'return_err' => "",                          # Boolean, return errors?
                'create_tbl' => "",                          # Boolean, create tables?
                'attr'       => {},                          # DB attributes, such as DB_USER, etc
                @_,
              };

    my $errors  = 0;
    my $found   = 0;
    my @fatal_errors;
    my ($have_dbi, $have_dbd, $can_connect, $found_db);

    # Test for the DBI library

    if ($SQL->{DBI} ne 'Yes') {
        ++$errors;
        push @{ $obj->{errors} }, "You must install the DBI suite of modules. Visit <a href='http://www.cpan.org' target='_blank'>CPAN</a> for more information.";
        goto 'ERRORS';
    }
    


    # Test for Oracle DBI::Driver
    $found = 0;
    my @drivers = DBI->available_drivers;

    foreach(@drivers){ # coolest
        if(/Oracle/){
            $found = 1;
            last;
        }
    }
    unless ($found) {
        ++$errors;
        push @{ $obj->{errors} }, "You must install the Oracle DBD driver.";

    }
    
    # Test for connection
    $found = 0;
    my $dsn  = "DBI:Oracle:$IN->{attr}->{'DB_NAME'}";
    my $dbh = DBI->connect($dsn, $IN->{attr}->{'DB_USER'}, $IN->{attr}->{'DB_PASS'});
  
   if ($DBI::errstr) {
       ++$errors;
       push @{ $obj->{errors} }, 
       goto 'ERRORS';
   } 

    # Grab the create_tables.txt file and set about
    # creating our tables.

    my @SQLS;

    if ($IN->{create_tbl}) {
        local $/ = undef;
        open (ORACLE, "$IN->{schema_dir}/oracle_schema.txt") || ( push @{ $obj->{errors} }, "Cannot open the table schema!" and return );        
  
        @SQLS = split /\;/, <ORACLE>;
        close (ORACLE);

        for my $sSQL (@SQLS) {
          next if $sSQL =~ /^\s+$/;
          if ($IN->{attr}->{'DB_PREFIX'} ne "ib_") {
            $sSQL =~ s/CREATE TABLE ib_(\w+) \(/CREATE TABLE $IN->{attr}->{'DB_PREFIX'}$1 (/ig;
          }

          my $sth=$dbh->do($sSQL); # or die "Oracle create table error. $DBI::errstr ($sSQL)";

          # we're ignoring ORA-00942 error which means 'table doesn't exists'

          if ($DBI::errstr & $DBI::err !=942) {
            ++$errors;
            push @{ $obj->{errors} }, "Oracle create table error. $DBI::errstr ($sSQL)";
          }
        }

    }

    $dbh->disconnect();  

    $obj->{success}++;


ERRORS:


    return;

    
}







1;
