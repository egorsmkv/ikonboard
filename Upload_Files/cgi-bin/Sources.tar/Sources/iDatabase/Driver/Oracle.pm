package iDatabase::Driver::Oracle;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# Oracle: A driver class for Oracle
# -> Written by Andrey Propopenko
#
#################################################################################

# Use the DBI suite of modules.
use DBI;
use vars qw(@ISA $VERSION $CONN $TYPE $error);
#Inherit from the base class
require iDatabase::Driver::Base;
@ISA = qw(iDatabase::Driver::Base);

# Set the type
$TYPE = 'Oracle';

$VERSION = 1.1;

#--------------------------------------
#
# Create a DB connection
#
#--------------------------------------

sub newSQL {
    my ($pkg, $args)  = @_;
    my $rPkg = ref $pkg || $pkg;
    
    my $obj = { 'error'    => '',
                'query'    => '',
                'query_c'  => 0,
                'PREFIX'   => $args->{'DB_PREFIX'},
                'base_dir' => $args->{'DB_DIR'}
              };

    # Create the Oracle class.
    bless $obj, $rPkg;
    
    # Connect, if we don't already have a live connection or
    # DB Handle
    $CONN = $obj->connect($args);
    $obj->{DB} = $CONN;

    # Return an error if something is wrong.
    unless ($CONN) {
        die ("Can't connect to $TYPE database. $DBI::errstr $!");
    }
    
    # Set a flag to indicate a current Oracle connection
    
    $obj->{dsn} = $TYPE;
    
    # Set the permissions for creating / dropping tables
    $obj->{_can_drop}   = $args->{ATTR}->{allow_drop}   || 0;
    $obj->{_can_create} = $args->{ATTR}->{allow_create} || 0;
    
    return $obj;
}


#--------------------------------------
#
# Override the base method, and connect
#
#--------------------------------------

sub connect {
    my ($obj, $args) = @_; 
#    my $dsn  = "DBI:Oracle:$args->{'DATABASE'}";
    my $dsn = "DBI:Oracle:(description=(address=(host=$args->{'IP'})(protocol=tcp)(port=1521))(connect_data=(sid=$args->{'DATABASE'})))";
       $dsn = "DBI:Oracle:(description=(address=(host=$args->{'IP'})(protocol=tcp)(port=$args->{'PORT'}))(connect_data=(sid=$args->{'DATABASE'})))" if $args->{'PORT'};
    my $connection ||= DBI->connect($dsn, $args->{'USERNAME'}, $args->{'PASSWORD'}, 
    { LongReadLen => 128000, LongTruncOk => 1} ) or die "$args->{'DATABASE'}<br>Connection error: $DBI::errstr;\n ";
    return $connection;
}

#----------------------------------------------------------------
#
# Override the base method, disconnect
#
#----------------------------------------------------------------

sub disconnect {
    #Kill the connection from the DBI
    $CONN->disconnect() if ($CONN);
    undef $CONN;
    return "connection ended";
}


sub END {
    &disconnect();
}
sub DESTROY {
    &disconnect();
}


#---------------------------------------------------------
# Parse where statememnt
#---------------------------------------------------------
# Allows you to fine tune your where statement for your
# driver. Default behaviour suits mySQL.

sub parse_where {
my $tmp_where = shift;
    my %ops = ( 'eq' => '=',
                'ne' => '<>',
                '==' => '=',
                '!=' => '<>',
                '=~' => 'LIKE ',
                '!~' => 'NOT LIKE'
              );
    my %bln = ( 'and' => 'AND',
                'or'  => 'OR',
                '&&'  => 'AND'
              );

my @where_values;
my $new_where;
my $tmp_val;

$tmp_where =~ s#\s{1,}(eq|ne|==|!=|=~)\s{1,}# $ops{$1} #ig;
$tmp_where =~ s#\s+(and|or|&&)\s+# $bln{"\L$1\E"} #ig;
#$tmp_where =~ s#\s{1,}(and|or|&&)\s{1,}# $bln{$1} #ig;

while ( $tmp_where =~ m/(((and|or|&&)\s{1,})?(\s|[()])*\s*\w{1,}\s{1,}(=|>|<>|<|like|not like)\s{1,})((\w|'|"|-|%|\/){1,})(\s*[()]*)/ig) {

# $new_where .= $1.'?'.$4;
# $tmp_val = $3;
 $new_where .= ' '.$1.'?'.$8;
 $tmp_val = $6;
 $tmp_val =~ s#^('|"|/)(.+)\1$#$2#;
# $tmp_val =~ s#^('|"|/)(.+)\1$#$2#;
 push @where_values, $tmp_val;
 
}

$new_where = ' '. $new_where;
$new_where =~ s/(\W+)(_WHERE|VIEW|DATE|LANGUAGE|TIME)(\s*(=|<>|<|>|LIKE|NOT LIKE)\s*.+)/$1\"$2\"$3/g; 

return $new_where,@where_values;
}

#----------------------------------------------------------------
# parse_raw: Fire a query straight into Oracle, returning the $sth
#----------------------------------------------------------------

sub parse_raw {
    my ($obj, $db_query) = @_;
    $obj->{'error'} = undef;
    
    my $DB = $CONN;
    
    my $sth = $DB->prepare($db_query) || ($obj->{'error'} = "Can't query the data: $DBI::errstr Statement:$db_query" and return);;
    $sth->execute() || ($obj->{'error'} = "Can't query the data: $DBI::errstr" and return);
    ++$obj->{query_c};
    # simply return the $sth for use in get_row
    return $sth;
}

#-------------------------------------------------------------------------------------------
# convert_field_name: Adds double quotes around field name in case reserved words are used 
#-------------------------------------------------------------------------------------------

sub convert_field_name {
 my $field = @_;
 $field =~ s/(_WHERE|VIEW|DATE|LANGUAGE|TIME)/\"$1\"/g;  
 return $field;
}

#----------------------------------------------------------------
# get_row: get a hashref based on $sth
#----------------------------------------------------------------

sub get_row {
    my ($obj, $sth) = @_;
    
    unless ($sth) {
        $obj->{error} = "\$sth contains no value!";
        return undef;
    }
    #otherwise..
    return $sth->fetchrow_hashref();
}

#----------------------------------------------------------------
# done: Tidy up and close the $sth
#----------------------------------------------------------------

sub done {
    my ($obj, $sth) = @_;
    
    unless ($sth) {
        $obj->{error} = "\$sth contains no value!";
        return undef;
    }
    
    #otherwise..
    $sth->finish();
    undef $sth;
    return 1;
}

#----------------------------------------------------------------
# select, overrides base class method
#----------------------------------------------------------------

sub select  {
    my $obj = shift;
    my ($data, $found);
    #$obj->{'error'} = undef;
    my $IN = {  
                "TABLE"   => "",
                "COLUMNS" => [],
                "KEY"     => "",
                "DBID"    => "", # DEPRECIATED IN SQL
                "ID"      => "", # DEPRECIATED IN SQL
                @_
              };

    $obj->load_cfg($IN->{'TABLE'});
    my @where_values;
    my $DB = $CONN;
    my $db_query = "SELECT";

    if (scalar @{$IN->{'COLUMNS'}} > 0) {
        $db_query .= ' ' . join(', ',@{$IN->{'COLUMNS'}});
        $db_query =~ s/(\W+)(_WHERE|VIEW|DATE|LANGUAGE|TIME)(\W*)/$1\"$2\"$3/g;
    } else {
        $db_query .= ' *';
    }   
    my $key_temp = $obj->{'cur_p_key'};
    $key_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g;
    $db_query .=' FROM '.$obj->{'PREFIX'}.$IN->{'TABLE'}.' WHERE '.$key_temp.' = ?';
    push @where_values,$IN->{'KEY'};
    my $sth = $DB->prepare($db_query) or die 'DBI Error:'. $DBI::errstr . '\n Statement:' . $db_query;
    $sth->execute(@where_values) || ($obj->{'error'} = "Can't query the data from \"$IN->{'TABLE'}\". $DBI::errstr" and return);
    my $return = {};
    # No need to use the make_hash_ref
    $return    = $sth->fetchrow_hashref();
    ++$obj->{query_c};
    return $return;
}


#----------------------------------------------------------------
# query, overrides base class method
#----------------------------------------------------------------

sub query  {
    my $obj = shift;
       $obj->{'error'}     = undef;
       $obj->{'query'}     = undef;
       $obj->{'cur_p_key'} = undef;
       
    my $IN = {  
                "TABLE"     => "",
                "COLUMNS"   => [],
                "SORT_KEY"  => "",
                "SORT_BY"   => "",
                "WHERE"     => "",
                "MATCH"     => "",
                "RANGE"     => "",
                "DBID"      => "", # DEPRECIATED IN SQL
                "ID"        => "", # DEPRECIATED IN SQL
                "COUNT"     => "",
                "INDEX"     => "",
                @_,
              };

    $obj->load_cfg($IN->{'TABLE'});

    my $DB = $CONN;
    my $statement;
    my $db_query = "SELECT";
    my $columns;
    my ($new_where, @where_values);

    if (scalar @{$IN->{'COLUMNS'}} > 0) { 

     $columns = ' ' . join(', ',@{$IN->{'COLUMNS'}});     
     $columns =~ s/(\W+)(_WHERE|VIEW|DATE|LANGUAGE|TIME)(\W*)/$1\"$2\"$3/g;

    }
    else { $columns = ' *'; }


    $db_query .= $columns . ' FROM '.$obj->{'PREFIX'}.$IN->{'TABLE'};

    if ($IN->{'INDEX'}) {
        my $ind_temp = $IN->{'INDEX'}->{'KEY'};
        $ind_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g;  
        $db_query .= ' WHERE '.$ind_temp.' = ?';
        push @where_values,$IN->{'INDEX'}->{'VALUE'};
        my $sth = $DB->prepare($db_query) or die 'DBI Error:'. $DBI::errstr . '\n Statement:' . $db_query;
        $sth->execute(@where_values) || ($obj->{'error'} = "Can't query the data from \"$IN->{'TABLE'}\". Query:'$db_query'. $DBI::errstr" and return);
        my $return = {};
        $return = $sth->fetchrow_hashref();
        ++$obj->{query_c};
        return $return || {};       
    }
    
    if ($IN->{'WHERE'}) {
        $db_query .= ' WHERE ';       

        ($new_where, @where_values) = parse_where($IN->{'WHERE'});

        $IN->{'WHERE'} = $new_where;

        $db_query .= $IN->{'WHERE'};

        $obj->{query} = $IN->{'WHERE'};
    } else {
        $obj->{query} =  $obj->{'cur_p_key'}." <> '0'";
    }
    $obj->{_query} = $obj->{query};
    
    if ($IN->{'MATCH'} eq 'WITH COUNT') {
        my $count_query = 'SELECT COUNT(*) FROM '.$obj->{'PREFIX'}.$IN->{'TABLE'}.' WHERE '.$obj->{'query'};

        my $sub = $DB->prepare($count_query) or die ' Count DBI Error:'. $DBI::errstr . "\n Statement:<br>$count_query";
        $sub->execute(@where_values) || die "Can't count data from '$obj->{'PREFIX'}$IN->{'DBID'}$IN->{'TABLE'}' table. $DBI::errstr using query: $obj->{'query'}";
        $obj->{matched_records} = $sub->fetchrow_array();
    }
 
    if ($IN->{'SORT_KEY'}) {
     my $temp_order = " ORDER BY $IN->{'SORT_KEY'} ";
     $temp_order =~ s/(\W+)(_WHERE|VIEW|DATE|LANGUAGE|TIME)(\W+)/$1\"$2\"$3/g;
     $db_query .= $temp_order;
    }
    

    if ($IN->{'SORT_BY'} eq "Z-A")    {  $db_query .= " DESC"; }
    elsif ($IN->{'SORT_BY'} eq "A-Z") {  $db_query .= " ASC";  }


    # �᫨ ��� �㦭� ��࠭���� ���-�� ��ப � �롮થ, �����稬 ���� ����� � ᪮��� � �ਬ���� 2 ��������
    #$db_query .= $obj->parse_limit($IN->{'RANGE'}) ;    

    if ($IN->{'RANGE'}) {
     my ($from, $to) = split " to ", $IN->{'RANGE'};
     if (($from =~/\s*\d+\s*/) && ($to =~ /\s*\d+\s*/)) {
      $db_query = "SELECT $columns FROM (SELECT n.*,rownum oracle_row_num from ( $db_query ) n where rownum <= ?) where oracle_row_num >= ?";
      push @where_values,$to;
      push @where_values,$from;
     }    
    }

    my $sth = $DB->prepare($db_query) or die 'DBI Error:'. $DBI::errstr . '<br> Statement:<br>' . $db_query ;
    $sth->execute(@where_values) || die "Can't query the data from '$IN->{'TABLE'}'\nReason: $DBI::errstr\n Query: $db_query";
    
    if ($IN->{'MATCH'} eq 'ONE') {
        # Simple query and return the data..
        ++$obj->{query_c};
        my $row = $sth->fetchrow_hashref();
        $sth->finish;
        return $row;
    }

    # If we have multiple records to return, instead of stuffing them
    # all into one huge array and returning, lets do something more
    # elegant, this is also useful for DB's without the LIMIT clause
    # as we'll get a chance to skip and stop saving when we've fulfilled
    # our own limit implementation
    
    ++$obj->{query_c};
    my $i = 0;
    
    # Bug with perl v 5.004?
    #tie my @return, "iDatabase::Driver::mySQL::Bind", $obj;
    my @return;
    while( my $row = $sth->fetchrow_hashref() ) {
        #$return[ $i ] = $row; ++$i;
        push @return, $row;
    }
    $sth->finish;
    return wantarray ? @return : \@return;
}



#----------------------------------------------------------------
# insert, overrides base class method
#----------------------------------------------------------------


sub insert {
    my $obj = shift;
       $obj->{'error'} = undef;
    
    # some strange precidence error, hackish fix for
    #now:
    
    local $^W = undef;
       
       
    my $IN = {  
                "TABLE"    => "",
                "VALUES"   => {},
                "DBID"     => "", # DEPRECIATED IN SQL
                "ID"       => "", # DEPRECIATED IN SQL
                @_
              };  

    $obj->load_cfg($IN->{'TABLE'});

    my $DB = $CONN;

    my $table = $obj->{'PREFIX'}.$IN->{'TABLE'};

    my (@fields, @values, $bind_val);

    for my $k (keys %{ $IN->{'VALUES'} }) {
        next unless exists $obj->{'all_cols'}->{$k};
        my $k_temp = $k;
        $k_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g; 
        push @fields, $k_temp;
        push @values, $IN->{'VALUES'}->{$k};

        $bind_val .= '?, ';
    }

    #This is slightly contrived... Must fix later.
    #I know there is an 'auto_increment' protocol on mySQL
    #But we need to return the new ID, so we'd have to query
    #twice anyway..

    if ($obj->{'all_cols'}->{$obj->{'cur_p_key'}}[1] eq 'update') {
        my $q = 'SELECT MAX('.$obj->{'cur_p_key'}.') FROM '.$table;

        my $sth = $DB->prepare($q) or die 'DBI Error:'. $DBI::errstr . '\n Statement:' . $q;
        $sth->execute() || ($obj->{'error'} = "Can't insert data into '$table' table. Query: $q. $DBI::errstr" and return);
        my $new_id = $sth->fetch();
        push @fields, $obj->{'cur_p_key'};
        push @values, $new_id->[0]+1;
        $bind_val .= '?, ';
        $IN->{'VALUES'}->{ $obj->{'cur_p_key'} } = $new_id->[0]+1;
    }
   
    $bind_val =~ s/\, $//; #removing last ',' symbol

    my $db_query = "INSERT INTO $table (" . join(", ", @fields) . ") VALUES (". $bind_val .")";
 
    my $stmt = $DB->prepare($db_query) or die "Prepare statement DBI Error: $DBI::errstr <br> Statement:<br> $db_query";

    $stmt->execute(@values) or die "exec statement DBI Error: $DBI::errstr <br> Statement:<br> $db_query";
    $stmt->finish();

    # Return the new ID (Incase we need it)
    ++$obj->{query_c};
    $obj->{query} = $db_query;
    return $IN->{'VALUES'}->{ $obj->{'cur_p_key'} };
 
}



#----------------------------------------------------------------
# delete, overrides base class method
#----------------------------------------------------------------
sub delete  {
    my $obj = shift;
       $obj->{'error'} = undef;
    my $IN = {  
                "TABLE"   => "",
                "KEY"     => "",
                "DBID"    => "", #DEPRECIATED IN SQL
                "ID"      => "", #DEPRECIATED IN SQL
                "WHERE"   => "",
                @_
              };
    my @where_values;

    $obj->load_cfg($IN->{'TABLE'});

    my $DB = $CONN;

    my $table = $obj->{'PREFIX'}.$IN->{'TABLE'};

    my $statement;

    if ($IN->{'WHERE'} ne '') {

        ($statement, @where_values) = parse_where($IN->{'WHERE'});

    } else {
        if (ref($IN->{'KEY'}) ne 'ARRAY') {
            #$statement = $obj->{'cur_p_key'}.'='.$DB->quote($IN->{'KEY'});
                        my $k_temp = $obj->{'cur_p_key'};
                        $k_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g;  
                        $statement = $k_temp.' = ?';
                        push @where_values,$IN->{'KEY'};
        } else {
                        my @keys;
            for (@{$IN->{'KEY'}}) {
                          my $k_temp = $obj->{'cur_p_key'};
                          $k_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g;  
                          $statement .= $k_temp.' = ? OR ';
                          push @where_values,$_;
                        }
                        # Remove last ' OR '
                        $statement =~ s!\s{1,}OR\s*$!!;
               }
        
      }

    my $db_query = "DELETE FROM $table WHERE $statement";

    # ������稢��� ����� �⮫�殢 � ��१�ࢨ஢���묨 �������
    #$db_query =~ s/(\W{1,})(_WHERE|VIEW|DATE|LANGUAGE|TIME)(\W{1,})/$1\"$2\"$3/g;

    $obj->{query} = $db_query;


    my $del_stmt = $DB->prepare($db_query) || ($obj->{'error'} = "Can't delete data from '$table' table. Statement: '$db_query'. $DBI::errstr" and return);
    $del_stmt->execute(@where_values) || ($obj->{'error'} = "Can't delete data from '$table' table. Statement: '$db_query'. $DBI::errstr" and return);
    $del_stmt->finish();
    #$DB->do($db_query) or die 'DBI Error:'. $DBI::errstr . '\n Statement:' . $db_query; 
    ++$obj->{query_c};
    return 1;
}

#----------------------------------------------------------------
# update, overrides base class method
#----------------------------------------------------------------
sub update  {
    my $obj = shift;
       $obj->{'error'} = undef;
    my $IN = {  
                "TABLE"   => "",
                "VALUES"  => "",
                "KEY"     => "",
                "WHERE"   => "",
                "DBID"    => "", #DEPRECIATED IN SQL
                "ID"      => "", #DEPRECIATED IN SQL
                @_
              };

    my @where_values;

    $obj->load_cfg($IN->{'TABLE'});

    my $DB = $CONN;

    my $table = $obj->{'PREFIX'}.$IN->{'TABLE'};

    my (@fields, $statement, @values);
    my $k_temp;
    for my $k (keys %{ $IN->{'VALUES'} }) {
        next unless exists $obj->{'all_cols'}->{$k};

        # ������稢��� �㦭� ��� ����
        my $k_temp = $k;
        $k_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g; 
#        push @fields, $k_temp.' = '. $DB->quote($IN->{'VALUES'}->{$k});
        push @fields, $k_temp.' = ?';
        push @values, $IN->{'VALUES'}->{$k};
    }
       
    if ($IN->{'WHERE'} ne '') {

        ($statement, @where_values) = parse_where($IN->{'WHERE'});
        for my $tmp_val (@where_values) { push @values,$tmp_val; }

    } else {
        if (ref($IN->{'KEY'}) ne 'ARRAY') {
            #$statement = $obj->{'cur_p_key'}.'='.$DB->quote($IN->{'KEY'});
                        my $k_temp = $obj->{'cur_p_key'};
                        $k_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g;  
                        $statement = $k_temp.' = ?';
                        push @values,$IN->{'KEY'};
        } else {
                        my @keys;
            for (@{$IN->{'KEY'}}) {
                          my $k_temp = $obj->{'cur_p_key'};
                          $k_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g;  
                          $statement .= $k_temp.' = ? OR ';
                          push @values,$_;
                        }
                        # Remove last ' OR '
                        $statement =~ s!\s{1,}OR\s*$!!;
               }

        
    }    

    my $db_query = "UPDATE $table SET ".join(", ", @fields)." WHERE $statement";
    #$DB->do($db_query) || ($obj->{'error'} = "Can't update data to '$table' table. Statement: '$db_query'. $DBI::errstr" and return);
    my $stmt = $DB->prepare($db_query) or die "Error:$DBI::errstr. Can't prepare update statement for '$table' table. Statement: ($db_query)\n ";
    $stmt->execute(@values) or die "Error:$DBI::errstr. Can't update data to '$table' table. Statement: ($db_query)\n ";
    $stmt->finish();
    ++$obj->{query_c};
}


#----------------------------------------------------------------
# count, overrides base class method
#----------------------------------------------------------------

sub count {
    my $obj = shift;
    my ($new_where, @where_values);
    my $IN = {  
                "TABLE"    => "",
                "DBID"     => "",
                "ID"       => "",
                "WHERE"    => "",
                @_,
              };

    $obj->load_cfg($IN->{'TABLE'});
    
    my $DB = $CONN;
    my $count = 0;
    ++$obj->{query_c};
    my $db_query = 'SELECT COUNT(*) FROM '.$obj->{'PREFIX'}.$IN->{'TABLE'};
    
    if ($IN->{'WHERE'}) {
        $db_query .= ' WHERE ';
        ($new_where, @where_values) = parse_where($IN->{'WHERE'});

        $IN->{'WHERE'} = $new_where;

        $db_query .= $IN->{'WHERE'};
        $obj->{query} = $IN->{'WHERE'};
    }
    
    my $sth = $DB->prepare($db_query) or die 'DBI Error:'. $DBI::errstr . '\n Statement:' . $db_query;
    $sth->execute(@where_values) || ($obj->{'error'} = "Can't count data from '$obj->{'PREFIX'}$IN->{'DBID'}$IN->{'TABLE'}' table. Statement: '$db_query'. $DBI::errstr" and return);
    my $return = $sth->fetchrow_array();
    $sth->finish();    
    return $return;
}


#----------------------------------------------------------------
# table import, overrides base class method
#----------------------------------------------------------------

sub table_import {
    my $obj = shift;

    my $DB = $CONN;
    
    my $IN = {  
                "TABLE"   => "",
                "SOURCE"  => "",
                "DBID"    => "",
                "ID"      => "",
                @_
             };
    $obj->load_cfg($IN->{'TABLE'});

    # Ok, we A.S.S.U.ME that these files may be potentially large.
    # So, the first step is to identify which entries we're going to need.
    # Then, copy these entries into a text file to work with.
    # If we are not fussed on ID's and DBIDs, then we just suck it all up.
    
    # Open up the source file..
    open SOURCE, "$IN->{'SOURCE'}/$IN->{'TABLE'}.txt" or die "Cannot find $IN->{'SOURCE'}/$IN->{'TABLE'}.txt to open";
    
    # Open up the temp file...
    open TEMP, ">$IN->{'SOURCE'}/$IN->{'TABLE'}.tmp" or die "Cannot create $IN->{'SOURCE'}/$IN->{'TABLE'}.tmp";

    # Start the loop..
    while (<SOURCE>) {
        if ($IN->{DBID}) {
            next unless m#^$IN->{'DBID'}-#;
        }
        if ($IN->{ID}) {
            next unless m#^(.+?)-$IN->{ID}\|\*\|#;
        }
        #chomp;
        /^(.+?)\|\*\|(.*)$/;
        my $data = $2;
        print TEMP $data."\n";
    }
    close SOURCE;
    close TEMP;

    # Now we have our needed file to import, lets do so...
    my $table = $obj->{'PREFIX'}.$IN->{'TABLE'};
    # Open the text file..
    my $seen_keys = {};
    open TEMP2, "$IN->{'SOURCE'}/$IN->{'TABLE'}.tmp" or die "Cannot find the $IN->{'TABLE'} temp file $!";
    while (<TEMP2>) {
        chomp;
        next unless $_;
        
        my $data = $obj->decode_record($_);
        next unless $data->{ $obj->{'cur_p_key'} };
        next if exists $seen_keys->{ $data->{ $obj->{'cur_p_key'} } };
        
        # add the primary key to the seen keys to ensure that we don't get duplicate entries
        $seen_keys->{ $data->{ $obj->{'cur_p_key'} } } = 1;
        
        my (@fields, @values, $bind_val);
        my $k_temp;
        for my $k (keys %{ $data }) {                         
            $k_temp = $k;
            $k_temp =~ s/^(_WHERE|VIEW|DATE|LANGUAGE|TIME)$/\"$1\"/g;
            push @fields, $k_temp;
            push @values, $data->{$k};
            $bind_val .= '?, ';
        }
        
        $bind_val =~ s/\, $//; #removing last ',' symbol 

        my $db_query = "INSERT INTO $table (" . join(", ", @fields) . ") VALUES (". $bind_val .")";

        my $stmt = $DB->prepare($db_query) or die "Prepare statement DBI Error: $DBI::errstr <br> Statement:<br> $db_query";
        $stmt->execute(@values) or die "exec statement DBI Error: $DBI::errstr <br> Statement:<br> $db_query";
        $stmt->finish();
    }
    close TEMP2;

    # Remove the work file...
    unlink ("$IN->{'SOURCE'}/$IN->{'TABLE'}.tmp");

}


#----------------------------------------------------------------
# backup, overrides base class method
#----------------------------------------------------------------

sub back_up {
    my $obj = shift;
    
    # EXPORTING DATABASE
    #
    # This will export all the information to a single text file per table

    # The format for each entry is:
    
    # DBID-ID|*|values


    my $IN = {  
                "TABLE"          => "",   #Provide table name
                "DESTINATION"    => "",   #Root directory for destination
                @_
              };
              
    my $DB = $CONN;
    my $table = $obj->{'PREFIX'}.$IN->{'TABLE'};
    $obj->load_cfg($IN->{'TABLE'});
    #Ensure the destination directory is trailing slash free.

    $IN->{'DESTINATION'} =~ s!/$!!;

    unless (-e $IN->{'DESTINATION'}) {
        $obj->{'error'} = "Could not find the destination directory to back-up into";
        return;
    }
    unless (-w $IN->{'DESTINATION'}) {
        $obj->{'error'} = "Permission Denied: Cannot write into the destination directory.";
        return;
    }
    
    my $destination = "$IN->{'DESTINATION'}/$IN->{'TABLE'}.txt";


    my $sth = $DB->prepare("SELECT * FROM $table");
    $sth->execute() || ($obj->{'error'} = "Can't query the data from '$IN->{'TABLE'}'\nReason: $DBI::errstr" and return);
    # Open up our text file..
    open F, ">".$destination;
    while (my $row = $sth->fetchrow_hashref()) {
        my ($id, $dbid);
        if ($obj->{'cur_ID'}) {
            $id   = $row->{ $obj->{'cur_ID'}   };
        }
        if ($obj->{'cur_DBID'}) {
            $dbid = $row->{ $obj->{'cur_DBID'} };
        }
        my $c_row = $obj->encode_record( $row );
        print F "$dbid-$id|*|".$c_row."\n";   
    }
    # Close the text file
    close F;
    
    # Export the index if needed
    if ($obj->{'cur_INDEX'}) {
        for my $key ( keys %{ $obj->{'cur_INDEX'} } ) {
            my $sth = $DB->prepare("SELECT $key, $obj->{'cur_INDEX'}->{ $key } FROM $table");
            $sth->execute();
            open IND, ">$IN->{'DESTINATION'}/$IN->{'TABLE'}-$key.index";
            while (my $row = $sth->fetchrow_hashref()) {
                print IND "$row->{ $key }|*|$row->{ $obj->{'cur_INDEX'}->{ $key } }\n";
            }
            $sth->finish(); 
            close IND;
        }
    }
    return "0 but true";
}


#----------------------------------------------------------------
# Create Table: Creates a table, all 
# errors to $obj->{'error'}, returns 1 on success.
#----------------------------------------------------------------

sub create_table {
    my $obj = shift;
       $obj->{'error'} = undef;
       
    # Return unless we can create tables
    return unless $obj->{_can_create};

    my $IN = {  
                "TABLE"   => "",
                "DBID"    => "",
                @_,
              };

    my $DB = $CONN;

    $obj->load_cfg($IN->{'TABLE'});

    $IN->{'DBID'} = $IN->{'DBID'} ? $IN->{'DBID'}.'_' : '';

    # Start the query with Example: CREATE TABLE ib_f2_forum_posts (

    my $db_query = "CREATE TABLE ".$obj->{'PREFIX'}.$IN->{'DBID'}.$IN->{'TABLE'}." (";

    foreach my $entry (sort { $obj->{'all_cols'}->{$a}[0] <=> $obj->{'all_cols'}->{$b}[0] } keys %{$obj->{'all_cols'}} ) {

        my $field = convert_field_name($entry);

        if ($obj->{'all_cols'}->{$entry}[1] eq 'update') {

           $field .= " NUMBER($obj->{'all_cols'}->{$entry}[2])";

        } elsif ($obj->{'all_cols'}->{$entry}[1] eq 'num') {

           $field .= " NUMBER($obj->{'all_cols'}->{$entry}[2])";

        } elsif ($obj->{'all_cols'}->{$entry}[1] eq 'string') {

           $field .= " VARCHAR2($obj->{'all_cols'}->{$entry}[2])";

        } elsif ($obj->{'all_cols'}->{$entry}[1] eq 'text') {

           $field .= " CLOB";

        } else {

           $field .= " VARCHAR2(255)";

        }

        if ($obj->{'all_cols'}->{$entry}[3]) {

          $field .= " NOT NULL";
        }
       
        $db_query .= $field.',';
    }

    $db_query .= 'PRIMARY KEY (' . $obj->{'cur_p_key'} . ')';
    $db_query .= ");";

    my $sth = $DB->do($db_query) || ($obj->{'error'} = "Can't create table. Statement: $db_query. $DBI::errstr $!" and return);

    return 1;

}


sub drop_table {
    my $obj = shift;
    # Return unless we can create tables
    return unless $obj->{_can_drop};

    my %IN = ( TABLE    => "",
               DBID     => "",
               @_,
             );

    $obj->load_cfg($IN{'TABLE'});

    my $DB    = $CONN;
    my $table = $obj->{'PREFIX'}.$IN{'DBID'}.$IN{'TABLE'};

    my $db_query = "DROP TABLE $table CASCADE CONSTRAINTS";
    my $sth= $DB->do($db_query) or ($obj->{'error'} = "Can't drop table $table (Query: $db_query). $DBI::errstr $!" and return);
    $sth->finish();
    return 1;
}



sub drop_tables {
    my $obj = shift;
    my %IN = ( TABLES => [], @_, );
    foreach my $table (@{$IN{'TABLES'}}) {
        $obj->drop_table( TABLE => $table->{'TABLE'},
                          DBID  => $table->{'DBID'},
                        );
    }
    return 1;
}


sub drop_database {
    my $obj = shift;

    my $DB = $CONN;
    
    # Grab the table names.
    opendir DIR, $obj->{'base_dir'}.'config';
    my @files = grep { !/^\./ && !/\.html$/ } readdir DIR;
    closedir DIR;
    

    my $cnt;
    
    for my $table (@files) {

        next unless $table =~ m/cfg$/;
        $table =~ s/\.cfg//i;
        $table = $obj->{'PREFIX'}.$table;        
        $DB->do("DELETE FROM $table") || die "Can't remove data from table $table. $DBI::errstr $!";
        ++$cnt;
    }

    return $cnt;
}   

sub rebuild_record {
    my $obj = shift;
    my $IN = {  
                "TABLE"   => "",
                "STRING"  => "",
                "VALUES"  => {},
                @_
             };
             

    $obj->load_cfg($IN->{'TABLE'});
    
    my $record = $obj->decode_record($IN->{STRING});
    # Override the column values from the string with those
    # given to us by the accessing script.
    if ($IN->{VALUES}) {
        for my $k (keys %{ $IN->{VALUES} }) {
            $record->{$k} = $IN->{VALUES}->{$k};
        }
    }
    return $record;
}

#----------------------------------------------------------------
# SQL client:
#----------------------------------------------------------------

sub client_do_do {
    my $obj = shift;
    $obj->{'error'} = undef;
    my $IN = {  
                "QUERY"   => "",
                @_
              };
    
    my $DB = $obj->{'DB'};
    my $query = parse($IN->{'QUERY'});

    my $sth = $DB->do($query) || ($obj->{'error'} = "Can't handle your request: $DBI::errstr" and return);
    ++$obj->{query_c};
    return $sth;
}


sub client_exec {
    my $obj = shift;
    $obj->{'error'} = undef;
    my $IN = {  
                "QUERY"   => "",
                @_
              };
    
    my $DB = $obj->{'DB'};
    my $query = parse($IN->{'QUERY'});

    my $sth = $DB->prepare("$query") || ($obj->{'error'} = "Can't query the data: $DBI::errstr" and return);
    $sth->execute() || ($obj->{'error'} = "Can't query the data: $DBI::errstr" and return);
    ++$obj->{query_c};

    return $sth;
}

sub client_do {
    my $obj = shift;
    $obj->{'error'} = undef;
    my $IN = {  
                "QUERY"   => "",
                @_
              };
    
    my $DB = $obj->{'DB'};
    my $query = parse($IN->{'QUERY'});

    my $sth = $DB->prepare("$query") || ($obj->{'error'} = "Can't prepare query the data from \"$IN->{'TABLE'}\". $DBI::errstr" and return);

    $sth->execute() || ($obj->{'error'} = "Can't query the data from \"$IN->{'TABLE'}\". $DBI::errstr" and return);

    my @return;

    while (my $row = $obj->make_hash_ref($sth)){
        push (@return, $row);    
    }

    ++$obj->{query_c};
    return \@return;  
}

sub tables {

    my $obj = shift;
    my $db = $obj->{'DB'};
    my @tables = $db->tables();
    my @temp_tables;
    my $k_temp;
    
    for my $i (@tables) {     
    $k_temp = $i;   
    $k_temp =~ s/^$iB::INFO->{DB_USER}\.(.*)$/\L$1\E/gi;
    push @temp_tables, $k_temp;
   }


    return \@temp_tables;

}

sub table_attr {
    my $obj = shift;
    my $db = $obj->{'DB'};
    my $IN = {  
                "TABLE"   => "",
                @_
             };
             
    my @attr;
    my $table = $IN->{TABLE};
    my $db_query = qq~
select column_name as NAME, data_type as TYPE, data_default as "DEFAULT", 
(
select cc.position from user_constraints c, user_cons_columns cc
where c.table_name = tb.table_name and 
c.CONSTRAINT_TYPE='P' and c.CONSTRAINT_NAME=cc.CONSTRAINT_NAME and cc.POSITION = '1'
and cc.COLUMN_NAME= tb.column_name
) PRIMARY_KEY,
(
select 'NOT NULL' from user_constraints c, user_cons_columns cc
where c.table_name = tb.table_name 
and c.CONSTRAINT_TYPE='C' 
and c.CONSTRAINT_NAME=cc.CONSTRAINT_NAME 
and cc.COLUMN_NAME= tb.column_name
) NOTNULL from user_tab_columns tb where lower(table_name) = ('$table')~;

    #$obj->{query} = $db_query;
    $obj->{query} = "select * from $table";
    
    my $sth = $db->prepare($db_query);
    die "Oracle error: $DBI::errstr<P>$db_query" if $DBI::errstr;
    $sth->execute();
    die "Oracle error: $DBI::errstr<P>$db_query" if $DBI::errstr;
    
    while (my $row = $obj->make_hash_ref($sth) ) {
        push @attr, $row;
    }
    $sth->finish();
    return \@attr;

}


sub parse {
    my ($obj, $where) = @_;

    $_[0] =~ s/(\W*)(_WHERE|VIEW|DATE|LANGUAGE|TIME)(\s*(=|<>|<|>|LIKE|NOT LIKE)\s*.+)/$1\"$2\"$3/g; 
    $_[0] =~ s|&#33;|!|g;
    $_[0] =~ s|&amp;|&|g;
    $_[0] =~ s|&gt;|>|g;
    $_[0] =~ s|&lt;|<|g;
    $_[0] =~ s|&quot;|"|g;
    $_[0] =~ s!&#124;!\|!g;
    $_[0] =~ s|\n||g;
    $_[0] =~ s|&#036;|\$|g;
    $_[0] =~ s|&#92;|\\|g;
    $_[0] =~ s|&#039;|\'|g;
    $_[0] =~ s/(\s*(=|<>|<|>|LIKE|NOT LIKE)\s*)\"|'(.+)\"|'/$1'$3'/g;

    return $_[0];

}
