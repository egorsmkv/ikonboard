package NotePad;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Notepad: Member notepad functions
#
#################################################################################
BEGIN { require 'Lib/FUNC.pm'; }

my $output  = FUNC::Output->new();
my $mem     = FUNC::Member->new();
my $std     = FUNC::STD->new();

$NotePad::lang = $std->LoadLanguage('NotePadWords');

sub new {
 my $pkg = shift;
 my $obj = { 'NOTE_PAD' => undef };
 bless $obj, $pkg;
 return $obj;
}

sub NotePad {
   my ($obj, $db) = @_;

   $obj->{'NOTE_PAD'} = $db->select( TABLE => 'member_notepads',
                                     ID    => 'MEMBER_ID',
                                     KEY   => "$iB::MEMBER->{'MEMBER_ID'}",
                                   );

   $obj->{'NOTE_PAD'}->{'NOTEPAD_TEXT'} =~ s#\r##g;
   $obj->{'NOTE_PAD'}->{'NOTEPAD_TEXT'} =~ s#<br>#\n#g;

   $output->print_ikonboard( DB         => $db,
                             STD        => $std,
                             NAV        => [ qq!Your Note Pad! ],
                             OUTPUT     => NotePadView::pad_text_area( $obj->{'NOTE_PAD'}->{'NOTEPAD_TEXT'} ),
                             JAVASCRIPT => '1',
                             TITLE      => "iB::" . $NotePad::lang->{'page_title'},
                           );
}

sub saved_p {
   my ($obj, $db) = @_;

   $obj->{'NOTE_PAD'} = $db->select( TABLE => 'member_notepads',
                                     ID    => 'MEMBER_ID',
                                     KEY   => "$iB::MEMBER->{'MEMBER_ID'}",
                                   );

   $obj->{'NOTE_PAD'}->{'SAVED_P'} =~ s#\r##g;
   $obj->{'NOTE_PAD'}->{'SAVED_P'} =~ s#<br>#\n#g;

   $output->print_ikonboard( DB         => $db,
                             STD        => $std,
                             NAV        => [ qq!Your Note Pad! ],
                             OUTPUT     => NotePadView::post_text_area( $obj->{'NOTE_PAD'}->{'SAVED_P'} ),
                             JAVASCRIPT => '1',
                             TITLE      => "iB::" . $NotePad::lang->{'page_title'},
                           );
}

sub mess {
   my ($obj, $db) = @_;

   $obj->{'NOTE_PAD'} = $db->select( TABLE => 'member_notepads',
                                     ID    => 'MEMBER_ID',
                                     KEY   => "$iB::MEMBER->{'MEMBER_ID'}",
                                   );

   $obj->{'NOTE_PAD'}->{'SAVED_M'} =~ s#\r##g;
   $obj->{'NOTE_PAD'}->{'SAVED_M'} =~ s#<br>#\n#g;

   $output->print_ikonboard( DB         => $db,
                             STD        => $std,
                             NAV        => [ qq!Your Note Pad! ],
                             OUTPUT     => NotePadView::mess_text_area( $obj->{'NOTE_PAD'}->{'SAVED_M'} ),
                             JAVASCRIPT => '1',
                             TITLE      => "iB::" . $NotePad::lang->{'page_title'},
                           );
}

sub SaveNotePad {
   my ($obj, $db) = @_;

   my $notes = $iB::IN{'NOTEPAD_TEXT'} || '';
   $std->Error( DB      => $db,
                LEVEL   => 1,
                MESSAGE =>'post_too_long'
               ) if length $notes > $iB::INFO->{'MAX_POST_LENGTH'} * 1024;

   my $is_already_in = $db->select( TABLE => 'member_notepads',
                                    KEY   => "$iB::MEMBER->{'MEMBER_ID'}",
                                    WHERE => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!,
                                    MATCH => 'ONE',
                                  );

   if ($is_already_in->{'MEMBER_ID'}) {
       $db->update(  TABLE  => 'member_notepads',
                     ID     => "$iB::MEMBER->{'MEMBER_ID'}",
                     KEY    => "$iB::MEMBER->{'MEMBER_ID'}",
                     VALUES => { NOTEPAD_TEXT => $notes},
                  ) || die $db->{'error'};
   } else {
       $db->insert(  TABLE  => 'member_notepads',
                     VALUES => { MEMBER_ID    => "$iB::MEMBER->{'MEMBER_ID'}",
                                 NOTEPAD_TEXT => $notes,
                               },
                  ) || die $db->{'error'};
   }

   $output->redirect_screen( TEXT => $NotePad::lang->{'save_successful'}, URL => "act=NotePad;CODE=00" );
}

sub save_saved_p {
   my ($obj, $db) = @_;

   my $s_post = $iB::IN{'NOTEPAD_TEXT'} || '';

   $std->Error( DB      => $db,
                LEVEL   => 1,
                MESSAGE =>'post_too_long'
               ) if length $s_post > $iB::INFO->{'MAX_POST_LENGTH'} * 1024;

   my $is_already_in = $db->select( TABLE => 'member_notepads',
                                    KEY   => "$iB::MEMBER->{'MEMBER_ID'}",
                                    WHERE => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!,
                                    MATCH => 'ONE',
                                  );

   if ($is_already_in->{'MEMBER_ID'}) {
       $db->update(  TABLE  => 'member_notepads',
                     ID     => "$iB::MEMBER->{'MEMBER_ID'}",
                     KEY    => "$iB::MEMBER->{'MEMBER_ID'}",
                     VALUES => { SAVED_P => $s_post},
                  ) || die $db->{'error'};
   } else {
       $db->insert(  TABLE  => 'member_notepads',
                     VALUES => { MEMBER_ID    => "$iB::MEMBER->{'MEMBER_ID'}",
                                 SAVED_P => $s_post,
                               },
                  ) || die $db->{'error'};
   }

   $output->redirect_screen( TEXT => $NotePad::lang->{'save_successful'}, URL => "act=NotePad;CODE=02" );
}

sub save_mess {
   my ($obj, $db) = @_;

   my $s_post = $iB::IN{'NOTEPAD_TEXT'} || '';

   $std->Error( DB      => $db,
                LEVEL   => 1,
                MESSAGE =>'post_too_long'
               ) if length $s_post > $iB::INFO->{'MAX_POST_LENGTH'} * 1024;

   my $is_already_in = $db->select( TABLE => 'member_notepads',
                                    KEY   => "$iB::MEMBER->{'MEMBER_ID'}",
                                    WHERE => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!,
                                    MATCH => 'ONE',
                                  );

   if ($is_already_in->{'MEMBER_ID'}) {
       $db->update(  TABLE  => 'member_notepads',
                     ID     => "$iB::MEMBER->{'MEMBER_ID'}",
                     KEY    => "$iB::MEMBER->{'MEMBER_ID'}",
                     VALUES => { SAVED_M => $s_post},
                  ) || die $db->{'error'};
   } else {
       $db->insert(  TABLE  => 'member_notepads',
                     VALUES => { MEMBER_ID    => "$iB::MEMBER->{'MEMBER_ID'}",
                                 SAVED_M => $s_post,
                               },
                  ) || die $db->{'error'};
   }

   $output->redirect_screen( TEXT => $NotePad::lang->{'save_successful'}, URL => "act=NotePad;CODE=04" );
}

sub Process {
   my ($obj, $db) = @_;

   my %Mode = ( '00'   =>   \&NotePad,
                '01'   =>   \&SaveNotePad,
                '02'   =>   \&saved_p,
                '03'   =>   \&save_saved_p,
                '04'   =>   \&mess,
                '05'   =>   \&save_mess,
              );

   require ($iB::SKIN->{'DIR'} . '/NotePadView.pm') or die $!;

   $Mode{ $iB::IN{'CODE'} } ? $Mode{ $iB::IN{'CODE'} }->($obj,$db) : NotePad($obj,$db);
}

1;
