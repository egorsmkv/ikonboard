package ModCP;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
# ModCP: Moderation Control Panel
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
    require 'Searchlog.pm';
    require 'Moderate.pm';
}

my $output      = FUNC::Output->new();
my $mem         = FUNC::Member->new();
my $std         = FUNC::STD->new();
my $txt         = iTextparser->new();
my $s_log       = Searchlog->new();
my $mod         = Moderate->new();
$ModCP::lang    = $std->LoadLanguage('ModCPWords');
$Moderate::lang = $std->LoadLanguage('ModerateWords');



sub new {
    my $pkg = shift;
    my $obj = { 'html' => undef, 'PASSED' => 0 };
    bless $obj, $pkg;
    return $obj;
}

################################################################
#
# ModSplash, print out the beginning mod CP screen
#
################################################################

sub mod_splash {
    my ($obj, $db) = @_;

    # Do we have a forum we're looking at?

    $obj->{html} = ModCPView::startcp();

    $iB::IN{'f'} ? $obj->_forum_splash($db) : $obj->_main_splash($db);

    $obj->{html} .= ModCPView::endcp();


}

sub read_post {
    my ($obj, $db) = @_;

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
    }

    my $p_data = $db->select( TABLE => 'mod_posts',
                              KEY   => $iB::IN{'ID'},
                            );
    my $print = ModCPView::read_post( $p_data );
    ++$obj->{bypass};
    $output->print_popup( STD    => $std,
                          OUTPUT => $print,
                          TITLE  => "iB::" . "$ModCP::lang->{'title'}",
                        );
}

sub _forum_splash {
    my ($obj, $db) = @_;

    # Are we a moderator of this forum?

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
    }

    # Sort out the menu...
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;

    $obj->{html} .= ModCPView::forum_splash( $forum_info);
    # Get the number of watched topics
    my $watched = $db->query( TABLE => 'forum_topics',
                  ID    => $iB::IN{'f'},
                  WHERE => "WATCHED == 1 and FORUM_ID == '$iB::IN{'f'}'",
                  COLUMNS   => ['TOPIC_ID'],
                );
    my $watched_count = scalar @{$watched};

    $obj->{html} .= ModCPView::watched_form_header( $watched_count );

    $obj->{html} .= $watched_count > 0 ? ModCPView::watched_form() : ModCPView::watched_none();
    my $mod_mail = $db->query( TABLE    => 'mod_email',
                               WHERE  => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}" and FORUM_ID eq "$iB::IN{'f'}" and WHENE == 1!,
                                );
    if ($mod_mail->[0]->{'ID'}) {
    $db->update( TABLE  => 'mod_email',
                 KEY    => $mod_mail->[0]->{'ID'},
                 VALUES => {
                             SENT        => 0,
                            },
               ) || die $db->{'error'};
    }


    # Get the number of topics to preview
    my $topic_mod = $db->query( TABLE   => 'forum_topics',
                                ID      => $iB::IN{'f'},
                                WHERE   => "APPROVED == 0 and FORUM_ID == '$iB::IN{'f'}'",
                                COLUMNS => ['TOPIC_ID'],
                              );
    my $topic_count = scalar @{$topic_mod};

    # Get the number of posts to preview
    my $posts_mod = $db->query( TABLE   => 'mod_posts',
                                WHERE   => "FORUM_ID == '$iB::IN{'f'}' and TYPE ne 'new'",
                              );
    my $posts_count = scalar @{$posts_mod};

    # Print the topics to moderate header
    $obj->{html} .= ModCPView::topic_form_header( $topic_count );

    # Do we have any? If so, print out the form
    $obj->{html} .= $topic_count > 0 ? ModCPView::topic_form() : ModCPView::topic_none();

    # Print the posts to moderate header
    $obj->{html} .= ModCPView::post_form_header( $posts_count );

    # Do we have any? If so, print out the form
    $obj->{html} .= $posts_count > 0 ? ModCPView::post_form() : ModCPView::post_none();

    $obj->{html} .= ModCPView::end_forum_splash();
    
    $obj->{nav} = qq|<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'}'>Moderating Forum: $forum_info->{'FORUM_NAME'}</a>|;
}

################################################################
#
# DELETE TOPICS
#
################################################################

sub delete {
    my ($obj, $db) = @_;

    # Are we a moderator of this forum?

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless $obj->{moderator}->{ $iB::IN{'f'} }->{'DELETE_TOPIC'};
    }

    $obj->{html} .= ModCPView::startcp();
    # Sort out the menu...
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;
    $obj->{html} .= ModCPView::forum_splash( $forum_info);
    $obj->{html} .= ModCPView::delete_form_header();
    $obj->{html} .= ModCPView::end_forum_splash();
    $obj->{html} .= ModCPView::endcp();
}
sub process_delete {
    my ($obj, $db) = @_;

    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ( defined($iB::IN{'DAYS'}) and defined($iB::IN{'LIMIT'}) );

    # Build the query...
    my $date_cut = " and TOPIC_START_DATE > ".(time-(60*60*24*$iB::IN{'DAYS'}));
    my $order    = $iB::IN{'ORDER'} eq 'asc' ? 'A-Z' : 'Z-A';

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );
    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;

    # Get the topics...
    my $topics = $db->query( TABLE    => 'forum_topics',
                             ID       => $iB::IN{'f'},
                             WHERE    => "FORUM_ID == $iB::IN{'f'} and APPROVED == 1$date_cut",
                             SORT_KEY => 'TOPIC_LAST_DATE',
                             SORT_BY  => $order,
                             RANGE    => "0 to $iB::IN{'LIMIT'}",
                           );

    unless (scalar(@{$topics}) > 0) {
        ++$obj->{bypass};
        $output->redirect_screen( TEXT => $ModCP::lang->{'no_matches'}, URL => "act=ModCP&f=$iB::IN{'f'}&CODE=delete" );
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $forum_info->{'search_type'} = 'do_delete';
    $obj->{html} .= ModCPView::topic_header( $forum_info );

    for my $t (@{$topics}) {
        # Convert unix time to human readable
        $t->{'TOPIC_START_DATE'} = $std->get_date( TIME => $t->{'TOPIC_START_DATE'}, METHOD => 'LONG' );
        $t->{'TOPIC_LAST_DATE'}  = $std->get_date( TIME => $t->{'TOPIC_LAST_DATE'},  METHOD => 'LONG' );

        my $select = qq!<select name='CHOICE_$t->{'TOPIC_ID'}' class='forminput'>!;
        $select .= qq!<option value='leave' selected>$ModCP::lang->{'c_leave'}</option><option value='delete'>* $ModCP::lang->{'c_delete'} *</option>!;

        $t->{'SELECT'} = $select . "</select>";

        if ($t->{'POLL_STATE'}) {$t->{'STATE'} = $iB::INFO->{'PRE_POLLS'}};
        if ($t->{'PIN_STATE'} == 1) { $t->{'STATE'} = $iB::INFO->{'PRE_PINNED'}};
        if ($t->{'MOVED_TO'}) { $t->{'STATE'} = $iB::INFO->{'PRE_MOVED'} };

        $t->{'LAST_POSTER'} = ($t->{'TOPIC_LAST_POSTER'} != 0)   ? qq[<b><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$t->{'TOPIC_LAST_POSTER'}'>$t->{'TOPIC_LASTP_N'}</a></b>]
                                                                 : qq[-$t->{'TOPIC_LASTP_N'}-];

        my $event_name = $db->select( TABLE   => 'calendar',
                                      KEY     => "f=$iB::IN{'f'};t=$t->{'TOPIC_ID'}",
                                      );
        $t->{'CALENDAR'} = $event_name->{'MEMBER_NAME'};
        $t->{'YEAR'} = $event_name->{'YEAR'};
        $t->{'MONTH'} = $event_name->{'MONTH'};
        $t->{'DAY'} = $event_name->{'DAY'};

        $obj->{html} .= ModCPView::render_opentopic( $t );
    }


    $obj->{html} .= ModCPView::topic_footer();
    $obj->{html} .= ModCPView::endcp();
}

sub do_delete {
    my ($obj, $db) = @_;

    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );


    # Sort out the form data.
    my @topic_ids = grep { /^CHOICE_(\d+)$/ } $iB::CGI->param();

    my $global = { leave => 0, delete => 0 };

    my $count  = { TOPICS => 0, POSTS => 0 };

    for my $id (@topic_ids) {
        $id  =~ /^CHOICE_(\d+)$/;
        $id  = $1;
        next unless $id;
        my $choice = $iB::CGI->param( 'CHOICE_'.$id );
        next unless $choice;
        ++$global->{ $choice } and next if $choice eq 'leave';

        my $topic = $db->select( TABLE => 'forum_topics',
                                 ID     => $iB::IN{'f'},
                                 KEY    => $id,
                               );


        # If we are deleting..

### Delete attachments when pruning by [EMAIL=sly@swarf.net]sly@swarf.net[/EMAIL]
        my $t_post = $db->query( TABLE  => 'forum_posts',
                                 DBID   => 'f'.$iB::IN{'f'},
                                 ID     => $id,
                                 WHERE  => "TOPIC_ID == $id and FORUM_ID == $iB::IN{'f'} and POST_ID > '0'",
                               );

        foreach my $p (@{$t_post}) {
        if ($p->{'ATTACH_ID'}) {
# Ensure a directory is specified for the public uploads
        unless ($iB::INFO->{'PUBLIC_UPLOAD'}) {
                $iB::INFO->{'PUBLIC_UPLOAD'} = $iB::INFO->{'HTML_DIR'};
                $iB::INFO->{'PUBLIC_UPLOAD'} =~ s/non-cgi/uploads/;
        }
# Make sure it's got a trailing slash..

                $iB::INFO->{'PUBLIC_UPLOAD'} .= '/' unless $iB::INFO->{'PUBLIC_UPLOAD'} =~ m!/$!;

        my $at = $db->select( TABLE => 'attachments',
                              KEY   => $p->{'ATTACH_ID'},
                             );
                $db->delete( TABLE => 'attachments',
                             KEY   => $p->{'ATTACH_ID'},
                             );
        unlink $iB::INFO->{'PUBLIC_UPLOAD'}."$at->{'FILE_NAME'}";
        }
        }

### Delete attachments when pruning by [EMAIL=sly@swarf.net]sly@swarf.net[/EMAIL]

        $db->delete( TABLE  => 'forum_topics',
                     ID     => $iB::IN{'f'},
                     KEY    => $id,
                   );

        $db->delete(  TABLE  => 'forum_polls',
                      WHERE  => "POLL_ID == $id and FORUM_ID == $iB::IN{'f'}"
                   );

        $db->delete(  TABLE  => 'forum_poll_voters',
                      WHERE  => "POLL_ID == $id and FORUM_ID == $iB::IN{'f'}"
                   );

        my $t_post = $db->query( TABLE  => 'forum_posts',
                                 DBID   => 'f'.$iB::IN{'f'},
                                 ID     => $id,
                                 WHERE  => "TOPIC_ID == $id and FORUM_ID == $iB::IN{'f'} and POST_ID > '0'",
                                );
        $db->delete(  TABLE  => 'forum_posts',
                      DBID   => 'f'.$iB::IN{'f'},
                      ID     => $id,
                      WHERE  => "TOPIC_ID == $id and FORUM_ID == $iB::IN{'f'} and POST_ID > '0'",
                    );
        foreach my $p (@{$t_post}) {
            if ($p->{'ATTACH_ID'}) {
                # Ensure a directory is specified for the public uploads
                unless ($iB::INFO->{'PUBLIC_UPLOAD'}) {
                    $iB::INFO->{'PUBLIC_UPLOAD'} = $iB::INFO->{'HTML_DIR'};
                    $iB::INFO->{'PUBLIC_UPLOAD'} =~ s/non-cgi/uploads/;
                }
                # Make sure it's got a trailing slash..

                $iB::INFO->{'PUBLIC_UPLOAD'} .= '/' unless $iB::INFO->{'PUBLIC_UPLOAD'} =~ m!/$!;

                my $at = $db->select( TABLE => 'attachments',
                                      KEY   => $p->{'ATTACH_ID'},
                                   );
                $db->delete( TABLE => 'attachments',
                             KEY   => $p->{'ATTACH_ID'},
                           );
                unlink $iB::INFO->{'PUBLIC_UPLOAD'}."$at->{'FILE_NAME'}";
            }
        }
        $db->delete(  TABLE  => 'calendar',
                  WHERE  => "FORUM_ID == $iB::IN{'f'} and TOPIC_ID == $id",
               );


        $db->delete(  TABLE  => 'search_log',
                      ID     => $iB::IN{'f'},
                      WHERE  => qq[FORUM_ID == $iB::IN{'f'} and TOPIC_ID == $id],
                   );
        my $del_views = $db->query(  TABLE  => 'topic_views',
                                     ID     => $iB::IN{'f'},
                                     WHERE  => "TOPIC_ID == $id and FORUM_ID == $iB::IN{'f'}",
                                    );
        foreach my $v (@{$del_views}) {
        $db->delete(  TABLE  => 'topic_views',
                      ID     => $iB::IN{'f'},
                      KEY    => $v->{'ID'},
                      WHERE  => "TOPIC_ID == $id and FORUM_ID == $iB::IN{'f'}",
                      );
        }

        ++$global->{ 'delete' };
        $count->{'POSTS'}  += $topic->{'TOPIC_POSTS'};
        $count->{'TOPICS'} += 1;
    }

    # Fix up the forum...
    if ($global->{ 'delete' }) {
        $obj->_reset_forum( FORUM      => $iB::IN{'f'},
                            DEL_POSTS  => $count->{'POSTS'},
                            DEL_TOPICS => $count->{'TOPICS'},
                            DB         => $db,
                          );
        $obj->_reset_stats(
                            DEL_POSTS  => $count->{'POSTS'},
                            DEL_TOPICS => $count->{'TOPICS'},
                          );

    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::show_delete_results( $global );
    $obj->{html} .= ModCPView::endcp();
}

################################################################
#
# PRUNE FORUM
#
################################################################

sub prune {
    my ($obj, $db) = @_;

    # Are we a moderator of this forum?

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };

        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless $obj->{moderator}->{ $iB::IN{'f'} }->{'MASS_PRUNE'};
    }

    $obj->{html} .= ModCPView::startcp();
    # Sort out the menu...
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;
    $obj->{html} .= ModCPView::forum_splash( $forum_info);
    $obj->{html} .= ModCPView::prune_form_header();
    $obj->{html} .= ModCPView::end_forum_splash();
    $obj->{html} .= ModCPView::endcp();
}

sub process_prune {
    my ($obj, $db) = @_;

    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;

    my $st = $iB::IN{st} || 0;

    my $total = $iB::IN{PAGE} + ($st - 1);

    $iB::IN{RUN} = $st + $iB::IN{PAGE};

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ( defined($iB::IN{'DAYS'}) );

    # Build the query...
    my $date_cut = " and TOPIC_LAST_DATE < ".(time-(60*60*24*$iB::IN{'DAYS'}));

    if ($st == 0 and $iB::IN{PROCESS} != 1) {
        my $topics = $db->query( TABLE    => 'forum_topics',
                                 ID       => $iB::IN{'f'},
                                 COLUMNS  => ['TOPIC_ID'],
                                 WHERE    => "FORUM_ID == $iB::IN{'f'} and APPROVED == 1$date_cut",
                               );
        my $topic_total = scalar(@{$topics});

        unless ($topic_total > 0) {
            ++$obj->{bypass};
            $output->redirect_screen( TEXT => $ModCP::lang->{'no_matches'}, URL => "act=ModCP&f=$iB::IN{'f'}&CODE=prune" );
        }

        # else, just redirect.

        $ModCP::lang->{s_pstart} =~ s/<#TOTAL#>/$topic_total/;
        $output->redirect_screen( TEXT => $ModCP::lang->{s_pstart}, URL => "act=ModCP&f=$iB::IN{'f'}&CODE=process_prune&DAYS=$iB::IN{'DAYS'}&PAGE=$iB::IN{PAGE}&st=$st&PROCESS=1&ORIG=$topic_total" );
    }

    # Get the topics...
    my $topics = $db->query( TABLE    => 'forum_topics',
                             ID       => $iB::IN{'f'},
                             WHERE    => "FORUM_ID == $iB::IN{'f'} and APPROVED == 1$date_cut",
                             RANGE    => "0 to ".($iB::IN{PAGE} - 1),
                           );


    my $forum_info = $db->select( TABLE  => 'forum_info',
                                  KEY    => $iB::IN{'f'},
                                );

    my $global = { leave => $forum_info->{'FORUM_TOPICS'}, delete => 0 };

    my $count  = { TOPICS => 0, POSTS => 0 };

    for my $id (@{$topics}) {
        next unless $id;

        $id = $id->{'TOPIC_ID'};

        my $topic = $db->select( TABLE => 'forum_topics',
                                 ID     => $iB::IN{'f'},
                                 KEY    => $id,
                               );

        # If we are deleting..
        $db->delete( TABLE  => 'forum_topics',
                     ID     => $iB::IN{'f'},
                     KEY    => $id,
                   );
        $db->delete(  TABLE  => 'calendar',
                  WHERE  => "FORUM_ID == $iB::IN{'f'} and TOPIC_ID == $id",
                );

        if ($topic->{POLL_STATE} or $topic->{LAST_VOTE}) {
            $db->delete(  TABLE  => 'forum_polls',
                          WHERE  => "POLL_ID == $id and FORUM_ID == $iB::IN{'f'}"
                       );

            $db->delete(  TABLE  => 'forum_poll_voters',
                          WHERE  => "POLL_ID == $id and FORUM_ID == $iB::IN{'f'}"
                       );
        }
        $db->delete(  TABLE  => 'forum_posts',
                      DBID   => 'f'.$iB::IN{'f'},
                      ID     => $id,
                      WHERE  => "TOPIC_ID == $id and FORUM_ID == $iB::IN{'f'}",
                    );

        $db->delete(  TABLE  => 'search_log',
                      ID     => $iB::IN{'f'},
                      WHERE  => qq[FORUM_ID == $iB::IN{'f'} and TOPIC_ID == $id],
                   );
        $db->delete(  TABLE  => 'topic_views',
                      ID     => $iB::IN{'f'},
                      WHERE  => "TOPIC_ID == $id and FORUM_ID == $iB::IN{'f'}",
                    );

        ++$global->{'delete'};
        --$global->{'leave'};
        $count->{'POSTS'}  += $topic->{'TOPIC_POSTS'};
        $count->{'TOPICS'} += 1;

    }

    if ( (scalar(@{$topics}) < 1) or ($iB::IN{RUN} >= $iB::IN{ORIG}) ) {
        # Fix up the forum...

        if ($global->{ 'delete' }) {
            $obj->_reset_forum( FORUM      => $iB::IN{'f'},
                                DEL_POSTS  => $count->{'POSTS'},
                                DEL_TOPICS => $count->{'TOPICS'},
                                DB         => $db,
                              );
            $obj->_reset_stats(
                                DEL_POSTS  => $count->{'POSTS'},
                                DEL_TOPICS => $count->{'TOPICS'},
                              );

        }

        $obj->{html} = ModCPView::startcp();
        $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
        $obj->{html} .= ModCPView::show_delete_results( $global );
        $obj->{html} .= ModCPView::endcp();
    } else {
        # if not, redirect..

        $ModCP::lang->{s_refresh} =~ s/<#NUM#>/$iB::IN{RUN}/;
        $ModCP::lang->{s_refresh} =~ s/<#TOTAL#>/$iB::IN{ORIG}/;

        $output->redirect_screen( TEXT => $ModCP::lang->{s_refresh}, URL => "act=ModCP&f=$iB::IN{'f'}&CODE=process_prune&DAYS=$iB::IN{'DAYS'}&PAGE=$iB::IN{PAGE}&st=$iB::IN{RUN}&PROCESS=1&ORIG=$iB::IN{ORIG}&RUN=$iB::IN{RUN}&GL=$global->{leave}&GD=$global->{delete}&CT=$count->{TOPICS}&PC=$count->{POSTS}" );

    }
}

################################################################
#
# OPEN  /  CLOSE
#
################################################################


sub open_close_topics {
    my ($obj, $db) = @_;

    # Are we a moderator of this forum?

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless $obj->{moderator}->{ $iB::IN{'f'} }->{'OPEN_TOPIC'};
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless $obj->{moderator}->{ $iB::IN{'f'} }->{'CLOSE_TOPIC'};

    }

    $obj->{html} .= ModCPView::startcp();
    # Sort out the menu...
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;
    $obj->{html} .= ModCPView::forum_splash( $forum_info);
    $obj->{html} .= ModCPView::open_form_header();
    $obj->{html} .= ModCPView::end_forum_splash();
    $obj->{html} .= ModCPView::endcp();
}

sub process_open_close_topics {
    my ($obj, $db) = @_;

    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ( defined($iB::IN{'DAYS'}) and defined($iB::IN{'LIMIT'}) );

    # Build the query...
    my $date_cut = " and TOPIC_START_DATE > ".(time-(60*60*24*$iB::IN{'DAYS'}));
    my $order    = $iB::IN{'ORDER'} eq 'asc' ? 'A-Z' : 'Z-A';

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );
    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;

    # Get the topics...
    my $topics = $db->query( TABLE    => 'forum_topics',
                             ID       => $iB::IN{'f'},
                             WHERE    => "FORUM_ID == $iB::IN{'f'} and APPROVED == 1$date_cut",
                             SORT_KEY => 'TOPIC_LAST_DATE',
                             SORT_BY  => $order,
                             RANGE    => "0 to $iB::IN{'LIMIT'}",
                           );

    unless (scalar(@{$topics}) > 0) {
        ++$obj->{bypass};
        $output->redirect_screen( TEXT => $ModCP::lang->{'no_matches'}, URL => "act=ModCP&f=$iB::IN{'f'}&CODE=open" );
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $forum_info->{'search_type'} = 'do_openclose';
    $obj->{html} .= ModCPView::topic_header( $forum_info );

    for my $t (@{$topics}) {
        # Convert unix time to human readable
        $t->{'TOPIC_START_DATE'} = $std->get_date( TIME => $t->{'TOPIC_START_DATE'}, METHOD => 'LONG' );
        $t->{'TOPIC_LAST_DATE'}  = $std->get_date( TIME => $t->{'TOPIC_LAST_DATE'},  METHOD => 'LONG' );

        my $select = qq!<select name='CHOICE_$t->{'TOPIC_ID'}' class='forminput'>!;
        $select .= $t->{'TOPIC_STATE'} eq 'open'
                 ? qq!<option value='open' selected>$ModCP::lang->{'st_open'}</option><option value='closed'>$ModCP::lang->{'st_close'}</option>!
                 : qq!<option value='open'>$ModCP::lang->{'st_open'}</option><option value='closed' selected>$ModCP::lang->{'st_close'}</option>!;

        $t->{'SELECT'} = $select . "</select>";

        if ($t->{'POLL_STATE'}) {$t->{'STATE'} = $iB::INFO->{'PRE_POLLS'}};
        if ($t->{'PIN_STATE'} == 1) { $t->{'STATE'} = $iB::INFO->{'PRE_PINNED'}};
        if ($t->{'MOVED_TO'}) { $t->{'STATE'} = $iB::INFO->{'PRE_MOVED'} };

        $t->{'LAST_POSTER'} = ($t->{'TOPIC_LAST_POSTER'} != 0)   ? qq[<b><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$t->{'TOPIC_LAST_POSTER'}'>$t->{'TOPIC_LASTP_N'}</a></b>]
                                                                 : qq[-$t->{'TOPIC_LASTP_N'}-];
        my $event_name = $db->select( TABLE   => 'calendar',
                                      KEY     => "f=$iB::IN{'f'};t=$t->{'TOPIC_ID'}",
                                      );
        $t->{'CALENDAR'} = $event_name->{'MEMBER_NAME'};
        $t->{'YEAR'} = $event_name->{'YEAR'};
        $t->{'MONTH'} = $event_name->{'MONTH'};
        $t->{'DAY'} = $event_name->{'DAY'};

        $obj->{html} .= ModCPView::render_opentopic( $t );
    }


    $obj->{html} .= ModCPView::topic_footer();
    $obj->{html} .= ModCPView::endcp();
}

sub do_openclose {
    my ($obj, $db) = @_;

    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    # Sort out the form data.
    my @topic_ids = grep { /^CHOICE_(\d+)$/ } $iB::CGI->param();

    my $global = { open => 0, closed => 0 };

    for my $id (@topic_ids) {
        $id  =~ /^CHOICE_(\d+)$/;
        $id  = $1;
        next unless $id;
        my $choice = $iB::CGI->param( 'CHOICE_'.$id );
        next unless $choice;
        $db->update( TABLE  => 'forum_topics',
                     ID     => $iB::IN{'f'},
                     KEY    => $id,
                     VALUES => { TOPIC_STATE => $choice },
                   );

        ++$global->{ $choice };
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::show_open_results( $global );
    $obj->{html} .= ModCPView::endcp();
}


################################################################
#
# MOVE TOPICS
#
################################################################

sub move_topics {
    my ($obj, $db) = @_;

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE => 'moderate_no_permission'
                   ) unless $obj->{moderator}->{ $iB::IN{'f'} }->{'MASS_MOVE'};

        # Are we a moderator of this forum?
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
    }

    $obj->{html} .= ModCPView::startcp();
    # Sort out the menu...
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;
    $obj->{html} .= ModCPView::forum_splash( $forum_info);
    $obj->{html} .= ModCPView::move_form_header();
    $obj->{html} .= ModCPView::end_forum_splash();
    $obj->{html} .= ModCPView::endcp();
}

sub process_move {
    my ($obj, $db) = @_;

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE => 'moderate_no_permission'
                   ) unless $obj->{moderator}->{ $iB::IN{'f'} }->{'MASS_MOVE'};

        # Are we a moderator of this forum?
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
    }

    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;

    my $html = qq[ <select name='destination' class='forminput'>];

    require $iB::INFO->{'IKON_DIR'}.'Data/ForumJump.pm';
    my $Forums = ForumJump->new();

    for (sort { $a <=> $b } keys %{$Forums}) {
        if ($Forums->{$_}[0] eq 'c') {
            if ($Forums->{$_}[3] ne '*') {
                next unless grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split (/,/, $Forums->{$_}[3]) );
            }
            my $dash = '-' x length($Forums->{$_}[2]);
            $html .= qq[<option value="">&nbsp;\n
                        <option value="">&gt;$Forums->{$_}[2]\n
                        <option value="">&nbsp;&nbsp;$dash\n
                       ];
        } elsif ($Forums->{$_}[0] eq 'f') {
            if ($Forums->{$_}[3] ne '*') {
                next unless grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split (/,/, $Forums->{$_}[3]) );
            }
            $html .= qq[<option value="$Forums->{$_}[1]">&nbsp;&nbsp;&nbsp;+- $Forums->{$_}[2]\n];
        }
    }

    $html .= qq[</select>\n];

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ( defined($iB::IN{'DAYS'}) and defined($iB::IN{'LIMIT'}) );

    # Build the query...
    my $date_cut = " and TOPIC_START_DATE > ".(time-(60*60*24*$iB::IN{'DAYS'}));
    my $order    = $iB::IN{'ORDER'} eq 'asc' ? 'A-Z' : 'Z-A';

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );
    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;

    # Get the topics...
    my $topics = $db->query( TABLE    => 'forum_topics',
                             ID       => $iB::IN{'f'},
                             WHERE    => "FORUM_ID == $iB::IN{'f'} and APPROVED == 1$date_cut",
                             SORT_KEY => 'TOPIC_LAST_DATE',
                             SORT_BY  => $order,
                             RANGE    => "0 to $iB::IN{'LIMIT'}",
                           );

    unless (scalar(@{$topics}) > 0) {
        ++$obj->{bypass};
        $output->redirect_screen( TEXT => $ModCP::lang->{'no_matches'}, URL => "act=ModCP&f=$iB::IN{'f'}&CODE=move" );
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $forum_info->{'search_type'} = 'do_move';
    $obj->{html} .= ModCPView::move_ops( $html, $forum_info->{'FORUM_NAME'} );
    $obj->{html} .= ModCPView::topic_header( $forum_info );


    for my $t (@{$topics}) {
        # Convert unix time to human readable
        $t->{'TOPIC_START_DATE'} = $std->get_date( TIME => $t->{'TOPIC_START_DATE'}, METHOD => 'LONG' );
        $t->{'TOPIC_LAST_DATE'}  = $std->get_date( TIME => $t->{'TOPIC_LAST_DATE'},  METHOD => 'LONG' );

        my $select = qq!<select name='CHOICE_$t->{'TOPIC_ID'}' class='forminput'>!;
        $select .= qq!<option value='leave' selected>$ModCP::lang->{'c_leave'}</option><option value='move'>$ModCP::lang->{'st_move'}</option>!;


        $t->{'SELECT'} = $select . "</select>";

        if ($t->{'POLL_STATE'}) {$t->{'STATE'} = $iB::INFO->{'PRE_POLLS'}};
        if ($t->{'PIN_STATE'} == 1) { $t->{'STATE'} = $iB::INFO->{'PRE_PINNED'}};
        if ($t->{'MOVED_TO'}) { $t->{'STATE'} = $iB::INFO->{'PRE_MOVED'}};

        $t->{'LAST_POSTER'} = ($t->{'TOPIC_LAST_POSTER'} != 0)   ? qq[<b><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$t->{'TOPIC_LAST_POSTER'}'>$t->{'TOPIC_LASTP_N'}</a></b>]
                                                                 : qq[-$t->{'TOPIC_LASTP_N'}-];
        my $event_name = $db->select( TABLE   => 'calendar',
                                      KEY     => "f=$iB::IN{'f'};t=$t->{'TOPIC_ID'}",
                                      );
        $t->{'CALENDAR'} = $event_name->{'MEMBER_NAME'};
        $t->{'YEAR'} = $event_name->{'YEAR'};
        $t->{'MONTH'} = $event_name->{'MONTH'};
        $t->{'DAY'} = $event_name->{'DAY'};

        $obj->{html} .= ModCPView::render_opentopic( $t );
    }


    $obj->{html} .= ModCPView::topic_footer();
    $obj->{html} .= ModCPView::endcp();
}

sub do_move {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE => 'move_no_forum'
               ) if $iB::IN{'destination'} == "&nbsp;\n";

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE => 'move_no_source'
               ) unless defined $iB::IN{'f'};


    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE => 'move_same_forum'
               ) if $iB::IN{'f'} == $iB::IN{'destination'};

    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    # Sort out the form data.
    my @topic_ids = grep { /^CHOICE_(\d+)$/ } $iB::CGI->param();
    my @real_ids;


    my $global = { leave => 0, move => 0 };

    for my $id (@topic_ids) {
        $id  =~ /^CHOICE_(\d+)$/;
        $id  = $1;
        next unless $id;
        my $choice = $iB::CGI->param( 'CHOICE_'.$id );
        next unless $choice;
        if ($choice eq 'move') {
            push @real_ids, $id;
        }
        ++$global->{ $choice };
    }

    my $info = $mod->move_topic( SOURCE       => $iB::IN{'f'},
                                 DESTINATION  => $iB::IN{'destination'},
                                 TOPICS       => \@real_ids,
                                 LINK         => $iB::IN{'leave'},
                                 DB           => $db,
                               );

    $obj->_reset_forum( FORUM      => $iB::IN{'f'},
                        DB         => $db,
                        ADD_POSTS  => $info->{'S_POSTS'},
                        ADD_TOPICS => $info->{'S_TOPICS'},
                      );

    $obj->_reset_forum( FORUM      => $iB::IN{'destination'},
                        DB         => $db,
                        ADD_POSTS  => $info->{'D_POSTS'},
                        ADD_TOPICS => $info->{'D_TOPICS'},
                      );

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::show_move_results( $global );
    $obj->{html} .= ModCPView::endcp();

}

################################################################
#
# TOPIC / POST PROCESSING
#
################################################################

sub watched_search {
    my ($obj, $db) = @_;

    if ($iB::IN{'POSTS'}) {
        $obj->post_search($db);
    }

    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ( defined($iB::IN{'DAYS'}) and defined($iB::IN{'LIMIT'}) );

    # Build the query...
    my $date_cut = " and TOPIC_LAST_DATE > ".(time-(60*60*24*$iB::IN{'DAYS'}));
    my $order    = $iB::IN{'ORDER'} eq 'asc' ? 'A-Z' : 'Z-A';

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );
    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;

    # Get the topics...
    my $topics = $db->query( TABLE    => 'forum_topics',
                             ID       => $iB::IN{'f'},
                             WHERE    => "FORUM_ID == $iB::IN{'f'} and WATCHED == 1$date_cut",
                             SORT_KEY => 'TOPIC_LAST_DATE',
                             SORT_BY  => $order,
                             RANGE    => "0 to $iB::IN{'LIMIT'}",
                           );

    unless (scalar(@{$topics}) > 0) {
        ++$obj->{bypass};
        $output->redirect_screen( TEXT => $ModCP::lang->{'no_matches'}, URL => "act=ModCP&f=$iB::IN{'f'}" );
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $forum_info->{'search_type'} = 'watched_topics';
    $obj->{html} .= ModCPView::watched_search_header( $forum_info );

    for my $t (@{$topics}) {
        # Convert unix time to human readable
        $t->{'TOPIC_START_DATE'} = $std->get_date( TIME => $t->{'TOPIC_START_DATE'}, METHOD => 'LONG' );
        $t->{'TOPIC_LAST_DATE'}  = $std->get_date( TIME => $t->{'TOPIC_LAST_DATE'},  METHOD => 'LONG' );

        $obj->{html} .= ModCPView::render_watched( { TOPIC => $t } );
    }


    $obj->{html} .= ModCPView::watched_search_footer();
    $obj->{html} .= ModCPView::endcp();
}


sub topic_search {
    my ($obj, $db) = @_;

    if ($iB::IN{'POSTS'}) {
        $obj->post_search($db);
    }

    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ( defined($iB::IN{'DAYS'}) and defined($iB::IN{'LIMIT'}) );

    # Build the query...
    my $date_cut = " and TOPIC_START_DATE > ".(time-(60*60*24*$iB::IN{'DAYS'}));
    my $order    = $iB::IN{'ORDER'} eq 'asc' ? 'A-Z' : 'Z-A';

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );
    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;

    # Get the topics...
    my $topics = $db->query( TABLE    => 'forum_topics',
                             ID       => $iB::IN{'f'},
                             WHERE    => "FORUM_ID == $iB::IN{'f'} and APPROVED == 0$date_cut",
                             SORT_KEY => 'TOPIC_START_DATE',
                             SORT_BY  => $order,
                             RANGE    => "0 to $iB::IN{'LIMIT'}",
                           );

    unless (scalar(@{$topics}) > 0) {
        ++$obj->{bypass};
        $output->redirect_screen( TEXT => $ModCP::lang->{'no_matches'}, URL => "act=ModCP&f=$iB::IN{'f'}" );
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $forum_info->{'search_type'} = 'process_topics';
    $obj->{html} .= ModCPView::search_header( $forum_info );

    for my $t (@{$topics}) {
        # Convert unix time to human readable
        $t->{'TOPIC_START_DATE'} = $std->get_date( TIME => $t->{'TOPIC_START_DATE'}, METHOD => 'LONG' );
        $t->{'TOPIC_LAST_DATE'}  = $std->get_date( TIME => $t->{'TOPIC_LAST_DATE'},  METHOD => 'LONG' );

        # Can we delete queued topics?
        if ($obj->{moderator}->{ $iB::IN{'f'} }->{'TOPIC_Q'} or $obj->{type} eq 'all') {
            $t->{'DELETE'} = qq!<option value='DELETE' selected>$ModCP::lang->{'c_delete'}</option>!;
        }

        # Get the corresponding post
        my $post = $db->query(  TABLE  => 'mod_posts',
                                MATCH  => 'ONE',
                                WHERE  => "TOPIC_ID == '$t->{'TOPIC_ID'}' and TYPE eq 'new'",
                             );

        $post->{'POST'} = substr( $post->{'POST'}, 0, 200 ) . '...';
        $post->{'POST'} = $txt->Convert_for_textfield($post->{'POST'});
        $obj->{html} .= ModCPView::render_newtopic( { TOPIC => $t, POST => $post } );
    }


    $obj->{html} .= ModCPView::search_footer();
    $obj->{html} .= ModCPView::endcp();
}


sub post_search {
    my ($obj, $db) = @_;

    if ($iB::IN{'TOPICS'}) {
        $obj->topic_search($db);
    }

    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ( defined($iB::IN{'DAYS'}) and defined($iB::IN{'LIMIT'}) );

    # Build the query...
    my $date_cut = " and POST_DATE > ".(time-(60*60*24*$iB::IN{'DAYS'}));
    my $order    = $iB::IN{'ORDER'} eq 'asc' ? 'A-Z' : 'Z-A';

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );
    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;

    # Get the topics...
    my $posts  = $db->query( TABLE    => 'mod_posts',
                             WHERE    => "FORUM_ID == $iB::IN{'f'} and TYPE ne 'new'$date_cut",
                             SORT_KEY => 'POST_DATE',
                             SORT_BY  => $order,
                             RANGE    => "0 to $iB::IN{'LIMIT'}",
                           );



    unless (scalar(@{$posts}) > 0) {
        ++$obj->{bypass};
        $output->redirect_screen( TEXT => $ModCP::lang->{'no_matches'}, URL => "act=ModCP&f=$iB::IN{'f'}" );
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $forum_info->{'search_type'} = 'process_posts';
    $obj->{html} .= ModCPView::search_header( $forum_info );

    # Set up a topics cache to save queries
    my $topic_cache = {};

    for my $p (@{$posts}) {
        if ( $topic_cache->{ $p->{'TOPIC_ID'} } ) {
            push @{ $topic_cache->{ $p->{'TOPIC_ID'} } }, $p;
        } else {
             $topic_cache->{ $p->{'TOPIC_ID'} } = [];
             push @{ $topic_cache->{ $p->{'TOPIC_ID'} } }, $p;
        }
    }


    for my $t (keys %{ $topic_cache }) {
        my $this_topic = $db->select( TABLE  => 'forum_topics',
                                      ID     => $iB::IN{'f'},
                                      KEY    => $t,
                                    );
        # Convert unix time to human readable
        $this_topic->{'TOPIC_START_DATE'} = $std->get_date( TIME => $this_topic->{'TOPIC_START_DATE'}, METHOD => 'LONG' );
        $this_topic->{'TOPIC_LAST_DATE'}  = $std->get_date( TIME => $this_topic->{'TOPIC_LAST_DATE'},  METHOD => 'LONG' );

        # Can we delete queued topics?
        if ($obj->{moderator}->{ $iB::IN{'f'} }->{'TOPIC_Q'} or $obj->{type} eq 'all') {
            $this_topic->{'DELETE'} = qq!<option value='DELETE' selected>$ModCP::lang->{'c_delete'}</option>!;
        }

        $obj->{html} .= ModCPView::render_topic_title( $this_topic );

        # loop through the posts to print
        for my $i (@{ $topic_cache->{ $t } }) {
            if ($i->{'AUTHOR_TYPE'}) {
                my $member = $db->select( TABLE => 'member_profiles',
                                          KEY   => $i->{'AUTHOR'},
                                        );
                $i->{'MEMBER_NAME'} = qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$i->{'AUTHOR'}" target='_blank'><b><$member->{'MEMBER_NAME'}</b></a>!;
                undef $member;
            } else {
                $i->{'MEMBER_NAME'} = $i->{'AUTHOR'};
            }
            $i->{'POST'}       = substr( $i->{'POST'}, 0, 200 ) . '...';
            $i->{'POST_DATE'}  = $std->get_date( TIME => $i->{'POST_DATE'},  METHOD => 'LONG' );
            $i->{'POST'} = $txt->Convert_for_textfield($i->{'POST'});
            $obj->{html} .= ModCPView::render_topic_post( { POST => $i, TOPIC => $this_topic } );
        }
    }
    $obj->{html} .= ModCPView::search_footer();
    $obj->{html} .= ModCPView::endcp();
}


sub process_posts {
    my ($obj, $db) = @_;

    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    # Sort out the form data.
    my @post_ids = grep { /^CHOICE_(\d+)$/ } $iB::CGI->param();

    # Lets sort them into topic order.
    my $topic_ids = {};

    for my $i ( @post_ids ) {
        $i               =~ /^CHOICE_(\d+)$/;
        my $modpost_id   = $1;
        my $realpost_id  = $iB::CGI->param('POST_'   .$modpost_id);
        my $realtopic_id = $iB::CGI->param('TOPIC_'  .$modpost_id);
        my $choice       = $iB::CGI->param('CHOICE_' .$modpost_id);
        if ($topic_ids->{ $realtopic_id }) {
            push @{ $topic_ids->{ $realtopic_id } }, {
                                                        MODPOST_ID  => $modpost_id,
                                                        REALPOST_ID => $realpost_id,
                                                        CHOICE      => $choice,
                                                     };
        } else {
            $topic_ids->{ $realtopic_id } = [ ];
            push @{ $topic_ids->{ $realtopic_id } }, {
                                                        MODPOST_ID  => $modpost_id,
                                                        REALPOST_ID => $realpost_id,
                                                        CHOICE      => $choice,
                                                     };
        }
    }

    # Set up some counters

    my $global = {
                   APPROVED => 0,
                   LEFT     => 0,
                   DELETED  => 0,
                 };

    my $added_posts = {};
    # First, lets sort out the posts.
    for my $i (keys %{ $topic_ids }) {

        my $t_data = $db->select( TABLE  => 'forum_topics',
                                  ID     => $iB::IN{'f'},
                                  KEY    => $i,
                                );
        for my $t (@{ $topic_ids->{ $i } }) {

            my $topic_id  = $i;
            my $post_id   = $t->{'MODPOST_ID'};
            my $r_post_id = $t->{'REALPOST_ID'};
            my $choice    = $t->{'CHOICE'};
            $added_posts->{ $t } = {
                                     ADDED_POSTS      => 0,
                                     LAST_POSTER_NAME => "",
                                     LAST_POSTER_ID   => "",
                                     LAST_POST_TIME   => "",
                                   };
            # Did we choose to leave this post alone?
            ++$global->{'LEFT'} and next if $choice eq 'LEAVE';
            if ($choice eq 'DELETE') {
                ++$global->{'DELETED'};
                $db->delete( TABLE => 'mod_posts',
                             KEY   => $post_id,
                           );
                $db->delete( TABLE  => 'forum_posts',
                             DBID   => 'f'.$iB::IN{'f'},
                             ID     => $topic_id,
                             KEY    => $r_post_id,
                           );
            } elsif ($choice eq 'APPROVE') {
                ++$global->{'APPROVED'};
                my $p_data = $db->select( TABLE => 'mod_posts',
                                          KEY   => $post_id,
                                        );

                $db->update( TABLE  => 'forum_posts',
                             DBID   => 'f'.$iB::IN{'f'},
                             ID     => $topic_id,
                             KEY    => $r_post_id,
                             VALUES => { QUEUED    => 0 },
                           );

                $db->delete( TABLE => 'mod_posts',
                             KEY   => $post_id,
                           );
                # Update the search records
                $s_log->compile_entry(     DB    => $db,
                                           TOPIC => $t_data,
                                           FORUM => $forum_info,
                                           POST  => $p_data,
                                     );

                # Sort out our topic stuff
                ++$added_posts->{ $i }->{'ADDED_POSTS'};
                if ($p_data->{'POST_DATE'} > $added_posts->{ $i }->{'LAST_POST_TIME'}) {
                    $added_posts->{ $i }->{'LAST_POST_TIME'}   = $p_data->{'POST_DATE'};
                    $added_posts->{ $i }->{'LAST_POSTER_NAME'} = $p_data->{'AUTHOR'};
                }

                # Update the members post count.
                if ($p_data->{'AUTHOR_TYPE'}) {
                    my $member = $db->select( TABLE  => 'member_profiles',
                                              KEY    => $p_data->{'AUTHOR'},
                                            );
                    ++$member->{'MEMBER_POSTS'};
                    $db->update( TABLE  => 'member_profiles',
                                 KEY    => $p_data->{'AUTHOR'},
                                 VALUES => { MEMBER_POSTS => $member->{'MEMBER_POSTS'} }
                               );
                    # If it's a member, and it's to be used in the last post info
                    # column, we'd better update our hash for the member ID and name.
                    if ($p_data->{'POST_DATE'} == $added_posts->{ $i }->{'LAST_POST_TIME'}) {
                        $added_posts->{ $i }->{'LAST_POSTER_NAME'} = $member->{'MEMBER_NAME'};
                        $added_posts->{ $i }->{'LAST_POSTER_ID'}   = $member->{'MEMBER_ID'};
                    }
                }
            }
        }
    }

    # Now lets update each topic with the info we stored in our topic specfic hash reference

    for my $k (keys %{ $topic_ids }) {

        if ($added_posts->{ $k }->{'ADDED_POSTS'}) {
            my $t_data = $db->select( TABLE  => 'forum_topics',
                                      ID     => $iB::IN{'f'},
                                      KEY    => $k,
                                    );
            $t_data->{'TOPIC_POSTS'}      += $added_posts->{ $k }->{'ADDED_POSTS'};
            $t_data->{'TOPIC_LAST_DATE'}   = $added_posts->{ $k }->{'LAST_POST_TIME'};
            $t_data->{'TOPIC_LAST_POSTER'} = $added_posts->{ $k }->{'LAST_POSTER_ID'};
            $t_data->{'TOPIC_LASTP_N'}     = $added_posts->{ $k }->{'LAST_POSTER_NAME'};

            $db->update( TABLE  => 'forum_topics',
                         ID     => $iB::IN{'f'},
                         KEY    => $k,
                         VALUES => $t_data,
                       );
        }
        if ( defined $iB::INFO->{'NEWS_SHOW_S'} and ($iB::INFO->{'NEWS_SHOW_S'} == '1') ) {
            require SSI::Parser;
            SSI::Parser::parse( DB       => $db,
                                TEMPLATE => 'news',
                             );
        }
        if ( defined $iB::INFO->{'NEWS_TIKER'} and ($iB::INFO->{'NEWS_TIKER'} eq '1') ) {
            require SSI::Parser;
            SSI::Parser::parse( DB       => $db,
                                TEMPLATE => 'tiker',
                             );
        }
    }


    if ($global->{'APPROVED'}) {
        $obj->_reset_forum( FORUM      => $iB::IN{'f'},
                            ADD_POSTS  => $global->{'APPROVED'},
                            ADD_TOPICS => 0,
                            DB         => $db,
                          );
        $obj->_reset_stats(
                            ADD_POSTS  => $global->{'APPROVED'},
                            ADD_TOPICS => 0,
                          );

    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::show_post_results( $global );
    $obj->{html} .= ModCPView::endcp();

}

sub process_topics {
    my ($obj, $db) = @_;

    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    # Sort out the form data.
    my @topic_ids = grep { /^CHOICE_(\d+)$/ } $iB::CGI->param();

    # Set up some counters

    my $count = {
                  APPROVED => 0,
                  LEFT     => 0,
                  DELETED  => 0,
                };

    for my $i(@topic_ids) {
        $i             =~ /^CHOICE_(\d+)$/;
        my $topic_id   = $1;
        my $post_id    = $iB::CGI->param('POST_'    .$topic_id);
        my $r_post_id  = $iB::CGI->param('R_POST_'  .$topic_id);
        my $choice     = $iB::CGI->param('CHOICE_'  .$topic_id);
        # Did we choose to leave this topic alone?
        ++$count->{'LEFT'} and next if $choice eq 'LEAVE';
        if ($choice eq 'DELETE') {
            ++$count->{'DELETED'};
            $db->delete( TABLE => 'mod_posts',
                         KEY   => $post_id,
                       );
            $db->delete( TABLE => 'forum_topics',
                         ID    => $iB::IN{'f'},
                         KEY   => $topic_id,
                       );
            $db->delete( TABLE  => 'forum_posts',
                         DBID   => 'f'.$iB::IN{'f'},
                         ID     => $topic_id,
                         KEY    => $r_post_id,
                       );
        } elsif ($choice eq 'APPROVE') {
            ++$count->{'APPROVED'};
            my $p_data = $db->select( TABLE => 'mod_posts',
                                      KEY   => $post_id,
                                    );
            my $t_data = $db->select( TABLE => 'forum_topics',
                                      ID    => $iB::IN{'f'},
                                      KEY   => $topic_id,
                                    );
            $db->update( TABLE  => 'forum_topics',
                         ID     => $iB::IN{'f'},
                         KEY    => $topic_id,
                         VALUES => { APPROVED  => 1 },
                       );
            $db->update( TABLE  => 'forum_posts',
                         DBID   => 'f'.$iB::IN{'f'},
                         ID     => $topic_id,
                         KEY    => $r_post_id,
                         VALUES => { QUEUED    => 0 },
                       );
            $db->delete( TABLE => 'mod_posts',
                         KEY   => $post_id,
                       );

            # Update the search records
            $s_log->compile_entry(     DB    => $db,
                                       TOPIC => $t_data,
                                       FORUM => $forum_info,
                                       POST  => $p_data,
                                 );

            # Update the members post count.
            if ($p_data->{'AUTHOR_TYPE'}) {
                my $member = $db->select( TABLE  => 'member_profiles',
                                          KEY    => $p_data->{'AUTHOR'},
                                        );
                ++$member->{'MEMBER_POSTS'};
                $db->update( TABLE  => 'member_profiles',
                             KEY    => $p_data->{'AUTHOR'},
                             VALUES => { MEMBER_POSTS => $member->{'MEMBER_POSTS'} }
                           );
            }
        }
        if ( defined $iB::INFO->{'NEWS_SHOW_S'} and ($iB::INFO->{'NEWS_SHOW_S'} == '1') ) {
            require SSI::Parser;
            SSI::Parser::parse( DB       => $db,
                                TEMPLATE => 'news',
                             );
        }
        if ( defined $iB::INFO->{'NEWS_TIKER'} and ($iB::INFO->{'NEWS_TIKER'} eq '1') ) {
            require SSI::Parser;
            SSI::Parser::parse( DB       => $db,
                                TEMPLATE => 'tiker',
                             );
        }
    }

    if ($count->{'APPROVED'}) {
        $obj->_reset_forum( FORUM      => $iB::IN{'f'},
                            ADD_POSTS  => 0,
                            ADD_TOPICS => $count->{'APPROVED'},
                            DB         => $db,
                          );
        $obj->_reset_stats(
                            ADD_POSTS  => 0,
                            ADD_TOPICS => $count->{'APPROVED'},
                          );
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::show_topic_results( $count );
    $obj->{html} .= ModCPView::endcp();

}

sub _reset_stats {
    my $obj = shift;
    my %IN  = (
                ADD_POSTS  => 0,
                ADD_TOPICS => 0,
                DEL_POSTS  => 0,
                DEL_TOPICS => 0,
            @_,
              );

    $IN{'ADD_POSTS'}  = $IN{'ADD_POSTS'}  - $IN{'DEL_POSTS'};
    $IN{'ADD_TOPICS'} = $IN{'ADD_TOPICS'} - $IN{'DEL_TOPICS'};

    my $stats = {};

    $stats->{'TOTAL_REPLIES'} = '-'.$IN{'DEL_POSTS'};
    $stats->{'TOTAL_TOPICS'}  = '-'.$IN{'DEL_TOPICS'};

    $std->ib_stats( $stats );
}


sub _reset_forum {
    my $obj = shift;
    my %IN  = ( FORUM      => "",
                DEL_POSTS  => 0,
                DEL_TOPICS => 0,
                ADD_POSTS  => 0,
                ADD_TOPICS => 0,
                DB         => "",
            @_,
              );

    my $db = $IN{'DB'};

    my $s_forum = $db->select( TABLE => 'forum_info',
                               KEY   => $IN{'FORUM'},
                             );

    # Sort out the last post stuff
    my $old_topic = $db->query( TABLE    => 'forum_topics',
                                ID       => $IN{'FORUM'},
                                WHERE    => "FORUM_ID == $IN{'FORUM'} and APPROVED == 1",
                                RANGE    => "0 to 1",
                                SORT_KEY => "TOPIC_LAST_DATE",
                                SORT_BY  => "Z-A"
                              );

    my ($topics, $posts);

    $topics = $IN{DEL_TOPICS} ? $s_forum->{'FORUM_TOPICS'} - $IN{'DEL_TOPICS'} : $s_forum->{'FORUM_TOPICS'} + $IN{'ADD_TOPICS'};
    $posts  = $IN{DEL_POSTS}  ? $s_forum->{'FORUM_POSTS'}  - $IN{'DEL_POSTS'}  : $s_forum->{'FORUM_POSTS'}  + $IN{'ADD_POSTS'};

    $topics = 0 if $topics < 0;
    $posts  = 0 if $posts  < 0;

    $db->update(  TABLE  => 'forum_info',
                  KEY    => $IN{'FORUM'},
                  VALUES => { L_TOPIC_TITLE       => $old_topic->[0]->{'TOPIC_TITLE'} || '',
                              L_TOPIC_ID          => $old_topic->[0]->{'TOPIC_ID'} || '',
                              FORUM_LAST_POST     => $old_topic->[0]->{'TOPIC_LAST_DATE'},
                              FORUM_LAST_POSTER_N => $old_topic->[0]->{'TOPIC_LASTP_N'} || '',
                              FORUM_LAST_POSTER   => $old_topic->[0]->{'TOPIC_LAST_POSTER'} || '',
                              FORUM_TOPICS        => $topics,
                              FORUM_POSTS         => $posts,
                            },
               );
}

sub _main_splash {
    my ($obj, $db) = @_;

    # Sort out the menu...
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;

    $obj->{html} .= ModCPView::main_splash();

    # Get the forum/cat combo

    my $cats   = $db->query( TABLE     => 'categories',
                             SORT_KEY  => 'CAT_POS',
                             SORT_BY   => 'A-Z',
                             MATCH     => 'ALL',
                           );

    my $forums = $db->query( TABLE     => 'forum_info',
                             SORT_KEY  => 'FORUM_POSITION',
                             SORT_BY   => 'A-Z',
                             MATCH     => 'ALL'
                           );

    for my $this_cat (@{$cats}) {

        # We assume two things:
        #
        # 1) If we are a moderator on this forum, we can read/reply and start threads.
        # 2) No one is stupid enough to make it otherwise.

        my @these_cat_forums = grep { $_->{'CATEGORY'} == $this_cat->{'CAT_ID'} } @{ $forums };
        # which ones do we moderate?
        my @moderated_forums;
        for my $life (@these_cat_forums) {
            if ( ($obj->{type} eq 'all') or (exists $obj->{moderator}->{ $life->{'FORUM_ID'} }) ) {
                push @moderated_forums, $life;
            }
        }

        if (scalar @moderated_forums > 0) {
            $obj->{html} .= ModCPView::render_cat( $this_cat );
            for my $i (@moderated_forums) {
                # Get the number of topics awaiting moderation
        my $watched = $db->query( TABLE => 'forum_topics',
                      ID    => $i->{'FORUM_ID'},
                      WHERE => "WATCHED == 1 and FORUM_ID == '$i->{'FORUM_ID'}'",
                      COLUMNS => ['TOPIC_ID'],
                    );

                my $need_mod = $db->query( TABLE   => 'forum_topics',
                                           ID      => $i->{'FORUM_ID'},
                                           WHERE   => "APPROVED == 0 and FORUM_ID == '$i->{'FORUM_ID'}'",
                                           COLUMNS => ['TOPIC_ID'],
                                         );
        $i->{'TOPICS_WATCHED'} = scalar(@{$watched}) > 0 ? scalar(@{$watched}) : 0;
                $i->{'TOPICS_NOT_APPROVED'} = scalar(@{$need_mod}) > 0 ? scalar(@{$need_mod}) : 0;
                $i->{'FORUM_LAST_POST'} = $std->get_date( TIME => $i->{'FORUM_LAST_POST'}, METHOD => 'LONG');
                $obj->{html} .= ModCPView::render_forum( $i );
            }
        }
    }

    $obj->{html} .= ModCPView::end_main_splash();
}

sub merge {
    my ($obj, $db) = @_;

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE => 'moderate_no_permission'
                   ) unless $obj->{moderator}->{ $iB::IN{'f'} }->{'MASS_MOVE'};

        # Are we a moderator of this forum?
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
    }

    $obj->{html} .= ModCPView::startcp();
    # Sort out the menu...
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;

    # Get the forum info
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );

    $ModCP::lang->{'f_moderate_t'} =~ s!<# FORUM NAME #>!$forum_info->{'FORUM_NAME'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# POSTS #>!$forum_info->{'FORUM_POSTS'}!i;
    $ModCP::lang->{'f_moderate_t'} =~ s!<# TOPICS #>!$forum_info->{'FORUM_TOPICS'}!i;
    $obj->{html} .= ModCPView::forum_splash( $forum_info);
    $obj->{html} .= ModCPView::merge_form_header();
    $obj->{html} .= ModCPView::end_forum_splash();
    $obj->{html} .= ModCPView::endcp();
}

sub td_select {
    my $obj = shift;

    my %IN = ( TEXT     => "",
               NAME     => "",
               SIZE     => "",
               MULTIPLE => "",
               DATA     => [],
               VALUES   => undef,
               REQ      => "",
               JS       => "",
               @_,
             );

    my $req = $IN{'REQ'} ? " <font class='h'>*</font>" : '';

    my $text = $IN{'MULTIPLE'} ? $ModCP::lang->{'method_select'} : '';

    $IN{'SIZE'}     = "size='$IN{'SIZE'}'" if $IN{'SIZE'};
    $IN{'MULTIPLE'} = 'multiple' if $IN{'MULTIPLE'};

    my $return = qq!<select name='$IN{'NAME'}' $IN{'SIZE'} $IN{'MULTIPLE'} class='forminput' $IN{'JS'}>\n!;

    if (ref($IN{'VALUES'}) eq 'ARRAY') {
        my @values = @{ $IN{'VALUES'} };
        $IN{'VALUES'} = {};
        for (@values) {
            $IN{'VALUES'}->{$_} = 1;
        }
    } else {
        my $value = $IN{'VALUES'};
        $IN{'VALUES'} = {};
        $IN{'VALUES'}->{$value} = 1;
    }

    for my $i (@{ $IN{'DATA'} }) {
        my $selected = ' selected' if $i->{'VALUE'} ne '' and exists $IN{'VALUES'}->{ $i->{'VALUE'} };
        $return .= qq! <option value="$i->{'VALUE'}"$selected>$i->{'NAME'}</option>\n!;
    }

    $return .= '</select>';

    return qq~
      <tr>
      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%' align='left' valign='top'><font class='t'>$IN{'TEXT'}$req</font></td>
      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%' align='left'>$return $text</td>
      </tr>
~;
}

sub select_merge {
    my ($obj, $db) = @_;

    unless ($obj->{type} eq 'all') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE => 'moderate_no_permission'
                   ) unless $obj->{moderator}->{ $iB::IN{'f'} }->{'MASS_MOVE'};

        # Are we a moderator of this forum?
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'moderate_no_permission'
                   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
    }


    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'DAYS'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'LIMIT'} =~ s!^(\d+)$!$1!g;
    $iB::IN{'LIMIT'} =~ s!^(\d+)$!$1!g;
    my $limit = $iB::IN{'LIMIT'};
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ($iB::IN{'LIMIT'} and $iB::IN{'DAYS'});


    my $date = time - ($iB::IN{'DAYS'} * 3600 *24);

    my $get_topic = $db->query( TABLE    => 'forum_topics',
                                ID       => "$iB::IN{'f'}",
                                WHERE    => "TOPIC_LAST_DATE > '$date' and FORUM_ID == '$iB::IN{'f'}'",
                                SORT_KEY => 'TOPIC_LAST_DATE',
                                RANGE    => "0 to $limit",
                                SORT_BY  => 'Z-A'
                                );
    my @choice;

    for my $t (@{ $get_topic } ) {
        push @choice, { NAME => "&gt;--". $t->{'TOPIC_ID'}."-". $t->{'TOPIC_TITLE'} , VALUE => $t->{'TOPIC_ID'} };
    }
    $obj->{html} .= ModCPView::startcp_merge();

    # Sort out the menu...
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .=  $obj->td_select( TEXT     => $ModCP::lang->{'merge_source'},
                               NAME     => 'SOURCE_TOPIC',
                               SIZE     => 10,
                               REQ      => 1,
                               MULTIPLE => 0,
                               DATA     => \@choice,
                             );

   $obj->{html} .=  $obj->td_select( TEXT     => $ModCP::lang->{'merge_q'},
                              NAME     => 'DELETE_SOURCE',
                              SIZE     => 1,
                              REQ      => 1,
                              VALUES   => 1,
                              DATA     => [ { NAME => $ModCP::lang->{'merge_ch_1'}, VALUE => '1' },
                                             { NAME => $ModCP::lang->{'merge_ch_2'}, VALUE => '2' },
                                             { NAME => $ModCP::lang->{'merge_ch_3'},  VALUE => '0' }, ]
                             );

    $obj->{html} .=  $obj->td_select( TEXT     => $ModCP::lang->{'merge_target'},
                               NAME     => 'TARGET_TOPIC',
                               SIZE     => 10,
                               REQ      => 1,
                               MULTIPLE => 0,
                               DATA     => \@choice,
                             );
    $obj->{html} .= ModCPView::merge_close_form();
    $obj->{html} .= ModCPView::endcp();
}

sub do_merge {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'please_complete_form'
               ) unless ($iB::IN{'SOURCE_TOPIC'} and $iB::IN{'TARGET_TOPIC'});

    $std->Error( DB=>,$db, MESSAGE => 'diff_topic_target') unless ($iB::IN{'TARGET_TOPIC'} ne $iB::IN{'SOURCE_TOPIC'});

    my $t_source = $iB::IN{'SOURCE_TOPIC'};
    my $t_target = $iB::IN{'TARGET_TOPIC'};
    my $forum = $iB::IN{'f'};

    $obj->{'TOPIC'}->{'TOPIC_STATE'} = 'closed';

    $db->update(  TABLE  => 'forum_topics',
                  KEY    => $t_source,
                  ID     => $forum,
                  VALUES => $obj->{'TOPIC'},
                )        || die $db->{'error'};
    delete $obj->{'TOPIC'};

    my $source_posts = $db->query( TABLE    => 'forum_posts',
                                   DBID     => 'f'.$forum,
                                   ID       => $t_source,
                                   WHERE  => "FORUM_ID == '$forum' and TOPIC_ID == '$t_source'",
                                 );

   for my $p (@{$source_posts}) {
            delete ($p->{'POST_ID'});
            $p->{'TOPIC_ID'} = $t_target;
            $p->{'FORUM_ID'} = $forum;

            $db->insert( TABLE  => 'forum_posts',
                         DBID   => 'f'.$forum,
                         ID     => $t_target,
                         VALUES => $p
                       );
        }

    if ($iB::IN{'DELETE_SOURCE'} eq '1') {

                $db->delete(  TABLE  => 'forum_topics',
                              ID     => $forum,
                              KEY    => $t_source,
                           );

                $db->delete( TABLE   => 'forum_posts',
                             DBID    => 'f'.$forum,
                             ID      => $t_source,
                             WHERE   => "TOPIC_ID == $t_source"
                           );
                           }

    elsif ($iB::IN{'DELETE_SOURCE'} eq '2') {

            my $breadcrumb = 'link';

            $db->update(  TABLE  => 'forum_topics',
                          ID     => $forum,
                          KEY    => $t_source,
                          VALUES => { TOPIC_STATE  => $breadcrumb ,
                                      MOVED_TO     => $forum.';'.$t_target,
                                      PIN_STATE    => 0,
                                    }
                      );

                $db->delete( TABLE   => 'forum_posts',
                             DBID    => 'f'.$forum,
                             ID      => $t_source,
                             WHERE   => "TOPIC_ID == $t_source"
                           );
                           }

    my $new_topic = $db->query(   TABLE    => 'forum_posts',
                                  DBID     => 'f'.$forum,
                                  ID       => $t_target,
                                  WHERE    => "TOPIC_ID == $t_target",
                               );
    my $replies = 0;
    my $last_post = {};
    my @delete;

    for my $i (@{$new_topic}) {
        # Don't intefere with any queued posts..
        next if $i->{'QUEUED'};
        # Check to see if this is a duplicate post.
        if ($i->{'POST'} eq $last_post->{'POST'} and $i->{'AUTHOR'} eq $last_post->{'AUTHOR'}) {
            push @delete, $i->{'POST_ID'};
            next;
        } else {
            $last_post->{'POST'}   = $i->{'POST'};
            $last_post->{'AUTHOR'} = $i->{'AUTHOR'};
        }
        ++$replies;
    }

    # As the $replies actually equals the number of replies PLUS the first post,
    # we need to remove one from the counter to make it accurate.

    --$replies;

    # Safety check, lets make sure it doesn't fall into silly numbers

    $replies = 0 if $replies < 0;

    my $stats = {};

    my $del_count = scalar (@delete) || 0;

    # Do we have any to delete?

    if (scalar (@delete) > 0) {

        $db->delete(  TABLE    => 'forum_posts',
                      DBID     => 'f'.$forum,
                      ID       => $t_target,
                      KEY      => \@delete,
                   );

        $obj->{'FORUM'}->{'FORUM_POSTS'} -= $del_count;

        $stats->{'TOTAL_REPLIES'}       = '-'.$del_count;
        $std->ib_stats($stats);

        #Sort out the last poster details in topic/board view

        my $old_post = $db->query( TABLE    => 'forum_posts',
                                   DBID     => 'f'.$forum,
                                   ID       => $t_target,
                                   COLUMNS  => ['POST_DATE', 'AUTHOR', 'AUTHOR_TYPE'],
                                   WHERE    => "TOPIC_ID == $t_target and QUEUED != 1",
                                   RANGE    => '0 to 1',
                                   SORT_KEY => 'POST_DATE',
                                   SORT_BY  => 'Z-A'
                                 );

        $obj->{'TOPIC'}->{'TOPIC_LAST_DATE'}   = $old_post->[0]->{'POST_DATE'};

        if ($old_post->[0]->{'AUTHOR_TYPE'}) {

            my $old_member = $mem->LoadMember( DB => $db, KEY => $old_post->[0]->{'AUTHOR'}, METHOD => 'by id');
            $obj->{'TOPIC'}->{'TOPIC_LAST_POSTER'} = $old_member->{'MEMBER_ID'};
            $obj->{'TOPIC'}->{'TOPIC_LASTP_N'}     = $old_member->{'MEMBER_NAME'};

        } else {

            $obj->{'TOPIC'}->{'TOPIC_LAST_POSTER'} = 0;
            $obj->{'TOPIC'}->{'TOPIC_LASTP_N'}     = $old_post->[0]->{'AUTHOR'};

        }


        if ($obj->{'.topic_id'} == $obj->{'FORUM'}->{'L_TOPIC_ID'}) {

            $obj->{'FORUM'}->{'FORUM_LAST_POST'}     = $obj->{'TOPIC'}->{'TOPIC_LAST_DATE'};
            $obj->{'FORUM'}->{'FORUM_LAST_POSTER_N'} = $obj->{'TOPIC'}->{'TOPIC_LASTP_N'};
            $obj->{'FORUM'}->{'FORUM_LAST_POSTER'}   = $obj->{'TOPIC'}->{'TOPIC_LAST_POSTER'};

        }

        $db->update(  TABLE  => 'forum_info',
                      KEY    => $forum,
                      VALUES => $obj->{'FORUM'}
                   );
    }

    #update the topic counter.

    $obj->{'TOPIC'}->{'TOPIC_POSTS'} = $replies;

    $db->update(  TABLE  => 'forum_topics',
                  KEY    => $t_target,
                  ID     => $forum,
                  VALUES => $obj->{'TOPIC'}
                )        || die $db->{'error'};

    my $newer_t = $db->query( TABLE    => 'forum_topics',
                              ID       => "$iB::IN{'f'}",
                              WHERE    => "TOPIC_ID == $t_target",
                                    );

    my $post_count = $db->count( TABLE  => 'forum_posts',
                                 DBID   => 'f'.$forum,
                                 ID     => '',
                                 WHERE  => "FORUM_ID == $forum and QUEUED != '1'",
                               );

    my $topic_count = $db->count( TABLE => 'forum_topics',
                                  ID    => $forum,
                                  WHERE  => "FORUM_ID == $forum and APPROVED == 1",
                                );

    #XXX We need the replies only, so we substract the no. topics from the count

    $post_count -= $topic_count;

    $post_count  = 0 if $post_count  < 0;
    $topic_count = 0 if $topic_count < 0;

    $db->update( TABLE  => 'forum_info',
                 KEY    => $forum,
                 VALUES => { FORUM_TOPICS   => $topic_count,
                             FORUM_POSTS    => $post_count,
                           }
               );

    # Write the log..
    $db->insert(  TABLE  => 'moderator_logs',
                  VALUES => { FORUM_ID     => $forum,
                              TOPIC_ID     => $t_target,
                              POST_ID      => undef,
                              MEMBER_ID    => $iB::MEMBER->{'MEMBER_ID'},
                              MEMBER_NAME  => $iB::MEMBER->{'MEMBER_NAME'},
                              REMOTE_ADDR  => $iB::IN{'IP_ADDRESS'},
                              HTTP_REFERER => $ENV{'HTTP_REFERER'},
                              TIME         => time,
                              TOPIC_TITLE  => 'Merged in '.$newer_t->[0]->{'TOPIC_TITLE'},
                              ACTION       => "Merge a topic",
                              QUERY_STRING => $ENV{'QUERY_STRING'},
                            },
               );

    my $choice_t = $ModCP::lang->{'result5'};
    if ($iB::IN{'DELETE_SOURCE'} eq '1') {
    $choice_t = $ModCP::lang->{'result2'};
    }
    elsif ($iB::IN{'DELETE_SOURCE'} eq '2'){
    $choice_t = $ModCP::lang->{'result4'};
    }

    my $message = "$ModCP::lang->{'result1'}$replies$ModCP::lang->{'result3'}$choice_t.";
    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::show_merge_results( $message);
    $obj->{html} .= ModCPView::endcp();

}

# added by kevaholic00
sub forum_rules {
    my ($obj, $db) = @_;

    my $forum = $db->select( TABLE     => 'forum_info',
                             KEY       => $iB::IN{'f'},
                           );

    my $rules = $db->select( TABLE     => 'forum_rules',
                             KEY       => $iB::IN{'f'},
                           );

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::forum_rules($forum, $rules);
    $obj->{html} .= ModCPView::endcp();
}

sub do_forum_rules {
    my ($obj, $db) = @_;

    $db->update( TABLE  => 'forum_info',
                 KEY    => $iB::IN{'f'},
                 VALUES => {  SHOW_RULES => $iB::IN{'SHOW_RULES'} }
               );

    my $rules = $db->select( TABLE  => 'forum_rules',
                             KEY    => $iB::IN{'f'}
                           );

    my $rules_text = $iB::CGI->param('RULES_TEXT');
##      $rules_text = $txt->Convert_for_db($rules_text);
    if (defined $rules->{'ID'}) {
        $db->update( TABLE  => 'forum_rules',
                     KEY    => $iB::IN{'f'},
                     VALUES => { RULES_TITLE  => $iB::IN{'RULES_TITLE'},
                                 RULES_TEXT   => $rules_text,
                                 LAST_UPDATE  => time,
                                 SHOW_ALL     => $iB::IN{'SHOW_ALL'}
                               }
                   );
    } else {
        $db->insert( TABLE  => 'forum_rules',
                     VALUES => { ID           => $iB::IN{'f'},
                                 RULES_TITLE  => $iB::IN{'RULES_TITLE'},
                                 RULES_TEXT   => $rules_text,
                                 LAST_UPDATE  => time,
                                 SHOW_ALL     => $iB::IN{'SHOW_ALL'}
                               }
                   );
    }

    $obj->{html} = ModCPView::startcp();
    $obj->{html} =~ s/<!--menu goes here-->/&ModCPView::online_menu/e;
    $obj->{html} .= ModCPView::forum_rules_applied();
    $obj->{html} .= ModCPView::endcp();
}
# end add

sub do_approve {
 my ($obj, $db) = @_;
 my $post_id = $iB::IN{'p'};
 my $topic_id = $iB::IN{'t'};

 if ($iB::IN{'CHOICE'} eq 'approve') {

    my $p_data = $db->select( TABLE => 'mod_posts',
                              KEY   => $post_id,
                            );
    my $t_data = $db->select( TABLE => 'forum_topics',
                              ID    => $iB::IN{'f'},
                              KEY   => $topic_id,
                            );
    $db->update( TABLE  => 'forum_topics',
                 ID     => $iB::IN{'f'},
                 KEY    => $topic_id,
                 VALUES => { APPROVED  => 1 },
               );
    $db->update( TABLE  => 'forum_posts',
                 DBID   => 'f'.$iB::IN{'f'},
                 ID     => $topic_id,
                 KEY    => $post_id,
                 VALUES => { QUEUED    => 0 },
               );
    $db->delete( TABLE => 'mod_posts',
                 KEY   => $post_id,
               );
    my $forum_info = $obj->LoadForum( $db, $iB::IN{'f'} );
    # Update the search records
    $s_log->compile_entry(     DB    => $db,
                               TOPIC => $t_data,
                               FORUM => $forum_info,
                               POST  => $p_data,
                         );

    # Update the members post count.
    if ($p_data->{'AUTHOR_TYPE'}) {
        my $member = $db->select( TABLE  => 'member_profiles',
                                  KEY    => $p_data->{'AUTHOR'},
                                );
        ++$member->{'MEMBER_POSTS'};
        $db->update( TABLE  => 'member_profiles',
                     KEY    => $p_data->{'AUTHOR'},
                     VALUES => { MEMBER_POSTS => $member->{'MEMBER_POSTS'} }
                   );
    }
  }
  $output->redirect_screen( TEXT => $ModCP::lang->{'no_matches'}, URL => "act=ST&f=$iB::IN{'f'}&t=$iB::IN{'t'}" );
}

sub	memedit {
	my ($obj, $db) = @_;
	$obj->{nav} = qq|<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;CODE=memedit'>$ModCP::lang->{'memedit_link'}</a>|;
	
	$obj->{html} = ModCPView::startcp();
	$obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;
	
		$obj->{html} .= ModCPView::mem_search_field();

	
		$obj->{html} .= ModCPView::endcp();
}

sub	edit_mem {
	my ($obj, $db) = @_;
		$std->Error( DB      => $db,
				 LEVEL   => 1,
				 MESSAGE =>'memid_blank'
			   ) unless $iB::IN{'USER_KEY'};
	my $method = $iB::IN{'KEY_TYPE'};
	if ($method eq 'NAME') {
		$method = 'by name';
	} elsif ($method eq 'EMAIL') {
		$method = 'by email';
	} elsif ($method eq 'IP') {
		$method = 'by ip';
	} else {
		$method = 'by id';
	}
	my $member = $mem->LoadMember( DB => $db, KEY => $iB::IN{'USER_KEY'}, METHOD => $method );
	my $mem_groups = $db->query( TABLE      => 'mem_groups',
								 COLUMNS    => ['ID', 'TITLE'],
								 SORT_KEY   => 'TITLE',
								 SORT_BY    => 'A-Z',
							   );
	my @groups;
		$obj->{nav} = qq|<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;CODE=memedit'>$ModCP::lang->{'memedit_link'}</a>|;

	for (@{$mem_groups}) {
		next if ( ($_->{'ID'} == $iB::INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $iB::INFO->{'SUPAD_GROUP'}) );
		push @groups, { NAME => $_->{'TITLE'}, VALUE => $_->{'ID'} };
	}
	my $size   = scalar (@groups) + 1;
	#XXX No member found? Lets query the DB to find a near match
	unless ($member->{'MEMBER_ID'}) {

		$iB::IN{'USER_KEY'} =~ s!\[!\\\\[!g;
		$iB::IN{'USER_KEY'} =~ s!\]!\\\\]!g;
		my $query_stm;
		if ($iB::IN{'KEY_TYPE'} eq 'NAME') {
			$query_stm = "MEMBER_NAME LIKE /%".$iB::IN{'USER_KEY'}."%/";
		} elsif ($iB::IN{'KEY_TYPE'} eq 'EMAIL') {
			$query_stm = "MEMBER_EMAIL LIKE /%".$iB::IN{'USER_KEY'}."%/";
		} elsif ($iB::IN{'KEY_TYPE'} eq 'IP') {
			$query_stm = "MEMBER_IP LIKE /%".$iB::IN{'USER_KEY'}."%/";
		} else {
			$query_stm = "MEMBER_ID LIKE /%".$iB::IN{'USER_KEY'}."%/";
		}
		my $member_query = $db->query( TABLE    => 'member_profiles',
									   COLUMNS  => ['MEMBER_NAME', 'MEMBER_ID', 'MEMBER_GROUP', 'MEMBER_EMAIL', 'MEMBER_POSTS'],
									   WHERE    => $query_stm,
									   SORT_KEY => 'MEMBER_NAME'
									 );
		unless (scalar (@{$member_query}) > 0) {
		$std->Error( DB      => $db,
				 LEVEL   => 1,
				 MESSAGE =>'no_such_user'
			   ) unless $iB::IN{'USER_KEY'};
		}

		
	
	$obj->{html} = ModCPView::startcp();
	$obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;
	
		$obj->{html} .= ModCPView::mem_search_header();

			for my $this_mem (@{$member_query}) {

			my $this_mem_g = {} ;
			for (@{$mem_groups}) {
				next if ( ($_->{'ID'} == $iB::INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $iB::INFO->{'SUPAD_GROUP'}) );
				$this_mem_g = $_ if $_->{'ID'} == $this_mem->{'MEMBER_GROUP'};
			}
		$obj->{html} .= ModCPView::mem_search_row($this_mem,$this_mem_g);

		}
		$obj->{html} .= ModCPView::mem_search_footer();

			
		$obj->{html} .= ModCPView::endcp();
		
	} else {
	
my ($sel_allow_no,$sel_allow_yes,$sel_ng,$sel_male,$sel_fem,$sel_email_yes,$sel_email_no,$sel_0,$sel_1,$sel_2,$sel_3,$sel_4,$sel_5);
if ($member->{'GENDER'} == 0) {
	$sel_ng = "selected";
} elsif ($member->{'GENDER'} == 1) {
	$sel_male = "selected";
} else {
	$sel_fem = "selected";
}


	if ( ($member->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $iB::INFO->{'SUPAD_GROUP'}) ) {
				$std->Error( DB      => $db,
				 LEVEL   => 1,
				 MESSAGE =>'moderate_no_permission'
			   );
		}
	$member->{'LAST_ACTIVITY'} = $std->get_date( TIME => $member->{'LAST_ACTIVITY'}, METHOD => 'LONG' );

	#XXX If we get here, we must have found an exact match.

	$member->{'SIGNATURE'} = $txt->Convert_for_textfield($member->{'SIGNATURE'});
	$member->{'INTERESTS'} = $txt->Convert_for_textfield($member->{'INTERESTS'});

	my ($width, $height) = split "x", $member->{'AVATAR_DIMS'};

	$member->{'ALLOW_POST'} ||= 0;
	$obj->{html} = ModCPView::startcp();
		$obj->{nav} = qq|<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;CODE=memedit'>$ModCP::lang->{'memedit_link'}: $member->{'MEMBER_NAME'}</a>|;

	$obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;
	
	$obj->{html} .= ModCPView::mem_edit($member,$width, $height,$sel_allow_no,$sel_allow_yes,$sel_ng,$sel_male,$sel_fem,$sel_email_yes,$sel_email_no,$sel_0,$sel_1,$sel_2,$sel_3,$sel_4,$sel_5);
	
	$obj->{html} .= ModCPView::endcp();		
	}
}
sub	do_edit_mem {
	my ($obj, $db) = @_;
	
			$std->Error( DB      => $db,
				 LEVEL   => 1,
				 MESSAGE =>'memid_blank'
			   ) unless defined $iB::IN{'ID'};
		$obj->{nav} = qq|<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;CODE=memedit'>$ModCP::lang->{'memedit_link'}</a>|;

	my $sig = $txt->Convert_for_db( TEXT    => $iB::CGI->param('SIGNATURE'),
                                                 SMILIES => 1,
                                                 IB_CODE => 1,
                                                 HTML    => 1,
												);
	$iB::IN{'INTERESTS'} = $txt->Convert_for_db( TEXT    => $iB::IN{'INTERESTS'},
                                                 SMILIES => 1,
                                                 IB_CODE => 1,
                                                 HTML    => 1,
												);

		$iB::IN{'AVATAR_DIMS'}   = $iB::IN{'AVATAR_W'}.'x'.$iB::IN{'AVATAR_H'};

	$db->update( TABLE   => 'member_profiles',
				 KEY     => $iB::IN{'ID'},
				 ID      => $iB::IN{'ID'},
				 VALUES  => {  
								MEMBER_EMAIL   => $iB::IN{'MEMBER_EMAIL'},
								MEMBER_TITLE   => $iB::IN{'MEMBER_TITLE'},
								MEMBER_AVATAR  => $iB::IN{'MEMBER_AVATAR'},
								AVATAR_DIMS    => $iB::IN{'AVATAR_DIMS'},
								MEMBER_POSTS   => $iB::IN{'MEMBER_POSTS'},
								PHOTO          => $iB::IN{'PHOTO'},
								AOLNAME        => $iB::IN{'AOLNAME'},
								ICQNUMBER      => $iB::IN{'ICQNUMBER'},
								YAHOONAME      => $iB::IN{'YAHOONAME'},
								MSNNAME        => $iB::IN{'MSNNAME'},
								LOCATION       => $iB::IN{'LOCATION'},
								WEBSITE        => $iB::IN{'WEBSITE'},
								SIGNATURE      => $sig,
								INTERESTS      => $iB::IN{'INTERESTS'},
								GENDER         => $iB::IN{'GENDER'},
								MEMBER_NAME_R  => $iB::IN{'MEMBER_NAME_R'},
						   },
			  );

	$db->insert(  TABLE  => 'moderator_logs',
				  VALUES => { FORUM_ID     => undef,
							  TOPIC_ID     => undef,
							  POST_ID      => undef,
							  MEMBER_ID    => $iB::MEMBER->{'MEMBER_ID'},
							  MEMBER_NAME  => $iB::MEMBER->{'MEMBER_NAME'},
							  REMOTE_ADDR  => $iB::MEMBER->{'MEMBER_IP'},
							  HTTP_REFERER => $ENV{'HTTP_REFERER'},
							  TIME         => time,
							  TOPIC_TITLE  => undef,
							  ACTION       => "Edited the Member Profile of <B>$iB::IN{'NAME'}</b>",
							  QUERY_STRING => $ENV{'QUERY_STRING'},
							},
			   );
	$obj->{html} = ModCPView::startcp();
	$obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;
	$obj->{html} .= ModCPView::mem_edit_sucess();
	$obj->{html} .= ModCPView::endcp();
}


sub Process {
    my ($obj,$db) = @_;

    require "$iB::SKIN->{'DIR'}" . '/ModCPView.pm';
    $obj->SetSession($db);
    my $CodeNo = $iB::IN{'CODE'};
    my %Mode = ( topic_search   => \&topic_search,
                 post_search    => \&post_search,
                 process_topics => \&process_topics,
                 process_posts  => \&process_posts,
                 readpost       => \&read_post,
                 open           => \&open_close_topics,
                 process_open   => \&process_open_close_topics,
                 do_openclose   => \&do_openclose,
                 delete         => \&delete,
                 process_delete => \&process_delete,
                 do_delete      => \&do_delete,
                 prune          => \&prune,
                 process_prune  => \&process_prune,
                 move           => \&move_topics,
                 process_move   => \&process_move,
                 do_move        => \&do_move,
                 watched_search => \&watched_search,
                 merge          => \&merge,
                 select_merge   => \&select_merge,
                 do_merge       => \&do_merge,
                 forum_rules    => \&forum_rules,
                 do_forum_rules => \&do_forum_rules,
                 do_approve     => \&do_approve,
                 memedit		=> \&memedit,
				 edit_mem		=> \&edit_mem,
				 do_edit_mem		=> \&do_edit_mem,

               );

    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : mod_splash($obj, $db);

    unless ($obj->{bypass}) {
        $output->print_ikonboard( DB           => $db,
                                  STD          => $std,
                                  OUTPUT       => $obj->{html},
                                  NAV          => [ qq|<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP'>$ModCP::lang->{'home'}</a>|,
                                                  $obj->{nav},
                                   ],
                                  TITLE        => "iB::" . "$ModCP::lang->{'title'}"
                                );
    }
}


#+------------------------------------------------------------------------------------------------------
#+------------------------------------------------------------------------------------------------------
# UNIVERSAL



sub LoadForum {
    my ($obj, $db, $forum) = @_;
    my $return = $db->select( TABLE   => 'forum_info',
                              KEY     => $forum,
                            );
    return $return;
}

#+------------------------------------------------------------------------------------------------------

sub LoadTopic {
    my ($obj, $db, $forum, $topic) = @_;

    my $return = $db->select( TABLE  => 'forum_topics',
                              ID     => $forum,
                              KEY    => $topic,
                            );
    return $return;
}

#+------------------------------------------------------------------------------------------------------

sub SetSession {
    my ($obj, $db) = @_;

    # As our Russian friends might say to non members trying
    # to gain access to our moderators CP: Pisky Ofsky.
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'moderate_no_permission'
               ) unless $iB::MEMBER->{'MEMBER_ID'};

    # Set the default moderator type to none
    $obj->{type} = 'n';

    # If we're superman...er supermod, then we get "all"
    if ($iB::MEMBER_GROUP->{'IS_SUPMOD'}) {
        $obj->{type} = 'all';
        return;
    }

    # Ok, lets see if this member is a moderator
    my @mods = $db->query( TABLE      => 'forum_moderators',
                           WHERE      => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!
                         );

    # Yes? cool, set the type and return
    if (scalar @mods > 0) {
        $obj->{type} = 'multiple';
        # Build our hash.
        $obj->{moderator} = {};
        for my $i (@mods) {
            $obj->{moderator}->{ $i->{'FORUM_ID'} } = { };
            for my $k (keys %{$i}) {
                next if $k eq 'FORUM_ID';
                $obj->{moderator}->{ $i->{'FORUM_ID'} }->{ $k } = $i->{ $k };
            }
        }
        return;
    }

    # Buh-bye our moderatory challenged friends
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'moderate_no_permission'
               ) if $obj->{type} eq 'n';
}


1;
