package Topic;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Topic: Topic display functions
#
#################################################################################

BEGIN {
   require 'Lib/FUNC.pm';
}

my $std      = FUNC::STD->new();
my $output   = FUNC::Output->new();
$Topic::lang = $std->LoadLanguage('TopicWords');

sub new {
    my $pkg = shift;
    my $obj = { '.can_warn' => 0 };
    bless $obj, $pkg;
    return $obj;
}

#+------------------------------------------------------------------------------------------------------

sub ShowTopic {
    my ($obj, $db) = @_;

    return unless ((defined $iB::IN{'t'}) and (defined $iB::IN{'f'}));

    my $First = $iB::IN{'st'} || 0;

    require $iB::SKIN->{'DIR'} . '/TopicView.pm' or die $!;
    $iB::INFO->{'AVATAR_URL'} = $iB::INFO->{'IMAGES_URL'};

    $obj->{'.forum_id'} = $std->IsNumber($iB::IN{'f'}) || 0;
    $obj->{'.topic_id'} = $std->IsNumber($iB::IN{'t'}) || 0;

    #+---------------------------------------------------------
    # Are we looking for an older/newthread?
    #+---------------------------------------------------------

    my $r = '0';
    if ($std->IsNumber($iB::IN{'r'}) == 1){
    $r = 1;
    }
    my $forum_view1 = $obj->{'.forum_id'};
    my $topic_view1 = $obj->{'.topic_id'};
    my $membid      = $iB::MEMBER->{'MEMBER_ID'};
    if ($iB::MEMBER->{'MEMBER_ID'} ne '') {
        my $view1 = $db->query( TABLE  => 'topic_views',
                                ID     => $obj->{'.forum_id'},
                                WHERE  => "TOPIC_ID == '$topic_view1' and FORUM_ID eq '$forum_view1' and MEMBER_ID eq '$membid'",
                               );
        if ($view1->[0]->{'ID'} ne ""){
             if ($r == ''){
                 $r = $view1->[0]->{'POSTED_IN'};
                         }
                   $db->update( TABLE  => 'topic_views',
                                ID     => $obj->{'.forum_id'},
                                KEY    => $view1->[0]->{'ID'},
                                VALUES => { VIEWED => time, POSTED_IN => $r, SENT => 0},
                               );
        } else {
         my $view1 = $db->insert(TABLE  => 'topic_views',
                                 ID     => $obj->{'.forum_id'},
                                 VALUES => { MEMBER_ID => $membid, TOPIC_ID => $topic_view1, FORUM_ID => $forum_view1, VIEWED => time, POSTED_IN => $r, SENT => 0 },
                                 );
        }
    }

    if ($iB::IN{'view'}) {
        my $get_topic = [ {} ];

        my $cur_topic = $db->select( TABLE  => 'forum_topics',
                                     ID     => $obj->{'.forum_id'},
                                     KEY    => $obj->{'.topic_id'}
                                   );

        if ($iB::IN{'view'} eq 'new') {
            $get_topic = $db->query( TABLE    => 'forum_topics',
                                     ID       => $obj->{'.forum_id'},
                                     WHERE    => "FORUM_ID == '$obj->{'.forum_id'}' and APPROVED == 1 and TOPIC_LAST_DATE > '$cur_topic->{'TOPIC_LAST_DATE'}'",
                                     RANGE    => "0 to 1",
                                     SORT_KEY => 'TOPIC_LAST_DATE',
                                     SORT_BY  => 'A-Z'
                                    );

            $get_topic->[0]->{'TOPIC_ID'} ? $obj->{'.topic_id'} = $get_topic->[0]->{'TOPIC_ID'}
                                          : $std->Error( DB => $db, LEVEL => 1, MESSAGE => "no_newer");

            # Make sure the rest of the scripts catch up..
            $iB::IN{'t'} = $obj->{'.topic_id'};
        }

        if ($iB::IN{'view'} eq 'old') {
            $get_topic = $db->query( TABLE    => 'forum_topics',
                                     ID       => $obj->{'.forum_id'},
                                     WHERE    => "FORUM_ID == '$obj->{'.forum_id'}' and APPROVED == 1 and TOPIC_LAST_DATE < '$cur_topic->{'TOPIC_LAST_DATE'}'",
                                     RANGE    => "0 to 1",
                                     SORT_KEY => 'TOPIC_LAST_DATE',
                                     SORT_BY  => 'Z-A'
                                   );
            $get_topic->[0]->{'TOPIC_ID'} ? $obj->{'.topic_id'} = $get_topic->[0]->{'TOPIC_ID'}
                                          : $std->Error( DB => $db, LEVEL => 1, MESSAGE => "no_older");

            # Make sure the rest of the scripts catch up..
            $iB::IN{'t'} = $obj->{'.topic_id'};
        }
    }

    #+---------------------------------------------------------
    # Load the relevant forum/topic info
    #+----------------------------------------------------------

    $obj->{'FORUM'} = $db->select( TABLE => 'forum_info',
                                   KEY   => $obj->{'.forum_id'},
                                 );

    $obj->{'TOPIC'} = $db->select( TABLE => 'forum_topics',
                                   ID    => $obj->{'.forum_id'},
                                   KEY   => $obj->{'.topic_id'}
                                 );

    $obj->{'EVENT'} = $db->select ( TABLE => 'calendar',
                                    KEY   => "f=$obj->{'.forum_id'};t=$obj->{'.topic_id'}"
                                  );

    #+---------------------------------------------------------
    # Assume nothing, confirm everything.
    #+---------------------------------------------------------

    $std->Error( DB      => $db,
                LEVEL   => 1,
                MESSAGE => 'illegal_db_query',
              ) unless (!$iB::IN{'st'} || $iB::IN{'st'} =~ /^\d+/);

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE => 'missing_files',
               ) unless defined $obj->{'FORUM'}->{'FORUM_ID'};

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE => 'missing_files',
               ) unless defined $obj->{'TOPIC'}->{'TOPIC_ID'};

    $std->Error( DB      => $db,
             LEVEL   => 1,
             MESSAGE => 'missing_files',
               ) unless ($obj->{'FORUM'}->{'FORUM_ID'} eq $obj->{'TOPIC'}->{'FORUM_ID'});

    # If someone has bookmarked this topic either via the topic tracker
    # or via their web browser, we'll need to redirect them.
    # The same is true is they surf on it from the last post link in forum
    # view.

    if ($obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'link') {
        my ($forum, $topic_id) = split ";", $obj->{'TOPIC'}->{'MOVED_TO'};
        $output->redirect_screen( URL => "act=ST&f=$forum&t=$topic_id", TEXT => $Topic::lang->{topic_moved} );
    }

   #+---------------------------------------------------------
   # Check Viewing Permissions
   #+---------------------------------------------------------

   unless ($iB::MEMBER_GROUP->{'OTHER_TOPICS'}) {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'no_view_topic'
                   ) unless $obj->{'TOPIC'}->{'TOPIC_STARTER'} eq $iB::MEMBER->{'MEMBER_ID'};
    }

    #+---------------------------------------------------------
    # Check for viewing access
    #+---------------------------------------------------------

    my $check = $obj->Check_access($db);
    return if $check == 1;

    #+---------------------------------------------------------
    # Update topic views
    #+---------------------------------------------------------

    ++$obj->{'TOPIC'}->{'TOPIC_VIEWS'};

    $db->update( TABLE  => 'forum_topics',
                 ID     => $obj->{'.forum_id'},
                 KEY    => $obj->{'.topic_id'},
                 VALUES => { TOPIC_VIEWS => $obj->{'TOPIC'}->{'TOPIC_VIEWS'} },
               );
    $obj->{'FORUM'}->{'JUMP'} = $std->ForumJump();
    $obj->{'FORUM'}->{'JUMP'} =~ s!#Forum Jump#!$Topic::lang->{'forum_jump'}!;

    #+---------------------------------------------------------
    # Grab the member groups and push into a hash
    #+---------------------------------------------------------

    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE', 'TEAM_ICON'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );

    my %temp_table = map { $_->{'ID'} => { TITLE  => $_->{'TITLE'},
                                           ICON   => $_->{'TEAM_ICON'}
                                         }
                         } @{$mem_groups};
    $obj->{'group_table'} = \%temp_table;

    #+---------------------------------------------------------
    # Grab the member titles and push into a hash
    #+---------------------------------------------------------

    my $mem_titles = $db->query( TABLE      => 'member_titles',
                                 COLUMNS    => ['ID', 'TITLE', 'PIPS'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );

    my %temp_titles = map { $_->{'ID'} => { TITLE => $_->{'TITLE'},
                                            PIPS  => $_->{'PIPS'}
                                          }
                          } @{$mem_titles};
    $obj->{'title_table'} = \%temp_titles;

   my $can_view = $db->query( TABLE  => 'address_books',
                              WHERE  => "MEMBER_ID eq '$iB::MEMBER->{'MEMBER_ID'}'",
                            );

   my %can_view = map { $_->{'IN_MEMBER_ID'} => { RECEIVE_MSG => $_->{'RECEIVE_MSG'} }
                         } @{$can_view};
   $obj->{'view_table'} = \%can_view;

    #+---------------------------------------------------------
    # Load the moderator if needed
    #+---------------------------------------------------------

    unless( (!$iB::MEMBER->{'MEMBER_ID'}) or ($iB::MEMBER_GROUP->{'IS_SUPMOD'}) ) {
        $obj->{'moderator'} = { };

        $obj->{'moderator'} = $db->query( TABLE      => 'forum_moderators',
                                          MATCH      => 'ONE',
                                          WHERE      => qq!FORUM_ID == "$obj->{'.forum_id'}" and MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!
                                        );
    }

    #+---------------------------------------------------------
    # How are we sorting this topic?
    #+---------------------------------------------------------

    my $sort_by      = $iB::IN{'sort_by'} || $iB::INFO->{'TOPIC_SORT_ORDER'} || "Z-A";

    my $sort_by_keys = { 'Z-A'  => 'descending_order',
                         'A-Z'  => 'ascending_order',
                       };

    $std->Error( DB      => $db,
                 LEVEL   => 5,
                 MESSAGE =>'illegal_sort_use'
               ) unless (exists $sort_by_keys->{$sort_by});

    #+---------------------------------------------------------
    # Get the posting buttons
    #+---------------------------------------------------------

    $obj->{'TOPIC'}->{'REPLY_BUTTON'}
        = $obj->get_t_button();
        
       $obj->{'TOPIC'}->{'QUICKREPLY_UNREG'}
        = $obj->quickreply_unreg();

    $obj->{'TOPIC'}->{'POLL_BUTTON'}
        = $iB::INFO->{'ALLOW_POLLS'} ? qq[<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Poll;CODE=01;f=$iB::IN{'f'}' title="$Topic::lang->{'start_new_poll'}">$iB::SKIN->{'A_POLL'}</a>]
                                     : '';

    $obj->{'TOPIC'}->{'TOPIC_START_DATE'} = $std->get_date( TIME => $obj->{'TOPIC'}->{'TOPIC_START_DATE'}, METHOD => 'LONG' );

    ####################################
    # Generate the forum page span links
    ####################################

    $obj->{'TOPIC'}->{'SHOW_PAGES'}
        = $std->build_pagelinks( TOTAL_POSS  => ($obj->{'TOPIC'}->{'TOPIC_POSTS'}+1),
                                 PER_PAGE    => $iB::INFO->{'DISPLAY_MAX_POSTS'},
                                 CUR_ST_VAL  => $iB::IN{'st'},
                                 L_SINGLE    => $Topic::lang->{'single_page_topic'},
                                 L_MULTI     => $Topic::lang->{'multi_page_topic'},
                                 BASE_URL    => "$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$obj->{'FORUM'}->{'FORUM_ID'};t=$obj->{'TOPIC'}->{'TOPIC_ID'}",
                               );

my $Print;

    # added by kevaholic00: Who's Currently Viewing A Topic.
    if ($iB::INFO->{'SHOW_ONLINE'} && $iB::INFO->{'TOPIC_ACT_POS'} == 1) {
        my $run_time       = time - 900;
        my $total_sessions = $db->query(  TABLE     => 'active_sessions',
                                          SORT_KEY  => 'RUNNING_TIME',
                                          SORT_BY   => 'Z-A',
                                          WHERE     => "RUNNING_TIME > ".$run_time." and LOG_IN_TYPE != 1",
                                          MATCH     => 'WITH COUNT',
                                       );

        # Get the formatting options
        my %format;
        for (split /\|/, $iB::INFO->{AU_FORMAT}) {
            /^(\d+)\~(.+?),(.+?)$/;
            $format{ $1 } = { ST => $2, END =>$3 };
        }

        my @intopic;
        my @already_printed;
        for my $session (@{$total_sessions}) {
            if ($session->{'LOCATION'}) {
                my ($act, $q_string) = split (/\|&\|/, $session->{'LOCATION'});
                my ($sub_act, $number);
                if ( $q_string =~ m{[&;\?](t)=(\d+)[&;\|\Z]} ) {
                    $sub_act = $1;
                    $number  = $2;

                    if ($sub_act eq 't' and $number eq $obj->{'TOPIC'}->{'TOPIC_ID'}) {
                        if ($session->{'MEMBER_NAME'}) {
                            # XXX Remove Dupes (this occurs if a user is on a proxy, and their IP changes).
                            next if exists $obj->{'seen_name'}->{ $session->{'MEMBER_NAME'} };
                            $obj->{'seen_name'}->{ $session->{'MEMBER_NAME'} } = 1;
                        }

                        if ($session->{'MEMBER_ID'}) {
                            unless (grep { $_ eq $session->{'MEMBER_NAME'} } @already_printed) {
                                push @intopic, qq!<span class='highlight'>&gt;<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$session->{'MEMBER_ID'}'>$format{ $session->{'MEMBER_GROUP'} }->{ST}$session->{'MEMBER_NAME'}$format{ $session->{'MEMBER_GROUP'} }->{END}</a></span>!;
                                push @already_printed, $session->{'MEMBER_NAME'};
                            }
                        }
                    }

                }
            }
        }

        push @intopic, qq!<span class='highlight'>&gt;<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$iB::MEMBER->{'MEMBER_ID'}'>$format{ $iB::MEMBER->{'MEMBER_GROUP'} }->{ST}$iB::MEMBER->{'MEMBER_NAME'}$format{ $iB::MEMBER->{'MEMBER_GROUP'} }->{END}</a></span>! unless exists $obj->{'seen_name'}->{ $iB::MEMBER->{'MEMBER_NAME'} };

        my $intopic_count = scalar @intopic;
        my $intopic_list  = join ' ', @intopic;

        $Print .= TopicView::Online( $intopic_count, $intopic_list );
    }
    # end addition


   #+---------------------------------------------------------
   # Do we have a poll to view?
   #+---------------------------------------------------------

   if ($obj->{'TOPIC'}->{'POLL_STATE'} eq 'open' or $obj->{'TOPIC'}->{'POLL_STATE'} eq 'closed'){
       require 'iPoll.pm';
       my $poll     = iPoll->new();
       $Print .=  $poll->display_poll(  DB          => $db,
                                        FORUM_ID    => $obj->{'.forum_id'},
                                        TOPIC_ID    => $obj->{'.topic_id'},
                                        TOPIC_STATE => $obj->{'TOPIC'}->{'TOPIC_STATE'}
                                     );
   }

    #+---------------------------------------------------------
    # Mash the language pack entries
    #+---------------------------------------------------------

    $Topic::lang->{'topic_stats'}   =~ s!<#START#>!$obj->{'TOPIC'}->{'TOPIC_START_DATE'}!;
    $Topic::lang->{'topic_stats'}   =~ s!<#POSTS#>!$obj->{'TOPIC'}->{'TOPIC_POSTS'}!;
    $obj->{'TOPIC'}->{'TOPIC_DESC'} = ', '.$obj->{'TOPIC'}->{'TOPIC_DESC'} if $obj->{'TOPIC'}->{'TOPIC_DESC'};

    #+---------------------------------------------------------
    # Render the page top
    #+---------------------------------------------------------

    $Print .= TopicView::PageTop({
                                  TOPIC => $obj->{'TOPIC'},
                                  FORUM => $obj->{'FORUM'}
                                 }
                                );

    #+---------------------------------------------------------
    # Grab the posts to show.
    #+---------------------------------------------------------

    my $total_posts = $db->query( TABLE    => 'forum_posts',
                                  DBID     => 'f'.$obj->{'.forum_id'},
                                  ID       => $obj->{'.topic_id'},
                                  WHERE    => "TOPIC_ID == '$obj->{'.topic_id'}' and QUEUED != '1'",
                                  RANGE    => $First.' to '.($iB::INFO->{'DISPLAY_MAX_POSTS'} + ($First - 1)),
                                  SORT_KEY => 'POST_DATE',
                                  SORT_BY  => $sort_by
                                 );

    my ($attach,$where,$i,$a);
   foreach my $mi (@{$total_posts}) {
           $i++;
           $where .= " or " unless $i == 1;
        if ($mi->{'AUTHOR_TYPE'}){
           $where .= qq!MEMBER_ID eq "$mi->{'AUTHOR'}"!;
         } else {
           $where .= qq!MEMBER_ID eq "0"!;
}
       if ($mi->{'ATTACH_ID'}){
           $a++;
           $attach .= " or " unless $a == 1;
           $attach .= "ID == \'$mi->{'ATTACH_ID'}\'";
       }
    }
    my $mem_tot = $db->query( TABLE      => 'member_profiles',
                              WHERE      => qq!$where!,
                              SORT_KEY   => "MEMBER_NAME",
                              SORT_BY    => 'A-Z',
                             );

      my $at = $db->query( TABLE => 'attachments',
                           WHERE => $attach,
                           ) unless $a == '';

    my $totals = scalar (@{$total_posts});
    my $Cnt = 0;
    my $member_hash = {};

    #+---------------------------------------------------------
    # Bash, smash and thrash the data
    #+---------------------------------------------------------

    # added by kevaholic00
    my @total_posts = @{$total_posts};
    my $counter = 0;
    # end addition
    for my $Row (@{$total_posts}) {

        # We want to internally cache the loaded member data. There seems little point in spinning up
        # the server everytime we need the member details if that member has posted 3 or 4 times in the
        # topic - as is often the case. We can make good savings here.

        $obj->{'POSTER'} = undef;

        if ($Row->{'AUTHOR_TYPE'} == 1) {

            # Is it in our hash?
            if (exists $member_hash->{ $Row->{'AUTHOR'} }) {

                # Ok, lets read from the hash
                $obj->{'POSTER'} = $member_hash->{ $Row->{'AUTHOR'} };
                $Row->{'NAME_CSS'} = 'normalname';
            }
            else {
            foreach (@{$mem_tot}) {
                if ($Row->{'AUTHOR'} eq $_->{'MEMBER_ID'}) {
                 $obj->{'POSTER'} = $_;
                 last;
                }
            }

                # Do we have a geniune member to use?
                if ($obj->{'POSTER'}->{'MEMBER_ID'}) {

                    # Parse the member...
                    $obj->do_member($Row);
                    $Row->{'NAME_CSS'} = 'normalname';

                    # Set the hash.
                    $member_hash->{ $Row->{'AUTHOR'} } = $obj->{'POSTER'};
            $obj->{'POSTER'}->{'ONLINE'} = $obj->mem_stat();
                } else {
                    # It's probably a deleted member, so..
                    $obj->do_guest($Topic::lang->{'guest'});
                    $Row->{'NAME_CSS'} = 'unreg';
                }
            }
        } else {
            # Else, it must be a guest, so do nothing but
            # set up the default data.
            $obj->do_guest($Row->{'AUTHOR'});
            $Row->{'NAME_CSS'} = 'unreg';
        }

        $Cnt == 0 ? eval { $Row->{'POST_BACK_COL'} = $iB::SKIN->{'POST_COL_ONE'}; ++$Cnt;   }
                  : eval { $Row->{'POST_BACK_COL'} = $iB::SKIN->{'POST_COL_TWO'}; $Cnt = 0; };

        if ($iB::IN{'hl'}) {
            $Row->{'POST'} =~ s!(\s{1,3}|\A|<br>|\(|"|')($iB::IN{'hl'})(\s{1,3}|\Z|<br>|,|\.|\!|\?|\)|"|')!$1<span style='color:#FF0000'><b>$2</b></span>$3!ig;
        }

        $iB::SKIN->{'EDIT_FONT_SIZE'} ||= 7;
        $Row->{'POST'}     =~ s#<!--EDIT\|(.+?)\|(.+?)-->#my $two=$2; $two=$std->get_date( TIME => $two, METHOD => 'LONG'); qq~<span style='font-size:$iB::SKIN->{'EDIT_FONT_SIZE'}pt'>$Topic::lang->{'edit_by'} $1 $Topic::lang->{'on'} $two</span>~#eig;

        unless ($iB::MEMBER->{'VIEW_IMG'}) {
            $Row->{'POST'} =~ s#<img src=["'](?!$iB::INFO->{'EMOTICONS_URL'})(\S+)["'].+?>#\(IMG:<a href="$1" target="_blank">$1</a>\)#isg;
        }

        if ($Row->{'AUTHOR'} ne $iB::MEMBER->{'MEMBER_ID'}) {

            $Row->{'IGNORE_ICON'} = qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=UserCP;CODE=11;MID=$obj->{'POSTER'}->{'MEMBER_ID'};allow_msg=0;f=$iB::IN{'f'};t=$iB::IN{'t'};st=$iB::IN{'st'}">$iB::SKIN->{'P_IGNORE'}</a>];

        }

        if ($obj->{'view_table'}->{ $Row->{'AUTHOR'} } and $obj->{'view_table'}->{ $Row->{'AUTHOR'} }->{'RECEIVE_MSG'} == 0 and $obj->{'POSTER'}->{'MEMBER_GROUP_NO'} != $iB::INFO->{'SUPAD_GROUP'}) {
            $Row->{'IGNORE_ICON'} = qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=UserCP;CODE=12;MID=$obj->{'POSTER'}->{'MEMBER_ID'};f=$iB::IN{'f'};t=$iB::IN{'t'};st=$iB::IN{'st'}">$iB::SKIN->{'P_UNIGNORE'}</a>];
            $Row->{'POST'} = "<i>$Topic::lang->{'post_ignored'}</i>";
        }

        $Row->{'DELETE_ICON'} = $obj->delete_button($Row->{'POST_ID'}, $totals, $First);
        $Row->{'EDIT_ICON'}   = $obj->edit_button($Row->{'POST_ID'});
        $Row->{'POST_DATE'}   = $std->get_date( TIME => $Row->{'POST_DATE'}, METHOD => 'LONG');
        $Row->{'QUOTE_ICON'}  = $obj->quote_button($Row->{'POST_ID'});
        if ($iB::INFO->{'ICON_TOP_VIEW'} == 1) {
        $Row->{'POST_ICON'}   = $Row->{'POST_ICON'}
                              ? "<img src="."'$iB::INFO->{'IMAGES_URL'}/PostIcons/icon$Row->{'POST_ICON'}.gif'"." border='0' width='19' height='19' align='middle' alt='PostIcon'>"
                              : "<img src="."'$iB::INFO->{'IMAGES_URL'}/PostIcons/icon0.gif'"." border='0' width='19' height='19' align='middle' alt='PostIcon'>";
        } else {
        $Row->{'POST_ICON'}   = $Row->{'POST_ICON'}
                              ? "<img src="."'$iB::INFO->{'IMAGES_URL'}/PostIcons/icon$Row->{'POST_ICON'}.gif'"." border='0' width='19' height='19' align='middle' alt='PostIcon'>"
                              : "&nbsp;&nbsp;&nbsp;";
        }

        $Row->{'USER_IP'}     = $obj->view_ip($Row);
        $Row->{'REPORT_POST'}   = $iB::INFO->{'REPORT_POST_ENABLED'} && $iB::MEMBER->{'MEMBER_ID'} ? TopicView::report_link($Row,$iB::IN{'st'}) : '';
      $Row->{'WARN_USER'}   = ($iB::MEMBER->{'MEMBER_ID'} and ($iB::MEMBER_GROUP->{'IS_SUPMOD'} or $obj->{'moderator'}->{'ALLOW_WARN'})) ? TopicView::warn_link($Row) : '';
      $Row->{'WARN_USER'}   = '' if ($obj->{'POSTER'}->{'MEMBER_ID'} eq '' || $iB::MEMBER->{'MEMBER_ID'} eq $obj->{'POSTER'}->{'MEMBER_ID'});
        if ($Row->{'ATTACH_ID'} and $obj->{'FORUM'}->{'ALLOW_ATTACH'}) {

            # Let there be attachments!
            # Is it an image, and are we just adding it to the post?

       require 'MimeTypes.cfg';
       my $mime     = MimeTypes->new();

        $attach = undef;
            if (($iB::INFO->{'IMG_ATT_SHOW'}) and
               ($Row->{'ATTACH_TYPE'} eq "image/gif" or $Row->{'ATTACH_TYPE'} eq "image/jpeg" or $Row->{'ATTACH_TYPE'} eq "image/x-png" or $Row->{'ATTACH_TYPE'} eq "image/pjpeg") ) {
        foreach my $att(@{$at}) {
            if ($Row->{'ATTACH_ID'} == $att->{'ID'}){
                $attach = $att;
                last;
            }
            }
               $Row->{'RENDER_ATTACHMENT'} = TopicView::Show_attachments_img( { NAME => $attach->{'FILE_NAME'} } );
            } else {
                $Row->{'RENDER_ATTACHMENT'} = TopicView::Show_attachments( {
                                                                             ID    => $Row->{'ATTACH_ID'},
                                                                             HITS  => $Row->{'ATTACH_HITS'},
                                                                             IMG   => $mime->{ $Row->{'ATTACH_TYPE'} }[1],
                                                                             NAME  => $mime->{ $Row->{'ATTACH_TYPE'} }[2],
                                                                             POST  => $Row->{'POST_ID'},
                                                                             TOPIC => $obj->{'TOPIC'}->{'TOPIC_ID'},
                                                                             FORUM => $obj->{'FORUM'}->{'FORUM_ID'},
                                                                         } );
            }
        }

        # Do we have a signature to add?

        $iB::INFO->{'SIG_SEP'} ||= '<br><br>--------------<br>';

        if ($obj->{'POSTER'}->{'SIGNATURE'} and $iB::MEMBER->{'VIEW_SIGS'}) {
            $Row->{'SIGNATURE'} = $Row->{'ENABLE_SIG'}
                                  ?  qq[<!--Signature-->$iB::INFO->{'SIG_SEP'}<span id='signature'>$obj->{'POSTER'}->{'SIGNATURE'}</span><!--E Signature-->]
                                  : ();
        }

        $Row->{'POST_NO'} = $counter + $iB::IN{'st'} + 1;

        if ($counter != 0) {
            my $prev = $total_posts->[ $counter - 1 ]->{'POST_ID'};
            $Row->{'PREV'} = qq[<a href='#postid$prev'>$iB::SKIN->{'P_PREV'}</a>];
        }
        if ($counter != $#total_posts) {
            my $next = $total_posts->[ $counter + 1 ]->{'POST_ID'};
            $Row->{'NEXT'} = qq[<a href='#postid$next'>$iB::SKIN->{'P_NEXT'}</a>];
        }
        ++$counter;

        $Print .= TopicView::RenderRow( { POST => $Row, POSTER => $obj->{'POSTER'} } );
        $obj->{'POSTER'} = undef;
    }

    #+---------------------------------------------------------
    # Do the table footer
    #+---------------------------------------------------------

    $Print .= TopicView::TableFooter({
                                        TOPIC => $obj->{'TOPIC'},
                                        FORUM => $obj->{'FORUM'}
                                     }
                                    );

    #+---------------------------------------------------------
    # Quick Reply Box
    #+---------------------------------------------------------

    if ($iB::INFO->{'QUICK_REPLY'}) {

        my $emotes;
        for my $e (split /\|\&\|/, $iB::INFO->{'QR_EMOTICONS'}) {
            my $thisEmote = (grep { (split /\|/, $_)[1] eq $e } ( split /\|\&\|/, $iB::INFO->{'EMOTICONS'} ) )[0];

            next unless $thisEmote;

            my ($type, $image, $p_inc) = split /\|/, $thisEmote;

            $emotes .= qq~
<td align='center' valign='middle' style="font-style: normal; font-variant: normal; font-weight: normal; font-size: 10px; font-family: Verdana; color: #666666" width="0">
<a href="javascript: InstaSmilie()" onClick="AddSmile('$type');this.blur();return false" style="text-decoration: none; color: #660066">
<img src="$iB::INFO->{'EMOTICONS_URL'}/$image" border="0" alt="Emoticon"></a></div>
</td>
            ~;
        }

        $Print .= TopicView::Quick_Reply( {
                                             TOPIC => $obj->{'TOPIC'},
                                             FORUM => $obj->{'FORUM'},
                                             EMOTE => $emotes,
                                          } );
    }


    # added by kevaholic00: Who's Currently Viewing A Topic.
    if ($iB::INFO->{'SHOW_ONLINE'} && $iB::INFO->{'TOPIC_ACT_POS'} == 2) {
        my $run_time       = time - 900;
        my $total_sessions = $db->query(  TABLE     => 'active_sessions',
                                          SORT_KEY  => 'RUNNING_TIME',
                                          SORT_BY   => 'Z-A',
                                          WHERE     => "RUNNING_TIME > ".$run_time." and LOG_IN_TYPE != 1",
                                          MATCH     => 'WITH COUNT',
                                       );

        # Get the formatting options
        my %format;
        for (split /\|/, $iB::INFO->{AU_FORMAT}) {
            /^(\d+)\~(.+?),(.+?)$/;
            $format{ $1 } = { ST => $2, END =>$3 };
        }

        my @intopic;
        for my $session (@{$total_sessions}) {
            if ($session->{'LOCATION'}) {
                my ($act, $q_string) = split (/\|&\|/, $session->{'LOCATION'});
                my ($sub_act, $number);
                if ( $q_string =~ m{[&;\?](t)=(\d+)[&;\|\Z]} ) {
                    $sub_act = $1;
                    $number  = $2;

                    if ($sub_act eq 't' and $number eq $obj->{'TOPIC'}->{'TOPIC_ID'}) {
                        if ($session->{'MEMBER_NAME'}) {
                            # XXX Remove Dupes (this occurs if a user is on a proxy, and their IP changes).
                            next if exists $obj->{'seen_name'}->{ $session->{'MEMBER_NAME'} };
                            $obj->{'seen_name'}->{ $session->{'MEMBER_NAME'} } = 1;
                        }

                        if ($session->{'MEMBER_ID'}) {
                            push @intopic, qq!&gt;<span class='highlight'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$session->{'MEMBER_ID'}'>$format{ $session->{'MEMBER_GROUP'} }->{ST}$session->{'MEMBER_NAME'}$format{ $session->{'MEMBER_GROUP'} }->{END}</a></span>!;
                        }
                    }

                }
            }
        }

        push @intopic, qq!&gt;<span class='highlight'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$iB::MEMBER->{'MEMBER_ID'}'>$format{ $iB::MEMBER->{'MEMBER_GROUP'} }->{ST}$iB::MEMBER->{'MEMBER_NAME'}$format{ $iB::MEMBER->{'MEMBER_GROUP'} }->{END}</a></span>! unless exists $obj->{'seen_name'}->{ $iB::MEMBER->{'MEMBER_NAME'} };

        my $intopic_count = scalar @intopic;
        my $intopic_list  = join ' ', @intopic;

        $Print .= TopicView::Online( $intopic_count, $intopic_list );
    }
    # end addition

    #+---------------------------------------------------------
    # Slide all the info to the output routines
    #+---------------------------------------------------------

    my $event;
    if ($obj->{'EVENT'}->{'MEMBER_NAME'} ne '') {
                      my $offset = ($iB::INFO->{'TIME_ZONE'} * 3600)+($iB::MEMBER->{'TIME_ADJUST'} * 3600);
                      $event = $std->get_date( TIME => ($obj->{'EVENT'}->{'UTIME'} - $offset), METHOD   => 'SHORT' );
                      $event = " <font color='$iB::INFO->{'EVENT_NAV'}'>[$obj->{'EVENT'}->{'MEMBER_NAME'} $event]</font>";
                                                }
    my $cat = $db->select( TABLE   => 'categories',
                           KEY     => $obj->{'FORUM'}->{'CATEGORY'},
                           COLUMNS => ['CAT_ID', 'CAT_NAME']
                         );
    my $IN = {NAV => ''};
    $IN->{'NAV'} = [
                     qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SC;c=$cat->{'CAT_ID'}" class='nav'>$cat->{'CAT_NAME'}</a>|,
                     qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF;f=$obj->{'FORUM'}->{'FORUM_ID'}" class='nav'>$obj->{'FORUM'}->{'FORUM_NAME'}</a>|,
                     qq|$obj->{'TOPIC'}->{'TOPIC_TITLE'}$event|
                     ];
    $Print .= $output->navigation($IN);
    $Print .= $obj->Moderation_panel($db);

    $output->print_ikonboard( DB         => $db,
                              STD        => $std,
                              OUTPUT     => $Print,
                              JAVASCRIPT => 1,
                              TITLE      => "iB::".$Topic::lang->{topic_page_h}."::$obj->{'TOPIC'}->{'TOPIC_TITLE'}",
                              NAV        => [
                                              qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SC;c=$cat->{'CAT_ID'}" class='nav'>$cat->{'CAT_NAME'}</a>|,
                                              qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF;f=$obj->{'FORUM'}->{'FORUM_ID'}" class='nav'>$obj->{'FORUM'}->{'FORUM_NAME'}</a>|,
                                              qq|$obj->{'TOPIC'}->{'TOPIC_TITLE'}$event|
                                            ]
                            );
}

#+------------------------------------------------------------------------------------------------------

sub do_member ($$) {
    my ($obj, $Row) = @_;

    $obj->{'POSTER'}->{'MEMBER_AVATAR'}
        = $obj->get_avatar();

    $obj->{'POSTER'}->{'MEMBER_TITLE'}
        = $obj->{'POSTER'}->{'MEMBER_TITLE'} ? $obj->{'POSTER'}->{'MEMBER_TITLE'}
                                             : $obj->{'title_table'}->{  $obj->{'POSTER'}->{'MEMBER_LEVEL'}  }->{'TITLE'};

    $obj->{'POSTER'}->{'MEMBER_JOINED'}
        = $Topic::lang->{'m_joined'}.' '.$std->get_date( TIME => $obj->{'POSTER'}->{'MEMBER_JOINED'}, METHOD => 'JOINED');

    unless( $obj->{'group_table'}->{ $obj->{'POSTER'}->{'MEMBER_GROUP'} }->{'ICON'} ) {
        $obj->{'POSTER'}->{'MEMBER_PIPS'} = $obj->{'title_table'}->{  $obj->{'POSTER'}->{'MEMBER_LEVEL'}  }->{'PIPS'};
        if (defined $obj->{'POSTER'}->{'MEMBER_PIPS'}) {
            if ($obj->{'POSTER'}->{'MEMBER_PIPS'} !~ /^\d+$/) {
                 $obj->{'POSTER'}->{'MEMBER_PIPS_IMG'} = qq!<img src="$iB::INFO->{'TEAM_ICON_URL'}/$obj->{'POSTER'}->{'MEMBER_PIPS'}" border='0' alt="TeamIcon">!;
            } else {
                 $obj->{'POSTER'}->{'MEMBER_PIPS_IMG'} = qq!$iB::SKIN->{'A_STAR'}! x $obj->{'POSTER'}->{'MEMBER_PIPS'};
            }
        }
    } else {
        $obj->{'POSTER'}->{'MEMBER_PIPS_IMG'} = qq!<img src="$iB::INFO->{'TEAM_ICON_URL'}/$obj->{'group_table'}->{ $obj->{'POSTER'}->{'MEMBER_GROUP'} }->{'ICON'}" border='0' alt="TeamIcon">!
    }

    $obj->{'POSTER'}->{'MEMBER_GROUP_NO'} = $obj->{'POSTER'}->{'MEMBER_GROUP'};
    $obj->{'POSTER'}->{'MEMBER_GROUP'}
        = $Topic::lang->{'m_group'}.' '.$obj->{'group_table'}->{ $obj->{'POSTER'}->{'MEMBER_GROUP'} }->{'TITLE'};
    $obj->{'POSTER'}->{'MEMBER_POSTS'}
        = $Topic::lang->{'m_posts'}.' '.$obj->{'POSTER'}->{'MEMBER_POSTS'};
    $obj->{'POSTER'}->{'UP_ICON'}
        = qq!<a href="#top">$iB::SKIN->{'P_UP'}</a>!;
    $obj->{'POSTER'}->{'PROFILE_ICON'}
        = qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$obj->{'POSTER'}->{'MEMBER_ID'}" title="$Topic::lang->{'profile'}">$iB::SKIN->{'P_PROFILE'}</a>&nbsp;!;
    $obj->{'POSTER'}->{'CONTACT_ICON'}
       = qq!<a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=07;MID=$obj->{'POSTER'}->{'MEMBER_ID'}','Contact','400','280','0','1','1','1')" title="$Topic::lang->{'contact'}">$iB::SKIN->{'P_CONTACTINFO'}</a>&nbsp;!;
    $obj->{'POSTER'}->{'HIDE_EMAIL'} = $obj->{'POSTER'}->{'HIDE_EMAIL'} || 0;
    if ($iB::MEMBER->{'MEMBER_ID'}) {
        $obj->{'POSTER'}->{'EMAIL_ICON'}
            = $obj->{'POSTER'}->{'HIDE_EMAIL'} ? ''
                                               : qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Mail;CODE=00;MID=$obj->{'POSTER'}->{'MEMBER_ID'}" title="$Topic::lang->{'email'}">$iB::SKIN->{'P_EMAIL'}</a>&nbsp;];
    }

    $obj->{'POSTER'}->{'WEBSITE_ICON'}
        = ($obj->{'POSTER'}->{'WEBSITE'} and $obj->{'POSTER'}->{'WEBSITE'} =~ m#^http://.+?\S$#i)
                                           ? (qq[<a href='$obj->{'POSTER'}->{'WEBSITE'}' target='_blank'  title="$Topic::lang->{'website'}">$iB::SKIN->{'P_WEBSITE'}</a>&nbsp;])
                                           : ('');

    $obj->{'POSTER'}->{'SEARCH_ICON'}
        = qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Search;CODE=01;keywords=$obj->{'POSTER'}->{'MEMBER_NAME'};type=name;forums=all;search_in=all;prune=$iB::INFO->{'USER_POST_SEARCH_SPAN'}" title="$Topic::lang->{'search_member_posts'}">$iB::SKIN->{'P_SEARCH'}</a>];

    # Get the member warn GFX
    $obj->{'POSTER'}->{'WARN_GFX'} = '';

    # Does the member have a warn value?
    if ($obj->{'POSTER'}->{'WARN_LEVEL'} and length($obj->{'POSTER'}->{'WARN_LEVEL'}) == 1) {
        $obj->{'POSTER'}->{'WARN_GFX'} = $iB::SKIN->{ 'WARN_'.$obj->{'POSTER'}->{'WARN_LEVEL'} };
    }

    my @ratings = split /\|/, $obj->{'POSTER'}->{'RATINGS'};

    my ($total, $count);
    for (@ratings) {
        $count++;
        $total += $_;
    }

    if ($count > 0) {
        my $rating = $total / $count;
        $obj->{'POSTER'}->{'MEMBER_RATING_PCT'} = $rating * 20 . '%';
        $obj->{'POSTER'}->{'MEMBER_RATING_NUM'} = substr($rating, 0, 4);
    } else {
        $obj->{'POSTER'}->{'MEMBER_RATING_PCT'} = '0%';
        $obj->{'POSTER'}->{'MEMBER_RATING_NUM'} = $Topic::lang->{'member_not_rated'};
    }

    if ($iB::INFO->{'MEMBER_RATING'}) {
        $obj->{'POSTER'}->{'MEMBER_RATING'} = TopicView::MemberRating( $obj->{'POSTER'} ) if $iB::INFO->{'TOPIC_SHOW_RATE'};
    }

}

sub do_guest ($) {
   my ($obj, $g_name) = @_;

    $obj->{'POSTER'}->{'MEMBER_NAME'}   = $g_name;
    $obj->{'POSTER'}->{'MEMBER_AVATAR'} = undef;
    $obj->{'POSTER'}->{'MEMBER_TITLE'}  = $Topic::lang->{'unreg'};
    $obj->{'POSTER'}->{'MEMBER_PIPS'}   = undef;
    $obj->{'POSTER'}->{'MEMBER_JOINED'} = undef;
    $obj->{'POSTER'}->{'SIGNATURE'}     = undef;
    $obj->{'POSTER'}->{'PROFILE'}       = undef;
    $obj->{'POSTER'}->{'MEMBER_POSTS'}  = undef;
    $obj->{'POSTER'}->{'MEMBER_GROUP'}  = undef;
    $obj->{'POSTER'}->{'MEMBER_JOINED'} = undef;
    $obj->{'POSTER'}->{'MEMBER_WEB'}    = undef;
    $obj->{'POSTER'}->{'MEMBER_EMAIL'}  = undef;
    $obj->{'POSTER'}->{'MEMBER_ID'}     = undef;
    $obj->{'POSTER'}->{'IP_ADDRESS'}    = $ENV{'REMOTE_ADDR'};
}

sub Check_access ($) {
    my ($obj, $db) = @_;

    if ($obj->{'FORUM'}->{'FORUM_PROTECT'}) {
        if (exists $iB::COOKIES->{ $iB::INFO->{'COOKIE_ID'}.'iBForum' . $obj->{'FORUM'}->{'FORUM_ID'} }) {
            return if $iB::COOKIES->{ $iB::INFO->{'COOKIE_ID'}.'iBForum' . $obj->{'FORUM'}->{'FORUM_ID'} } eq FUNC::Member::MD5($iB::SESSION, $obj->{'FORUM'}->{'FORUM_PROTECT'});
        }
        $output->redirect_screen( TEXT => "$Topic::lang->{'please_log_in'}", URL => "?act=SF;f=$iB::IN{'f'}");
        return 1;
    }

    if ($obj->{'FORUM'}->{'FORUM_VIEW_THREADS'} ne '*') {
        unless (grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$obj->{'FORUM'}->{'FORUM_VIEW_THREADS'}) ) {
            $std->Error(     DB      => $db,
                             LEVEL   => '2',
                             MESSAGE =>'forum_no_access'
                       );
        }
    }
    return 0;
}

#+------------------------------------------------------------------------------------------------------

sub view_ip {
    my ($obj, $Row) = @_;
    if ($iB::MEMBER_GROUP->{'IS_SUPMOD'} or $obj->{'moderator'}->{'VIEW_IP'}) {

        $Row->{'IP_ADDR'} = $obj->{'POSTER'}->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}
                          ? qq~[ -------- ]~
                          : qq~[ <a href='http://www.dnsstuff.com/tools/whois.ch?ip=$Row->{'IP_ADDR'}' target='_blank'>$Row->{'IP_ADDR'}</a> ]~;

        return TopicView::ip_show($Row->{'IP_ADDR'});
    } else {
        return undef;
    }
}

#+------------------------------------------------------------------------------------------------------

my $action = { 'CLOSE_TOPIC'  => '00',
                        'OPEN_TOPIC'   => '01',
                        'MOVE_TOPIC'   => '02',
                        'DELETE_TOPIC' => '03',
                        'EDIT_TOPIC'   => '05',
                        'PIN_TOPIC'    => 15,
                        'UNPIN_TOPIC'  => 16,
                        'RECOUNT'      => 17,
                        'ADD_TOPIC_WATCH'    => 18,
                        'REMOVE_TOPIC_WATCH' => 19,
                      };

sub Moderation_panel {
    my ($obj, $db) = @_;
    # Not a member? Sod off then..
    return unless $iB::MEMBER->{'MEMBER_ID'};
    return unless (
                    ($iB::MEMBER->{'MEMBER_ID'} eq $obj->{'TOPIC'}->{'TOPIC_STARTER'})
                      or ($iB::MEMBER_GROUP->{'IS_SUPMOD'})
                      or ($obj->{'moderator'}->{'MODERATOR_ID'})
                  );

    for my $key (qw[MOVE_TOPIC CLOSE_TOPIC OPEN_TOPIC DELETE_TOPIC EDIT_TOPIC PIN_TOPIC UNPIN_TOPIC RECOUNT ADD_TOPIC_WATCH REMOVE_TOPIC_WATCH]) {
        if    ($iB::MEMBER_GROUP->{'IS_SUPMOD'}) {
            $obj->{'.can_do'} .= $obj->_append($key);
        }
        elsif ($obj->{'moderator'}->{'MODERATOR_ID'}) {
            if ($key eq 'RECOUNT') {
                $obj->{'.can_do'} .= $obj->_append($key);
            } else {
                $obj->{'.can_do'} .= $obj->_append($key) if $obj->{'moderator'}->{ $key };
            }
        }
        elsif ($key eq 'OPEN_TOPIC' or $key eq 'CLOSE_TOPIC') {
            $obj->{'.can_do'} .= $obj->_append($key) if ($iB::MEMBER_GROUP->{'OPEN_CLOSE_TOPICS'});
        }
        elsif ($key eq 'EDIT_TOPIC') {
            if ($iB::MEMBER_GROUP->{'EDIT_OWN_TOPICS'}) {
                $obj->{'.can_do'} .= $obj->_append($key);
            }
        }
        elsif ($key eq 'DELETE_TOPIC') {
            $obj->{'.can_do'} .= $obj->_append($key) if ($iB::MEMBER_GROUP->{'DELETE_OWN_TOPICS'});
        }
    }

    # Do we have the link to the moderators control panel to show?
    if ($iB::MEMBER_GROUP->{'IS_SUPMOD'} or $obj->{'moderator'}->{'MODERATOR_ID'}) {
        $obj->{'.can_do'} .= TopicView::mod_cp_link( $iB::IN{'f'} );
    }
    return TopicView::Mod_Panel($obj->{'.can_do'}) if $obj->{'.can_do'};
}

sub _append {
    my ($obj, $moderate) = @_;
    return if $obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'open'   and $moderate eq 'OPEN_TOPIC';
    return if $obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'closed' and $moderate eq 'CLOSE_TOPIC';
    return if $obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'moved'  and ($moderate eq 'CLOSE_TOPIC' or $moderate eq 'MOVE_TOPIC');
    return if $obj->{'TOPIC'}->{'PIN_STATE'}   and $moderate eq 'PIN_TOPIC';
    return if $obj->{'TOPIC'}->{'PIN_STATE'} < 1  and $moderate eq 'UNPIN_TOPIC';
    return if $obj->{'TOPIC'}->{'WATCHED'} and $moderate eq 'ADD_TOPIC_WATCH';
    return if $obj->{'TOPIC'}->{'WATCHED'} < 1 and $moderate eq 'REMOVE_TOPIC_WATCH';
    return  qq{[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Mod;CODE=$action->{$moderate};f=$iB::IN{'f'};t=$iB::IN{'t'};st=$iB::IN{'st'}'>$Topic::lang->{ $moderate }</a> ] };
}

#+------------------------------------------------------------------------------------------------------

sub get_avatar {
    my $obj = shift;
    return unless $iB::INFO->{'AVATARS'}
              and $obj->{'POSTER'}->{'MEMBER_AVATAR'}
              and $iB::MEMBER->{'VIEW_AVS'};


    if ($obj->{'POSTER'}->{'MEMBER_AVATAR'} eq 'noavatar'){
       $obj->{'POSTER'}->{'MEMBER_AVATAR'} = 'noavatar.gif';}
    return '' if $obj->{'POSTER'}->{'MEMBER_AVATAR'} =~ m#\.swf#i and $iB::INFO->{'ALLOW_FLASH'} != 1;
    my ($a_width   , $a_height)  = split "x", $iB::INFO->{'AV_DIMS'};
    my ($d_a_width, $d_a_height) = split "x", $iB::INFO->{'DEF_AV_DIMS'};
    if ($obj->{'POSTER'}->{'MEMBER_AVATAR'} =~ m#\Ahttp\://#i) {
        if ($iB::INFO->{'AV_ALLOW_URL'}) {
            my ($width  , $height)   = split "x", $obj->{'POSTER'}->{'AVATAR_DIMS'};
            $height ||= $a_height;
            $width  ||= $a_width;
            return $obj->{'POSTER'}->{'MEMBER_AVATAR'} =~ m#\.swf\Z#i ? qq|<OBJECT CLASSID="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" WIDTH=$width HEIGHT=$height><PARAM NAME=MOVIE VALUE=$obj->{'POSTER'}->{'MEMBER_AVATAR'}><PARAM NAME=PLAY VALUE=TRUE><PARAM NAME=LOOP VALUE=TRUE><PARAM NAME=QUALITY VALUE=HIGH><EMBED SRC=$obj->{'POSTER'}->{'MEMBER_AVATAR'} WIDTH=$width HEIGHT=$height PLAY=TRUE LOOP=TRUE QUALITY=HIGH></EMBED></OBJECT>|
                                                                      : qq|<img src='$obj->{'POSTER'}->{'MEMBER_AVATAR'}' border='0' width='$width' height='$height' alt='Avatar'>|;
        }
    }
    return qq|<img src='$iB::INFO->{'AVATARS_URL'}/$obj->{'POSTER'}->{'MEMBER_AVATAR'}' border='0' width='$d_a_width' height='$d_a_height' alt='Avatar'>| unless $obj->{'POSTER'}->{'MEMBER_AVATAR'} =~ m#\Ahttp\://#i;
}

#+------------------------------------------------------------------------------------------------------

sub edit_button {
    my ($obj, $post_number) = @_;
    return unless $iB::MEMBER->{'MEMBER_ID'};
    my $edit_button =  qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=08;f=$iB::IN{'f'};t=$iB::IN{'t'};p=$post_number;st=$iB::IN{'st'}" title="$Topic::lang->{'edit'}">$iB::SKIN->{'P_EDIT'}</a>];
    return $edit_button if $obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'open';
    return $edit_button if $iB::MEMBER_GROUP->{'IS_SUPMOD'};
    return $edit_button if $obj->{'moderator'}->{'EDIT_POST'};
    return $edit_button if $obj->{'POSTER'}->{'MEMBER_ID'} eq $iB::MEMBER->{'MEMBER_ID'} and $iB::MEMBER_GROUP->{'EDIT_OWN_POSTS'};
    return;
}

#+------------------------------------------------------------------------------------------------------

sub quote_button {
	    my ($obj, $post_number) = @_;
    my $quote_button = qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=06;f=$iB::IN{'f'};t=$iB::IN{'t'};p=$post_number" title="$Topic::lang->{'quote'}">$iB::SKIN->{'P_QUOTE'}</a>];
    return $quote_button if $obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'open';
    return;
}

#+------------------------------------------------------------------------------------------------------


sub delete_button {
    my ($obj, $post_number, $posts, $dir) = @_;
    return unless $iB::MEMBER->{'MEMBER_ID'};
    if ($posts == 1){
    return unless ($dir >0);
    }
    my $button = qq[<a href="javascript:delete_post('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Mod;CODE=04;f=$iB::IN{'f'};t=$iB::IN{'t'};p=$post_number;st=$iB::IN{'st'}')">$iB::SKIN->{'P_DELETE'}</a>];
    return $button if $iB::MEMBER_GROUP->{'IS_SUPMOD'};
    return $button if $obj->{'moderator'}->{'DELETE_POST'};
    return $button if $obj->{'POSTER'}->{'MEMBER_ID'} eq $iB::MEMBER->{'MEMBER_ID'} and $iB::MEMBER_GROUP->{'DELETE_OWN_POSTS'};
    return;
}

#+------------------------------------------------------------------------------------------------------

sub get_t_button ($) {
    my $obj = shift;
    return $iB::SKIN->{'A_LOCKED_B'}      if $obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'closed';
    if ($obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'moved') {
    my ($forum, $topic) = split /;/, $obj->{'TOPIC'}->{'MOVED_TO'};
    return qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$forum;t=$topic">$iB::SKIN->{'A_MOVED_B'}</a>!;
    }
    return $iB::SKIN->{'A_POLLONLY_B'}   if $obj->{'TOPIC'}->{'POLL_STATE'} eq 'closed';
    return qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=02;f=$obj->{'FORUM'}->{'FORUM_ID'};t=$obj->{'TOPIC'}->{'TOPIC_ID'}" title='$Topic::lang->{'reply_to_topic'}'>$iB::SKIN->{'A_REPLY'}</a>! if $obj->{'TOPIC'}->{'TOPIC_STATE'} eq 'open';
}

#+-------------------------------------------------------------------------------------------------------

sub mem_stat {
  my $data = shift;
  my $status = 'off';
  foreach  (@{ $iB::ACTIVE->{'NAMES'} }) {
    if ($_->{'NAME'} eq $data->{'POSTER'}->{'MEMBER_NAME'}) {
      return $iB::SKIN->{'ONLINE'};
    }
  }
  return $iB::SKIN->{'OFFLINE'};
}

#+-------------------------------------------------------------------------------------------------------

sub quickreply_unreg {
	my $obj = shift;
	if ($iB::MEMBER->{'MEMBER_ID'}) {
	return qq!<center><b>$iB::MEMBER->{'MEMBER_NAME'}</center></b><br />!;
} else {
	return qq!<input type='text' size='40' maxlength='40' name='UserName' value="$iB::MEMBER->{'MEMBER_NAME'}" onMouseOver="this.focus()" onFocus="this.select()" class='forminput'><br />!;
}
}

1;
