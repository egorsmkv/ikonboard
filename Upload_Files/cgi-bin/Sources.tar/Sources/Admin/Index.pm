package Admin::Index;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#| Index: Admin CP index page
#|
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Lib/ADMIN.pm';
    require 'Admin/SKIN.pm';
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
    use DirHandle;
}

my $SKIN = Admin::SKIN->new();
my $std = FUNC::STD->new();
my $mem = FUNC::Member->new();
my $ADMIN = FUNC::ADMIN->new();
my $INFO = Boardinfo->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub clean_registrations {
    my ($obj, $db) = @_;

    $iB::INFO->{'AUTHORISE_PRUNE'} ||= 30;

    my $t_q = time - $iB::INFO->{'AUTHORISE_PRUNE'} * 60 * 60 * 24;

    my $old_reg = $db->query( TABLE => 'authorisation',
                              WHERE => qq[DATE_ENTERED < "$t_q"],
                              COLUMNS => ['ID', 'MEMBER_ID', 'MEMBER_NAME', 'MEMBER_EMAIL', '_WHERE'],
                            );

    return unless scalar @{$old_reg} > 0;

    for my $i (@{$old_reg}) {
        if ($i->{'_WHERE'} eq 'register' or $i->{'_WHERE'} eq 'outdate') {
            $db->delete( TABLE => 'member_profiles',
                         ID     => $i->{'MEMBER_ID'},
                         KEY    => $i->{'MEMBER_ID'}
                       );
            $db->delete( TABLE => 'calendar',
                         KEY    => $i->{'MEMBER_ID'},
                       );
            $db->delete( TABLE => 'member_notepads',
                         ID     => $i->{'MEMBER_ID'},
                         KEY    => $i->{'MEMBER_ID'},
                       );

            # Clean subscriptions
            my $member_query = $db->query( TABLE    => 'forum_subscriptions',
                                           WHERE    => "MEMBER_ID == '$i->{'MEMBER_ID'}'",
                                           SORT_KEY => 'ID',
                                           SORT_BY => 'Z-A'
                                         );

            if (scalar (@{$member_query}) > 0) {
                foreach my $m (@{$member_query}) {
                    $db->delete( TABLE => 'forum_subscriptions',
                                 ID     => $m->{'ID'},
                                 KEY     => $m->{'ID'},
                               );
                }
            }

            #Delete from Name index

            $db->update_index( TABLE     => 'member_profiles',
                               INDEX_KEY => 'MEMBER_NAME',
                               R_KEY     => $i->{'MEMBER_NAME'},
                               REMOVE    => 1
                             );

            #Delete from Email index

            $db->update_index( TABLE     => 'member_profiles',
                               INDEX_KEY => 'MEMBER_EMAIL',
                               R_KEY     => $i->{'MEMBER_EMAIL'},
                               REMOVE    => 1
                             );

            $db->delete( TABLE => 'authorisation',
                         KEY    => $i->{'ID'},
                       );
        }
    }

    # Clean old message from the messenger
    my $date = (time - (60 * 60 * 24 * $iB::INFO->{'MSG_PRUNE_DAYS'}));
    my $message_query = $db->query( TABLE    => 'message_data',
                                    WHERE    => "DATE < '$date'",
                                    SORT_KEY => 'DATE',
                                    SORT_BY => 'A-Z'
                                  );

    if (scalar (@{$message_query}) > 0) {
        foreach my $p (@{$message_query}) {
            $db->delete( TABLE => 'message_data',
                         ID     => $p->{'MESSAGE_ID'},
                         KEY     => $p->{'MESSAGE_ID'},
                       );
        }
    }
}



sub process {
    my ($obj, $db, $new_updates) = @_;

    $obj->clean_registrations($db);

    # The easiest way to patch a bug in the pre RC1 releases.
    # This code does no harm at all, so it can be left in safely.

    my $cats = $db->query( TABLE => 'categories');

    for my $c (@{$cats}) {
        if ($c->{SUB_CAT_ID} eq '-') {
            $c->{SUB_CAT_ID} = 0;
            $db->update( TABLE => 'categories',
                         KEY    => $c->{CAT_ID},
                         VALUES => $c
                       );
        }
    }

    my $reg_url = "$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&CP=1&act=auth";
    my $pre_url = "$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&CP=1&act=auth&CODE=preview";
    my $las_url = "$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&CP=1&act=auth&CODE=list_lost";
    my $pru_url = "$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&CP=1&act=auth&CODE=prune";
    my $coppa_url = "$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&AD=1&act=auth&CODE=coppa";

    # Get the awaiting authorisation details

    my $auth = $db->query( TABLE    => 'authorisation',
                           SORT_KEY => 'DATE_ENTERED',
                           SORT_BY => 'Z-A',
                         );

    # Split up into the groups

    my (@register, @lostpass, @preview, @prune, @coppa, @files, @foo);

    my $reg_count     = 0;
    my $lost_count    = 0;
    my $pre_count     = 0;
    my $pru_count     = 0;
    my $coppa_count   = 0;
    my $size_board    = 0;
    my $size_emo      = 0;
    my $size_up       = 0;
    my $meg           = (1024 * 1024);
    my $kilob         = 1024;


    for my $a (@{$auth}) {
        if ($a->{'_WHERE'} eq 'register') {
            # just get the top 10
            ++$reg_count;
            next if $reg_count > 10;
            push @register, $a;
        } elsif ($a->{'_WHERE'} eq 'lostpass') {
            # just get the top 10
            ++$lost_count;
            next if $lost_count > 10;
            push @lostpass, $a;
        } elsif ($a->{'_WHERE'} eq 'authorise') {
            ++$pre_count;
            next if $pre_count > 10;
            push @preview, $a;
        } elsif ($a->{'_WHERE'} eq 'coppa') {
            ++$coppa_count;
            next if $coppa_count > 10;
            push @coppa, $a;
        } elsif ($a->{'_WHERE'} eq 'outdate') {
            ++$pru_count;
            next if $pru_count > 10;
            push @prune, $a;
        }
    }




    ## Read Board Folder
    $size_board = $std->Dir_Size(dir => $INFO->{'IKON_DIR'});
    $size_board += $std->Dir_Size(dir => $INFO->{'HTML_DIR'});


    if ($size_board > $meg) { $size_board = sprintf("%.2f", $size_board / $meg); $size_board .= " MB"; }
    elsif ($size_board > $kilob) { $size_board = sprintf("%.2f", $size_board / $kilob); $size_board .= " kB"; }
    else { $size_board .= " Bytes"; }


    ## Read Emoticon Folder
    $size_emo = $std->Dir_Size(dir => $iB::INFO->{'HTML_DIR'}.'emoticons');

    if ($size_emo > $meg) { $size_emo = sprintf("%.2f", $size_emo / $meg); $size_emo .= " MB"; }
    elsif ($size_emo > $kilob) { $size_emo = sprintf("%.2f", $size_emo / $kilob); $size_emo .= " kB"; }
    else { $size_emo .= " Bytes"; }


    ## Read Upload Folder
    $size_up = $std->Dir_Size(dir => $iB::INFO->{'PUBLIC_UPLOAD'});

    if ($size_up > $meg) { $size_up = sprintf("%.2f", $size_up / $meg); $size_up .= " MB"; }
    elsif ($size_up > $kilob) { $size_up = sprintf("%.2f", $size_up / $kilob); $size_up .= " kB"; }
    else { $size_up .= " Bytes"; }

    my $html = qq~

   <table cellspacing='0' cellpadding='5' border='0' width='100%'>
     <tr>
        <td class='t'>Welcome to your Administrative Control Panel. Here you can control every aspect of the forum and change the way it looks and works.</td>
     </tr>
     <tr>
        <td>
    <table cellspacing='0' cellpadding='5' border='0' width='100%' style='border:1px solid black'>
            <tr>
    <td bgcolor='#8888AA' class='t' colspan=3><span style='color:white;font-size:11px'><b>Folder Sizes</span></td>
            </tr>
            <tr>
    <td bgcolor='#F1F1F1' class='t' width=20%>  <b>Board size : </b> </td>
    <td bgcolor='#F1F1F1' class='t' width=20%>$size_board</td><td bgcolor='#F1F1F1' class='t'></td>
            </tr>
            <tr>
    <td bgcolor='#F1F1F1' class='t' width=20%>  <b>Upload folder size : </b> </td>
    <td bgcolor='#F1F1F1' class='t' width=20%>$size_up</td><td bgcolor='#F1F1F1' class='t'></td>
            </tr>
            <tr>
    <td bgcolor='#F1F1F1' class='t' width=20%>  <b>Emoticon directory size : </b> </td>
    <td bgcolor='#F1F1F1' class='t' width=20%>$size_emo</td><td bgcolor='#F1F1F1' class='t'></td>
            </tr>
    </table>
         </td>
    </tr>
    <tr>
    <td>

     <table cellspacing='0' cellpadding='5' border='0' width='100%' style='border:1px solid black'>
    ~;


    $html .= qq~<tr>
             <td bgcolor='#8888AA' class='t'><span style='color:white;font-size:11px'><b>$pre_count members awaiting an admin to preview their registration</b> (showing last 10)</span></td>
              </tr>
               ~;
    for my $m (@preview) {
        my $date = $std->get_date( TIME => $m->{'DATE_ENTERED'}, METHOD => 'LONG' );
        $html .= qq~
                      <tr>
                        <td bgcolor='#F1F1F1' class='t'>&nbsp;&nbsp;<span style='color:red'>&gt;</span><b>$m->{'MEMBER_NAME'}</b> (email address: $m->{'MEMBER_EMAIL'}) registered on <b>$date</b></td>
                      </tr>
                   ~;
    }

    $html .= qq~<tr>
                <td bgcolor='#F1F1F1' class='t' align='right'><a href='$pre_url' target='BODY'>PREVIEW THESE ACCOUNTS (Members cannot post until you do so)</a></td>
              </tr>
             </table>
           </td>
          </tr>
          <tr>
          <td>
            <table cellspacing='0' cellpadding='5' border='0' width='100%' style='border:1px solid black'>
              <tr>
             <td bgcolor='#8888AA' class='t'><span style='color:white;font-size:11px'><b>$pru_count members awaiting an admin to authorize their COPPA registration</b> (showing last 10)</span></td>
              </tr>
    ~;

    for my $m (@coppa) {
        my $date = $std->get_date( TIME => $m->{'DATE_ENTERED'}, METHOD => 'LONG' );
        $html .= qq~
                      <tr>
                        <td bgcolor='#F1F1F1' class='t'>&nbsp;&nbsp;<span style='color:red'>&gt;</span><b>$m->{'MEMBER_NAME'}</b> (email address: $m->{'MEMBER_EMAIL'}) registered on <b>$date</b></td>
                      </tr>
                   ~;
    }

    $html .= qq~<tr>
                <td bgcolor='#F1F1F1' class='t' align='right'><a href='$coppa_url' target='BODY'>PREVIEW THESE ACCOUNTS (Members cannot post until you do so)</a></td>
              </tr>
             </table>
           </td>
          </tr>
          <tr>
          <td>
            <table cellspacing='0' cellpadding='5' border='0' width='100%' style='border:1px solid black'>
              <tr>
             <td bgcolor='#8888AA' class='t'><span style='color:white;font-size:11px'><b>$pru_count members being pruned from the database</b> (showing last 10)</span></td>
              </tr>
    ~;

    for my $m (@prune) {
        my $date = $std->get_date( TIME => $m->{'DATE_ENTERED'}, METHOD => 'LONG' );
        $html .= qq~
                      <tr>
                        <td bgcolor='#F1F1F1' class='t'>&nbsp;&nbsp;<span style='color:red'>&gt;</span><b>$m->{'MEMBER_NAME'}</b> (email address: $m->{'MEMBER_EMAIL'}) pruned on <b>$date</b></td>
                      </tr>
                   ~;
    }

    $html .= qq~<tr>
                <td bgcolor='#F1F1F1' class='t' align='right'><a href='$pru_url' target='BODY'>Manually process these accounts? (You don't have to)</a></td>
              </tr>
             </table>
           </td>
          </tr>
          <tr>
          <td>
            <table cellspacing='0' cellpadding='5' border='0' width='100%' style='border:1px solid black'>
              <tr>
             <td bgcolor='#8888AA' class='t'><span style='color:white;font-size:11px'><b>$reg_count members processing their registration</b> (showing last 10)</span></td>
              </tr>
    ~;

    # Print out the details..
    for my $m (@register) {
        my $date = $std->get_date( TIME => $m->{'DATE_ENTERED'}, METHOD => 'LONG' );
        $html .= qq~
                      <tr>
                        <td bgcolor='#F1F1F1' class='t'>&nbsp;&nbsp;<span style='color:red'>&gt;</span><b>$m->{'MEMBER_NAME'}</b> (email address: $m->{'MEMBER_EMAIL'}) registered on <b>$date</b></td>
                      </tr>
                   ~;
    }

    $html .= qq~
              <tr>
                <td bgcolor='#F1F1F1' class='t' align='right'><a href='$reg_url' target='BODY'>Manually process these accounts? (You don't have to)</a></td>
              </tr>
             </table>
           </td>
          </tr>
          <tr>
          <td>
            <table cellspacing='0' cellpadding='5' border='0' width='100%' style='border:1px solid black'>
              <tr>
               <td bgcolor='#8888AA' class='t'><span style='color:white;font-size:11px'><b>$lost_count members changing their passwords</b> (showing last 10)</span></td>
                </tr>
              ~;

    # Print out the details..
    for my $l (@lostpass) {
        my $date = $std->get_date( TIME => $l->{'DATE_ENTERED'}, METHOD => 'LONG' );
        $html .= qq~
                      <tr>
                        <td bgcolor='#F1F1F1' class='t'>&nbsp;&nbsp;<span style='color:red'>&gt;</span><b>$l->{'MEMBER_NAME'}</b> (email address: $l->{'MEMBER_EMAIL'}) requested a password change on <b>$date</b></td>
                      </tr>
                   ~;
    }

    $html .= qq~
              <tr>
                <td bgcolor='#F1F1F1' class='t' align='right'><a href='$las_url' target='BODY'>Manually process these accounts? (You don't have to)</a></td>
              </tr>
             </table>
          </td>
      </tr>
    ~;
    
    Update();
    
sub Update {
	my ($obj, $db, $new_updates) = @_;
  return unless ($iB::INFO->{'UPDATE_CENTER'});
  require Admin::Update;
  my ($count, $announce) = Admin::Update::ShowCount();
  $new_updates = $count;
  my $bgcolor = "#8888AA";
  $bgcolor = "red" if ($count > 0);
  $html .= qq~
            <tr>
             <td>
               <table cellspacing='0' cellpadding='5' border='0' width='100%' style='border:1px solid black'>
                 <tr>
                  <td bgcolor="$bgcolor" class='t'><span style='color:white;font-size:11px'><b>$new_updates updates are available for your IkonBoard version</b></span></td>
                 </tr>
                 <tr>
                  <td bgcolor='#F1F1F1' class='t' align='left'>$announce</td>
                 </tr>
                 <tr>
                  <td bgcolor='#F1F1F1' class='t' align='right'><a href="http://impluxdesigns.com/ikonboard" target='BODY'>Visit iB Update Center</a></td>
                 </tr>
               </table>
             </td>
            </tr>
            ~;
        }
        
  $html .= qq~
  			</table>
           ~;
       

    $ADMIN->Output( WHERE => 'WELCOME', NAV_ONE => 'Welcome to your CP', PRINT => $html);

}


1;
__END__
