package Admin::Menuadmin;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Menuadmin: Admin CP side menu
# -> Javascript menu functions by Method and KEVaholic00
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Lib/ADMIN.pm';
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
}

my $std   = FUNC::STD->new();
my $ADMIN = FUNC::ADMIN->new();
my $INFO  = Boardinfo->new();
my $img   = $INFO->{'IMAGES_URL'}.'/sys-img';
my $help  = $INFO->{'IMAGES_URL'}.'/help_admin';

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub start {
    my ($obj, $db) = @_;

    open MENU, "<".$INFO->{'DB_DIR'}."Temp/menu-$iB::MEMBER->{'MEMBER_ID'}.cgi";
    my $admin_menu = <MENU>;
    my @valu = split(/&/,$admin_menu);
    my $url = "$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}";
    my $board_st = $INFO->{'B_ONLINE'} ? 'Offline' : 'Online';
    close MENU;

    my $open_menus = {};
    foreach my $m (@valu) {
        $open_menus->{ $m } = 1;
    }
    my $board_status = { 'Offline' => 'Online',
                         'Online'  => 'Offline',
                       };
    my $status = $board_status->{ $board_st };

    my $html = qq~
    <html>
    <head>
    <title>Ikonboard Menu Frame</title>
    <style type="text/css">
    #expand {
        font-weight:plain;
        font-size:10px;
    }

    #expand a:link,
    #expand a:visited,
    #expand a:active {
        font-size:10px;
        font-weight:plain;
        text-decoration:none;
    }

    .menutitle {
        cursor:pointer;
        margin-bottom: 12px;
        background-color:#8C91B5;
        border:1px solid black;
        color:#FFFFFF;
        width:98%;
        padding:1px;
        text-align:left;
        font-weight:bold;
        font-family:Verdana, Arial;
        font-size:12px;
    }

    .submenu {
        margin-bottom: 0.5em;
        text-decoration:none;
        background-image:url('$img/whiteslice.gif');
        width:100%;
        padding:2px;
        font-family:Verdana, Arial;
        font-size:10px;
    }

    body {
        overflow:auto;
        font-family: Verdana, Arial;
        font-size: 11px;
    }

    body          { scrollbar-track-color: rgb(241, 241, 241);
                    scrollbar-face-color: rgb(102, 102, 152);
                    scrollbar-arrow-color: rgb(241, 241, 241);
                    scrollbar-shadow-color: rgb(241, 241, 241);
                    scrollbar-darkshadow-color: rgb(0, 0, 0);
                    scrollbar-highlight-color: rgb(100, 100, 100);
                    scrollbar-3dlight-color: rgb(241, 241, 241);
                  }

    a:link {
        text-decoration: none;
        text-align:left;
        font-weight:bold;
        color:#797979;
    }

    a:visited {
        text-decoration: none;
        color:#797979;
        font-weight:bold;
    }

    a:hover {
        background-color:#F0E1FF;
    }

    font          { font-family: Verdana, Arial; font-size: 12px; color: #000000 }
    font.large    { font-family: Verdana, Arial; font-size: 11px; font-weight: bold; color: #CC0000 }

    #tble         { width: 100%; background-color: #EEEEEE }
    #toptble      { background-image:url('$img/whiteslice.gif') }

    font.title    { background-color: #666699; font-weight: 800; font-family: Verdana, Arial; font-size:11px; color: #FFFFFF; width: 100%; padding: 2px; cursor: hand;}
    font.item     { font-family: Verdana, Arial; font-size:11px; color: #333366; }

    #title        { background-color: #666699; font-weight: 800; font-family: Verdana, Arial; font-size:11px; color: #FFFFFF; padding: 2px; cursor: hand;}

    a.title       { cursor:hand; font-family: Verdana, Arial; font-size:11px; color : #FFFFFF }
    a.title:visited { color: #FFFFFF }
    </style>
    <script language="JavaScript">
    <!--

function refresh() {
    window.location.reload(false);
}

function SwitchMenu(obj){
    if(document.getElementById){
        var el = document.getElementById(obj);
        var ar = document.getElementById("masterdiv").getElementsByTagName("span");
        if(el.style.display != "block"){
            /*for (var i=11; i<ar.length; i++){*/
                /*if (ar[i].className=="submenu") ar[i].style.display = "none";*/
            /*}*/
            el.style.display = "block";
        }else{
            el.style.display = "none";
        }
    }
}

function ExpandAll(){
    var ar = document.getElementById("masterdiv").getElementsByTagName("span");
    for(i=0; i<ar.length; i++){
        if (ar[i].className=="submenu") ar[i].style.display = "block";
    }
}

function CollapseAll(){
    var ar = document.getElementById("masterdiv").getElementsByTagName("span");
    for(i=0; i<ar.length; i++){
        if (ar[i].className=="submenu") ar[i].style.display = "none";
    }
}

    //-->
    </script>
    <script src="$INFO->{'IMAGES_URL'}/Skin/Default/ikonboard.js">
    </script>
    </head>
    <body background="$img/whiteslice.gif" marginheight='0' marginwidth='0' leftmargin='0' topmargin='0'>
            <table width='100%' cellspacing='0' cellpadding='0' border='0' align='center' bgcolor='#666699' id='toptble'>
            <tr>
                    <td align='center'><img src='$img/cp-side-logo.jpg' border='0' width='100%' height='77' alt=''></td>
            </tr>
            <tr>
                    <td align='center'>
                    <a href='$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION' target='_top'><font class='item'>Go to your board</font></a>
                    <br><a href='$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?CP=1&act=body&s=$iB::SESSION' target='BODY'><font class='item'>Go to admin index</font></a>
                    <br><font class='item'>Board is currently <b>$status</b></font>
                    <br><font class='item'>Using <b>$INFO->{'DB_DRIVER'}</b> DB</font>
                    <br>
                    </td>
            </tr>
            </table>
    <!-- Keep all menus within masterdiv-->
    <div id="masterdiv">
          <span id="expand"><center>[ <a href="#" onclick="ExpandAll();this.blur();return false">Expand All</a> ][ <a href="#" onclick="CollapseAll();this.blur();return false">Collapse All</a> ]</center></span>
                <div class="menutitle" onclick="SwitchMenu('sub1')">Maintain / Tool Box</div>
                <span class="submenu" id="sub1">
                            &gt; <a href='$url?AD=1&act=online&s=$iB::SESSION' target='BODY'>Switch board on/off</a><br><br>
                            &gt; <a href='$url?AD=1&act=file&s=$iB::SESSION' target='BODY'>Launch File Manager</a><br><br>
                            &gt; <a href='$url?AD=1&act=temps&s=$iB::SESSION' target='BODY'>Clean Temp Files</a><br>
                            &gt; <a href='$url?AD=1&act=sess&s=$iB::SESSION' target='BODY'>Reset Sessions</a><br>
                            &gt; <a href='$url?AD=1&act=stats&s=$iB::SESSION' target='BODY'>Rebuild Board Stats</a><br><br>
                            &gt; <a href='$url?AD=1&act=logs&s=$iB::SESSION' target='BODY'>View Moderator Logs</a><br>
                            &gt; <a href='$url?AD=1&act=logs&s=$iB::SESSION&CODE=del' target='BODY'>Remove Moderator Logs</a><br><br>
            <b><u>General Tool Box</u></b><br>
                &gt; <a href='$url?AD=1&act=tools&s=$iB::SESSION&CODE=groups' target='BODY'>Remove duplicate member groups</a><br>
                &gt; <a href='$url?AD=1&act=tools&s=$iB::SESSION&CODE=titles' target='BODY'>Remove custom member titles</a><br>
                &gt; <a href='$url?AD=1&act=tools&s=$iB::SESSION&CODE=skin'   target='BODY'>Rebuild skin .cfg files</a><br>
                &gt; <a href='$url?AD=1&act=tools&s=$iB::SESSION&CODE=calendar'   target='BODY'>Clean dead links in the events calendar</a><br>
                &gt; <a href='$url?AD=1&act=postcolors&s=$iB::SESSION&CODE=reset'  target='BODY'>Reset Post Colors</a><br><br>
                &gt; <a href="javascript:PopUp('$img/colours.html','Colours','500','300','0','1','1','1')">Color Chart</a><br>
                &gt; <a href="javascript:PopUp('$img/css.html','CSS','500','300','0','1','1','1')">CSS Maker</a><br>
                </span>
                <div class="menutitle" onclick="SwitchMenu('sub2')">Options / Settings</div>
                <span class="submenu" id="sub2">
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=password' target='BODY'>Set/Delete AdminCP PWD</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=password_set' target='BODY'>AdminCP Protected Sections</a><br><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=defaults' target='BODY'>Skin/Language Defaults</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=showPaths' target='BODY'>Board Paths</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=showOps' target='BODY'>Board Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=forum' target='BODY'>Forum Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=topic' target='BODY'>Topic Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=email' target='BODY'>Email Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=search' target='BODY'>Search Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=register' target='BODY'>Register Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=post' target='BODY'>Post Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=memberlist' target='BODY'>MemberList Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=member' target='BODY'>Member Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=pm' target='BODY'>PM Options</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=active' target='BODY'>Active Users Hi-lighting</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=report' target='BODY'>"Report Post" set up</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=event' target='BODY'>"Event calendar" set up</a><br>
                        &gt; <a href='$url?AD=1&act=webring&s=$iB::SESSION' target='BODY'>Manage Web Ring</a><br>
                        &gt; <a href='$url?AD=1&act=ops&s=$iB::SESSION&CODE=coppa' target='BODY'>Coppa Options</a><br><br>
                </span>
                <div class="menutitle" onclick="SwitchMenu('sub3')">Categories / Forums</div>
                <span class="submenu" id="sub3">
                        <b><u>Category Control</u></b><br>
                                &gt; <a href='$url?AD=1&act=cat&s=$iB::SESSION&CODE=02' target='BODY'>Add New</a><br>
                                &gt; <a href='$url?AD=1&act=cat&s=$iB::SESSION&CODE=delete' target='BODY'>Remove Category</a><br>
                                &gt; <a href='$url?AD=1&act=cat&s=$iB::SESSION' target='BODY'>Edit Category</a><br>
                                &gt; <a href='$url?AD=1&act=cat&s=$iB::SESSION&CODE=reorder' target='BODY'>Re-Order Categories</a><br><br>
                        <b><u>Forum Control</b></u><br>
                                &gt; <a href='$url?AD=1&act=forum&s=$iB::SESSION&CODE=add' target='BODY'>Add New</a><br>
                                &gt; <a href='$url?AD=1&act=forum&s=$iB::SESSION&CODE=del' target='BODY'>Remove Forum</a><br>
                                &gt; <a href='$url?AD=1&act=forum&s=$iB::SESSION' target='BODY'>Edit Forum</a><br>
                                &gt; <a href='$url?AD=1&act=forum&s=$iB::SESSION&CODE=reorder' target='BODY'>Re-Order Forums</a><br>
                                &gt; <a href='$url?AD=1&act=forum&s=$iB::SESSION&CODE=count' target='BODY'>Recount Forum</a><br><br>
                                &gt; <a href='$url?AD=1&act=forum&s=$iB::SESSION&CODE=list_rules' target='BODY'>Edit/Add Forum Rules</a>
                        </span>
                <div class="menutitle" onclick="SwitchMenu('sub4')">Member Control</div>
                <span class="submenu" id="sub4">
                        <b><u>Member Control</b></u><br>
                               &gt; <a href='$url?AD=1&act=member&s=$iB::SESSION&CODE=reg' target='BODY'>Pre-Register</a><br>
                               &gt; <a href='$url?AD=1&act=member&s=$iB::SESSION' target='BODY'>Edit Member</a><br>
                               &gt; <a href='$url?AD=1&act=member&s=$iB::SESSION&CODE=del' target='BODY'>DELETE Member(s)</a><br>
                               &gt; <a href='$url?AD=1&act=member&s=$iB::SESSION&CODE=outdate' target='BODY'>PRUNE Member</a><br>
                               &gt; <a href='$url?AD=1&act=member&s=$iB::SESSION&CODE=ban' target='BODY'>Ban Control</a><br>
                               &gt; <a href='$url?AD=1&act=member&s=$iB::SESSION&CODE=email' target='BODY'>Send Email</a><br><br>
                               &gt; <a href='$url?AD=1&act=member&s=$iB::SESSION&CODE=titles' target='BODY'>Add/Edit/Remove Titles</a><br><br>
                               &gt; <a href='$url?AD=1&act=member&s=$iB::SESSION&CODE=list' target='BODY'>Create member list CSV file</a><br><br>
                          <b><u>Member Groups</u></b><br>
                              &gt; <a href='$url?AD=1&act=group&s=$iB::SESSION&CODE=add' target='BODY'>Add Group</a><br>
                              &gt; <a href='$url?AD=1&act=group&s=$iB::SESSION' target='BODY'>Edit Groups</a><br>
                              &gt; <a href='$url?AD=1&act=group&s=$iB::SESSION&CODE=del' target='BODY'>Delete Groups</a><br>
                              &gt; <a href='$url?AD=1&act=group&s=$iB::SESSION&CODE=default' target='BODY'>Default User Groups</a><br>
                              &gt; <a href='$url?AD=1&act=group&s=$iB::SESSION&CODE=forummask' target='BODY'>Edit a group's forum mask</a>
                </span>
            <div class="menutitle" onclick="SwitchMenu('sub5')">Moderation Control</div>
                        <span class="submenu" id="sub5">
                <b><u>Add Forum Moderators</u></b><br>
                &gt; <a href='$url?AD=1&act=mods&s=$iB::SESSION' target='BODY'>Add Moderator</a><br>
                &gt; <a href='$url?AD=1&act=mods&s=$iB::SESSION&CODE=del' target='BODY'>Remove Moderator(s)</a><br>
                &gt; <a href='$url?AD=1&act=mods&s=$iB::SESSION&CODE=edit' target='BODY'>Edit Moderators</a><br><br>
           <b><u>Moderate Registrations</u></b><br>
                &gt; <a href='$url?AD=1&act=auth&s=$iB::SESSION' target='BODY'>Manage Reg. Requests</a><br>
                &gt; <a href='$url?AD=1&act=auth&s=$iB::SESSION&CODE=list_lost' target='BODY'>Manage lostP/W requests</a><br>
                &gt; <a href='$url?AD=1&act=auth&s=$iB::SESSION&CODE=preview' target='BODY'>Preview Registrations</a><br>
                &gt; <a href='$url?AD=1&act=auth&s=$iB::SESSION&CODE=prune' target='BODY'>Manage Pruned Reg.</a><br>
                </span>
            <div class="menutitle" onclick="SwitchMenu('sub6')">News / Help Manager</div>
                        <span class="submenu" id="sub6">
                          <b><u>News Manager</u></b><br>
                                 &gt; <a href='$url?AD=1&act=template&s=$iB::SESSION&CODE=news' target='BODY'>Set Up/Edit Settings</a><br>
                                 &gt; <a href='$url?AD=1&act=template&s=$iB::SESSION&CODE=tiker' target='BODY'>Set Up/Edit Headline News</a><br>
                                 &gt; <a href='$url?AD=1&act=template&s=$iB::SESSION&CODE=update' target='BODY'>Force News Update</a><br>
                            <b><u>Help Manager</u></b><br>
                                 &gt; <a href='$url?AD=1&act=help&s=$iB::SESSION&CODE=add'  target='BODY'>Add Help Topic</a><br>
                                 &gt; <a href='$url?AD=1&act=help&s=$iB::SESSION&CODE=edit' target='BODY'>Edit Topics</a><br>
                                 &gt; <a href='$url?AD=1&act=help&s=$iB::SESSION&CODE=del'  target='BODY'>Delete Topics</a><br>
                        </span>
              <div class="menutitle" onclick="SwitchMenu('sub7')">Skin / Templates</div>
                          <span class="submenu" id="sub7">
                                  <b><u>Skin</u></b><br>
                                      &gt; <a href='$url?AD=1&act=styles&s=$iB::SESSION' target='BODY'>Edit Skin Properties</a><br>
                                      &gt; <a href='$url?AD=1&act=skin&s=$iB::SESSION' target='BODY'>Create New Skin</a><br>
                                      &gt; <a href='$url?AD=1&act=skin&s=$iB::SESSION&CODE=export' target='BODY'>Export Skin Pack</a><br>
                                      &gt; <a href='$url?AD=1&act=skin&s=$iB::SESSION&CODE=import' target='BODY'>Import Skin Pack</a><br><br>
                                      &gt; <a href='$url?AD=1&act=skin&s=$iB::SESSION&CODE=show' target='BODY'>Show Skin Paths</a><br><br>
                                      &gt; <a href='$url?AD=1&act=skin&s=$iB::SESSION&CODE=remove' target='BODY'>Remove Skin</a><br><br>
                                 <b><u>Templates</u></b><br>
                                      &gt; <a href='$url?AD=1&act=template&s=$iB::SESSION' target='BODY'>Edit SSI/Email Templates</a><br>
                                      &gt; <a href='$url?AD=1&act=board&s=$iB::SESSION' target='BODY'>New Board Template</a><br>
                                      &gt; <a href='$url?AD=1&act=board&s=$iB::SESSION&CODE=edit' target='BODY'>Edit Board Template</a><br>
                          </span>
              <div class="menutitle" onclick="SwitchMenu('sub8')">Global Settings</div>
                          <span class="submenu" id="sub8">
                                        &gt; <a href='$url?AD=1&act=emoticon&s=$iB::SESSION' target='BODY'>Edit Emoticons</a><br>
                                        &gt; <a href='$url?AD=1&act=emoticon&s=$iB::SESSION&CODE=add' target='BODY'>Add Emoticons</a><br>
                                        &gt; <a href='$url?AD=1&act=emoticon&s=$iB::SESSION&CODE=upload' target='BODY'>Upload Emoticons</a><br>
                                        &gt; <a href='$url?AD=1&act=emoticon&s=$iB::SESSION&CODE=quickreply' target='BODY'>Edit Quick Reply Emoticons</a><br><br>
                                        &gt; <a href='$url?AD=1&act=mime&s=$iB::SESSION' target='BODY'>Edit MIME Types</a><br>
                                        &gt; <a href='$url?AD=1&act=mime&s=$iB::SESSION&CODE=add' target='BODY'>Add MIME Types</a><br>
                          </span>
              <div class="menutitle" onclick="SwitchMenu('sub9')">Database Control</div>
                          <span class="submenu" id="sub9">
                                        &gt; <a href='$url?AD=1&act=bak&s=$iB::SESSION' target='BODY'>Export Database</a><br>
                                        &gt; <a href='$url?AD=1&act=import&s=$iB::SESSION' target='BODY'>Import Database</a><br><br>
                                        &gt; <a href='$url?AD=1&act=dbHandler&s=$iB::SESSION' target='BODY'>Drop Database</a><br>
                                        &gt; <a href='$url?AD=1&act=dbHandler&s=$iB::SESSION&CODE=setup' target='BODY'>Set-up Database</a><br>
                                        &gt; <a href='$url?AD=1&act=dbHandler&s=$iB::SESSION&CODE=switch' target='BODY'>Switch DB Driver</a><br><br>

                                        &gt; <a href='$url?AD=1&act=convert&s=$iB::SESSION' target='BODY'>iB 2 Import into DBM</a><br><br>
                                  <b><u>DBM Tools</u></b><br>
                                        &gt; <a href='$url?AD=1&act=dbmclient&s=$iB::SESSION' target='BODY'>ReIndex Members</a><br>
                                        &gt; <a href='$url?AD=1&act=sqlclient&s=$iB::SESSION&CODE=forum_info' target='BODY'>Forum Info Fixer</a><br><br>
                                  <b><u>SQL Tools</u></b><br>
                                        &gt; <a href='$url?AD=1&act=sqlclient&s=$iB::SESSION' target='BODY'>SQL client</a><br>
                          </span>
               <div class="menutitle" onclick="SwitchMenu('sub10')">Language Control</div>
                           <span class="submenu" id="sub10">
                                         &gt; <a href='$url?AD=1&act=lang&s=$iB::SESSION' target='BODY'>Edit Language files</a><br>
                                         &gt; <a href='$url?AD=1&act=lang&s=$iB::SESSION&CODE=new' target='BODY'>Create Language Pack</a><br>
                                         &gt; <a href='$url?AD=1&act=lang&s=$iB::SESSION&CODE=export' target='BODY'>Export Language Packs</a><br>
                                         &gt; <a href='$url?AD=1&act=lang&s=$iB::SESSION&CODE=import' target='BODY'>Import Language Packs</a><br><br>
                                         &gt; <a href='$url?AD=1&act=lang&s=$iB::SESSION&CODE=remove' target='BODY'>Remove Language Pack</a>
                           </span>
               <div class="menutitle" onclick="SwitchMenu('sub11')">Network Links</div>
                           <span class="submenu" id="sub11">
                                                                              &gt; <a href="http://impluxdesigns.com" target='_blank'>Implux Designs</a><br>
                                    
                           </span>

</div>
<br><br>
        </body>
        </html>
    ~;

    $ADMIN->Print( DB     => $db,
                   STD    => $std,
                   OUTPUT => $html,
                 );
}

sub process {
    my ($obj, $db) = @_;
    start($obj,$db);
}

1;
__END__
