package Admin::WebRing;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# MemberControl: Member account editor
#
#################################################################################
#
# WebRing: Web ring control
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Lib/ADMIN.pm';
    require 'Admin/SKIN.pm';
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
}

my $SKIN  = Admin::SKIN->new();
my $std   = FUNC::STD->new();
my $ADMIN = FUNC::ADMIN->new();
my $INFO  = Boardinfo->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub splash {
    my ($obj, $db) = @_;

    my $web_ring =  $INFO->{'WEB_RING'};
       $web_ring =~ s#\|\^\|#\n#g;
       $web_ring =~ s#\|\&\|#\=#g;

    my $html  = $SKIN->title( TITLE => 'Your Web Ring' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'webring',
                                        CODE  => 'savering'
                                      } );
       $html .= $SKIN->section_header( TITLE => "You may edit your web ring below.", TEXT => qq~You can add other Ikonboards to your Web Ring below. One per line!<br><br>To remove a link, remove it from the textbox below.<br><br>FORMAT: <b><font color='red'>URL</font></b>=<b><font color='red'>TITLE</font></b><br>In other words, you type in the URL to the Ikonboard, then type an equal sign ("<font color='red'>=</font>") and finally the title you want it to appear as in your web ring.~ );
       $html .= $SKIN->td_textarea( TEXT => "", NAME => "WEB_RING", VALUE => $web_ring, ROWS => "7", SPAN => 1, NO_PARSE => 1 );
       $html .= $SKIN->td_submit( NAME => '', VALUE => 'Save Web Ring' );
       $html .= $SKIN->form_end();
       $html .= $SKIN->end_table();



    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => 'Your Web Ring', PRINT => $html );
}

sub SaveRing {
    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();

    my $data =  $iB::CGI->param('WEB_RING');

    my @web_ring = split /\r/, $data;

    my (@new_web_ring);
    my $underscore;
    for (@web_ring) {
        next if ($_ eq '' or $_ eq "\n");
        my @underscore = split /\=/;
        my $title = pop @underscore;
        my $underscore = (join '=', @underscore) . '|&|' . $title;
        push @new_web_ring, $underscore;
    }

    my $web_ring       =  join '', @new_web_ring;
       $web_ring       =~ s!\n!\|\^\|!g;
    $OLD->{'WEB_RING'} = $web_ring;

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->write_log( TITLE => 'Web Ring Modified' );
    $ADMIN->static_screen( URL   => "act=webring",
                           TITLE => "Web Ring Edited",
                           TEXT  => "The changes were successful"
                         );
}

sub Process {
    my ($obj, $db) = @_;

    my %Mode = ( 'savering' => \&SaveRing,
               );

    $Mode{ $iB::IN{'CODE'} } ? $Mode{ $iB::IN{'CODE'} }->($obj,$db) : splash($obj,$db);
}

1;
