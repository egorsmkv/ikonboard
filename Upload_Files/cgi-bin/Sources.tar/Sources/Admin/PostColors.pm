package Admin::PostColors;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# MemberControl: Member account editor
#
#################################################################################
#
# PostColors: Reset post colors
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Lib/ADMIN.pm';
    require 'Admin/SKIN.pm';
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
    require 'Sessions.pm';
}

my $SKIN  = Admin::SKIN->new();
my $std   = FUNC::STD->new();
my $ADMIN = FUNC::ADMIN->new();
my $INFO  = Boardinfo->new();
my $sess  = Sessions->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub splash {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Resetting Post Colors');
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'postcolors',
                                        CODE  => 'do_reset'
                                      } );

    #+-----------------------------------

    $html .= $SKIN->section_header( TITLE => "Please select an option", TEXT => "Choose how you want the colors used in posts to be reset. (NOTE: This will reset ALL colors, not just those used from the user's post font color from their User CP.) Also, note that this process can take a minute or two after you submit the form, depending on how many posts there are on your board." );

    $html .= qq~
    <tr>
    <td bgcolor='#FFFFFF' width='40%' align='left' valign='top'><font class='t'>&nbsp;&nbsp;&nbsp;&nbsp;Choose... <font class='h'>*</font></font></td>
    <td bgcolor='#FFFFFF' width='60%' align='left'><font class='t'><input type='radio' style='background-color:transparent' name='METHOD' value='1' checked> Remove all color tags and user post font colors from all posts</font><br>
    <font class='t'><input type='radio' style='background-color:transparent' name='METHOD' value='2'> Replace all color tags and user post font colors in all posts with the following color: <input type='text' size='7' name='REPLACE' value='#000000' class='forminput' style='width:100px'></font></td>
    </tr>
    ~;

    my @all_forums = map { { NAME => $_->{'FORUM_NAME'}, VALUE => $_->{'FORUM_ID'} } }
                     $db->query( TABLE     => 'forum_info',
                                 SORT_KEY  => 'FORUM_POSITION',
                                 SORT_BY   => 'A-Z',
                                 MATCH     => 'ALL'
                               );

    $html .= $SKIN->td_select( TEXT     => 'Forums to replace colors in:',
                               NAME     => 'FORUMS',
                               SIZE     => '8',
                               MULTIPLE => '1',
                               VALUES   => '',
                               DATA     => \@all_forums
                             );



    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Reset Post Colors' );


    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'MAINTAIN', NAV_ONE => 'Resetting Post Colors', PRINT => $html);

}


sub do_reset {
    my ($obj, $db) = @_;

    my @forums = $iB::CGI->param('FORUMS');

    $ADMIN->Error( DB => $db, STD => $std, MSG => "You didn't choose any forums to replace colors in") unless (scalar @forums > 0);
    $ADMIN->Error( DB => $db, STD => $std, MSG => "To replace colors in posts, you must enter a replacement!") if ($iB::IN{'METHOD'} == 2 and $iB::IN{'REPLACE'} eq '');

    # Query for all the topics in the selected forums.
    my $all_topics;
    for (@forums) {
        push @{$all_topics}, $db->query( TABLE => 'forum_topics',
                                         WHERE => "FORUM_ID = '$_'",
                                         ID    => $_
                                       );
    }

    # Query for all the posts in the found topics. Isn't this ludicrous?
    my $all_posts;
    for (@{$all_topics}) {
        push @{$all_posts}, $db->query( TABLE => 'forum_posts',
                                        DBID  => 'f'.$_->{'FORUM_ID'},
                                        ID    => $_->{'TOPIC_ID'},
                                      );
    }

    # Now we will go through __every__ post and replace the colors. This will be a tedious process,
    # but what must be done must be done.......

    for my $Row (@{ $all_posts }) {
        # Skip posts that don't have color tags in them.

        next unless ($Row->{'POST'} =~ /\[color=\S+?\].+?\[\/color\]/i or $Row->{'POST'} =~ /\[postcolor=\S+?\].+?\[\/postcolor\]/i or $Row->{'POST'} =~ /<span style=['"]color\:\S+?['"]>.+?<\/span>/i or $Row->{'POST'} =~ /<font color=['"]\S+?['"]>.+?<\/font>/i);

        # Replace the colors/remove the color tags.
        if ($iB::IN{'METHOD'} == 1) {
            $Row->{'POST'} =~ s!\[color=\S+?\]!!gi;
            $Row->{'POST'} =~ s!\[/color\]!!gi;
            $Row->{'POST'} =~ s!\[postcolor=\S+?\]!!gi;
            $Row->{'POST'} =~ s!\[/postcolor\]!!gi;
            $Row->{'POST'} =~ s!<span style=['"]color\:\S+?['"]>!!gi;
            $Row->{'POST'} =~ s!</span>!!gi;
            $Row->{'POST'} =~ s!<font color=['"]\S+?['"]>!!gi;
            $Row->{'POST'} =~ s!</font>!!gi;
        } else {
            $Row->{'POST'} =~ s!\[color=\S+?\]!\[color=$iB::IN{'REPLACE'}\]!gi;
            $Row->{'POST'} =~ s!\[postcolor=\S+?\]!\[postcolor=$iB::IN{'REPLACE'}\]!gi;
            $Row->{'POST'} =~ s!<span style=(['"])color\:\S+?(['"])>!<span style=${1}color\:$iB::IN{'REPLACE'}$2>!gi;
            $Row->{'POST'} =~ s!<font color=(['"])\S+?(['"])>!<font color=$1$iB::IN{'REPLACE'}$2>!gi;
        }

        # Update the post's row in the database.
        $db->update( TABLE     => 'forum_posts',
                     DBID      => 'f'.$Row->{'FORUM_ID'},
                     ID        => $Row->{'TOPIC_ID'},
                     KEY       => $Row->{'POST_ID'},
                     VALUES    => $Row
                   );
    }



    # Let the big cheese know what a rat we are.
    $ADMIN->write_log( TITLE => "Post colors reset (Method $iB::IN{'METHOD'})");

    # And - tada! - we are done.
    $ADMIN->static_screen( URL   => "act=postcolors",
                           TITLE => "Post Colors Reset",
                           TEXT  => "The changes were successful<br>"
                         );
}



##########################################################################################
#
# Process Sub
#
##########################################################################################


sub Process {
    my ($obj, $db) = @_;

    my $CodeNo = $iB::IN{'CODE'};

    my %Mode = ( 'reset'        => \&splash,
                 'do_reset'     => \&do_reset,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj,$db) : splash($obj,$db);
}


1;
__END__
