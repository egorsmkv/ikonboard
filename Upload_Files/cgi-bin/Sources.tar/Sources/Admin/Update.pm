package Admin::Update;
use strict;

############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Update Center: Enables Board Admin To Keep Their IkonBoards Up To Date.
# Written by ZiaTioN
#
#################################################################################

use lib ( './install_modules' ,
          './',
        );


require "Boardinfo.cgi";
my $BoardInfo = Boardinfo->new();
my $img       = $BoardInfo->{'IMAGES_URL'}.'/sys-img';
my $site      = "http://ib.impluxdesigns.com/support/update_center/";

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub Process {
   use LWP::Simple;

   my $view;
   if ($iB::IN{'ucact'}) {
      autoupdate($iB::IN{'id'}, $iB::IN{'path'}) if ($iB::IN{'ucact'} eq 'autoup');
      download($iB::IN{'path'}) if ($iB::IN{'ucact'} eq 'down');
      $view = download($iB::IN{'path'}) if ($iB::IN{'ucact'} eq 'view');
      ignore($iB::IN{'id'}) if ($iB::IN{'ucact'} eq 'ignore');
   }

   my $HTML = get("$site/update_center.txt") ||
      die "Unable to contact the Update Center at this time: ($!)\n";

   my %hash = ();
   if (-e "$BoardInfo->{'IKON_DIR'}/Database/Temp/UPDATE.log") {
      open(LOG, "<", "$BoardInfo->{'IKON_DIR'}/Database/Temp/UPDATE.log") || die "Unable to open log logfile: ($!)\n";
      while (<LOG>) {
         chomp();
         $hash{ $_ } = $_;
      }
      close(LOG);
   }

   my @data = split(/\n/, $HTML);
   my ($data, $announce, $downDir);
   for (@data) {
      next if ($_ =~ /^#/ || $_ =~ /^\s+$/);
      my ($id, $type, $desc, $date, $file) = split(/\:\:/, $_);
      chomp($id, $type, $desc, $date, $file);

      next if (exists($hash{ $id }));
      my $BoardVersion;
      if ($iB::VERSION =~ /(^\d\.\d\.\d).*/) {
         $BoardVersion = $1;
         $BoardVersion =~ s/\.//g;
      }

      if ($id eq '0000') {
         $announce = qq~
                       <tr align="left">
                        <td width="100%"><i>IkonBoard Team Announcement</i>: $type<br></td>
                       </tr>
                       ~;
      }

      if ($id eq '0001') {
         $downDir = $type;
      }

      if ($id >= $BoardVersion) {
         my $clog = qq~
                      <tr bgcolor="#EEEEEE"><td><p>&nbsp;</p></td></tr>
                      <tr align="center" bgcolor="#EEEEEE"><td>Change Log Files</td></tr>
                      <tr align="center" bgcolor="#EEEEEE">
                        <td width="100%">
                        <table cellspacing="0" cellpadding="0" align="center" width="50%" background="$img/whiteslice.gif" style='border:1px solid black'>
                        <tr><td>
                        $view
                        </td></tr>
                        </table>
                        </td>
                      </tr>
                      <tr bgcolor="#EEEEEE"><td><p>&nbsp;</p></td></tr>
                      ~ if ($iB::IN{'ucact'} eq 'view' && $id eq "$iB::IN{'id'}");

         $data .= qq~
                    <tr align="center"><td width="100%">
                    <table cellspacing="0" cellpadding="0" align="center" width="95%" style='border:1px solid black'>
                    <tr align="left" bgcolor="#8888AA">
                     <td width="100%"><span style='color:white;font-size:14px'><b><i>Classification</i>: $type</br></span></td>
                    </tr>
                    <tr align="left" bgcolor="#EEEEEE">
                     <td width="100%"><i>Posted</i>: $date<br>
                                      <i>Options</i>: <a href="$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?CP=1;act=Update&ucact=down&file=$file&path=$downDir">Download Only</a>&nbsp;
                                                      <a href="$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?CP=1;act=Update&ucact=autoup&file=$file&id=$id&path=$downDir">Update</a>&nbsp;
                                                      <a href="$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?CP=1;act=Update&ucact=ignore&id=$id">Ignore</a>&nbsp;
                                                      <a href="$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?CP=1;act=Update&ucact=view&file=$file&id=$id&path=$downDir">Changelog</a>&nbsp;

                     </td>
                    </tr>
                    <tr align="left" bgcolor="#EEEEEE">
                     <td width="100%"><i>Description</i>:<br>$desc</td>
                    </tr>
                    $clog
                    </table>
                    </td></tr>
                    ~;
      }
   }

   print "Content-type: text/html; charset=ISO-8859-1\n\n";
   print qq~
           <html>
           <head><title>IkonBoard Update Center</title>
           <style type="text/css">
           body          { scrollbar-track-color: rgb(241, 241, 241);
                           scrollbar-face-color: rgb(102, 102, 152);
                           scrollbar-arrow-color: rgb(241, 241, 241);
                           scrollbar-shadow-color: rgb(241, 241, 241);
                           scrollbar-darkshadow-color: rgb(0, 0, 0);
                           scrollbar-highlight-color: rgb(100, 100, 100);
                           scrollbar-3dlight-color: rgb(241, 241, 241);
                         }
           font.h        { font-family: Arial; font-size: 12px; color: #FF0000 }
           font.t        { font-family: Arial; font-size: 11px; color: #000000 }
               .t        { font-family: Arial; font-size: 11px; color: #000003 }
               .d        { background-color:#EEEEEE; font-family: Arial; font-size: 11px; color: #000003 }
           font.large    { font-family: Arial; font-size: 12px; font-weight: bold; color: #000000 }
           INPUT, SUBMIT   {
                             font-family: Verdana, Arial;
                              font-size: 10pt;
                              font-family: verdana, helvetica, sans-serif;
                             vertical-align:middle;
                             background-color: #CCCCCC;
           }
           .forminput    {
           font-size: 8pt;
           background-color: #CCCCCC;
           font-family: verdana, helvetica, sans-serif;
           vertical-align:middle;
           width:90%
           }
           </style>
           </head>

           <body bgcolor="#EEEEEE">
           <table cellspacing='0' cellpadding='0' width='95%' align='center' border='0' background='$img/t-bg.gif'>
           <tr>
           <td align='left' width='14'><img src='$img/wh-l.gif' border='0' width='14' height='23' alt=''></td>
           <td align='left' width='18'><a href='$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?s=$iB::SESSION' target='_top' title='Close AdminCP'><img src='$img/t-red.gif' border='0' width='18' height='23' alt='X'></a></td>
           <td align='left' width='23'><a href='$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?s=$iB::SESSION' target='_blank' title='Hide AdminCP'><img src='$img/t_amber.gif' border='0' width='23' height='23' alt='-'></a></td>
           <td align='left' width='24'><a href='$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?s=$iB::SESSION&AD=1' target='_top' title='AdminCP Home'><img src='$img/t-green.gif' border='0' width='24' height='23' alt='+'></a></td>
           <td align='center' width='100%'><img src='$img/blank.gif' border='0' height='23' width='68' alt=''></td>
           <td align='left' width='14'><img src='$img/wh-r.gif' border='0' width='14' height='23' alt=''></td>
           </tr>
           </table>
           <table cellspacing='0' cellpadding='0' width='95%' align='center' border='0' bgcolor='#EEEEEE'>
           <tr>
             <td background='$img/sh-mid-l.gif' align='right' valign='top' width='5'><img src='$img/sh-top-l.gif' border='0' width='5' height='12' alt=''></td>
               <!-- Middle -->
                <td colspan='3'><table cellspacing='1' cellpadding='0' width='100%' align='center' border='0' bgcolor='#000000'>
                    <tr>
                        <td>
                        <table cellspacing='0' cellpadding='0' width='100%' align='center' border='0' background="$img/whiteslice.gif">
                        <tr>
                             <td align='left'>
                              <table cellspacing="8" cellpadding="0" width="100%">
                               <tr align="left"><td width="100%"><font class='large'>Welcome to the iB Update Center<hr noshade size='1' color='#000000'></font></td></tr>
                              </table>
                              <table cellspacing="8" cellpadding="5" width="100%" align="center">
                               $announce
                               $data
                               </table>
                            </td>
                        </tr>
                        </table>
                        </td>
                      </tr>
                  </table></td>
                <!-- Middle-->
            <td background='$img/sh-mid-r.gif' align='left' valign='top' width='5'><img src='$img/sh-top-r.gif' border='0' width='5' height='12' alt=''></td>
            </tr>
            <tr>
            <td align='left' valign='top' width='5'><img src='$img/sh-bot-l.gif' border='0' width='5' height='7' alt=''></td>
                  <td align='left' background='$img/sh-bots.gif' valign='top'><img src='$img/sh-bots-l.gif' border='0' width='5' height='7' alt=''></td>
                  <td background='$img/sh-bots.gif' align='left' valign='top' width='100%'><img src='$img/blank.gif' border='0' width='5' height='7' alt=''></td>
                  <td align='right' background='$img/sh-bots.gif' valign='top'><img src='$img/sh-bots-r.gif' border='0' width='5' height='7' alt=''></td>
            <td align='left' valign='top' width='5'><img src='$img/sh-bot-r.gif' border='0' width='5' height='7' alt=''></td>
           </tr>
           </table>
           <br><br>
           <table cellspacing='0' cellpadding='0' width='95%' align='center' border='0' bgcolor='#EEEEEE'>
           <tr><td class='t' align='center'>Ikonboard $iB::VERSION &copy; <a href='http://www.impluxdesigns.com' target='_blank' class='t'>Implux Designs</a></td></tr>
           </table>
           </body>
           </html>
           ~;
}

sub download {
   use LWP::Simple;

   my $path = shift;
   my $BINARY = get("http://impluxdesigns.com/$path/$iB::IN{'file'}") ||
      die "Unable to download update file: ($!)\n";

   open (TAR, ">", "$BoardInfo->{'IKON_DIR'}INCOMING/$iB::IN{'file'}") || die "Error creating download file: ($!)\n";
   print TAR $BINARY;
   close(TAR);

   if ($iB::IN{'ucact'} eq 'view') {
      my $dir = untar();
      chdir($dir);

      open(INS, "<", "INSTALL") || die "Unable to open INSTALL: ($!)";
      my $data;
      while (<INS>) {
         next if(/^\s+$/ || /^#/);
         $data .= $_."<br>";
      }
      close(INS);
      unlink("../$iB::IN{'file'}");

      return ($data);
   }

   print "Content-type: text/html; charset=ISO-8859-1\n\n";
   print qq~
           <html>
           <head><title>IkonBoard Update Center</title>
           </head>

           <body bgcolor="#EEEEEE">
            <table cellspacing="0" cellpadding="0" width="100%">
             <tr align="left">
              <td><font color="#000000">Download complete<br><a href="$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?CP=1;act=Update">Back to Update Center</a></font></td>
             </tr>
            </table>
           </body>
           </html>
           ~;
   exit(0);
}

sub untar {
   # Extract the tar file
   use Archive::Tar;

   my $tar      = Archive::Tar->new();
   my $dir      = "$BoardInfo->{'IKON_DIR'}INCOMING/$iB::IN{'file'}";
   $dir         =~ s!^(.+?)\.tar!$1!;
   my $location = $BoardInfo->{'IKON_DIR'}."INCOMING";

   unless ($tar->read("$location/$iB::IN{'file'}", 0)) {
      die ("Error in untaring upgrade file!");
   }

   chdir($location);
   my @files = $tar->list_files();

   for (@files) {
       # Test for illegal characters
       die ("Illegal characters found in tar name!") if ($_ !~ /^(?:[\.\w\d\+\-\_\/\\]+)$/);

       # Test for embedded paths
       die ("The tar file contained embedded paths!") if ($_ =~ m!^$dir[/\\](\S+)[/\\]$dir!);
   }
   $tar->extract(@files, $location);
   return $dir;
}

sub autoupdate {
   my ($id, $path) = @_;

   use LWP::Simple;

   my $BINARY = get("http://impluxdesigns.com/$path/$iB::IN{'file'}") ||
      die "Unable to download update file: ($!)\n";

   open (TAR, ">", "$BoardInfo->{'IKON_DIR'}INCOMING/$iB::IN{'file'}") || die "Error in update process: ($!)\n";
   print TAR $BINARY;
   close(TAR);

   my $dir = untar();
   chdir($dir);

   install($dir) if (-e "INSTALL");
   install_fail() if (!-e "INSTALL");

   open(LOG, ">>", "$BoardInfo->{'IKON_DIR'}/Database/Temp/UPDATE.log") || die "Unable to open log logfile: ($!)\n";
   print LOG "$id\n";;
   close(LOG);

   print "Content-type: text/html; charset=ISO-8859-1\n\n";
   print qq~
           <html>
           <head><title>IkonBoard Update Center</title>
           </head>

           <body bgcolor="#EEEEEE">
            <table cellspacing="0" cellpadding="0" width="100%">
             <tr align="left">
              <td><font color="#000000">Update complete<br><a href="$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?CP=1;act=Update">Back to Update Center</a></font></td>
             </tr>
            </table>
           </body>
           </html>
           ~;
   exit(0);
}

sub install {
   my $dir = shift;

   open(INS, "<", "INSTALL") || die "Unable to open INSTALL: ($!)";
   my @paths = <INS>;
   close(INS);
   unlink("../$iB::IN{'file'}");

   for (@paths) {
      chomp();
      next if(/^\s+$/ || /^#/);
      my @tmp    = reverse(split(/\//, $_));
      my $file   = $tmp[0];
      $file      = $dir."/".$file;
     s/\%HTML_DIR\%/$BoardInfo->{'HTML_DIR'}/;
     s/\%IKON_DIR\%/$BoardInfo->{'IKON_DIR'}/;
     my $target = $_;
      $file =~ s!\s+!!;
      $target =~ s!\s+!!;

      open(SOURCE, "<", $file) || die "\"Unable to read $file\": ($!)\n";
      my @source = <SOURCE>;
      close(SOURCE);

      chmod(0644, $target) if (-e $target);
      open(DEST, ">", $target) || die "Unable to open $target: ($!)\n";
      print DEST @source;
      close(DEST);

      my $perms = ($file =~ /ikonboard\..*/) ? 0755 : 0444;
      chmod($perms, $target);
   }

   return;
}

sub install_fail {
   print "Content-type: text/html; charset=ISO-8859-1\n\n";
   print qq~
           <html>
           <head><title>IkonBoard Update Center</title>
           </head>

           <body bgcolor="#EEEEEE">
            <table cellspacing="0" cellpadding="0" width="100%">
             <tr align="left">
              <td><font color="#000000">Install unable to complete, manual installation required<br>
                                        Patch can be found in your INCOMING directory<a href="$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?CP=1;act=Update">Back to Update Center</a></font></td>
             </tr>
            </table>
           </body>
           </html>
           ~;
   exit(0);
}

sub ignore {
   my $id = shift;

   open(LOG, ">>", "$BoardInfo->{'IKON_DIR'}/Database/Temp/UPDATE.log") || die "Unable to open log logfile: ($!)\n";
   print LOG "$id\n";;
   close(LOG);

   print "Content-type: text/html; charset=ISO-8859-1\n\n";
   print qq~
           <html>
           <head><title>IkonBoard Update Center</title>
           </head>

           <body bgcolor="#EEEEEE">
            <table cellspacing="0" cellpadding="0" width="100%">
             <tr align="left">
              <td><font color="#000000">Update has been ignored<br><a href="$BoardInfo->{'BOARD_URL'}/ikonboard.$BoardInfo->{'CGI_EXT'}?CP=1;act=Update">Back to Update Center</a></font></td>
             </tr>
            </table>
           </body>
           </html>
           ~;
   exit(0);
}

sub ShowCount {
   unless (defined(eval {require LWP::Simple})) {
      return(0, "iB Update Center not available without LWP::Simple installed!");
   }

   my $HTML = get("$site/update_center.txt") ||
      return (0, "Unable to contact the Update Center right now: ($!)");

   my $BoardVersion;
   if ($iB::VERSION =~ /(^\d\.\d\.\d).*/) {
      $BoardVersion = $1;
      $BoardVersion =~ s/\.//g;
   }

   my %hash = ();
   if (-e "$BoardInfo->{'IKON_DIR'}/Database/Temp/UPDATE.log") {
      open(LOG, "<", "$BoardInfo->{'IKON_DIR'}/Database/Temp/UPDATE.log") || die "Unable to open log logfile: ($!)\n";
      while (<LOG>) {
         chomp();
         $hash{ $_ } = $_;
      }
      close(LOG);
   }

   my ($count, $announce);
   my @data = split(/\n/, $HTML);
   for (@data) {
      next if ($_ =~ /^#/ || $_ =~ /^\s+$/);
      my ($id, $type, $desc, $date, $file) = split(/\:\:/, $_);
      chomp($id, $type, $desc, $date, $file);

      next if (exists($hash{ $id }));
      if ($id eq '0000') {
         $announce = qq~<i>IkonBoard Team Announcement</i>: $type~;
      }

      if ($id >= $BoardVersion) {
         $count++;
      }
   }
   $count = 0 if (!$count);
   return($count, $announce);
}
1;
