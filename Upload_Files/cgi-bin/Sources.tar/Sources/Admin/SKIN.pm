package Admin::SKIN;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# MemberControl: Member account editor
#
#################################################################################
#
# Admin Skin: Admin CP HTML.
#
#################################################################################

BEGIN {
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
    require 'iTextparser.pm';
}

my $INFO   = Boardinfo->new();
my $img    = $INFO->{'IMAGES_URL'}.'/sys-img';
my $acpimg    = $INFO->{'IMAGES_URL'}.'/Skin/Default/images';
my $txt    = iTextparser->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub log_in {
    my ($obj, $error) = @_;

    $error = "<font class='text' style='color:#CC0000;font-weight:bold;font-size:14px'>$error</font><br><br>" if $error;

return qq~
    <html>
<head>
  <title>Ikonboard Administration -&gt; Please Log In</title>
  <style>
table {
background-color:#FFFFFF;
}

td {
  font-family: Verdana, Arial;
  font-size: 12px;
}

ul {
  list-style-type:none;
  line-height:12pt;
  margin:8px;
}

li {
text-align:center;
vertical-align:middle;
margin:8px;
}

#outer {
margin-top:15%;
}


#acp {
border:1px solid black;
padding-left:0em;
width:50%;
}

.acplogin {
background-color:#DFE6EF;
color:#000080;
font-family: Verdana, Arial;
font-size:10px;
margin-left:1em;
white-space:nowrap;
}


#category {
  font-family: Verdana, Arial;
  font-size: 12px;
  font-weight: bold;
  color: #FFFFFF;
  height: 18px;
  text-indent:1em;
  text-align:left;
  background-image: url($acpimg/bluebk.jpg);
  border-bottom:1px solid black;
}

#acpbottom {
  background-image: url($acpimg/graybk.jpg);
  border-top:1px solid black;
}

.inputbox {
  background-color: #FFFFFF;
  color: #000080;
  font-family: Verdana, Arial;
  font-size: 12px;
  letter-spacing: 1px;
}

.submitbox {
  background-color: #CCCCCC;
  color: #000000;
  font-family: Verdana, Arial;
  font-size: 12px;
}

</style>

</head>
<body bgcolor="#FFFFFF">
<br />
<table width="100%" cellpadding='0' cellspacing='0' style='border:0px solid black'id="outer">
<tr>
<td align="center" valign="middle">
<table width="100%" cellpadding='0' cellspacing='0' id="acp">
  <tr><!-- Row 1 -->
     <td align="center" id="category">&raquo; Log In: Welcome to your Admin Control Panel</td><!-- Col 1 -->
  </tr>
  <tr><!-- Row 2 -->
     <td class="acplogin"><div class="acplogin">
         <form action='$INFO->{'BOARD_URL'}/ikonboard.$INFO->{'CGI_EXT'}?AD=1&act=dologin' method='post'>
       <input type='hidden' name='AD' value='1' />
       <input type='hidden' name='act' value='dologin' />
       <input type='hidden' name='s'  value='$iB::SESSION' />
       <input type='hidden' name='CookieDate'  value='1' />
        <br />$error<br />
     Please enter your log in details. You must be an administrator to access the control panel
     <br />
         <ul>
           <li><table width='80%' border='0' cellpadding='0' cellspacing='0'class="acplogin"><tr><td width='20%'>Username:</td><td><input type='text' maxlength='32' size='32' name='UserName' class='inputbox' /></td></tr></table></li>

           <li><table width='80%' border='0' cellpadding='0' cellspacing='0'class="acplogin"><tr><td valign="middle" width='20%'>Password:</td><td width='1'><input type='password' maxlength='32' size='32' name='PassWord' class='inputbox' /></td><td>&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='Log In' class='submitbox' /></td></tr></table></li>
         </ul>
         </form>
         <br />
         <b><u>Please note:</u></b><br /> If you do not log in after <b>5</b> attempts, you will be banned from the Control Panel for 15 minutes.<br>Also note, that if you are not an administrator, you will have your posting rights removed upon log in.<br /><br />
         </div>
         </td><!-- Col 1 -->
  </tr>
  <tr><!-- Row 3 -->
     <td id="acpbottom">&nbsp;</td><!-- Col 1 -->
  </tr>
</table>
 </td>
</tr>
</table>
<br />



</body>
</html>

~;
}



sub Error {
    my ($obj, $msg) = @_;

return qq~
    <html>
    <head>

    <title>Ikonboard Administration -&gt; ERROR</title>
    <style type="text/css"><!--
    font.text     { font-family: Verdana, Arial; font-size: 12px; color: #000000 }
    font.large    { font-family: Verdana, Arial; font-size: 14px; font-weight: bold; color: #CC0000 }
    body          { scrollbar-track-color: rgb(241, 241, 241);
                    scrollbar-face-color: rgb(102, 102, 152);
                    scrollbar-arrow-color: rgb(0, 0, 0);
                    scrollbar-shadow-color: rgb(241, 241, 241);
                    scrollbar-darkshadow-color: rgb(100, 100, 100);
                    scrollbar-highlight-color: rgb(241, 241, 241);
                    scrollbar-3dlight-color: rgb(0, 0, 0);
                  }
    --></style>
    </head>
    <body background="$img/whiteslice.gif" marginheight='0' marginwidth='0' leftmargin='0' topmargin='0'>
    <table width='100%' height='100%' cellspacing='0' cellpadding='0' align='center' border='0'>
    <tr>
        <td align='center' valign='middle'>
            <table cellspacing='0' cellpadding='0' align='center' border='0'>
            <tr>
                <!-- TOP ROW -->
                <td background="$img/log-in_r1_c1.gif" width='10'><img src="$img/blank.gif" border='0' width='10'  height='44' border='0'></td>
                <td background="$img/error.gif" style='width:112px'><img src="$img/blank.gif" border='0' width='112' height='44' border='0'></td>
                <td background="$img/log-in_r1_c3.gif" style='width:400px'><img src="$img/blank.gif" border='0' width='251' height='44' border='0'></td>
                <td background="$img/log-in_r1_c4.gif" width='11'><img src="$img/blank.gif" border='0' width='11'  height='44' border='0'></td>
                <!-- END TOP ROW -->
            </tr>
            <tr>
                <!-- MIDDLE ROW -->
                <td background="$img/log-in_r2_c1.gif" bgcolor='#333366'><img src="$img/blank.gif" border='0' width='10'  height='1'></td>
                <td colspan='2' background="$img/log-in_r2_c2.gif">
                    <font class='large'>&gt;&gt; Ikonboard Error</font>
                    <br><br>
                    <font class='text'><b>The error returned was:<br><br>$msg<br><br><center><b>&gt;&gt;<a href='#' onClick='javascript:history.go(-1)'>Back</a> :: <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?AD=1;s=$iB::SESSION'>Log in</a></b></center></font>
                    <!-- END CONTENT -->
                </td>
                <td background="$img/log-in_r2_c4.gif" bgcolor='#333366'><img src="$img/blank.gif" border='0' width='11'  height='1'></td>
                <!-- END MIDDLE ROW -->
            </tr>
            <tr>
                <!-- BOTTOM ROW -->
                <td background="$img/log-in_r3_c1.gif"><img src="$img/blank.gif" border='0' width='10'  height='17'></td>
                <td colspan='2' background="$img/log-in_r3_c2.gif"><img src="$img/blank.gif" border='0' width='363'  height='17'></td>
                <td background="$img/log-in_r3_c4.gif"><img src="$img/blank.gif" border='0' width='10'  height='17'></td>
                <!-- END BOTTOM ROW -->
            </tr>
            </table>
        </td>
    </tr>
    </table>
    </body>
    </html>
~;
}

sub std_print {
    my $obj = shift;

    return qq~
    <html>
    <head>
    <title>Ikonboard Body Frame</title>
    <style type="text/css">
    body          { scrollbar-track-color: rgb(241, 241, 241);
                    scrollbar-face-color: rgb(102, 102, 152);
                    scrollbar-arrow-color: rgb(241, 241, 241);
                    scrollbar-shadow-color: rgb(241, 241, 241);
                    scrollbar-darkshadow-color: rgb(0, 0, 0);
                    scrollbar-highlight-color: rgb(100, 100, 100);
                    scrollbar-3dlight-color: rgb(241, 241, 241);
                  }
    font.h        { font-family: Arial; font-size: 12px; color: #FF0000 }
    font.t        { font-family: Arial; font-size: 11px; color: #000000 }
        .t        { font-family: Arial; font-size: 11px; color: #000003 }
        .d        { background-color:#EEEEEE; font-family: Arial; font-size: 11px; color: #000003 }
    font.large    { font-family: Arial; font-size: 12px; font-weight: bold; color: #000000 }
    INPUT, SUBMIT   {
                      font-family: Verdana, Arial;
                       font-size: 10pt;
                       font-family: verdana, helvetica, sans-serif;
                      vertical-align:middle;
                      background-color: #CCCCCC;
    }
    .forminput    {
    font-size: 8pt;
    background-color: #CCCCCC;
    font-family: verdana, helvetica, sans-serif;
    vertical-align:middle;
    width:90%
    }

    </style>
    </head>
    <body marginheight='0' marginwidth='0' leftmargin='0' topmargin='10' bgcolor='#EEEEEE'>
    <table cellspacing='0' cellpadding='0' width='95%' align='center' border='0' background='$img/t-bg.gif'>
    <tr>
    <td align='left' width='14'><img src='$img/wh-l.gif' border='0' width='14' height='23' alt=''></td>
    <td align='left' width='18'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION' target='_top' title='Close AdminCP'><img src='$img/t-red.gif' border='0' width='18' height='23' alt='X'></a></td>
    <td align='left' width='23'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION' target='_blank' title='Hide AdminCP'><img src='$img/t_amber.gif' border='0' width='23' height='23' alt='-'></a></td>
    <td align='left' width='24'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&AD=1' target='_top' title='AdminCP Home'><img src='$img/t-green.gif' border='0' width='24' height='23' alt='+'></a></td>
    <td align='center' width='100%'><img src='$img/<#TITLE#>' border='0' alt=''><img src='$img/blank.gif' border='0' height='23' width='68' alt=''></td>
    <td align='left' width='14'><img src='$img/wh-r.gif' border='0' width='14' height='23' alt=''></td>
    </tr>
    </table>
    <table cellspacing='0' cellpadding='0' width='95%' align='center' border='0' bgcolor='#EEEEEE'>
    <tr>
      <td background='$img/sh-mid-l.gif' align='right' valign='top' width='5'><img src='$img/sh-top-l.gif' border='0' width='5' height='12' alt=''></td>
        <!-- Middle -->
        <td colspan='3'><table cellspacing='1' cellpadding='0' width='100%' align='center' border='0' bgcolor='#000000'>
             <tr>
                 <td>
                 <table cellspacing='0' cellpadding='0' width='100%' align='center' border='0' background="$img/whiteslice.gif">
                 <tr>
                     <td align='left'>
                         <table cellspacing='8' cellpadding='0' width='100%' align='center' border='0'>
                         <tr><td align='left'><font class='large'><#NAV#><hr noshade size='1' color='#000000'></font></td></tr>
                         </table>

                         <#OUTPUT#>

                     </td>
                 </tr>
                 </table>
                 </td>
               </tr>
           </table></td>
         <!-- Middle-->
     <td background='$img/sh-mid-r.gif' align='left' valign='top' width='5'><img src='$img/sh-top-r.gif' border='0' width='5' height='12' alt=''></td>
     </tr>
     <tr>
     <td align='left' valign='top' width='5'><img src='$img/sh-bot-l.gif' border='0' width='5' height='7' alt=''></td>
           <td align='left' background='$img/sh-bots.gif' valign='top'><img src='$img/sh-bots-l.gif' border='0' width='5' height='7' alt=''></td>
           <td background='$img/sh-bots.gif' align='left' valign='top' width='100%'><img src='$img/blank.gif' border='0' width='5' height='7' alt=''></td>
           <td align='right' background='$img/sh-bots.gif' valign='top'><img src='$img/sh-bots-r.gif' border='0' width='5' height='7' alt=''></td>
     <td align='left' valign='top' width='5'><img src='$img/sh-bot-r.gif' border='0' width='5' height='7' alt=''></td>
    </tr>
    </table>
    <br><br>
    <table cellspacing='0' cellpadding='0' width='95%' align='center' border='0' bgcolor='#EEEEEE'>
    <tr><td class='t' align='center'>Ikonboard $iB::VERSION &copy; <a href='http://www.ikonboard.com' target='_blank' class='t'>Ikonboard</a></td></tr>
    </table>
    </body>
    </html>
    ~;

}


sub static {
    my $obj = shift;
    my $IN = {

                "TEXT"          => "",
                "URL"           => "",
                "TITLE"         => "",
                "LINK"          => "Back to the last action",
                @_
              };

    return qq~
    <html>
    <head>
    <title>Ikonboard Body Frame</title>
    <style type="text/css">
    body          { scrollbar-track-color: rgb(241, 241, 241);
                    scrollbar-face-color: rgb(102, 102, 152);
                    scrollbar-arrow-color: rgb(241, 241, 241);
                    scrollbar-shadow-color: rgb(241, 241, 241);
                    scrollbar-darkshadow-color: rgb(0, 0, 0);
                    scrollbar-highlight-color: rgb(100, 100, 100);
                    scrollbar-3dlight-color: rgb(241, 241, 241);
                  }
    font.h        { font-family: Verdana, Arial; font-size: 12px; color: #FF0000 }
    font.t        { font-family: Verdana, Arial; font-size: 10px; color: #000000 }
    font.large    { font-family: Verdana, Arial; font-size: 12px; font-weight: bold; color: #000000 }
    </style>
    </head>
    <body bgcolor="#EEEEEE" marginheight='0' marginwidth='0' leftmargin='0' topmargin='10'>
    <table cellspacing='1' cellpadding='0' width='90%' align='center' height='100%' border='0' bgcolor='#333366'>
        <tr>
            <td>
            <table cellspacing='0' cellpadding='8' width='100%' align='center' height='100%' border='0' background="$img/whiteslice.gif">
            <tr>
                <td align='left' valign='top'>
                 <font class='h'>&gt;</font>&nbsp;<font class='large'>$IN->{'TITLE'}</font>
                    <br><br>
                    <font class='t'>&nbsp;&nbsp;&nbsp;$IN->{'TEXT'}<br><br>&nbsp;&nbsp;&nbsp;<a href='$IN->{'URL'}' target='BODY'>$IN->{'LINK'}</a></font>
                </td>
            </tr>
            </table>
            </td>
        </tr>
    </table>
    </body>
    </html>
    ~;

}



sub do_frames {
    my $obj = shift;

    return qq~

            <html>
            <head>
                <title>Ikonboard Control Panel</title>
            </head>

            <frameset rows="50,*" cols="*" frameborder="NO" border="0" framespacing="0">
                <frame name="TOP" scrolling="NO" noresize src="$INFO->{'BOARD_URL'}/ikonboard.$INFO->{'CGI_EXT'}?AD=1&act=top&s=$iB::SESSION" >
                <frameset cols="185,1*" frameborder="NO" border="0" framespacing="0">
                    <frame name="MENU" noresize scrolling="auto" src="$INFO->{'BOARD_URL'}/ikonboard.$INFO->{'CGI_EXT'}?AD=1&act=menuadmin&s=$iB::SESSION">
                    <frame name="BODY" noresize scrolling="auto" src="$INFO->{'BOARD_URL'}/ikonboard.$INFO->{'CGI_EXT'}?AD=1&act=body&s=$iB::SESSION">
                </frameset>
            </frameset>
            <noframes><body bgcolor="#FFFFFF">
             <b>You need a frame capable browser to use the Administration Center
            </body></noframes>
            </html>
    ~;
}

sub Redirect {
    my ($obj, $Text, $Url) = @_;
    $Url =~ s!;!&!g;

    return qq~
    <html>
    <head>
    <title>iB::Please Stand by...</title>
    <meta http-equiv="refresh" content="2; url=$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}$Url" window-location="_top">
    <link type="text/css" href="$iB::INFO->{'IMAGES_URL'}/ikonboard.css" rel="stylesheet">
    </head>
    <body bgcolor='$iB::SKIN->{'HTML_BACK_COL'}'>

    <table cellpadding='0' cellspacing='0' border='0' width="$iB::SKIN->{'TABLE_WIDTH'}" align='center' height='85%'>
    <tr align='center' valign='middle'>
        <td>
        <table cellpadding='10' cellspacing='0' border='0' width="80%" align='center'>
        <tr>
            <td id=redirect valign='middle' align='center' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>

            Thanks, $Text
            <br><br>
            Please wait while we transfer you...
            <br><br>
            (<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}$Url' class='misc'>or click here if you do not wish to wait</a>)

            </td>
        </tr>
        </table>
        </td>
    </tr>
    </table>
    </body>
    </html>
    ~;


}

sub top {

return qq~
    <html>
    <head>
    <title>Ikonboard Top Frame</title>
    <style type="text/css">
    .large    { font-family: Verdana, Arial; font-size: 10px; font-weight: bold; color: #FFFFFF }
    </style>
    </head>
    <body bgcolor='#666699' marginheight='0' marginwidth='0' leftmargin='0' topmargin='0'>
    <table border='0' cellspacing='0' cellpadding='0' width='100%'>
    <tr>
    <td align='left' width='29'><img src='$img/cp-left.gif' border='0' width='29' height='50' alt=''></td>
    <td align='left' width='100%'><img src='$img/cp-middle.gif' border='0' width='315' height='50' alt=''></td>
    <td align='right'><img src='$img/cp-right.gif' border='0' width='29' height='50' alt=''></td>
    </tr>
    </table>
    </body>
    </html>
    ~;

}

sub body {

return qq~
    <html>
    <head>
    <title>Ikonboard Body Frame</title>
    <style type="text/css">
    font.text     { font-family: Verdana, Arial; font-size: 9px; color: #000000 }
    font.large    { font-family: Verdana, Arial; font-size: 11px; font-weight: bold; color: #CC0000 }
    </style>
    </head>
    <body background="$img/whiteslice.gif" marginheight='0' marginwidth='0' leftmargin='0' topmargin='0'>
    <br>BODY
    </body>
    </html>
    ~;

}

sub title {
    my $obj = shift;

    my %IN = ( TITLE => "",
               TEXT  => "",
               @_
             );

    $IN{'TEXT'} = qq!<br><br><font class='t'>$IN{'TEXT'}</font>! if $IN{'TEXT'};

    return qq~
    <table cellspacing='0' cellpadding='5' border='0' width='100%' border='0'>
    <tr>
    <td><font class='large'>&gt;&gt;$IN{'TITLE'}
        <font class='t'>$IN{'TEXT'}
        <br>Please fill out all required (<font class='h'>*</font>) fields.</font>
    </td>
    </tr>
    </table>
    <br>
    ~;
}

#########################

sub formalize {
    my ($obj, $TXT) = @_;
    return unless defined $TXT;
    return $TXT if $obj->{'_allow_html'};
    return $txt->Convert_for_textfield($TXT);
}

sub htmlalize {
    my ($obj, $TXT) = @_;
    return unless defined $TXT;
    return $TXT if $obj->{'_allow_html'};
    return $txt->Convert_for_db( TEXT => $TXT, SMILIES => 1, IB_CODE => 1, HTML => 1 );
}

sub td_input {
    my $obj = shift;

    my %IN = ( TEXT  => "",
               NAME  => "",
               VALUE => "",
               REQ   => "",
               JS    => "",
               NO_PARSE => "",
               TYPE     => "text",
               @_
             );

    my $req = $IN{'REQ'} ? " <font class='h'>*</font>" : '';

    $IN{'VALUE'} = $obj->formalize($IN{'VALUE'}) unless $IN{'NO_PARSE'};

    return qq~
    <tr>
    <td bgcolor='#FFFFFF' width='40%' align='left'><font class='t'>&nbsp;&nbsp;&nbsp;&nbsp;$IN{'TEXT'}$req</font></td>
    <td bgcolor='#FFFFFF' width='60%' align='left'><input type='$IN{TYPE}' name='$IN{'NAME'}' value='$IN{'VALUE'}' class='forminput'></td>
    </tr>
    ~;
}

#########################

sub td_checkbox {
    my $obj = shift;

    my %IN = ( TEXT     => "",
               NAME     => "",
               VALUE    => "",
               SELECTED => "",
               REQ      => "",
               JS       => "",
               @_
             );

    my $req = $IN{'REQ'} ? " <font class='h'>*</font>" : '';

    $IN{'SELECTED'} = ' checked' if $IN{'SELECTED'};

    return qq~
    <tr>
    <td bgcolor='#FFFFFF' width='40%' align='left'><font class='t'>&nbsp;&nbsp;&nbsp;&nbsp;$IN{'TEXT'}$req</font></td>
    <td bgcolor='#FFFFFF' width='60%' align='left'><input type='checkbox' name='$IN{'NAME'}' value='$IN{'VALUE'}' style='border:#FFFFFF' $IN{'SELECTED'} $IN{'JS'}></td>
    </tr>
    ~;
}

#########################

sub td_select {
    my $obj = shift;

    my %IN = ( TEXT     => "",
               NAME     => "",
               SIZE     => "",
               MULTIPLE => "",
               DATA     => [],
               VALUES   => undef,
               REQ      => "",
               JS       => "",
               @_
             );

    my $req = $IN{'REQ'} ? " <font class='h'>*</font>" : '';

    my $text = $IN{'MULTIPLE'} ? qq!<br><font class='t'><b>Windows Users:</b> Hold down [CTRL] to select multiple choices<br><b>Macintosh Users:</b> Hold down [APPLE] to select multiple choices</font>! : '';

    $IN{'SIZE'}     = "size='$IN{'SIZE'}'" if $IN{'SIZE'};
    $IN{'MULTIPLE'} = 'multiple' if $IN{'MULTIPLE'};

    my $return = qq!<select name='$IN{'NAME'}' $IN{'SIZE'} $IN{'MULTIPLE'} class='forminput' $IN{'JS'}>\n!;

    if (ref($IN{'VALUES'}) eq 'ARRAY') {
        my @values = @{ $IN{'VALUES'} };
        $IN{'VALUES'} = {};
        for (@values) {
            $IN{'VALUES'}->{$_} = 1;
        }
    } else {
        my $value = $IN{'VALUES'};
        $IN{'VALUES'} = {};
        $IN{'VALUES'}->{$value} = 1;
    }

    for my $i (@{ $IN{'DATA'} }) {
        my $selected = ' selected' if $i->{'VALUE'} ne '' and exists $IN{'VALUES'}->{ $i->{'VALUE'} };
        $return .= qq! <option value="$i->{'VALUE'}"$selected>$i->{'NAME'}</option>\n!;
    }

    $return .= '</select>';

    return qq~
    <tr>
    <td bgcolor='#FFFFFF' width='40%' align='left' valign='top'><font class='t'>&nbsp;&nbsp;&nbsp;&nbsp;$IN{'TEXT'}$req</font></td>
    <td bgcolor='#FFFFFF' width='60%' align='left'>$return $text</td>
    </tr>
    ~;
}


#########################

sub td_textarea {
    my $obj = shift;

    my %IN = ( TEXT  => "",
               NAME  => "",
               VALUE => "",
               REQ   => "",
               ROWS  => "",
               SPAN  => "",
               NO_PARSE => "",
               @_
             );

    $IN{'ROWS'} ||= 6;

    my $req = $IN{'REQ'} ? " <font class='h'>*</font>" : '';
    $IN{'VALUE'} = $obj->formalize($IN{'VALUE'}) unless $IN{'NO_PARSE'};


    if ($IN{'SPAN'}) {
        return qq~
        <tr>
        <td bgcolor='#FFFFFF' colspan='2' align='center'><font class='t'>&nbsp;&nbsp;&nbsp;&nbsp;$IN{'TEXT'}$req</font><br><textarea rows='$IN{'ROWS'}' cols='70' wrap='virtual' class='forminput' name='$IN{'NAME'}'>$IN{'VALUE'}</textarea></td>
        </tr>
        ~;
    } else {

        return qq~
        <tr>
        <td bgcolor='#FFFFFF' width='40%' align='left' valign='top'><font class='t'>&nbsp;&nbsp;&nbsp;&nbsp;$IN{'TEXT'}$req</font></td>
        <td bgcolor='#FFFFFF' width='60%' align='left' nowrap><textarea rows='$IN{'ROWS'}' cols='55' wrap='virtual' class='forminput' name='$IN{'NAME'}'>$IN{'VALUE'}</textarea></td>
        </tr>
        ~;
    }

}

#########################

sub td_submit {
    my $obj = shift;

    my %IN = ( NAME    => "",
               VALUE   => "",
               COLSPAN => "",
               @_
             );

    $IN{'NAME'} = " name='$IN{'NAME'}' " if $IN{'NAME'};
    $IN{'COLSPAN'} ||= 2;

    return qq~
    <tr>
    <td bgcolor='#FFFFFF' colspan='$IN{'COLSPAN'}' align='center'><br><input type='submit' $IN{'NAME'} value='$IN{'VALUE'}'></td>
    </tr>
    ~;
}

#########################
#########################

sub begin_table {
    my $obj = shift;

    return qq~
    <table cellspacing='1' cellpadding='0' width='100%' align='center' border='0' bgcolor='#333366'>
        <tr>
            <td>
            <table cellspacing='1' cellpadding='4' width='100%' align='center' border='0'>
            <tr>
            ~;

}

#########################

sub section_header {
    my $obj = shift;

    my %IN = ( TITLE   => "",
               TEXT    => "",
               COLSPAN => "",
               @_
             );

    $IN{'TEXT'} =~ s!<%!&lt;%!g;
    $IN{'TEXT'} =~ s!%>!%&gt;!g;
    $IN{'COLSPAN'} ||= 2;

    $IN{'TEXT'} = "<br>&nbsp;&nbsp;&nbsp;&nbsp;".$IN{'TEXT'} if $IN{'TEXT'};

    return qq~
    <tr>
    <td bgcolor='#EEEEEEF' colspan='$IN{'COLSPAN'}' align='left' valign='top'><font class='h'>&gt;</font>&nbsp;&nbsp;<font class='t'><b>$IN{'TITLE'}</b>$IN{'TEXT'}</font></td>
    </tr>
    ~;
}

#########################

sub end_table {
    my $obj = shift;

    return qq~
    </table>
    </td>
    </tr>
    </table>
    ~;
}

#########################

sub hidden_fields {
    my ($obj, $hidden) = @_;

    my $return;

    for my $i (keys %{$hidden}) {
        $return .= qq[ <input type='hidden' name='$i' value='$hidden->{$i}'>\n];
    }

    $return .= qq[ <input type='hidden' name='s' value='$iB::SESSION'>\n<input type='hidden' name='AD' value='1'>\n];

    return $return;
}

#########################

sub form_start {
    my $obj = shift;

    return qq~<form action='$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?AD=1&s=$iB::SESSION' method='post' name='TheForm'>~;
}

#########################

sub form_end {
    my $obj = shift;
    return qq~</form>~;
}

#########################
#########################
1;
