package Admin::MemberControl;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# MemberControl: Member account editor
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Lib/ADMIN.pm';
    require 'Admin/SKIN.pm';
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
}


my $SKIN  = Admin::SKIN->new();
my $std   = FUNC::STD->new();
my $mem   = FUNC::Member->new();
my $ADMIN = FUNC::ADMIN->new();
my $INFO  = Boardinfo->new();
my $mail  = FUNC::Mailer->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}


sub splash {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Member Control' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'member',
                                        CODE  => 'edit',
                                      } );

    $html .= $SKIN->section_header( TITLE => "Choose a member to edit");

    $html .= qq~
        <tr>
        <td colspan='2' bgcolor='#EEEEEEF'><font class='t'>Find user <input type='text' size='30' name='USER_KEY' class='forminput' style="width:200px"> by
        <select name='KEY_TYPE' class='forminput' style="width:100px"><option value='NAME'>name<option value='EMAIL'>Email address<option value='IP'>IP Address<option value='ID'>member ID</select>
        &nbsp;&nbsp;<input type='submit' class='forminput' style="width:50px" value='Go!'>
        ~;

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);


}



sub edit {
    my ($obj, $db) = @_;
    my $html;

    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must specify a name or user ID to look for!") unless defined $iB::IN{'USER_KEY'};

    #my $method = $iB::IN{'KEY_TYPE'} eq 'NAME' ? 'by name' : 'by id';
    my $method = $iB::IN{'KEY_TYPE'};
    if ($method eq 'NAME') {
        $method = 'by name';
    } elsif ($method eq 'EMAIL') {
        $method = 'by email';
    } elsif ($method eq 'IP') {
        $method = 'by ip';
    } else {
        $method = 'by id';
    }


    my $member = $mem->LoadMember( DB => $db, KEY => $iB::IN{'USER_KEY'}, METHOD => $method );

    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );
    my @groups;

    for (@{$mem_groups}) {
        next if ( ($_->{'ID'} == $INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $INFO->{'SUPAD_GROUP'}) );
        push @groups, { NAME => $_->{'TITLE'}, VALUE => $_->{'ID'} };
    }

    my $size   = scalar (@groups) + 1;


    #XXX No member found? Lets query the DB to find a near match

    unless ($member->{'MEMBER_ID'}) {

        # Make safe:

        $iB::IN{'USER_KEY'} =~ s!\[!\\\\[!g;
        $iB::IN{'USER_KEY'} =~ s!\]!\\\\]!g;

        #my $query_stm = $iB::IN{'KEY_TYPE'} eq 'NAME' ? "MEMBER_NAME LIKE /".$iB::IN{'USER_KEY'}."%/"
        #                                              : "MEMBER_ID LIKE /%".$iB::IN{'USER_KEY'}."%/";
        my $query_stm;
        if ($iB::IN{'KEY_TYPE'} eq 'NAME') {
            $query_stm = "MEMBER_NAME LIKE /%".$iB::IN{'USER_KEY'}."%/";
        } elsif ($iB::IN{'KEY_TYPE'} eq 'EMAIL') {
            $query_stm = "MEMBER_EMAIL LIKE /%".$iB::IN{'USER_KEY'}."%/";
        } elsif ($iB::IN{'KEY_TYPE'} eq 'IP') {
            $query_stm = "MEMBER_IP LIKE /%".$iB::IN{'USER_KEY'}."%/";
        } else {
            $query_stm = "MEMBER_ID LIKE /%".$iB::IN{'USER_KEY'}."%/";
        }


        my $member_query = $db->query( TABLE    => 'member_profiles',
                                       COLUMNS  => ['MEMBER_NAME', 'MEMBER_ID', 'MEMBER_GROUP', 'MEMBER_EMAIL', 'MEMBER_POSTS'],
                                       WHERE    => $query_stm,
                                       SORT_KEY => 'MEMBER_NAME'
                                     );

                                     #die "statement ".$db->show_query;


        unless (scalar (@{$member_query}) > 0) {
            $ADMIN->Error( DB=>"", STD=>"", MSG => "No matches found for that member data");
        }



        my $html = qq~

        <table cellspacing='0' cellpadding='5' border='0' width='100%' border='0'>
        <tr>
        <td>
        <font class='large'>&gt;&gt; Possible Member Matches</font>

        <form action='$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?AD=1&act=cat&s=$iB::SESSION&CODE=00' method='post'>
        <input type='hidden' name='AD' value='1'>
        <input type='hidden' name='act' value='member'>
        <input type='hidden' name='s' value='$iB::SESSION'>
        <input type='hidden' name='CODE' value='edit'>
        <input type='hidden' name='KEY_TYPE' value='ID'>

        <table cellspacing='1' cellpadding='0' width='100%' align='center' border='0' bgcolor='#333366'>
        <tr>
            <td>
            <table cellspacing='1' cellpadding='2' width='100%' align='center' border='0'>
            <tr>
            <td bgcolor='#666699' width='10%' align='center'>&nbsp;</td>
            <td bgcolor='#666699' width='30%'><font class='t'><b>Member Name</b></font></td>
            <td bgcolor='#666699' width='15%' align='center'><font class='t'><b>Member Group</b></font></td>
            <td bgcolor='#666699' width='8%' align='center'><font class='t'><b>Member Email</b></font></td>
            <td bgcolor='#666699' width='8%' align='center'><font class='t'><b>Member Posts</b></font></td>

            </tr>
        ~;


        for my $this_mem (@{$member_query}) {

            my $this_mem_g = {} ;
            for (@{$mem_groups}) {
                next if ( ($_->{'ID'} == $INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $INFO->{'SUPAD_GROUP'}) );
                $this_mem_g = $_ if $_->{'ID'} == $this_mem->{'MEMBER_GROUP'};
            }

            $html .= qq~
                <tr>
                <td bgcolor='#FFFFFF' align='center'><input type='radio' name='USER_KEY' value='$this_mem->{'MEMBER_ID'}' style='border:none'></td>
                <td bgcolor='#FFFFFF'><font class='t'>$this_mem->{'MEMBER_NAME'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem_g->{'TITLE'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem->{'MEMBER_EMAIL'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem->{'MEMBER_POSTS'}</font></td>
                </tr>
                ~;
        }


        $html .= qq~

                <tr>
                <td colspan='6' align='center' bgcolor='#FFFFFF'><br><input type='submit' value='Edit Selected Member'></td>
                </tr>
                </table>
            </td>
            </tr>
        </table>
        </form>
        </td>
        </tr>
        </table>
        ~;

        $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);
    }


    if ( ($member->{'MEMBER_GROUP'} == $INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $INFO->{'SUPAD_GROUP'}) ) {
        $ADMIN->Error( DB=>"", STD=>"", MSG => "You do not have permission to edit that member");
    }

    #XXX If we get here, we must have found an exact match.

    $member->{'SIGNATURE'} = $SKIN->formalize($member->{'SIGNATURE'});
    $member->{'INTERESTS'} = $SKIN->formalize($member->{'INTERESTS'});

    my ($width, $height) = split "x", $member->{'AVATAR_DIMS'};

    $member->{'ALLOW_POST'} ||= 0;

    $html  = $SKIN->title( TITLE => "Member Settings for $member->{'MEMBER_NAME'}<br>IP Address: $member->{'MEMBER_IP'}", TEXT => 'Please double check all the data before submitting the changes.' );
    $html .= $SKIN->begin_table();
    $html .= $SKIN->form_start();
    $html .= $SKIN->hidden_fields( {    act   => 'member',
                                        CODE  => 'doedit',
                                        ID    => $member->{'MEMBER_ID'},
                                        NAME  => $member->{'MEMBER_NAME'},
                                        OLD_P => $member->{'MEMBER_PASSWORD'},
                                      } );

    $html .= $SKIN->section_header( TITLE => "Main Settings");

    $member->{'LAST_ACTIVITY'} = $std->get_date( TIME => $member->{'LAST_ACTIVITY'}, METHOD => 'LONG' );
    $html .= qq~
    <tr>
    <td bgcolor='#FFFFFF' width='40%' align='left'><font class='t'>&nbsp;&nbsp;&nbsp;&nbsp;Last activity date</font></td>
    <td bgcolor='#FFFFFF' width='60%' align='left'>$member->{'LAST_ACTIVITY'}</td>
    </tr>~;

    $html .= $SKIN->td_input ( TEXT     => 'Member Real Name',         NAME => 'MEMBER_NAME_R',  VALUE=> "$member->{'MEMBER_NAME_R'}");

    $html .= $SKIN->td_select( TEXT     => "Allow this member to post where allowed?",
                               NAME     => 'ALLOW_POST',
                               REQ      => 1,
                               VALUES   => $member->{'ALLOW_POST'},
                               DATA     => [ { NAME => 'Yes', VALUE => 1 },
                                             { NAME => 'No' , VALUE => 0 } ],
                             );


    $html .= $SKIN->td_select( TEXT     => 'Member Group:',
                               NAME     => 'MEMBER_GROUP',
                               SIZE     => $size,
                               VALUES   => $member->{'MEMBER_GROUP'},
                               DATA     => \@groups
                             );
# added for gender
    $html .= $SKIN->td_select( TEXT     => "Gender selection?",
                               NAME     => 'GENDER',
                               REQ      => 1,
                               VALUES   => $member->{'GENDER'},
                               DATA     => [ { NAME => ''       , VALUE => 0 },
                                             { NAME => 'Male'   , VALUE => 1 },
                                             { NAME => 'Female' , VALUE => 2 } ],
                             );
# end added for gender
# added for Warn
    $html .= $SKIN->td_select( TEXT     => 'Warning Level:',
                               NAME     => 'WARN_LEVEL',
                               VALUES   => $member->{'WARN_LEVEL'},
                               DATA     => [ { NAME => '0', VALUE => 0 },
                                             { NAME => '1', VALUE => 1 },
                                             { NAME => '2', VALUE => 2 },
                                             { NAME => '3', VALUE => 3 },
                                             { NAME => '4', VALUE => 4 },
                                             { NAME => '5', VALUE => 5 } ],
                             );
# end added for Warn
    $html .= $SKIN->td_input ( TEXT     => 'Title',         NAME => 'MEMBER_TITLE',  VALUE=> "$member->{'MEMBER_TITLE'}");

    $html .= $SKIN->td_input ( TEXT     => 'Email Address', NAME => 'MEMBER_EMAIL',  VALUE=> "$member->{'MEMBER_EMAIL'}",  REQ => 1 );

    $html .= $SKIN->td_input ( TEXT     => 'Avatar',        NAME => 'MEMBER_AVATAR', VALUE=> "$member->{'MEMBER_AVATAR'}");

    $html .= $SKIN->td_input ( TEXT     => 'Avatar Width',  NAME => 'AVATAR_W',      VALUE=> $width);

    $html .= $SKIN->td_input ( TEXT     => 'Avatar Height', NAME => 'AVATAR_H',      VALUE=> $height);

    $html .= $SKIN->td_input ( TEXT     => 'Posts',         NAME => 'MEMBER_POSTS',  VALUE=> "$member->{'MEMBER_POSTS'}");

    $html .= $SKIN->td_input ( TEXT     => 'Photo',         NAME => 'PHOTO',         VALUE=> "$member->{'PHOTO'}");

    $html .= $SKIN->td_input ( TEXT     => 'AIM Name',      NAME => 'AOLNAME',       VALUE=> "$member->{'AOLNAME'}");

    $html .= $SKIN->td_input ( TEXT     => 'ICQ No.',       NAME => 'ICQNUMBER',     VALUE=> "$member->{'ICQNUMBER'}");

    $html .= $SKIN->td_input ( TEXT     => 'Yahoo Name',    NAME => 'YAHOONAME',     VALUE=> "$member->{'YAHOONAME'}");

    $html .= $SKIN->td_input ( TEXT     => 'MSN Name',      NAME => 'MSNNAME',       VALUE=> "$member->{'MSNNAME'}");

    $html .= $SKIN->td_input ( TEXT     => 'Location',      NAME => 'LOCATION',      VALUE=> "$member->{'LOCATION'}");

    $html .= $SKIN->td_input ( TEXT     => 'Website',       NAME => 'WEBSITE',       VALUE=> "$member->{'WEBSITE'}");

    $html .= $SKIN->td_textarea( TEXT   => "Signature",     NAME => 'SIGNATURE',     VALUE => "$member->{'SIGNATURE'}");

    $html .= $SKIN->td_textarea( TEXT   => "Interests",     NAME => 'INTERESTS',     VALUE => "$member->{'INTERESTS'}");

    $html .= $SKIN->td_input ( TEXT     => 'Posts per day<br>(0 = infinite)',               NAME => 'POST_PER_DAY',     VALUE=> "$member->{'POST_PER_DAY'}");
    $html .= $SKIN->td_input ( TEXT     => 'Period that posts can be made in (in hours)',   NAME => 'POST_PERIOD',      VALUE=> "$member->{'POST_PERIOD'}");

    $html .= $SKIN->td_select( TEXT     => "Email Hidden?",
                               NAME     => 'HIDE_EMAIL',
                               REQ      => 1,
                               VALUES   => $member->{'HIDE_EMAIL'},
                               DATA     => [ { NAME => 'Yes', VALUE => 1 },
                                             { NAME => 'No' , VALUE => 0 } ],
                             );

    $html .= $SKIN->section_header( TITLE => "Reset Members Password?", TEXT => 'Leave blank unless you want to change it!');

    $html .= $SKIN->td_input ( TEXT     => 'Enter a new password here<br>&nbsp;&nbsp;&nbsp;&nbsp;If you wish to reset the pass',         NAME => 'MEMBER_PASSWORD');


    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => "Member Preferences", PRINT => $html);

}


sub do_edit {
    my ($obj, $db) = @_;

    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must specify a member to edit!") unless defined $iB::IN{'ID'};

    my $pass;

    if (length($iB::CGI->param('MEMBER_PASSWORD')) > 0) {
        $pass = $mem->MD5($iB::IN{'NAME'},$iB::IN{'MEMBER_PASSWORD'});
    } else {
        $pass = $iB::CGI->param('OLD_P');
    }
    my $sig = $SKIN->htmlalize($iB::CGI->param('SIGNATURE'));
    $iB::IN{'INTERESTS'}     = $SKIN->htmlalize($iB::IN{'INTERESTS'});
    $iB::IN{'AVATAR_DIMS'}   = $iB::IN{'AVATAR_W'}.'x'.$iB::IN{'AVATAR_H'};

    $db->update( TABLE   => 'member_profiles',
                 KEY     => $iB::IN{'ID'},
                 ID      => $iB::IN{'ID'},
                 VALUES  => {   MEMBER_GROUP   => $iB::IN{'MEMBER_GROUP'},
                                MEMBER_PASSWORD => $pass,
                                MEMBER_EMAIL   => $iB::IN{'MEMBER_EMAIL'},
                                MEMBER_TITLE   => $iB::IN{'MEMBER_TITLE'},
                                MEMBER_AVATAR  => $iB::IN{'MEMBER_AVATAR'},
                                AVATAR_DIMS    => $iB::IN{'AVATAR_DIMS'},
                                MEMBER_POSTS   => $iB::IN{'MEMBER_POSTS'},
                                PHOTO          => $iB::IN{'PHOTO'},
                                AOLNAME        => $iB::IN{'AOLNAME'},
                                ICQNUMBER      => $iB::IN{'ICQNUMBER'},
                                YAHOONAME      => $iB::IN{'YAHOONAME'},
                                MSNNAME        => $iB::IN{'MSNNAME'},
                                LOCATION       => $iB::IN{'LOCATION'},
                                WEBSITE        => $iB::IN{'WEBSITE'},
                                SIGNATURE      => $sig,
                                INTERESTS      => $iB::IN{'INTERESTS'},
                                ALLOW_POST     => $iB::IN{'ALLOW_POST'},
                                HIDE_EMAIL     => $iB::IN{'HIDE_EMAIL'},
                                GENDER         => $iB::IN{'GENDER'},
                                WARN_LEVEL     => $iB::IN{'WARN_LEVEL'},
                                MEMBER_NAME_R  => $iB::IN{'MEMBER_NAME_R'},
                                POST_PER_DAY   => $iB::IN{'POST_PER_DAY'},
                                POST_PERIOD    => $iB::IN{'POST_PERIOD'},
                           },
              );

    $ADMIN->write_log( TITLE => 'Member Changed', EXTRA => "MemberName: $iB::IN{'NAME'}");

    $ADMIN->static_screen( URL   => "act=member&CODE=edit&USER_KEY=$iB::IN{'ID'}",
                           TITLE => "Member edited",
                           TEXT  => "The changes were successful"
                         );

}

sub ban {
    my ($obj, $db) = @_;

    my @bans = split /\|\&\|/, $INFO->{'IP_FILTER'};
    my $banned = join "\n", @bans;

    my @email = split /\|\&\|/, $INFO->{'EMAIL_FILTER'};
    my $emails = join "\n", @email;

    my $html  = $SKIN->title( TITLE => 'Ban Filter Control');
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'member',
                                        CODE  => 'doban'
                                      } );

    #+-----------------------------------

    $html .= $SKIN->section_header( TITLE => "Please edit your IP filters", TEXT => "You may use '*' as a wildcard. For example: 212.234.* will ban any user with an IP that starts with 212.234" );


    $html .= $SKIN->td_textarea( TEXT  => "Banned IP's<br>&nbsp;&nbsp;&nbsp;&nbsp;Add,edit or remove<br>&nbsp;&nbsp;&nbsp;&nbsp;One per line",
                                 NAME  => 'IP_FILTER',
                                 VALUE => $banned,
                                );

    $html .= $SKIN->section_header( TITLE => "Please edit your Email filters", TEXT => "You may use '*' as a wildcard. For example: '*\@yahoo.com' will ban any user with a 'yahoo' email address, and/or not let the register" );

    $html .= $SKIN->td_textarea( TEXT  => "Banned Email Addresses<br>&nbsp;&nbsp;&nbsp;&nbsp;Add,edit or remove<br>&nbsp;&nbsp;&nbsp;&nbsp;One per line",
                                 NAME  => 'EMAIL_FILTER',
                                 VALUE => $emails,
                                );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Ban Control', PRINT => $html);

}

sub doban {
    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();

    $iB::IN{'EMAIL_FILTER'} =~ s!<br>!\|\&\|!g;
    $iB::IN{'IP_FILTER'}    =~ s!<br>!\|\&\|!g;


    $OLD->{'EMAIL_FILTER'}  = $iB::IN{'EMAIL_FILTER'};
    $OLD->{'IP_FILTER'}     = $iB::IN{'IP_FILTER'} ;

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->write_log( TITLE => 'Board Control Changed');

    $ADMIN->static_screen( URL   => "act=member",
                           TITLE => "Ban Filters Changed",
                           TEXT  => "The changes were successful<br>"
                         );
}


sub reg {
    my ($obj, $db) = @_;

    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );
    my @groups;

    for (@{$mem_groups}) {
        next if ( ($_->{'ID'} == $INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $INFO->{'SUPAD_GROUP'}) );
        push @groups, { NAME => $_->{'TITLE'}, VALUE => $_->{'ID'} };
    }


    my $html  = $SKIN->title( TITLE => "Member pre-registration", TEXT => 'Please double check all the data before submitting.' );
    $html .= $SKIN->begin_table();
    $html .= $SKIN->form_start();
    $html .= $SKIN->hidden_fields( {    act   => 'member',
                                        CODE  => 'doreg',
                                      } );

    $html .= $SKIN->section_header( TITLE => "Member Settings");

    $html .= $SKIN->td_input ( TEXT => 'Member Name',          NAME => 'MEMBER_NAME',  VALUE=> '', REQ => 1);

    $html .= $SKIN->td_input ( TEXT => 'Member Password',       NAME => 'MEMBER_PASS',  VALUE=> '', REQ => 1);

    $html .= $SKIN->td_input ( TEXT => 'Member Email Address',  NAME => 'EMAIL',  VALUE=> '', REQ => 1);

    $html .= $SKIN->td_input ( TEXT => 'Member Post count',     NAME => 'POSTS',  VALUE=> '0', REQ => 1);

    $html .= $SKIN->td_select( TEXT     => 'Member Group:',
                               NAME     => 'MEMBER_GROUP',
                               VALUES   => "$INFO->{'MEMBER_GROUP'}",
                               DATA     => \@groups
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow this member to post where allowed?",
                               NAME     => 'ALLOW_POST',
                               REQ      => 1,
                               VALUES   => '',
                               DATA     => [ { NAME => 'Yes', VALUE => 1 },
                                             { NAME => 'No' , VALUE => 0 } ],
                             );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Pre Register this Member' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);

}


sub doreg {
    my ($obj, $db) = @_;

    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must enter a membername") unless defined $iB::IN{'MEMBER_NAME'};
    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must enter a password")   unless defined $iB::IN{'MEMBER_PASS'};
    $ADMIN->Error( DB=>,"", STD=>"", MSG => "The password must be at a minimum 5 characters long")   unless length $iB::IN{'MEMBER_PASS'} >= 5;
    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must enter an email address") unless defined $iB::IN{'EMAIL'};

    unless ($std->CheckEmail($iB::IN{'EMAIL'})) {
        $ADMIN->Error( DB=>,"", STD=>"", MSG => "Invalid email address");
    }

    my $name = $mem->CheckName( DB => $db, NAME => $iB::IN{'MEMBER_NAME'} );

    if ($name->{'MEMBER_NAME'}) {
        $ADMIN->Error( DB=>,"", STD=>"", MSG => "$iB::IN{'MEMBER_NAME'} already exists!");
    }

    my $new_id = $mem->AddMember( DB     => $db,
                                  STD    => $std,
                                  MEMBER => {
                                               MEMBER_NAME      => $iB::IN{'MEMBER_NAME'},
                                               MEMBER_PASSWORD  => $iB::IN{'MEMBER_PASS'},
                                               MEMBER_EMAIL     => $iB::IN{'EMAIL'},
                                               MEMBER_GROUP     => $iB::IN{'MEMBER_GROUP'},
                                               ALLOW_POST       => $iB::IN{'ALLOW_POST'},
                                               MEMBER_POSTS     => $iB::IN{'POSTS'},
                                               MEMBER_LEVEL     => 1,
                                               MEMBER_AVATAR    => 'noavatar',
                                               MEMBER_IP        => $ENV{'REMOTE_ADDR'},
                                               TIME_ADJUST      => 0,
                                               LANGUAGE         => 'en',
                                               MEMBER_SKIN      => 'Default',
                                               MEMBER_JOINED    => time,
                                               VIEW_SIGS        => 1,
                                               VIEW_IMG         => 1,
                                               VIEW_AVS         => 1,
                                               ALLOW_ADMIN_EMAILS => 1,
                                               PM_REMINDER     => '1&1',
                                            }
                                 );

    my $num = $db->count( TABLE => 'member_profiles' );

    $num++;

    my $stats = {};
    $stats->{'TOTAL_MEMBERS'}      = '+1';
    $stats->{'LAST_REG_MEMBER_N'}  = $iB::IN{'MEMBER_NAME'};
    $stats->{'LAST_REG_MEMBER_ID'} = $new_id;

    $std->ib_stats($stats);

    my $pass = $iB::IN{'MEMBER_PASS'};

    $iB::IN{'MEMBER_PASS'} = 'xxxxxxxxxxx';

    if ($iB::INFO->{'CALENDAR'}) {

        my $day = $db->insert( TABLE  => 'calendar',
                               VALUES => {
                                           MEMBER_ID    => $new_id,
                                           MEMBER_NAME  => $iB::IN{'MEMBER_NAME'},
                                           DAY          => '0',
                                           MONTH        => '0',
                                           YEAR         => '0',
                                         },
                             );
    };
    $ADMIN->write_log( TITLE => 'Member Pre-registered', EXTRA => "New Name: $iB::IN{'MEMBER_NAME'}");

    $ADMIN->static_screen( URL   => "act=member",
                           TITLE => "$iB::IN{'MEMBER_NAME'} has been registered",
                           TEXT  => "Member Name: $iB::IN{'MEMBER_NAME'}<br>Member Email: $iB::IN{'EMAIL'}<br>Member Password: $pass"
                         );
}

sub titles {
    my ($obj, $db) = @_;

    my @exempt = split /\:/, $iB::INFO->{'EXEMPT_GROUPS'};

    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );
    my $groups = qq!<option value=''>Don't Advance</option>!;
    my @member_groups;

    for (@{$mem_groups}) {
        push @member_groups, { NAME => $_->{'TITLE'}, VALUE => $_->{'ID'} };
        next if ( ($_->{'ID'} == $INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $INFO->{'SUPAD_GROUP'}) );
        $groups .= qq!<option value='$_->{ID}'>$_->{'TITLE'}</option>!;
    }



    my $mem_titles = $db->query( TABLE      => 'member_titles',
                                 SORT_KEY   => 'POSTS',
                                 SORT_BY    => 'A-Z',
                               );

    my $html  = $SKIN->title( TITLE => 'Member Title Set Up');
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'member',
                                        CODE  => 'dotitles'
                                      } );


    $html .= $SKIN->section_header( TITLE => "Please edit the titles below",TEXT=> "Or leave both fields blank to remove<br>If you wish to use a picture instead of differing pip numbers, enter the image name in the \"pips for this level\" box. Image must be uploaded into iB_html/non-cgi/team_icons. Just enter icon name instead of number, not the full URL For example: <b>newmember.gif</b>" );

    $html .= qq~
    <tr>
    <td bgcolor='#EEEEEE' width='40%' align='left' valign='top'><font class='t'><b>Titles and Post numbers</b></font></td>
    <td bgcolor='#EEEEEE' width='60%' align='left'><font class='t'><b>Advance to a new member group?</b></font></td>
    </tr>
    ~;

    my $cnt = 0;

    for my $t (@{$mem_titles}) {

        my $n_groups = $groups;

        $n_groups =~ s!<option value='$t->{'ADVANCE_GROUP'}'!<option value='$t->{'ADVANCE_GROUP'}' selected!;

        $html .= qq~
            <tr>
            <td bgcolor='#FFFFFF' width='40%' align='left'><font class='t'><input type='text' name="TITLE_$t->{'ID'}" value='$t->{'TITLE'}' class='forminput' style='width:150px'><br>must have over <input type='text' name="POSTS_$t->{'ID'}" value='$t->{'POSTS'}' class='forminput' style='width:50px'> posts<br># pips for this level = <input type='text' name="PIPS_$t->{'ID'}" value='$t->{'PIPS'}' class='forminput' style='width:50px'></font></td>
            <td bgcolor='#FFFFFF' width='60%' align='left' valign='left' nowrap><select name='AD_$t->{ID}' class='forminput' style='width:60%'>$n_groups</select></td>
            </tr>
        ~;
        $cnt = $t->{'ID'} if $t->{'ID'} > $cnt;
    }

    $cnt++;

    $html .= $SKIN->section_header( TITLE => "Add new titles",TEXT=> "You do not have to use any/all the fields" );

    for (0 .. 10) {

        my $n_groups = $groups;

        $n_groups =~ s!<option value=''!<option value='' selected!;

        $html .= qq~
            <tr>
            <td bgcolor='#FFFFFF' width='40%' align='left'><font class='t'><input type='text' name="TITLE_$cnt" value='' class='forminput' style='width:150px'><br>must have over <input type='text' name="POSTS_$cnt" value='' class='forminput' style='width:50px'> posts<br># pips for this level = <input type='text' name="PIPS_$cnt" class='forminput' style='width:50px'></font></td>
            <td bgcolor='#FFFFFF' width='60%' align='left' valign='left' nowrap><select name='AD_$cnt' class='forminput' style='width:60%'>$n_groups</select></td>
            </tr>
        ~;
        $cnt++;
    }

    $html .= $SKIN->section_header( TITLE => "Exempt Groups",TEXT=> "You may not wish certain groups to be affected by the title/advance group changes<br>&nbsp;&nbsp;&nbsp;&nbsp;Especially those with Global Moderator/Admin priviledges (As a safety measure, Super Admins are always exempt)" );


    $html .= $SKIN->td_select( TEXT     => 'Exempt Groups:',
                               NAME     => 'EXEMPT_GROUPS',
                               MULTIPLE => 1,
                               VALUES   => \@exempt,
                               DATA     => \@member_groups
                             );


    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Add/Edit Titles' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Title Control', PRINT => $html);
}

sub dotitles {
    my ($obj, $db) = @_;

    my $mem_titles = $db->query( TABLE      => 'member_titles',
                                 SORT_KEY   => 'POSTS',
                                 SORT_BY    => 'A-Z',
                               );

    my %title_hash = map {  $_->{'ID'} => $_->{'TITLE'}  } @{$mem_titles};

    my @titles     = grep { /^TITLE_(\d+)$/ } $iB::CGI->param();

    for my $t (@titles) {
        $t    =~ m#^TITLE_(\d+)$#;
        my $n = $1;
        if (defined $title_hash{$n}) {

            $db->update( TABLE    => 'member_titles',
                         KEY      => $n,
                         VALUES   => { TITLE         => $iB::IN{'TITLE_'.$n},
                                       POSTS         => $iB::IN{'POSTS_'.$n},
                                       ADVANCE_GROUP => $iB::IN{'AD_'.$n},
                                       PIPS          => $iB::IN{'PIPS_'.$n},
                                     }
                       );
        } else {

            next unless defined $iB::IN{'POSTS_'.$n};
            next unless $iB::IN{'TITLE_'.$n} ne '';

            $db->insert( TABLE    => 'member_titles',
                         VALUES   => { TITLE         => $iB::IN{'TITLE_'.$n},
                                       POSTS         => $iB::IN{'POSTS_'.$n},
                                       ADVANCE_GROUP => $iB::IN{'AD_'.$n},
                                       PIPS          => $iB::IN{'PIPS_'.$n},
                                     }
                       );
        }
    }

    #Remove dead..

    my $mem_titles = $db->query( TABLE      => 'member_titles',
                                 SORT_KEY   => 'POSTS',
                                 SORT_BY    => 'A-Z',
                               );

    for my $m (@{$mem_titles}) {
        if ($m->{'TITLE'} eq '') {
            $db->delete( TABLE    => 'member_titles',
                         KEY      => $m->{'ID'},
                       );
        }
    }

    my $OLD = Boardinfo->new();

    $OLD->{'EXEMPT_GROUPS'} = join ':', $iB::CGI->param('EXEMPT_GROUPS');

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );


    $ADMIN->write_log( TITLE => 'Member Titles Changed');

    $ADMIN->static_screen( URL   => "act=member&CODE=titles",
                           TITLE => "The changes were successful",
                         );
}

sub del {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Member Control' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'member',
                                        CODE  => 'delone',
                                      } );

    $html .= $SKIN->section_header( TITLE => "Choose a member to DELETE", TEXT => "Deleting a member physically removes them from the database, are you sure you wish to do this?");

    $html .= qq~
        <tr>
        <td colspan='2' bgcolor='#EEEEEEF'><font class='t'>Find user <input type='text' size='30' name='USER_KEY' class='forminput' style="width:200px"> by
        <select name='KEY_TYPE' class='forminput' style="width:100px"><option value='NAME'>name<option value='ID'>member ID</select>
        &nbsp;&nbsp;<input type='submit' class='forminput' style="width:50px" value='Go!'>
        ~;

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);


}



sub delone {
    my ($obj, $db) = @_;
    my $html;

    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must specify a name or user ID to look for!") unless defined $iB::IN{'USER_KEY'};

    my $method = $iB::IN{'KEY_TYPE'} eq 'NAME' ? 'by name' : 'by id';

    $iB::IN{'USER_KEY'} =~ s!\[!\\\\[!g;
    $iB::IN{'USER_KEY'} =~ s!\]!\\\\]!g;

    my $query_stm = $iB::IN{'KEY_TYPE'} eq 'NAME' ? "MEMBER_NAME LIKE /%$iB::IN{'USER_KEY'}%/"
                                                  : "MEMBER_ID LIKE /%$iB::IN{'USER_KEY'}%/";

    my $member_query = $db->query( TABLE    => 'member_profiles',
                                   COLUMNS  => ['MEMBER_NAME', 'MEMBER_ID', 'MEMBER_GROUP', 'MEMBER_EMAIL', 'MEMBER_POSTS'],
                                   WHERE    => $query_stm,
                                   SORT_KEY => 'MEMBER_NAME'
                                 );


    unless (scalar (@{$member_query}) > 0) {
        $ADMIN->Error( DB=>"", STD=>"", MSG => "No matches found for that member data");
    }

    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );
    my @groups;

    for (@{$mem_groups}) {
        next if ( ($_->{'ID'} == $INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $INFO->{'SUPAD_GROUP'}) );
        push @groups, { NAME => $_->{'TITLE'}, VALUE => $_->{'ID'} };
    }

        my $html = qq~

        <table cellspacing='0' cellpadding='5' border='0' width='100%' border='0'>
        <tr>
        <td>
        <font class='large'>&gt;&gt; Possible Member Matches for DELETION - You may choose more than one.<br><br><span style='color:red'>*ONLY PROCEED IF YOU WISH TO DELETE A MEMBER*</span></font>

        <form action='$INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?AD=1&s=$iB::SESSION' method='post'>
        <input type='hidden' name='AD' value='1'>
        <input type='hidden' name='act' value='member'>
        <input type='hidden' name='s' value='$iB::SESSION'>
        <input type='hidden' name='CODE' value='delfinal'>
        <input type='hidden' name='KEY_TYPE' value='ID'>

        <table cellspacing='1' cellpadding='0' width='100%' align='center' border='0' bgcolor='#333366'>
        <tr>
            <td>
            <table cellspacing='1' cellpadding='2' width='100%' align='center' border='0'>
            <tr>
            <td bgcolor='#666699' width='10%' align='center'>&nbsp;</td>
            <td bgcolor='#666699' width='30%'><font class='t'><b>Member Name</b></font></td>
            <td bgcolor='#666699' width='15%' align='center'><font class='t'><b>Member Group</b></font></td>
            <td bgcolor='#666699' width='8%' align='center'><font class='t'><b>Member Email</b></font></td>
            <td bgcolor='#666699' width='8%' align='center'><font class='t'><b>Member Posts</b></font></td>

            </tr>
        ~;


        for my $this_mem (@{$member_query}) {

            my $this_mem_g = {} ;
            for (@{$mem_groups}) {
                next if ( ($_->{'ID'} == $INFO->{'SUPAD_GROUP'}) and ($iB::MEMBER->{'MEMBER_GROUP'} != $INFO->{'SUPAD_GROUP'}) );
                $this_mem_g = $_ if $_->{'ID'} == $this_mem->{'MEMBER_GROUP'};
            }

            $html .= qq~
                <tr>
                <td bgcolor='#FFFFFF' align='center'><input type='checkbox' name='USER_KEY' value='$this_mem->{'MEMBER_ID'}' style='border:none'></td>
                <td bgcolor='#FFFFFF'><font class='t'>$this_mem->{'MEMBER_NAME'}<br>ID: $this_mem->{'MEMBER_ID'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem_g->{'TITLE'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem->{'MEMBER_EMAIL'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem->{'MEMBER_POSTS'}</font></td>
                </tr>
                ~;
        }


        $html .= qq~

                <tr>
                <td colspan='6' align='center' bgcolor='#FFFFFF'><br><input type='submit' value='DELETE Selected Member'></td>
                </tr>
                </table>
            </td>
            </tr>
        </table>
        </form>
        </td>
        </tr>
        </table>
        ~;

        $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);

}

sub delfinal {
    my ($obj, $db) = @_;

    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must specify a member to delete!") unless defined $iB::IN{'USER_KEY'};


    my @keys = $iB::CGI->param('USER_KEY');

    for my $key (@keys) {

        my $member = $db->select( TABLE => 'member_profiles',
                                  KEY   => $key
                                );

        next unless $member->{'MEMBER_ID'};

        $db->delete( TABLE => 'member_profiles',
                     KEY   => $member->{'MEMBER_ID'}
                   );
        $db->delete( TABLE  => 'member_notepads',
                     KEY   => $member->{'MEMBER_ID'}
                   );

        $db->delete( TABLE => 'calendar',
                     KEY   => $member->{'MEMBER_ID'}
                   );

        $db->update_index( TABLE     => 'member_profiles',
                           INDEX_KEY => 'MEMBER_EMAIL',
                           R_KEY     => $member->{'MEMBER_EMAIL'},
                           REMOVE    => 1
                         );

        $db->update_index( TABLE     => 'member_profiles',
                           INDEX_KEY => 'MEMBER_NAME',
                           R_KEY     => $member->{'MEMBER_NAME'},
                           REMOVE    => 1
                         );
    }

    $ADMIN->write_log( TITLE => 'Member(s) Deleted');

    $ADMIN->static_screen( URL   => "act=member",
                           TITLE => "The member was deleted",
                         );
}

sub email {
    my ($obj, $db) = @_;
    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );
    my @groups;

    for (@{$mem_groups}) {
        push @groups, { NAME => $_->{'TITLE'}, VALUE => $_->{'ID'} } unless ($_->{'ID'} eq $iB::INFO->{'GUEST_GROUP'});
    }

    my $size = scalar(@groups) + 1;

    my $html  = $SKIN->title( TITLE => 'Choose recipients',
                              TEXT  => "This will allow you to choose which member groups the email will be sent to"
                           );

       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'member',
                                        CODE  => 'doemail',
                                      } );

    $html .= $SKIN->section_header( TITLE => "Which member groups do you want to send to?");

    $html .= $SKIN->td_select( TEXT     => "Available membergroups",
                               NAME     => 'GROUPS',
                               MULTIPLE => 1,
                               REQ      => 1,
                               SIZE     => $size,
                               VALUES   => "",
                               DATA     => \@groups,
                             );

    $html .= $SKIN->section_header( TITLE => "Message to be sent.");

    $html .= $SKIN->td_input ( TEXT => "Subject", NAME => 'subject', REQ => 1 );

    $html .= $SKIN->td_textarea( TEXT => "Message", NAME => 'MESSAGE', REQ  => 1 );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Send the mail' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

     $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);
}

sub doemail {
    my ($obj, $db) = @_;

    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must specify at least one group to send to!") unless defined $iB::CGI->param('GROUPS');

    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must enter a message to send!") unless length($iB::CGI->param('MESSAGE')) > 2;

    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You must enter a subject!") unless length($iB::CGI->param('subject')) > 2;

    my @groups = split(/,/, (join ",", $iB::CGI->param('GROUPS')));

    my $qstr = "(";
    foreach (@groups) {
        $qstr .= "MEMBER_GROUP == $_ or ";
    }
    $qstr = substr($qstr, 0, length($qstr) - 4);
    $qstr .= ") and ALLOW_ADMIN_EMAILS == 1";

    my $members = $db->query( TABLE => 'member_profiles',
                      COLUMNS  => ['MEMBER_NAME', 'MEMBER_EMAIL'],
                      WHERE => $qstr,
                    );
    my $recip = "";
    foreach (@{$members}) {
        $recip .= $_->{'MEMBER_NAME'} . "<$_->{'MEMBER_EMAIL'}>,";
    }
    if ($recip eq "") {
        $ADMIN->static_screen( URL    => "act=member",
                               TITLE  => "Mail sent to no members."
                             );
        return;
    }
    my $message = $mail->parse_template( ID      => 'MASS_MAIL',
                                         DB      => $db,
                                         VALUES  =>
                                          {
                                            MESSAGE     =>  $iB::IN{'MESSAGE'},
                                           }
                                        );

    $mail->Send( BCC     => $recip,
                 FROM    => $iB::INFO->{'ADMIN_EMAIL_OUT'},
                 SUBJECT => $iB::IN{'subject'},
                 MESSAGE => $message
                  );

    $ADMIN->static_screen( URL   => "act=member",
                           TITLE => "Your mail has been sent.",
                         );
}




sub outdate {
   my ($obj, $db) = @_;
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'} and $iB::INFO->{'P_PRUNE_MEM'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        my $new1 = $iB::IN{'PASSWRD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records! Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
        } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '' and $iB::INFO->{'P_PRUNE_MEM'}) {

        my $html  = $SKIN->title( TITLE => "Prune old members", TEXT => ".");
        $html .= $SKIN->begin_table();
        $html .= $SKIN->form_start();
        $html .= $SKIN->hidden_fields( { act  => 'member',
                                         CODE => 'outdate',
                                          } );
        $html .= $SKIN->section_header( TITLE => "This feature is password protected!" );
        $html .= $SKIN->td_input ( TEXT => 'Enter the the admin password here', NAME => 'PASSWRD', VALUE=> "", REQ => 1, TYPE => 'password' );
        $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
        $html .= $SKIN->form_end();
        $html .= $SKIN->end_table();

        $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => "Protected Area!", PRINT => $html);

    }

    SKIPED:

   my $html  = $SKIN->title( TITLE => 'Member Control' );
      $html .= $SKIN->begin_table();
      $html .= $SKIN->form_start();
      $html .= $SKIN->hidden_fields( { act   => 'member',
                                       CODE  => 'show_outdate',
                                       PASSWRD => $iB::IN{'PASSWRD'}
                                     } );

   $html .= $SKIN->section_header( TITLE => "Choose time limit", TEXT => "Check if a member is out of date");

    $html .= $SKIN->td_select( TEXT     => "Choose the date limit to select members?",
                               NAME     => 'that_date',
                               SIZE     => 6,
                               REQ      => 1,
                               VALUES   => 10,
                               DATA     => [ { NAME => '10 days', VALUE => '10' },
                                             { NAME => '20 days', VALUE => '20' },
                                             { NAME => '60 days', VALUE => '20' },
                                             { NAME => '100 days',VALUE => '100' },
                                             { NAME => '200 days',VALUE => '200' },
                                             { NAME => '1 year',  VALUE => '365' },]
                             );

    $html .= $SKIN->td_select( TEXT     => 'Member selection method',
                               NAME     => 'TYPE',
                               SIZE     => 2,
                               VALUES   => 'ACTI',
                               DATA     => [
                                             { VALUE => 'ACTI', NAME => 'By last activity date' },
                                             { VALUE => 'POST', NAME => 'By last post date' },
                                           ]
                             );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Go!' );

   $html .= $SKIN->form_end();
   $html .= $SKIN->end_table();

   $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);


}

sub show_outdate {
   my ($obj, $db) = @_;
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'} and $iB::INFO->{'P_PRUNE_MEM'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records! Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
    } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '' and $iB::INFO->{'P_PRUNE_MEM'}) {

        $obj->outdate();
    }
    SKIPED:

    if ($iB::IN{'TYPE'} eq '') {
            $ADMIN->Error( DB=>"", STD=>"", MSG => "You need to select a method");
     }
   my $the_date = $iB::IN{'that_date'};

   my $html  = $SKIN->title( TITLE => 'Member Control' );
      $html .= $SKIN->form_start();
      $html .= $SKIN->hidden_fields( { act   => 'member',
                                       CODE  => 'del_outdate',
                                     } );

   $html .= $SKIN->section_header( TITLE => "Delete in $the_date", TEXT => "<b>Are you sure you want to delete these members?</b>");

     my $mem_outdate = $db->query( TABLE      => 'member_profiles',
                                 SORT_KEY   => 'MEMBER_NAME',
                                 SORT_BY    => 'A-Z',
                               );
     my $mem_aut = $db->query(TABLE   => 'authorisation',
                              COLOMNS => ['MEMBER_NAME', 'MEMBER_ID'],
                              );

        $html .= qq~
        <tr>
        <td>
        <font class='large'>&gt;&gt; Possible Member Matches</font>
         <table cellspacing='1' cellpadding='0' width='100%' align='center' border='0' bgcolor='#333366'>
        <tr>
            <td>
            <table cellspacing='1' cellpadding='2' width='100%' align='center' border='0'>
            <tr>
            <td bgcolor='#666699' width='20%' align='center'>&nbsp;</td>
            <td bgcolor='#666699' width='30%'><font class='t'><b>Member Name</b></font></td>
            <td bgcolor='#666699' width='20%' align='center'><font class='t'><b>Last activity</b></font></td>
            <td bgcolor='#666699' width='15%' align='center'><font class='t'><b>Member Email</b></font></td>
            <td bgcolor='#666699' width='15%' align='center'><font class='t'><b>Member Posts</b></font></td>
            </tr>
              ~;
        my $date;
        my $status;
if ($iB::IN{'TYPE'} eq 'POST'){
   for my $this_mem (@{$mem_outdate}) {
      $status = '0';
      $this_mem->{'count_post'} = $this_mem->{'LAST_POST'};
      $this_mem->{'count_post'} =~ s!(.+?)(-)!!isg;
      my $post_time = time - ($the_date * 60 * 60 * 24);
      foreach my $i(@{$mem_aut}) {
      if ($i->{'MEMBER_ID'} eq $this_mem->{'MEMBER_ID'}) {
         $status = '1'; last;
                                 }
                                 }
      if (($post_time > $this_mem->{'count_post'}) and ($status eq '0')) {
      $date = $std->get_date( TIME => $this_mem->{'LAST_ACTIVITY'}, METHOD => 'SHORT');
            $html .= qq~
                <tr>
                <td bgcolor='#FFFFFF' align='center'><select name='Del$this_mem->{"MEMBER_NAME"}' class='forminput'><option value='Leave' selected>Leave<option value='Delete' >Delete</select></td>
                <td bgcolor='#FFFFFF'><font class='t'>$this_mem->{'MEMBER_NAME'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$date</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem->{'MEMBER_EMAIL'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem->{'MEMBER_POSTS'}</font></td>
                </tr>
                 ~;
      }
   }
   }
   elsif ($iB::IN{'TYPE'} eq 'ACTI'){
      for my $this_mem (@{$mem_outdate}) {
      $status = '0';
      my $post_time = time - ($the_date * 60 * 60 * 24);
            foreach my $i(@{$mem_aut}) {
            if ($i->{'MEMBER_ID'} eq $this_mem->{'MEMBER_ID'}) {
            $status = '1'; last;
                                 }
                                 }
      if (($post_time > $this_mem->{'LAST_ACTIVITY'}) and ($status eq '0')) {
            $date = $std->get_date( TIME => $this_mem->{'LAST_ACTIVITY'}, METHOD => 'SHORT');
            $html .= qq~
                <tr>
                <td bgcolor='#FFFFFF' align='center'><select name='Del$this_mem->{"MEMBER_NAME"}' class='forminput'><option value='Leave' selected>Leave<option value='Delete' >Delete</select></td>
                <td bgcolor='#FFFFFF'><font class='t'>$this_mem->{'MEMBER_NAME'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$date</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem->{'MEMBER_EMAIL'}</font></td>
                <td bgcolor='#FFFFFF' align='center'><font class='t'>$this_mem->{'MEMBER_POSTS'}</font></td>
                </tr>
                ~;
      }
   }
   }

        $html .= qq~

                <tr>
                <td colspan='5' align='center' bgcolor='#FFFFFF'><br><input type='submit' class='formiput' style="width:50px" value='Go!'></td>
                </tr>
            </td>
            </tr>
            </table>
        ~;
   $html .= $SKIN->form_end();
   $html .= $SKIN->end_table();

        $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);
    }


sub del_outdate {
   my ($obj, $db) = @_;

   my $mem_outdate = $db->query( TABLE      => 'member_profiles',
                                 SORT_KEY   => 'MEMBER_NAME',
                                 SORT_BY    => 'A-Z',
                               );
   my $html  = $SKIN->title( TITLE => 'Member Control' );
      $html .= $SKIN->begin_table();
   $html .= $SKIN->section_header( TITLE => "Members selected for deletion", TEXT => "These members were sent an email to notify them that they will be deleted");
   $html .= qq~ <center><table bgcolor="#f3f3f3" width="99%"><tbody><tr><td>~;
   my $hehe;
   for my $this_member (@{$mem_outdate}) {
     $hehe = "Del".$this_member->{'MEMBER_NAME'};
     if ($iB::IN{$hehe} eq "Delete") {
       $html .= qq~ <span style='color:red'>&gt;</span> $this_member->{'MEMBER_NAME'}, $this_member->{'MEMBER_EMAIL'} <br>~;

#------------------------------------------------------------
# We send the member ID to the autorisation table.
# If the member doesn't confirm that they want to remain a member in the set period of time they will be deleted.
# The members will be shown in AdminCP in the section < members processing their registration >
#------------------------------------------------------------
    my $unique_id = $mail->my_gen_id();
    my $time      = time;


        my $new_id = $db->insert( TABLE   => 'authorisation',
                                  VALUES  => {  UNIQUE_CODE   =>  $unique_id,
                                                DATE_ENTERED  =>  $time,
                                                MEMBER_ID     =>  $this_member->{'MEMBER_ID'},
                                                MEMBER_NAME   =>  $this_member->{'MEMBER_NAME'},
                                                THIS_IP       =>  $this_member->{'IP_ADDRESS'},
                                                MEMBER_EMAIL  =>  $this_member->{'MEMBER_EMAIL'},
                                                '_WHERE'      =>  'outdate',
                                              },
                                );

        my $message = $mail->parse_template( ID     => 'OUT',
                                             DB     => $db,
                                             VALUES => { THE_LINK    =>  "$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg&CODE=03&SID=$unique_id",
                                                         MEMBER_NAME =>  $this_member->{'MEMBER_NAME'},
                                                         UNTIL       =>  $iB::INFO->{'AUTHORISE_PRUNE'},
                                                         MAN_LINK    =>  "$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg&CODE=05",
                                                         EMAIL       =>  $this_member->{'MEMBER_EMAIL'},
                                                         CODE        =>  $unique_id,
                                                       }
                                            );

        $mail->Send( TO      => $this_member->{'MEMBER_EMAIL'},
                     FROM    => '',
                     SUBJECT => "Registration at $iB::INFO->{'BOARDNAME'}",
                     MESSAGE => $message
                  );


     }
   }

   $html .= qq~
     </td></tr></tbody></table></center>
   ~;
   $html .= $SKIN->end_table();

   $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => 'Member Control', PRINT => $html);

}

sub list {
    my ($obj, $db) = @_;
    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You do not have permission for this action") unless $iB::MEMBER->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'};
    my $html  = $SKIN->title( TITLE => "Members List", TEXT => "This tool will create a CSV file in the OUTGOING directory.<br>This file will contain all your member list in the CSV comma delimited format. It is compatible with all spreadsheet software on the market.");
    $html .= $SKIN->begin_table();
    $html .= $SKIN->form_start();
    $html .= $SKIN->hidden_fields( { act  => 'member',
                                     CODE => 'do_list',
                                      } );
    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Make CSV file' );
    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'MEMBERS', NAV_ONE => "Members list", PRINT => $html);
}

sub do_list {
    my ($obj, $db) = @_;
    my $all_members = $db->query( TABLE => 'member_profiles',
                                  SORT_KEY   => 'MEMBER_NAME',
                                  SORT_BY    => 'A-Z',
                                 );
    my $list = "MEMBER_ID,MEMBER_NAME,MEMBER_REAL_NAME,DATE_JOINED,EMAIL,GENDER,GROUP,WEBSITE,YAHOO,ICQ,MSN,AOL,LOCATION\n";
    my $date;
    foreach my $member (@{$all_members}) {
        $date = $std->get_date(TIME=>$member->{'MEMBER_JOINED'}, METHOD=>'SHORT');
        $member->{'LOCATION'} =~ s!,!|!g;
        $list .= qq!$member->{'MEMBER_ID'},$member->{'MEMBER_NAME'},$member->{'MEMBER_NAME_R'},$date,$member->{'MEMBER_EMAIL'},$member->{'GENDER'},$member->{'MEMBER_GROUP'},$member->{'WEBSITE'},$member->{'YAHOONAME'},$member->{'ICQNUMBER'},$member->{'MSNNAME'},$member->{'AOLNAME'},$member->{'LOCATION'}\n!;
    }
    open LIST, ">".$iB::INFO->{'IKON_DIR'}.'OUTGOING/member_list.csv';
    print LIST $list;
    close LIST;
    $ADMIN->static_screen( URL   => "act=member&CODE=list",
                           TITLE => "File Created",
                           TEXT  => "The CSV file was created successfully and is in your OUTGOING directory."
                         );
}

sub process {
    my ($obj, $db) = @_;

    my $CodeNo = $iB::IN{'CODE'};

    my %Mode = ( 'edit'        => \&edit,
                 'doedit'      => \&do_edit,
                 'ban'         => \&ban,
                 'doban'       => \&doban,
                 'reg'         => \&reg,
                 'doreg'       => \&doreg,
                 'titles'      => \&titles,
                 'dotitles'    => \&dotitles,
                 'del'         => \&del,
                 'delone'      => \&delone,
                 'delfinal'    => \&delfinal,
                 'outdate'     => \&outdate,
                 'email'       => \&email,
                 'doemail'     => \&doemail,
                 'show_outdate'=> \&show_outdate,
                 'del_outdate' => \&del_outdate,
                 'list'        => \&list,
                 'do_list'     => \&do_list,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj,$db) : splash($obj,$db);
}


1;
__END__
