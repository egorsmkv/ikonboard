package Admin::dbHandler;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# dbHandler: Database manipulation
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Lib/ADMIN.pm';
    require 'Admin/SKIN.pm';
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
}

use File::Path;
use File::Copy;

my $SKIN  = Admin::SKIN->new();
my $std   = FUNC::STD->new();
my $ADMIN = FUNC::ADMIN->new();
my $INFO  = Boardinfo->new();



sub new {
    my $pkg = shift;
    my $obj = {  };
    bless $obj, $pkg;
    return $obj;
}


sub splash {
    my ($obj, $db) = @_;

if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'} and $iB::INFO->{'P_DATABASE'}) {
    my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
    my $new1 = $iB::IN{'PASSWRD'};
    require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
    require 'Sources/ARC4.pm' or die "Cannot open ARC4";
    opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
    my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
    closedir(DIR);
    my @key  = grep { /.+?(\.pwd)\Z/ } @list;
        for my $f (@key) {
            my $ark4 = Crypt::ARC4->new($f);
            $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
        }
        $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records! Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
        goto SKIPED;
    } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '' and $iB::INFO->{'P_DATABASE'}) {

    my $html  = $SKIN->title( TITLE => "Drop Tables", TEXT => ".");
    $html .= $SKIN->begin_table();
    $html .= $SKIN->form_start();
    $html .= $SKIN->hidden_fields( { act  => 'dbHandler',
                                     CODE => 'splash',
                                      } );
    $html .= $SKIN->section_header( TITLE => "This feature is password protected!" );
    $html .= $SKIN->td_input ( TEXT => 'Enter the the admin password here', NAME => 'PASSWRD', VALUE=> "", REQ => 1, TYPE => 'password' );
    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Protected Area!", PRINT => $html);

}

    SKIPED:

    my $html  = $SKIN->title( TITLE => 'Drop all Database Tables', TEXT => 'This will remove a database installation, populated or empty.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act     => 'dbHandler',
                                        CODE    => 'drop',
                                        PASSWRD => $iB::IN{'PASSWRD'}
                                      } );

    $html .= $SKIN->section_header( TITLE => "Drop a Database");


    $html .= $SKIN->td_select( TEXT     => "Which database do you wish to drop?",
                               NAME     => 'DB',
                               REQ      => 1,
                               VALUES   => 'DBM',
                               DATA     => [
                                              { NAME => 'DBM'   , VALUE => 'DBM'    },
                                              { NAME => 'mySQL' , VALUE => 'mySQL'  },
                                              { NAME => 'pgSQL' , VALUE => 'pgSQL'  },
                                              { NAME => 'Oracle', VALUE => 'Oracle' },
                                           ],
                             );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Drop this Database' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'DATABASE', NAV_ONE => "Drop a Database", PRINT => $html);

}


sub drop {
    my ($obj, $db) = @_;
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'} and $iB::INFO->{'P_DATABASE'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        my $new1 = $iB::IN{'PASSWRD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records! Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
    } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '' and $iB::INFO->{'P_DATABASE'}) {

        $obj->splash();
    }
    SKIPED:

    if ($iB::IN{'DB'} eq $iB::INFO->{DB_DRIVER}) {
        $ADMIN->Error( DB => $db, STD => $std, MSG => "You cannot drop the database you are currently using! Well you could, but it'd be beyond stupid.");
    }

    my $html  = $SKIN->title( TITLE => 'Drop all Tables of a Database', TEXT => 'This will remove a database installation, populated or empty.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'dbHandler',
                                        CODE  => 'dodrop',
                                        DB    => $iB::IN{'DB'},
                                        PASSWRD => $iB::IN{'PASSWRD'},
                                      } );

    $html .= $SKIN->section_header( TITLE => "Drop a Database", TEXT => "JUST TO CONFIRM: THIS WILL REMOVE ALL DATA FROM THE DATABASE");


    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Drop this Database!' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'DATABASE', NAV_ONE => "Drop a Database", PRINT => $html);

}

sub dodrop {
    my $obj = shift;
    unless ($iB::IN{'PASSWRD'}) {
        if ($iB::INFO->{'ADMIN_PASSWORD'}) {
        $obj->splash();
        }
    }
    require iDatabase::SQL;

    # Get a Database connection
    # Since we don't want to drop
    # and create tables..
    my $create = $iB::INFO->{DB_DRIVER} eq 'DBM' ? 1 : 0;
    my $drop   = $iB::INFO->{DB_DRIVER} eq 'DBM' ? 1 : 0;
    require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
    require 'Sources/ARC4.pm' or die "Cannot open ARC4";
    opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
    my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
    closedir(DIR);
    my @key  = grep { /.+?(\.pwd)\Z/ } @list;
    for my $f (@key) {
        my $ark4 = Crypt::ARC4->new($f);
        $iB::INFO->{$iB::IN{'DB'}.'_DB_PASS'} = $ark4->ARC4( MIME::Base64::decode_base64($iB::INFO->{$iB::IN{'DB'}.'_DB_PASS'}));# decrypting the pass
        last;
    }

    my $db    = iDatabase::SQL->new( DATABASE  => $iB::INFO->{$iB::IN{'DB'}.'_DB_NAME'},
                                     DB_DIR    => $iB::INFO->{'DB_DIR'},
                                     IP        => $iB::INFO->{$iB::IN{'DB'}.'_DB_IP'},
                                     PORT      => $iB::INFO->{$iB::IN{'DB'}.'_DB_PORT'},
                                     USERNAME  => $iB::INFO->{$iB::IN{'DB'}.'_DB_USER'},
                                     PASSWORD  => $iB::INFO->{$iB::IN{'DB'}.'_DB_PASS'},
                                     DB_PREFIX => $iB::INFO->{$iB::IN{'DB'}.'_DB_PREFIX'},
                                     DB_DRIVER => $iB::IN{'DB'},
                                     ATTR      => { allow_create => $create,
                                                    allow_drop   => $drop,
                                                  },
                                   );

    my $i = $db->drop_database();

    $ADMIN->static_screen( URL   => "&act=dbHandler",
                           TITLE => "The database table has been emptied ($i tables emptied).",
                         );
}

##########################################################################################
#
# Database set  up stuff, taken from the installer modules.
#
##########################################################################################

sub setup {
    my ($obj, $db) = @_;
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'} and $iB::INFO->{'P_DATABASE'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        my $new1 = $iB::IN{'PASSWRD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records! Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
    } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '' and $iB::INFO->{'P_DATABASE'}) {

        my $html  = $SKIN->title( TITLE => "Drop Tables", TEXT => ".");
        $html .= $SKIN->begin_table();
        $html .= $SKIN->form_start();
        $html .= $SKIN->hidden_fields( { act  => 'dbHandler',
                                         CODE => 'setup',
                                          } );
        $html .= $SKIN->section_header( TITLE => "This feature is password protected!" );
        $html .= $SKIN->td_input ( TEXT => 'Enter the the admin password here', NAME => 'PASSWRD', VALUE=> "", REQ => 1 );
        $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
        $html .= $SKIN->form_end();
        $html .= $SKIN->end_table();

        $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Protected Area!", PRINT => $html);

    }

    SKIPED:

    my $html  = $SKIN->title( TITLE => 'Set up a database', TEXT => 'This will set up a new database. PLEASE NOTE: You *MUST* make sure the INSTALL_DATA file is there and contains the up to date installer files' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'dbHandler',
                                        CODE  => 'startsetup',
                                        PASSWRD => $iB::IN{'PASSWRD'},
                                      } );

    $html .= $SKIN->section_header( TITLE => "Set up a Database");


    $html .= $SKIN->td_select( TEXT     => "Which database do you wish to set up?",
                               NAME     => 'DB',
                               REQ      => 1,
                               VALUES   => 'DBM',
                               DATA     => [
                                              { NAME => 'DBM'   , VALUE => 'DBM'    },
                                              { NAME => 'mySQL' , VALUE => 'mySQL'  },
                                              { NAME => 'pgSQL' , VALUE => 'pgSQL'  },
                                              { NAME => 'Oracle', VALUE => 'Oracle' },
                                           ],
                             );

    $html .= $SKIN->td_select( TEXT     => "Do you want Ikonboard to create the tables for you?",
                               NAME     => 'CREATE',
                               REQ      => 1,
                               VALUES   => '1',
                               DATA     => [
                                              { NAME => 'Yes'                                       , VALUE => '1'    },
                                              { NAME => 'No - The tables have already been created' , VALUE => '0'    },
                                           ],
                             );

    $html .= $SKIN->td_select( TEXT     => "Do you want Ikonboard to re-install the default database files for you?",
                               NAME     => 'INSTALL',
                               REQ      => 1,
                               VALUES   => '1',
                               DATA     => [
                                              { NAME => 'Yes - the tables are empty'                  , VALUE => '1'    },
                                              { NAME => 'No - I will be re-installing from a back up' , VALUE => '0'    },
                                           ],
                             );

    $html .= $SKIN->section_header( TITLE => "Needed information for SQL databases", TEXT => "You may leave this if you are setting up a DBM installation");


    $iB::INFO->{'DB_IP'}     ||= 'localhost';
    $iB::INFO->{'DB_PREFIX'} ||= 'ib_';

    # DB User name
    $html .= $SKIN->td_input (   TEXT => 'SQL Username', NAME => 'DB_USER', VALUE=> $iB::INFO->{'DB_USER'});
    # DB Password
    $html .= $SKIN->td_input (   TEXT => 'SQL Password', NAME => 'DB_PASS', VALUE=> "", TYPE => 'password');
    # DB Database name
    $html .= $SKIN->td_input (   TEXT => 'SQL Database name', NAME => 'DB_NAME', VALUE=> $iB::INFO->{'DB_NAME'});
    # DB Database Server
    $html .= $SKIN->td_input (   TEXT => 'SQL Database Server IP', NAME => 'DB_IP', VALUE=> $iB::INFO->{'DB_IP'});
    # DB Database Port
    $html .= $SKIN->td_input (   TEXT => 'SQL Database Server Port', NAME => 'DB_PORT', VALUE=> $iB::INFO->{'DB_PORT'});
    # DB Table Prefix
    $html .= $SKIN->td_input (   TEXT => 'SQL Table Prefix(so you can have multiple IBs in one DB', NAME => 'DB_PREFIX', VALUE=> $iB::INFO->{'DB_PREFIX'});

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Set up this Database' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'DATABASE', NAV_ONE => "Set up a Database", PRINT => $html);

}


sub startsetup {
    my $obj = shift;  #Just get the $obj, not the $db
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'} and $iB::INFO->{'P_DATABASE'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        my $new1 = $iB::IN{'PASSWRD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => "", STD => $std, MSG => "Your password does not match what we have in our records! Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
    } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '' and $iB::INFO->{'P_DATABASE'}) {

        $obj->setup();
    }
    SKIPED:

    ## Check to make sure we have all the info we need.

    if ($iB::IN{'DB'} ne 'DBM') {
        $ADMIN->Error( STD=>$std, MSG=>"You need to enter an SQL Username")  unless $iB::IN{'DB_USER'};
        $ADMIN->Error( STD=>$std, MSG=>"You need to enter an SQL Password")  unless $iB::IN{'DB_PASS'};
        $ADMIN->Error( STD=>$std, MSG=>"You need to enter an SQL Database")  unless $iB::IN{'DB_NAME'};
        $ADMIN->Error( STD=>$std, MSG=>"You need to enter an SQL Server IP") unless $iB::IN{'DB_IP'};
    }

    # Get our iDatabase admin driver

    require "iDatabase/Admin/a_$iB::IN{'DB'}.pm";

    my $aDB = iDatabase::Admin::SQL->new();

    # Set up the database..

    $aDB->install_database( schema_dir => $iB::INFO->{'IKON_DIR'}."INSTALL_DATA",
                            return_err => 1,
                            create_tbl => $iB::IN{CREATE},
                            attr       => { DB_NAME   => $iB::IN{'DB_NAME'},
                                            DB_IP     => $iB::IN{'DB_IP'},
                                            DB_PORT   => $iB::IN{'DB_PORT'},
                                            DB_USER   => $iB::IN{'DB_USER'},
                                            DB_PASS   => $iB::IN{'DB_PASS'},
                                            DB_PREFIX => $iB::IN{'DB_PREFIX'},
                                            DB_DRIVER => $iB::IN{'DB'},
                                          },
                          );

    # Check for errors..
    if (scalar @{ $aDB->{errors} } > 0 ) {
        goto 'ERRORS';
    }

    # let's Crypt the passwords.
    require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
    require 'Sources/ARC4.pm' or die "Cannot open ARC4";
    BACK:
    opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
    my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
    closedir(DIR);
    my @key  = grep { /.+?(\.pwd)\Z/ } @list;
    unless (scalar @key > 0) {
        my $file = &iB::my_gen_key();
        my $file_name = $iB::INFO->{'IKON_DIR'}.'/Data/' . $file . '.pwd';
        open (KEYF, ">" . $file_name ) or die "Cannot write to $file_name ($!)";
        close KEYF;
        chmod ( 0644, $file_name );
        goto BACK;
    }
    my $temp_pass;
    for my $f (@key) {
    my $ark4 = Crypt::ARC4->new($f);
    $temp_pass = $iB::IN{'DB_PASS'};
    $iB::IN{'DB_PASS'} = MIME::Base64::encode_base64($ark4->ARC4($iB::IN{'DB_PASS'}));# decrypting the pass
    $iB::IN{'DB_PASS'} =~ s!\n\Z!!;
    }

    sub my_gen_key {
        my $obj = shift;
        srand($$|time);
        my $f_name = int(rand(600000000000));
        return unpack("H*", pack("Nnn", time, $$, $f_name));
    }

    # NO errors? Good, lets write the new boardinfo file..
    my $OLD = Boardinfo->new();
    for my $homer (qw/DB_NAME DB_IP DB_PORT DB_USER DB_PASS DB_PREFIX/) {
        $OLD->{ $iB::IN{'DB'}."_".$homer } = $iB::IN{ $homer };
    }

    $OLD->{$iB::IN{'DB'}."_setup"} = 1;

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );
    $iB::IN{'DB_PASS'} = $temp_pass;

    if ($iB::IN{'INSTALL'}) {

        require 'Sources/iDatabase/SQL.pm' or iB::install_error( "Cannot locate the needed iDatabase driver to require" );

        my $db    = iDatabase::SQL->new( DATABASE  => $iB::IN{'DB_NAME'},
                                         DB_DIR    => $iB::INFO->{'DB_DIR'},
                                         IP        => $iB::IN{'DB_IP'},
                                         PORT      => $iB::IN{'DB_PORT'},
                                         USERNAME  => $iB::IN{'DB_USER'},
                                         PASSWORD  => $iB::IN{'DB_PASS'},
                                         DB_PREFIX => $iB::IN{'DB_PREFIX'},
                                         DB_DRIVER => $iB::IN{'DB'},
                                         ATTR      => { allow_create => 0,
                                                        allow_drop   => 0,
                                                      },
                                       );

        my @errors;
        my $limit;

        # Database: MemberGroups

        open (FILE, "$iB::INFO->{'IKON_DIR'}INSTALL_DATA/mem_groups.dat") or (push @{ $aDB->{errors} }, "Cannot open /INSTALL_DATA/mem_groups.dat" and goto 'ERRORS' );
        my @groups = <FILE>;
        close FILE;

        for my $f (@groups) {
            chomp ($f);
            next unless $f;
            my @entry = split (/\|\^\|/, $f);
            next unless defined $entry[0];
            $db->insert( TABLE   => 'mem_groups',
                         VALUES  => {   VIEW_BOARD          =>  1,
                                        MEM_INFO            =>  $entry[1],
                                        OTHER_TOPICS        =>  $entry[2],
                                        USE_SEARCH          =>  $entry[3],
                                        EMAIL_FRIEND        =>  $entry[4],
                                        INVITE_FRIEND       =>  $entry[5],
                                        EDIT_PROFILE        =>  $entry[6],
                                        POST_NEW_TOPICS     =>  $entry[7],
                                        REPLY_OWN_TOPICS    =>  $entry[8],
                                        REPLY_OTHER_TOPICS  =>  $entry[9],
                                        EDIT_OWN_POSTS      =>  $entry[10],
                                        DELETE_OWN_POSTS    =>  $entry[11],
                                        OPEN_CLOSE_TOPICS   =>  $entry[12],
                                        DELETE_OWN_TOPICS   =>  $entry[13],
                                        POST_POLLS          =>  $entry[14],
                                        VOTE_POLLS          =>  $entry[15],
                                        USE_PM              =>  $entry[16],
                                        IS_SUPMOD           =>  $entry[17],
                                        ACCESS_CP           =>  $entry[18],
                                        TITLE               =>  $entry[19],
                                        CAN_REMOVE          =>  0,
                                        READ_AD_LOGS        =>  $entry[21],
                                        DELETE_AD_LOGS      =>  $entry[22],
                                        EDIT_GROUPS         =>  $entry[23],
                                        APPEND_EDIT         =>  $entry[24],
                                        ACCESS_OFFLINE      =>  $entry[25],
                                        AVOID_Q             =>  $entry[26],
                                        AVOID_FLOOD         =>  $entry[27],
                                  },
                        );

        }



        # Database: Email Templates

        open (FILE, "$iB::INFO->{'IKON_DIR'}INSTALL_DATA/email_template.dat") or (push @{ $aDB->{errors} }, "Cannot open /INSTALL_DATA/email_template.dat" and goto 'ERRORS' );
        my @templates = <FILE>;
        close FILE;

        for my $t (@templates) {
            chomp ($t);
            next unless $t;
            my @entry = split (/\|\^\|/, $t);
            next unless defined $entry[0];
            $db->insert( TABLE   => 'email_templates',
                         VALUES  => {   ID       =>  $entry[0],
                                        TYPE     =>  $entry[1],
                                        TEMPLATE =>  $entry[2],
                                  },
                        );
            push @errors, $db->{'error'} if $db->{'error'};
        }



        # Database: (ikon)Board Rules

        open (FILE, "$iB::INFO->{'IKON_DIR'}INSTALL_DATA/board_rules.dat") or (push @{ $aDB->{errors} }, "Cannot open /INSTALL_DATA/board_rules.dat" and goto 'ERRORS' );
        my @templates = <FILE>;
        close FILE;

        for my $t (@templates) {
            next unless $t;
            chomp ($t);
            my @entry = split (/\|\^\|/, $t);
            next unless defined $entry[0];
            $db->insert( TABLE   => 'forum_rules',
                         VALUES  => {   ID           =>  $entry[0],
                                        RULES_TITLE  =>  $entry[1],
                                        RULES_TEXT   =>  $entry[2],
                                        LAST_UPDATE  =>  time,
                                  },
                        );
            push @errors, $db->{'error'} if $db->{'error'};
        }

        # Database: Board Rules

        open (FILE, "$iB::INFO->{'IKON_DIR'}INSTALL_DATA/news.html") or(push @{ $aDB->{errors} }, "Cannot open /INSTALL_DATA/news_html" and goto 'ERRORS' );
        my @news = <FILE>;
        close FILE;

        my $text = join '', @news;



        $db->insert( TABLE  => 'ssi_templates',
                     VALUES => { ID              => 'news',
                                 EXPORT_FILENAME => "newsdata.txt",
                                 TEMPLATE        => $text
                               }
                   );


        push @errors, $db->{'error'} if $db->{'error'};


        # Database: SSI Templates

        open (FILE, "$iB::INFO->{'IKON_DIR'}INSTALL_DATA/ssi_templates.dat") or (push @{ $aDB->{errors} }, "Cannot open /INSTALL_DATA/ssI_templates.dat" and goto 'ERRORS' );
        my @templates = <FILE>;
        close FILE;


        for my $t (@templates) {
            chomp ($t);
            next unless $t;
            my @entry = split (/\|\^\|/, $t);
            next unless defined $entry[0];
            $db->insert( TABLE  => 'ssi_templates',
                         VALUES => { ID              =>  $entry[0],
                                     EXPORT_FILENAME =>  $entry[1],
                                     TEMPLATE        =>  $entry[2]
                                   }
                   );
            push @errors, $db->{'error'} if $db->{'error'};
        }


        open (FILE, "$iB::INFO->{'IKON_DIR'}INSTALL_DATA/global_template.html") or (push @{ $aDB->{errors} }, "Cannot open /INSTALL_DATA/global_template.dat" and goto 'ERRORS' );
        my @news = <FILE>;
        close FILE;

        my $text = join '', @news;


        $db->insert( TABLE  => 'templates',
                     VALUES => { ID              => 'global',
                                 TEMPLATE        => $text
                               }
                   );

        push @errors, $db->{'error'} if $db->{'error'};


        open (FILE, "$iB::INFO->{'IKON_DIR'}INSTALL_DATA/register.html") or (push @{ $aDB->{errors} }, "Cannot open /INSTALL_DATA/register.html" and goto 'ERRORS' );
        my @news = <FILE>;
        close FILE;

        my $text = join '', @news;


        $db->insert( TABLE  => 'templates',
                     VALUES => { ID              => 'register',
                                 TEMPLATE        => $text
                               }
                   );

        push @errors, $db->{'error'} if $db->{'error'};


        open (FILE, "$iB::INFO->{'IKON_DIR'}INSTALL_DATA/help.txt") or (push @{ $aDB->{errors} }, "Cannot open /INSTALL_DATA/help.txt" and goto 'ERRORS' );
        my @help = <FILE>;
        close FILE;

        my $help = {};
        my $flag = 0;
        my $cur  = undef;

        for my $i (@help) {
            next unless $i;
            if ($i =~ /^\[(.+?)\]$/) {
                $help->{$1} = "";
                $flag = 1;
                $cur  = $1;
                next;
            } else {
                $help->{$cur} .= $i;
            }
        }


        for my $k (keys %{$help}) {
            $help->{$k} =~ s!\n!<br>!g;
            $db->insert( TABLE  => 'help',
                         VALUES => { TITLE  => $k,
                                     TEXT   => $help->{$k}
                                   }
                       );
        }

    } # End install

ERRORS:

    my $html  = $SKIN->title( TITLE => 'Set up a database result' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->section_header( TITLE => "Set up a Database Results");


    if ( scalar @{ $aDB->{errors} } > 0 ) {

        $html .= qq~<tr><td class='d'><b>The following errors were found...</b><br><ul>~;

        for (@{ $aDB->{errors} }) {
            $html .= qq~<li>$_\n~;
        }

        $html .= qq~</ul></td></tr>~;
    }
    else {
        $html .= qq~<td class='d'><b>Set up complete!</b></td></tr>~;
    }

    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'DATABASE', NAV_ONE => "Set up a Database", PRINT => $html);
}


##########################################################################################
#
# Switch Database drivers. Assumes that you have them already set up
#
##########################################################################################

sub switch {
    my ($obj, $db) = @_;
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'} and $iB::INFO->{'P_DATABASE'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        my $new1 = $iB::IN{'PASSWRD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records! Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
    } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '' and $iB::INFO->{'P_DATABASE'}) {

        my $html  = $SKIN->title( TITLE => "Drop Tables", TEXT => ".");
        $html .= $SKIN->begin_table();
        $html .= $SKIN->form_start();
        $html .= $SKIN->hidden_fields( { act  => 'dbHandler',
                                         CODE => 'switch',
                                          } );
        $html .= $SKIN->section_header( TITLE => "This feature is password protected!" );
        $html .= $SKIN->td_input ( TEXT => 'Enter the the admin password here', NAME => 'PASSWRD', VALUE=> "", REQ => 1, TYPE => 'password' );
        $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
        $html .= $SKIN->form_end();
        $html .= $SKIN->end_table();

        $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Protected Area!", PRINT => $html);

    }

    SKIPED:

    my $html  = $SKIN->title( TITLE => 'Switch Database Drivers', TEXT => 'You must have already set up the Database type you wish to switch to' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'dbHandler',
                                        CODE  => 'doswitch',
                                        PASSWRD => $iB::IN{'PASSWRD'},

                                      } );

    $html .= $SKIN->section_header( TITLE => "Switch Database Driver. You are currently using: $iB::INFO->{'DB_DRIVER'}");


    $html .= $SKIN->td_select( TEXT     => "Which database do you wish switch to?<br>(If you are going to import into the database you about to make active, IMPORT FIRST THEN SWITCH DATABASES!)",
                               NAME     => 'DRIVER',
                               REQ      => 1,
                               VALUES   => 'DBM',
                               DATA     => [
                                              { NAME => 'DBM'   , VALUE => 'DBM'    },
                                              { NAME => 'mySQL' , VALUE => 'mySQL'  },
                                              { NAME => 'pgSQL' , VALUE => 'pgSQL'  },
                                              { NAME => 'Oracle', VALUE => 'Oracle' },
                                           ],
                             );

    $html .= $SKIN->td_select( TEXT     => "Do you want add this admin member account to the new database?",
                               NAME     => 'ADMIN',
                               REQ      => 1,
                               VALUES   => '1',
                               DATA     => [
                                              { NAME => 'Yes'                                       , VALUE => '1'    },
                                              { NAME => 'No - I already have one I wish to use'     , VALUE => '0'    },
                                           ],
                             );

    $html .= qq~<tr><td bgcolor='#FFFFFF' colspan='2' class='t'><b>PLEASE NOTE:</b> If you DO NOT choose to add your admin account to the new database
                and you DONT have an admin account in the new database, you WILL NOT be able to get back into the Admin Center again!.<br><br>
                If you choose to add this admin account to the new database, it will also add this admin member group. If a member group already
                exists with this member group ID, it'll create a new one and assign that ID to the copied admin account. You can then chose to
                remove it after you've assigned a new member group to yourself.<br><br>
                In either case, as soon as you switch database drivers, you may have to re-log in again.<br><br><b>VERY IMPORTANT</b>: After switching
                database drivers, the first thing to do is to edit the "Default Member Groups" - this is vitally important as the ID's stored may no
                longer match those in the database. The last thing you want is new members getting assigned to an Administrators group, etc!~;


    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Switch Database Drivers' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'DATABASE', NAV_ONE => "Switch DB drivers", PRINT => $html);

}


sub doswitch {
    my ($obj, $db) = @_;
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'} and $iB::INFO->{'P_DATABASE'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        my $new1 = $iB::IN{'PASSWRD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records! Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
    } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '' and $iB::INFO->{'P_DATABASE'}) {

        $obj->switch();
    }
    SKIPED:

    if ($iB::IN{'DRIVER'} eq $iB::INFO->{DB_DRIVER}) {
        $ADMIN->Error( DB => $db, STD => $std, MSG => "You are currently using this database. ");
    }

    my ($admin, $group, $session);

    # Get the current session details.
    $session = $db->select(  TABLE  => "active_sessions",
                             KEY    => $iB::SESSION,
                          );

    if ($iB::IN{ADMIN}) {
        $admin = $db->select( TABLE  => "member_profiles",
                              KEY    => $iB::MEMBER->{'MEMBER_ID'},
                            );

        $group = $db->select( TABLE => "mem_groups",
                              KEY   => $iB::MEMBER->{'MEMBER_GROUP'},
                            );
    }

    # Sort out the boardinfo file.

    my $OLD = Boardinfo->new();

    unless($OLD->{$iB::IN{'DRIVER'}."_setup"} == 1) {
        $ADMIN->Error( DB => $db, STD => $std, MSG => "$iB::IN{'DRIVER'} database not set up, please do this first.");
    }

    # Lets make sure the current DB is assigned to the heady status of being set up

    $OLD->{$iB::INFO->{'DB_DRIVER'}."_setup"} = 1;
# decrypt password
    require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
    require 'Sources/ARC4.pm' or die "Cannot open ARC4";
    opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
    my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
    closedir(DIR);
    my @key  = grep { /.+?(\.pwd)\Z/ } @list;
    my ($temp_pass, $curent_crypt_pass);
    for my $f (@key) {
        my $ark4 = Crypt::ARC4->new($f);
        $temp_pass = $iB::INFO->{$iB::IN{'DRIVER'}.'_DB_PASS'};
        $iB::INFO->{$iB::IN{'DRIVER'}.'_DB_PASS'} = $ark4->ARC4( MIME::Base64::decode_base64($iB::INFO->{$iB::IN{'DRIVER'}.'_DB_PASS'}));# decrypting the pass
        $ark4 = Crypt::ARC4->new($f);
        $curent_crypt_pass = $iB::INFO->{'DB_PASS'};
        $iB::INFO->{'DB_PASS'} = MIME::Base64::encode_base64($ark4->ARC4($iB::INFO->{'DB_PASS'}));# crypting the current decrypted pass
        $iB::INFO->{'DB_PASS'} =~ s!\n\Z!!;
        last;
    }

    my $current = { DB_DRIVER => $iB::INFO->{'DB_DRIVER'},
                    DATABASE  => $iB::INFO->{'DB_NAME'},
                    IP        => $iB::INFO->{'DB_IP'},
                    PORT      => $iB::INFO->{'DB_PORT'},
                    USERNAME  => $iB::INFO->{'DB_USER'},
                    PASSWORD  => $iB::INFO->{'DB_PASS'},
                    DB_PREFIX => $iB::INFO->{'DB_PREFIX'},
                  };
    my $new     = { DB_DRIVER => $iB::IN{'DRIVER'},
                    DATABASE  => $iB::INFO->{$iB::IN{'DRIVER'}.'_DB_NAME'},
                    IP        => $iB::INFO->{$iB::IN{'DRIVER'}.'_DB_IP'},
                    PORT      => $iB::INFO->{$iB::IN{'DRIVER'}.'_DB_PORT'},
                    USERNAME  => $iB::INFO->{$iB::IN{'DRIVER'}.'_DB_USER'},
                    PASSWORD  => $iB::INFO->{$iB::IN{'DRIVER'}.'_DB_PASS'},
                    DB_PREFIX => $iB::INFO->{$iB::IN{'DRIVER'}.'_DB_PREFIX'},
                  };

    # Get a new DB connection, and insert the data we have..

    my $dbi   = iDatabase::SQL->new( DATABASE  => $new->{'DATABASE'},
                                     DB_DIR    => $iB::INFO->{'DB_DIR'},
                                     IP        => $new->{'IP'},
                                     PORT      => $new->{'PORT'},
                                     USERNAME  => $new->{'USERNAME'},
                                     PASSWORD  => $new->{'PASSWORD'},
                                     DB_PREFIX => $new->{'DB_PREFIX'},
                                     DB_DRIVER => $new->{'DB_DRIVER'},
                                     ATTR      => { allow_create => 0,
                                                    allow_drop   => 0,
                                                  },
                                   );


    if ($iB::IN{'ADMIN'}) {

        $admin->{'MEMBER_GROUP'} = $iB::INFO->{SUPAD_GROUP};

        $dbi->insert( TABLE  => "member_profiles",
                      VALUES => $admin,
                    );
    }

    # Fix up the boardinfo file..
    if ($current->{DB_DRIVER} eq 'DBM') {
        $current->{PASSWORD} = '';
    }
    $OLD->{$iB::INFO->{'DB_DRIVER'}."_DB_DRIVER"} = $current->{DB_DRIVER};
    $OLD->{$iB::INFO->{'DB_DRIVER'}."_DB_NAME"}   = $current->{DATABASE};
    $OLD->{$iB::INFO->{'DB_DRIVER'}."_DB_IP"}     = $current->{IP};
    $OLD->{$iB::INFO->{'DB_DRIVER'}."_DB_PORT"}   = $current->{PORT};
    $OLD->{$iB::INFO->{'DB_DRIVER'}."_DB_USER"}   = $current->{USERNAME};
    $OLD->{$iB::INFO->{'DB_DRIVER'}."_DB_PASS"}   = $current->{PASSWORD};
    $OLD->{$iB::INFO->{'DB_DRIVER'}."_DB_PREFIX"} = $current->{DB_PREFIX};

    # Change the current DB driver..

    $OLD->{DB_DRIVER} = $new->{DB_DRIVER};
    $OLD->{DB_NAME}   = $new->{DATABASE};
    $OLD->{DB_IP}     = $new->{IP};
    $OLD->{DB_PORT}   = $new->{PORT};
    $OLD->{DB_USER}   = $new->{USERNAME};
    $OLD->{DB_PASS}   = $temp_pass;
    $OLD->{DB_PREFIX} = $new->{DB_PREFIX};

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "",
                           TITLE => "Database Driver Changed!",
                           TEXT  => "The changes were successful"
                         );
}


sub process {
    my ($obj, $db) = @_;

    # Only allow super admins access...

    unless ($iB::MEMBER->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}) {
        $ADMIN->Error( DB => $db, STD => $std, MSG => "Sorry, only the board owners have access to this part");
    }

    my $CodeNo = $iB::IN{'CODE'};

    my %Mode = ( 'setup'        => \&setup,
                 'dodrop'       => \&dodrop,
                 'drop'         => \&drop,
                 'startsetup'   => \&startsetup,
                 'switch'       => \&switch,
                 'doswitch'     => \&doswitch,
               );

    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj,$db) : splash($obj,$db);
}

1;
