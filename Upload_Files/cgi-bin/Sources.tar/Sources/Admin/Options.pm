package Admin::Options;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# MemberControl: Member account editor
#
#################################################################################
#
# Options: LOTS of board configuration settings
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Lib/ADMIN.pm';
    require 'Admin/SKIN.pm';
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
}

my $SKIN  = Admin::SKIN->new();
my $std   = FUNC::STD->new();
my $mem   = FUNC::Member->new();
my $ADMIN = FUNC::ADMIN->new();
my $INFO  = Boardinfo->new();
my $txt   = iTextparser->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub active {
    my ($obj, $db) = @_;

    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE', 'CAN_REMOVE'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );

    my $html  = $SKIN->title( TITLE => 'Active Users Hi-Lighting', TEXT => 'You can change the way the active users are formatted' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'do_active'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Please enter the prefix and suffix code. You may use HTML", TEXT => "You may leave both fields blank to remove any special formatting");

    $html .= qq~
        <tr>
        <td bgcolor='#FFFFFF' align='left' class='t'><b><i>Example Only</i></b></td>
        <td bgcolor='#FFFFFF' class='t'><input type='text' class='forminput' readonly style='width:150px' name='EX' value='&lt;span style="color:red"&gt;'>&nbsp;Member Name&nbsp;<input type='text' readonly class='forminput' style='width:150px' name='EX' value='&lt;/span&gt;'>&nbsp;=&nbsp;<span style="color:red">Member Name</span></td>
        </tr>
    ~;

    for my $group (@{ $mem_groups }) {

        my ($st, $end);
        if ($iB::INFO->{AU_FORMAT} =~ /(^|\|)$group->{ID}\~(.+?),(.+?)($|\|)/) {
            $st  = $2;
            $end = $3;
        }

        $html .= qq~
            <tr>
            <td bgcolor='#FFFFFF' align='left' class='t'><b>$group->{'TITLE'}</b></td>
            <td bgcolor='#FFFFFF' class='t'><input type='text' class='forminput' style='width:150px' name='P_$group->{ID}' value='$st'>&nbsp;Member Name&nbsp;<input type='text' class='forminput' style='width:150px' name='S_$group->{ID}' value='$end'>&nbsp;=&nbsp;$st Member Name $end</td>
            </tr>
        ~;
    }

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Change the formatting' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => 'Active Users Hi-Lighting', PRINT => $html);
}

sub do_active {
    my ($obj, $db) = @_;

    # Collect the data
    my @formats = grep { /^P_(\d+)$/ } $iB::CGI->param();

    my $OLD = Boardinfo->new();
    $OLD->{AU_FORMAT} = "";
    for my $f (@formats) {
        $f =~ /^P_(\d+)$/;
        my $id = $1;
        my $start = $iB::CGI->param('P_'.$1);
        my $end   = $iB::CGI->param('S_'.$1);
        next unless $start and $end;
        # Make them safe:
        $start =~ s/!/&#033;/g;
        $start =~ s/\|/&#124;/g;
        $start =~ s/\~/&#126;/g;
        $start =~ s/,/&#044;/g;
        $end   =~ s/!/&#033;/g;
        $end   =~ s/\|/&#124;/g;
        $end   =~ s/\~/&#126;/g;
        $end   =~ s/,/&#044;/g;

        $OLD->{AU_FORMAT} .= qq($id~$start,$end|);
    }

    # Remove trailing pipe

    $OLD->{AU_FORMAT} =~ s/\|$//;

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=active",
                           TITLE => "The Active user formatting has been modified",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Skin/Lang Defaults Section ------------------------

sub defaults {
    my ($obj, $db) = @_;

    my @editable;
    my @skins = split( /\|\&\|/, $INFO->{'SKINS'} );

    for my $s (@skins) {
        @_ = split /\:/, $s;
        push @editable, { NAME => $_[2], VALUE => $_[1] };
    }

    my @sorted_lang_files;

    for my $l ( split( /\|\&\|/, $iB::INFO->{'LANGUAGES'} ) ) {
        my ($dir, $name) = split /:/, $l;
        push @sorted_lang_files, { NAME => $name, VALUE => $dir };
    }

    my $l_size = scalar @sorted_lang_files + 1;

    my $size = scalar @editable + 1;

    my $html  = $SKIN->title( TITLE => 'Skin/Language Defaults', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'dodefaults'
                                      } );

    #+-----------------------------------

    $html .= $SKIN->section_header( TITLE => "Please choose a default skin" );

    $html .= $SKIN->td_select( TEXT     => 'Installed Skins',
                               NAME     => 'DEFAULT_SKIN',
                               SIZE     => $size,
                               VALUES   => $INFO->{'DEFAULT_SKIN'},
                               DATA     => \@editable,
                             );

    $html .= $SKIN->section_header( TITLE => "Please choose a default language" );
    $html .= $SKIN->td_select( TEXT     => "Current Installed Languages",
                               NAME     => 'DEFAULT_LANGUAGE',
                               SIZE     => $l_size,
                               VALUES   => $INFO->{'DEFAULT_LANGUAGE'},
                               DATA     => \@sorted_lang_files
                             );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Set these defaults' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => 'Styles/Skin Defaults', PRINT => $html);
}

sub do_defaults {

    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();

    $OLD->{'DEFAULT_LANGUAGE'} = $iB::IN{'DEFAULT_LANGUAGE'};
    $OLD->{'DEFAULT_SKIN'}     = $iB::IN{'DEFAULT_SKIN'};

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=defaults",
                           TITLE => "Default skin/language information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Board Paths Section ------------------------

sub show_paths {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Edit the Board Paths', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',

                                        CODE  => 'doPaths'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Board URL's", TEXT => "Please DO NOT add a trailing slash");

    $html .= $SKIN->td_input ( TEXT => 'CGI URL (Board URL)',            NAME => 'cgi_url', VALUE=> "$INFO->{'BOARD_URL'}" ,   REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Non CGI URL (Root Images Path)', NAME => 'img_url', VALUE=> "$INFO->{'IMAGES_URL'}",   REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Website URL',                    NAME => 'web_url', VALUE=> "$INFO->{'HOME_URL'}"  ,   REQ => 1 );

    $html .= $SKIN->td_input ( TEXT => 'Uploads URL',                    NAME => 'upl_url', VALUE=> "$INFO->{'UPLOAD_URL'}"  ,   REQ => 1 );

    $html .= $SKIN->section_header( TITLE => "Directory Paths", TEXT => "Please enter the information carefully" );

    $html .= $SKIN->td_input ( TEXT => 'CGI Directory Path',             NAME => 'cgi_dir', VALUE=> "$INFO->{'IKON_DIR'}"    , REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Non CGI Directory Path',         NAME => 'img_dir', VALUE=> "$INFO->{'HTML_DIR'}"    , REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Uploads Directory',              NAME => 'ups_dir', VALUE=> "$INFO->{'PUBLIC_UPLOAD'}", REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Backups Directory',              NAME => 'bak_dir', VALUE=> "$INFO->{'BACKUP_DIR'}",   REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Database Directory Path',        NAME => 'db_dir',  VALUE=> "$INFO->{'DB_DIR'}",       REQ => 1 );

    $html .= $SKIN->td_input ( TEXT => 'Perl Script Extension',          NAME => 'perl_ex', VALUE=> "$INFO->{'CGI_EXT'}"  ,    REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Perl Path',                      NAME => 'perl_pa', VALUE=> "$INFO->{'PERL_PATH'}",    REQ => 1 );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Board Paths and Directories", PRINT => $html);
}

sub do_paths {
    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();

    my $NEW = {
                BOARD_URL    => ['cgi_url', 'CGI URL (Board URL)'           ],
                IMAGES_URL   => ['img_url', 'Non CGI URL (Root Images Path)'],
                HOME_URL     => ['web_url', 'Website URL'                   ],
                IKON_DIR     => ['cgi_dir', 'CGI Directory Path'            ],
                HTML_DIR     => ['img_dir', 'Non CGI Directory Path'        ],
                BACKUP_DIR   => ['bak_dir', 'Back-up Directory'             ],
                CGI_EXT      => ['perl_ex', 'Perl Script Extension'         ],
                PERL_PATH    => ['perl_pa', 'Perl Path'                     ],
                UPLOAD_URL   => ['upl_url', 'Upload URL'                    ],
                PUBLIC_UPLOAD => ['ups_dir', 'Upload Path'                   ],
                DB_DIR       => ['db_dir' , 'Database Directory'            ],
             };

    for my $i (keys %{$NEW}) {
        if ($iB::IN{ $NEW->{$i}[0] } eq '') {
            $ADMIN->Error( DB => $db, STD => $std, MSG => "You must enter a value for: $NEW->{$i}[1]");
        } else {
            $OLD->{ $i } = $iB::CGI->param( $NEW->{$i}[0] );
        }
    }

    # Remove Trailing slashes, because people cant read :D

    $OLD->{'BOARD_URL'}  =~ s!/+\Z!!;
    $OLD->{'IMAGES_URL'} =~ s!/+\Z!!;
    $OLD->{'HOME_URL'}   =~ s!/+\Z!!;

    # Add trailing slashes because people don't care :D

    $OLD->{'IKON_DIR'}      .= '/' unless $OLD->{'IKON_DIR'}     =~ m!/+\Z!;
    $OLD->{'HTML_DIR'}      .= '/' unless $OLD->{'HTML_DIR'}     =~ m!/+\Z!;
    $OLD->{'TEMPLATE_DIR'}  .= '/' unless $OLD->{'TEMPLATE_DIR'} =~ m!/+\Z!;
    $OLD->{'BACKUP_DIR'}    .= '/' unless $OLD->{'BACKUP_DIR'}   =~ m!/+\Z!;
    $OLD->{'PUBLIC_UPLOAD'} .= '/' unless $OLD->{'PUBLIC_UPLOAD'}   =~ m!/+\Z!;

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=showPaths",
                           TITLE => "Board Path information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Board OPTIONS Section ------------------------

sub show_ops {
    my ($obj, $db) = @_;

    my ($joined, $short, $long) = split /\|&\|/, $INFO->{'CLOCK_STYLE'};

    my @time_zone;
    for (-24 .. 24) {
        push @time_zone, { NAME => $_, VALUE => $_ };
    }

    $iB::INFO->{'USE_SSI'} ||= 0;
    $iB::INFO->{'HISTORIC_LIMIT'} ||= 60;
    my $time_now = $std->get_date( TIME => time, METHOD => 'LONG' );

    my $html  = $SKIN->title( TITLE => 'Edit the Board Settings', TEXT => 'Please double check all the data before submitting the changes.' );

       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'doOps'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Board Details");

    $html .= $SKIN->td_select( TEXT     => "Enable SSI file creation?<br>&nbsp;&nbsp;&nbsp;&nbsp;This will update txt files for SSI/PHP inclusion",
                               NAME     => 'USE_SSI',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'USE_SSI'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_input ( TEXT => 'Board name',        NAME => 'BOARDNAME',  VALUE=> "$INFO->{'BOARDNAME'}" ,   REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Board description', NAME => 'BOARD_DESC', VALUE=> "$INFO->{'BOARD_DESC'}");
    $html .= $SKIN->td_input ( TEXT => 'Website name',      NAME => 'HOME_NAME',  VALUE=> "$INFO->{'HOME_NAME'}" ,   REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Your copyright<br>&nbsp;&nbsp;&nbsp;&nbsp;&copy; symbol added automatically', NAME => 'COPYRIGHT_INFO',  VALUE=> "$INFO->{'COPYRIGHT_INFO'}");

    $html .= $SKIN->section_header( TITLE => "Cookie Settings");

    $html .= $SKIN->td_input ( TEXT => 'Cookie ID<br>&nbsp;&nbsp;&nbsp;&nbsp;(To make them unique to this iB)',   NAME => 'COOKIE_ID',   VALUE=> "$INFO->{'COOKIE_ID'}"  , REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Cookie Path<br>&nbsp;&nbsp;&nbsp;&nbsp;(Path from domain to the board - optional)',  NAME => 'COOKIE_PATH', VALUE=> "$INFO->{'COOKIE_PATH'}" );
    $html .= $SKIN->td_input ( TEXT => 'Cookie Domain<br>&nbsp;&nbsp;&nbsp;&nbsp;(Makes your cookies sitewide - optional)<br>&nbsp;&nbsp;&nbsp;&nbsp;IE: If the URL was "www.ikonboard.com" the cookie domain would be ".ikonboard.com"',  NAME => 'COOKIE_DOMAIN', VALUE=> "$INFO->{'COOKIE_DOMAIN'}" );

    $html .= $SKIN->section_header( TITLE => "Time and Date Settings");

    $html .= $SKIN->td_select( TEXT     => "Board time adjust<br>&nbsp;&nbsp;&nbsp;&nbsp;Current time is: $time_now",
                               NAME     => 'TIME_ZONE',
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'TIME_ZONE'} || 0,
                               DATA     => \@time_zone,
                             );

    $html .= $SKIN->td_select( TEXT     => "Clock type",
                               NAME     => 'CLOCK_TYPE',
                               SIZE     => 2,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'CLOCK_TYPE'},
                               DATA     => [ { NAME => '24 Hour', VALUE => '24h' },
                                             { NAME => '12 Hour', VALUE => '12h' }, ]
                             );

    $html .= $SKIN->td_input ( TEXT => 'Time Zone Name', NAME => 'BASE_TIME', VALUE=> "$INFO->{'BASE_TIME'}", REQ => 1 );

    $html .= $SKIN->section_header( TITLE => "Time and date style", TEXT => "You can use any separating characters. Example values for clock display: YEAR = 2000, MONTH_NUMBER = 5 (For May), MONTH_NAME = May, DATE_NUMBER = 15, DAY_NAME = Monday, HOUR = 3 (For 3 o'clock), MIN = 23 (For 23 mins), SUFFIX = AM (AM/PM for 12 hour time)");

    $html .= $SKIN->td_input ( TEXT => 'Clock Style: <b>Joined Date</b>', NAME => 'CLOCK_JOINED', VALUE=> $joined,  REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Clock Style: <b>Short Date</b>',  NAME => 'CLOCK_SHORT',  VALUE=> $short ,  REQ => 1 );

    $html .= $SKIN->td_input ( TEXT => 'Clock Style: <b>Long Date</b>',   NAME => 'CLOCK_LONG' ,  VALUE=> $long  ,  REQ => 1 );
    $html .= $SKIN->section_header( TITLE => "Set a load limit (*NIX ONLY)", TEXT => "You may enter a limit for the server load before a user gets a \"server busy\" message. 1.0 is 100% for single processor machines, 2.0 is 100% for dual processor machines. Leave blank if you do not want to set a limit. If a limit is set, the current load will be displayed with the admin stats");

    $html .= $SKIN->td_input ( TEXT => 'Server Load Limit',   NAME => 'LOAD_LIMIT' ,  VALUE=> $iB::INFO->{'LOAD_LIMIT'} );

    $html .= $SKIN->section_header( TITLE => "Basic Security Settings");

    $html .= $SKIN->td_input ( TEXT => 'Flood Control Wait (in seconds)<br>Leave blank, or enter 0 to switch it off',   NAME => 'FLOOD_CONTROL'     ,VALUE=> $INFO->{'FLOOD_CONTROL'}     ,REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Length of user sessions after log in<br>(in seconds: 3600 seconds = 1 hour)',   NAME => 'SESSION_EXPIRATION',VALUE=> $INFO->{'SESSION_EXPIRATION'},REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Length of admin sessions after log in<br>(in seconds: 3600 seconds = 1 hour | 86400 seconds = 24 hours)<br>For convenience, set to 24 hours, for maximum security, set to 1 hour.',   NAME => 'ADMIN_SESSION_LENGTH',VALUE=> $INFO->{'ADMIN_SESSION_LENGTH'},REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'How many days worth of historic records for the post markers do you want to keep in the database before it is pruned automaticaly?',   NAME => 'HISTORIC_LIMIT' ,  VALUE=> $iB::INFO->{'HISTORIC_LIMIT'} ,REQ => 1);
    $html .= $SKIN->td_select( TEXT     => "Validate the user's browser as part of the authorize procedure?",
                               NAME     => 'CHECK_USER_AGENT',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'CHECK_USER_AGENT'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow dynamic pages in IMG tags?<br>&nbsp;&nbsp;&nbsp;&nbsp;Enabling this poses a security risk.",
                               NAME     => 'ALLOW_DYNAMIC_IMG',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'ALLOW_DYNAMIC_IMG'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->section_header( TITLE => "Other Settings");

    $html .= $SKIN->td_input( TEXT   => "Your default charset<br>&nbsp;&nbsp;&nbsp;&nbsp;Default is ISO-8859-1",
                              NAME   => 'CHARSET',
                              REQ   => 0,
                               VALUE  => $iB::INFO->{'CHARSET'},
                           );

    $html .= $SKIN->td_select( TEXT     => "Show board calendar? (Must have \"Show online users\" on for this)",
                               NAME     => 'CALENDAR',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'CALENDAR'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show board statistics?<br>&nbsp;&nbsp;&nbsp;&nbsp;(Total users, posts, etc.)",
                               NAME     => 'SHOW_STATS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'SHOW_STATS'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show users online in board index?",
                               NAME     => 'SHOW_ONLINE',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'SHOW_ONLINE'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show link to who's online page?<br>&nbsp;&nbsp;&nbsp;&nbsp;(If you choose to show online users in the board index)",
                               NAME     => 'ALLOW_ONLINE_LIST',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'ALLOW_ONLINE_LIST'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );
    #added by Method
    $html .= $SKIN->td_select( TEXT     => "Show link to team list page?<br>&nbsp;&nbsp;&nbsp;&nbsp;(If you choose to show online users in the board index)",
                                   NAME     => 'ALLOW_TEAM_LIST',
                                   SIZE     => 1,
                                   REQ      => 1,
                                   VALUES   => $iB::INFO->{'ALLOW_TEAM_LIST'},
                                   DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                                 { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Enable \"invite a friend\" feature?",
                               NAME     => 'INVITE_FRIEND',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'INVITE_FRIEND'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Enable board legend?",
                               NAME     => 'BOARD_LEGEND',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'BOARD_LEGEND'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Force everyone to log in before viewing the board?",
                               NAME     => 'FORCE_LOGIN',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'FORCE_LOGIN'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Enable the skins feature?",
                               NAME     => 'ALLOW_SKINS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'ALLOW_SKINS'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Enable iB Template Tags?<br>&nbsp;&nbsp;&nbsp;&nbsp;Allows the use of SSI in the global templates",
                               NAME     => 'TEMPLATE_TAGS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'TEMPLATE_TAGS'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Compress HTML? (removes newlines and multiple spaces)",
                               NAME     => 'COMPRESS_HTML',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'COMPRESS_HTML'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show \"quick reply\" box under topic?",
                              NAME     => 'QUICK_REPLY',

                              SIZE     => 1,
                              REQ      => 1,
                              VALUES   => $iB::INFO->{'QUICK_REPLY'},
                              DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                            { NAME => 'No',  VALUE => '0' }, ]
                            );

    $html .= $SKIN->td_select( TEXT     => "Show a separate column for the forum's list of moderators?",
                             NAME     => 'MOD_DROP_DOWN',
                             SIZE     => 1,
                             REQ     => 1,
                             VALUES => $iB::INFO->{'MOD_DROP_DOWN'},
                             DATA     => [ { NAME => 'Yes - In a drop down menu', VALUE => '1' },
                                           { NAME => 'Yes - As a list of names', VALUE => '2' },
                                           { NAME => 'No - Show with the forum listing', VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow administrators to see anonymous users in who's online?",
                               NAME     => 'ADMINS_SEE_ANON',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'ADMINS_SEE_ANON'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No' , VALUE => '0' }, ]
                             );
                             
    $html .= $SKIN->td_select( TEXT     => "Update Center on index (useful if your host blocks remote connections)?",
    						   NAME		=> 'UPDATE_CENTER',
    						   SIZE		=> 1,
    						   REQ		=> 1,
    						   VALUES	=> $iB::INFO->{'UPDATE_CENTER'},
    						   DATA		=> [ { NAME => 'On', VALUE => '1' },
    						   				 { NAME => 'Off', VALUE => '0' }, ]
    						 );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Board Options", PRINT => $html);

}

sub do_ops {
    my ($obj, $db) = @_;

    my $NEW = {
                BOARDNAME          => ['Board Name'           , '1'  ],
                BOARD_DESC         => ['Board Description'    , '1'  ],
                HOME_NAME          => ['Website Name'         , '1'  ],
                COPYRIGHT_INFO     => ['Copyright Information', '0'  ],
                COOKIE_ID          => ['Cookie ID'            , '0'  ],
                COOKIE_PATH        => ['Cookie Path'          , '0'  ],
                TIME_ZONE          => ['Time Zone'            , '1'  ],
                CLOCK_TYPE         => ['Clock Type'           , '1'  ],
                BASE_TIME          => ['Time Zone Name'       , '1'  ],
                FLOOD_CONTROL      => ['Flood Control'        , '0'  ],
                SESSION_EXPIRATION => ['Session Expiration'   , '1'  ],
                ADMIN_SESSION_LENGTH => ['Admin Session Expiration'   , '1'  ],
                CHECK_USER_AGENT   => ['Validate Browser'     , '1'  ],
                SHOW_STATS         => ['Show Statistics'      , '1'  ],
                FORCE_LOGIN        => ['Force Log in'         , '1'  ],
                ALLOW_SKINS        => ['Allow Skins'          , '1'  ],
                INVITE_FRIEND      => ['Invite Friend Feature', '1'  ],
                BOARD_LEGEND       => ['Board Legend Feature' , '1'  ],
                ALLOW_ONLINE_LIST  => [''                     , '0'  ],
                ALLOW_TEAM_LIST    => [''                     , '0'  ],
                SHOW_ONLINE        => [''                     , '0'  ],
                ALLOW_DYNAMIC_IMG  => [''                     , '0'  ],
                USE_SSI            => [''                     , '0'  ],
                COMPRESS_HTML      => [''                     , '0'  ],
                QUICK_REPLY        => [''                     , '0'  ],
                MOD_DROP_DOWN      => [''                     , '0'  ],
                LOAD_LIMIT         => [''                     , '0'  ],
                COOKIE_DOMAIN      => [''                     , '0'  ],
                TEMPLATE_TAGS      => [''                     , '0'  ],
                COMPRESS_HTML      => [''                     , '0'  ],
                QUICK_REPLY        => [''                     , '0'  ],
                CHARSET            => ['Default charset'      , '0'  ],
                CALENDAR           => ['Board Calendar'       , '1'  ],
                HISTORIC_LIMIT     => ['Historic Limit'       , '1'  ],
                ADMINS_SEE_ANON    => [''                     , '0'  ],
                UPDATE_CENTER	   => [''					  , '0'  ],
             };

    my $OLD = Boardinfo->new();

    $OLD->{'CLOCK_STYLE'} = $iB::IN{'CLOCK_JOINED'}."|&|".$iB::IN{'CLOCK_SHORT'}."|&|".$iB::IN{'CLOCK_LONG'};

    for my $i (keys %{$NEW}) {
        if ($iB::IN{ $i } eq '' and $NEW->{$i}[1]) {
            $ADMIN->Error( DB => $db, STD => $std, MSG => "You must enter a value for: $NEW->{$i}[0]");
        } else {
            $OLD->{ $i } = $iB::IN{ $i };
        }
    }

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=showOps",
                           TITLE => "Board option information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Forum Section ------------------------

sub forum {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Forum Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'doforum'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Forum Options");

    $html .= $SKIN->td_input ( TEXT => 'No. posts before it\'s a hot topic',     NAME => 'HOT_TOPIC',          VALUE=> "$INFO->{'HOT_TOPIC'}"         ,   REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Topics per page',                        NAME => 'DISPLAY_MAX_TOPICS', VALUE=> "$INFO->{'DISPLAY_MAX_TOPICS'}",   REQ => 1 );

    $html .= $SKIN->td_select( TEXT     => "Default cut off date for topic display",
                               NAME     => 'PRUNE_DAYS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'PRUNE_DAYS'},
                               DATA     => [ { NAME => 'Today'       ,  VALUE => '1'   },
                                             { NAME => 'Last 5 Days' ,  VALUE => '5'   },
                                             { NAME => 'Last 7 Days' ,  VALUE => '7'   },
                                             { NAME => 'Last 10 Days',  VALUE => '10'  },
                                             { NAME => 'Last 15 Days',  VALUE => '15'  },
                                             { NAME => 'Last 20 Days',  VALUE => '20'  },
                                             { NAME => 'Last 25 Days',  VALUE => '25'  },
                                             { NAME => 'Last 30 Days',  VALUE => '30'  },
                                             { NAME => 'Last 60 Days',  VALUE => '60'  },
                                             { NAME => 'Last 90 Days',  VALUE => '90'  },
                                             { NAME => 'Show all'    ,  VALUE => '100' },
                                           ]
                             );
                             
    $html .= $SKIN->td_select( TEXT     => "Show the \"who's active in forum\" table at the top or bottom?",
                               NAME     => 'FORUM_ACT_POS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'FORUM_ACT_POS'},
                               DATA     => [ { NAME => 'Off'   , VALUE => '0' },
                                             { NAME => 'Top'   , VALUE => '1' },
                                             { NAME => 'Bottom', VALUE => '2' }, ]
                             );                         

    $html .= $SKIN->section_header( TITLE => "Default Forum Order", TEXT => "Your members can override this setting. You can also override these settings on a per forum basis" );

    $html .= $SKIN->td_select( TEXT     => "Default sort key",
                               NAME     => 'SORT_KEY',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'SORY_KEY'},
                               DATA     => [ { VALUE => 'TOPIC_LAST_DATE' ,  NAME => 'Date of the last post'     },
                                             { VALUE => 'TOPIC TITLE'     ,  NAME => 'Topic Title'               },
                                             { VALUE => 'TOPIC_STARTER_N' ,  NAME => "Topic Starter's Name"      },
                                             { VALUE => 'TOPIC_POSTS'     ,  NAME => 'Topic Posts'               },
                                             { VALUE => 'TOPIC_VIEWS'     ,  NAME => 'Topic Posts'               },
                                             { VALUE => 'TOPIC_START_DATE',  NAME => 'Date the topic was started'},
                                             { VALUE => 'TOPIC_LASTP_N'   ,  NAME => 'Name of the last poster'   },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Default sort order",
                               NAME     => 'FORUM_SORT_ORDER',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'FORUM_SORT_ORDER'},
                               DATA     => [ { VALUE => 'Z-A' ,  NAME => 'Descending (Z - A, 10 - 0)' },
                                             { VALUE => 'A-Z' ,  NAME => 'Ascending  (A - Z, 0 - 10)' },
                                           ]
                             );

    $html .= $SKIN->section_header( TITLE => "Forum Thread Prefixes");

    $html .= $SKIN->td_input ( TEXT => 'Prefix for pinned topics',NAME => 'PRE_PINNED',VALUE=> "$INFO->{'PRE_PINNED'}", NO_PARSE => 1);
    $html .= $SKIN->td_input ( TEXT => 'Prefix for moved topics', NAME => 'PRE_MOVED', VALUE=> "$INFO->{'PRE_MOVED'}", NO_PARSE => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Prefix for polls',        NAME => 'PRE_POLLS', VALUE=> "$INFO->{'PRE_POLLS'}", NO_PARSE => 1 );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Default Forum Options", PRINT => $html);
}

sub memberlist {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Member List Display Customization', TEXT => 'Turn on and off, the individual columns of the Memberlist' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'domemberlist'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Select on and off for the columns of the memberlist", TEXT => "When you select \"yes,\" the column is shown. When set to \"no,\" the column is not shown.");

#+----------------------------------------------------------------------------------------------------------

    $html .= $SKIN->td_select( TEXT     => "Show email column?",
                               NAME     => 'MEMBERLIST_EMAIL',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'MEMBERLIST_EMAIL'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show pips column?",
                               NAME     => 'MEMBERLIST_PIPS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'MEMBERLIST_PIPS'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show posts column?",
                               NAME     => 'MEMBERLIST_POSTS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'MEMBERLIST_POSTS'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show ICQ column?",
                           NAME     => 'MEMBERLIST_ICQ',
                           SIZE     => 1,
                           REQ      => 1,
                           VALUES   => $iB::INFO->{'MEMBERLIST_ICQ'},
                           DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                         { NAME => 'No',  VALUE => '0' }, ]
                          );

    $html .= $SKIN->td_select( TEXT     => "Show MSN column?",
                               NAME     => 'MEMBERLIST_MSN',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'MEMBERLIST_MSN'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show Yahoo! column?",
                               NAME     => 'MEMBERLIST_YAHOO',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'MEMBERLIST_YAHOO'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show member joined date column?",
                               NAME     => 'MEMBERLIST_JOINED',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'MEMBERLIST_JOINED'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show member group column?",
                               NAME     => 'MEMBERLIST_GROUP',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'MEMBERLIST_GROUP'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show AIM column?",
                               NAME     => 'MEMBERLIST_AIM',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'MEMBERLIST_AIM'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE', 'CAN_REMOVE'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );

    my @groups;

    for (@{$mem_groups}) {
        push @groups, { NAME => $_->{'TITLE'}, VALUE => $_->{'ID'} };
    }

    my $size = scalar @groups;

    my @selected = split/\,/, $iB::INFO->{'MEMBERLIST_HIDE_GROUPS'};

    $html .= $SKIN->td_select( TEXT      => "Choose which member groups to hide from the search feature",
                               NAME      => 'MEMBERLIST_HIDE_GROUPS',
                               SIZE      => $size,
                               REQ       => 1,
                               VALUES    => \@selected,
                               DATA      => \@groups,
                               MULTIPLE  => 1
                             );

    my $mem_groups2 = $db->query( TABLE      => 'mem_groups',
                                  COLUMNS    => ['ID', 'TITLE', 'CAN_REMOVE'],
                                  SORT_KEY   => 'TITLE',
                                  SORT_BY    => 'A-Z',
                                );

    my @groups2;

    push @groups2,     { NAME => '#ALL MEMBER GROUPS#', VALUE => '*' };

    for (@{$mem_groups2}) {
        push @groups2, { NAME => $_->{'TITLE'}, VALUE => $_->{'ID'}  };
    }

    my $size2 = scalar @groups2;

    my @selected2 = split/\,/, $iB::INFO->{'MEMBERLIST_ALLOW_VIEW'};

    $html .= $SKIN->td_select( TEXT      => "Choose which member groups are NOT allowed to view the memberlist",
                               NAME      => 'MEMBERLIST_ALLOW_VIEW',
                               SIZE      => $size2,
                               REQ       => 1,
                               VALUES    => \@selected2,
                               DATA      => \@groups2,
                               MULTIPLE  => 1
                             );


    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();

    #+-----------------------------------

    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => 'Memberlist Options', PRINT => $html);
}

sub domemberlist {
    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();
       $OLD->{'MEMBERLIST_JOINED'} = $iB::IN{'MEMBERLIST_JOINED'} || 0;
       $OLD->{'MEMBERLIST_GROUP'}  = $iB::IN{'MEMBERLIST_GROUP'}  || 0;
       $OLD->{'MEMBERLIST_AIM'}    = $iB::IN{'MEMBERLIST_AIM'}    || 0;
       $OLD->{'MEMBERLIST_ICQ'}    = $iB::IN{'MEMBERLIST_ICQ'}    || 0;
       $OLD->{'MEMBERLIST_MSN'}    = $iB::IN{'MEMBERLIST_MSN'}    || 0;
       $OLD->{'MEMBERLIST_YAHOO'}  = $iB::IN{'MEMBERLIST_YAHOO'}  || 0;
       $OLD->{'MEMBERLIST_EMAIL'}  = $iB::IN{'MEMBERLIST_EMAIL'}  || 0;
       $OLD->{'MEMBERLIST_PIPS'}   = $iB::IN{'MEMBERLIST_PIPS'}   || 0;
       $OLD->{'MEMBERLIST_POSTS'}  = $iB::IN{'MEMBERLIST_POSTS'}  || 0;
       $OLD->{'MEMBERLIST_HIDE_GROUPS'} = join ',', $iB::CGI->param('MEMBERLIST_HIDE_GROUPS');

    if (grep/\*/,$iB::CGI->param('MEMBERLIST_ALLOW_VIEW')) {
        $OLD->{'MEMBERLIST_ALLOW_VIEW'} = '*';
    } else {
        $OLD->{'MEMBERLIST_ALLOW_VIEW'} = join ',', $iB::CGI->param('MEMBERLIST_ALLOW_VIEW');
    }

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=memberlist",
                           TITLE => "Memberlist option changes Applied",
                           TEXT  => "The changes were successful"
                          );
}

sub do_forum {
    my ($obj, $db) = @_;

    my $NEW = {
                HOT_TOPIC          => ['No. Posts for Hot Topic', '1'  ],
                DISPLAY_MAX_TOPICS => ['Topics per page'        , '1'  ],
                SORT_KEY           => ['Sort Key'               , '1'  ],
                FORUM_SORT_ORDER   => ['Sort Order'             , '1'  ],
                PRUNE_DAYS         => ['Cut off topic days'     , '1'  ],
                FORUM_ACT_POS      => [''                       , '0'  ],
                PRE_PINNED         => [ ],
                PRE_MOVED          => [ ],
                PRE_POLLS          => [ ],
             };

    my $OLD = Boardinfo->new();

    for my $i (keys %{$NEW}) {
        if ($iB::IN{ $i } eq '' and $NEW->{$i}[1]) {
            $ADMIN->Error( DB => $db, STD => $std, MSG => "You must enter a value for: $NEW->{$i}[0]");
        } else {
            $OLD->{ $i } = $iB::IN{ $i };
            # Allow basic HTML tags
            $OLD->{ $i } =~ s/&lt;/</g;
            $OLD->{ $i } =~ s/&gt;/>/g;
            $OLD->{ $i } =~ s/&amp;/&/g;
        }
    }

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=forum",
                           TITLE => "Forum option information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Email Section -----------------------

sub email {
    my ($obj, $db) = @_;
    

    my $html  = $SKIN->title( TITLE => 'Email Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'doemail'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Email Addresses");

    $html .= $SKIN->td_input ( TEXT => 'Outgoing email address', NAME => 'ADMIN_EMAIL_OUT', VALUE=> "$INFO->{'ADMIN_EMAIL_OUT'}",   REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Incoming email address', NAME => 'ADMIN_EMAIL_IN',  VALUE=> "$INFO->{'ADMIN_EMAIL_IN'}",    REQ => 1 );

    $html .= $SKIN->section_header( TITLE => "Mail Options");

    $html .= $SKIN->td_select( TEXT     => "Send mail using:",
                               NAME     => 'EMAIL_TYPE',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'EMAIL_TYPE'},
                               DATA     => [ { NAME => 'SMTP'    ,  VALUE => 'smtp'      },
                                             { NAME => 'SendMail',  VALUE => 'send_mail' },
                                           ]
                             );    


    $html .= $SKIN->td_select( TEXT     => "Email content:",
                               NAME     => 'EMAIL_CONTENT',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'EMAIL_CONTENT'},
                               DATA     => [ { NAME => 'HTML',  VALUE => 'html' },
                                             { NAME => 'Text',  VALUE => 'text' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Use a form for when members email other members?<br>&nbsp;&nbsp;&nbsp;&nbsp;This keeps all email addresses private",
                               NAME     => 'USE_MAIL_FORM',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'USE_MAIL_FORM'},
                               DATA     => [ { NAME => 'Yes',  VALUE => 1 },
                                             { NAME => 'No' ,  VALUE => 0 },
                                           ]
                             );

    $html .= $SKIN->td_input ( TEXT => 'SMTP server (if using SMTP)',       NAME => 'SMTP_SERVER', VALUE=> "$INFO->{'SMTP_SERVER'}",REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Sendmail path (if using Sendmail)', NAME => 'SEND_MAIL',   VALUE=> "$INFO->{'SEND_MAIL'}",  REQ => 1 );

    $html .= $SKIN->section_header( TITLE => "Default Email Content");

    $html .= $SKIN->td_textarea( TEXT => "Email header", NAME => 'EMAIL_HEADER', VALUE => $INFO->{'EMAIL_HEADER'} );
    $html .= $SKIN->td_textarea( TEXT => "Email footer", NAME => 'EMAIL_FOOTER', VALUE => $INFO->{'EMAIL_FOOTER'} );
    $html .= $SKIN->td_textarea( TEXT => "Signature",    NAME => 'SIGNATURE',    VALUE => $INFO->{'SIGNATURE'} );

    $html .= $SKIN->section_header( TITLE => "Email Logging");

    $html .= $SKIN->td_select( TEXT     => "Log all emails sent from this board?",
                               NAME     => 'LOG_EMAILS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'LOG_EMAILS'},
                               DATA     => [ { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'No'  ,  VALUE => '0' },
                                             ]
                             );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Email Options", PRINT => $html);
}

sub do_email {
    my ($obj, $db) = @_;
    
    my $NEW = {
                ADMIN_EMAIL_IN  => ['Incoming email address'        , '1'  ],
                ADMIN_EMAIL_OUT => ['Outgoing email address'        , '1'  ],
                SMTP_SERVER     => [''                              , '0'  ],
                SEND_MAIL       => [''                              , '0'  ],
                EMAIL_TYPE      => ['Email sending program'         , '1'  ],
                EMAIL_CONTENT   => [''                              , '0'  ],
                EMAIL_HEADER    => [''                              , '0'  ],
                EMAIL_FOOTER    => [''                              , '0'  ],
                SIGNATURE       => [''                              , '0'  ],
                LOG_EMAILS      => ['Log emails sent from the board', '1'  ],
                USE_MAIL_FORM   => ['Use mail form'                 , '1'  ],
             };

    my $OLD = Boardinfo->new();

    for my $i (keys %{$NEW}) {
        if ($iB::IN{ $i } eq '' and $NEW->{$i}[1]) {
            $ADMIN->Error( DB => $db, STD => $std, MSG => "You must enter a value for: $NEW->{$i}[0]");
        } else {
            $OLD->{ $i } = $iB::IN{ $i };
        }
    }

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=email",
                           TITLE => "Email option information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Topic Settings ------------------------

sub topic {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Topic Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'dotopic'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Topic Options");

    $html .= $SKIN->td_input ( TEXT => 'Posts per page', NAME => 'DISPLAY_MAX_POSTS', VALUE=> "$INFO->{'DISPLAY_MAX_POSTS'}",   REQ => 1 );

    $html .= $SKIN->td_select( TEXT     => "Allow votes to bump a poll?",
                               NAME     => 'ALLOW_POLL_BUMP',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ALLOW_POLL_BUMP'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1'   },
                                             { NAME => 'No' ,  VALUE => '0'   },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow the poll creator to vote?",
                               NAME     => 'ALLOW_CREATOR_VOTE',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ALLOW_CREATOR_VOTE'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1'   },
                                             { NAME => 'No' ,  VALUE => '0'   },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Post display order",
                               NAME     => 'TOPIC_SORT_ORDER',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'TOPIC_SORT_ORDER'},
                               DATA     => [ { VALUE => 'A-Z' ,  NAME => 'Older Posts First' },
                                             { VALUE => 'Z-A' ,  NAME => 'Newer Posts First' },
                                             ]
                             );

    $INFO->{'IMG_ATT_SHOW'} ||= 0;

    $html .= $SKIN->td_select( TEXT     => "Show uploaded images in posts (rather than a link to the attachment)?",
                               NAME     => 'IMG_ATT_SHOW',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'IMG_ATT_SHOW'},
                               DATA     => [ { NAME => 'Yes - include with post'            ,  VALUE => '1'   },
                                             { NAME => 'No - handle as a normal attachment' ,  VALUE => '0'   },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show default post icon in topic view?",
                               NAME     => 'ICON_TOP_VIEW',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ICON_TOP_VIEW'},
                               DATA     => [ { NAME => 'Yes - show the default icon' ,  VALUE => '1'   },
                                             { NAME => 'No - hide them' ,  VALUE => '0'   },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show default post icon in forum view?",
                               NAME     => 'ICON_FOR_VIEW',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ICON_FOR_VIEW'},
                               DATA     => [ { NAME => 'Yes - show the default icon' ,  VALUE => '1'   },
                                             { NAME => 'No - hide them' ,  VALUE => '0'   },
                                           ]
                             );

  
    $html .= $SKIN->td_select( TEXT     => "Show the \"who's active in topic\" table at the top or bottom?",
                               NAME     => 'TOPIC_ACT_POS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'TOPIC_ACT_POS'},
                               DATA     => [ { NAME => 'Off'   , VALUE => '0' },
                                             { NAME => 'Top'   , VALUE => '1' },
                                             { NAME => 'Bottom', VALUE => '2' }, ]
                             );
    

    $html .= $SKIN->td_select( TEXT     => "Show member's rating with his or her posts?",
                               NAME     => 'TOPIC_SHOW_RATE',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'TOPIC_SHOW_RATE'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No' , VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Topic Options", PRINT => $html);
}

sub do_topic {
    my ($obj, $db) = @_;
    my $NEW = {
                DISPLAY_MAX_POSTS  => ['No. posts per page'         , '1'  ],
                ALLOW_POLL_BUMP    => ['Allow polls to bump'        , '1'  ],
                ALLOW_CREATOR_VOTE => ['Allow poll creator to vote' , '1'  ],
                TOPIC_SORT_ORDER   => ['Sort order'                 , '1'  ],
                IMG_ATT_SHOW       => [''                           , '0'  ],
                ICON_TOP_VIEW      => [''                           , '0'  ],
                ICON_FOR_VIEW      => [''                           , '0'  ],
                TOPIC_ACT_POS      => [''                           , '0'  ],
                TOPIC_SHOW_RATE    => [''                           , '0'  ],
             };

    my $OLD = Boardinfo->new();

    for my $i (keys %{$NEW}) {
        if ($iB::IN{ $i } eq '' and $NEW->{$i}[1]) {
            $ADMIN->Error( DB => $db, STD => $std, MSG => "You must enter a value for: $NEW->{$i}[0]");
        } else {
            $OLD->{ $i } = $iB::IN{ $i };
        }
    }

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=topic",
                           TITLE => "Topic option information changes applied",
                           TEXT  => "The changes were successful",
                          );
}

#+------------------------ Search Options ------------------------

sub search {
    my ($obj, $db) = @_;

    my @words = split (/\|/, $INFO->{'SKIP_WORDS'});

    $INFO->{'SKIP_WORDS'} = join "\n", @words;

    my $html  = $SKIN->title( TITLE => 'Search Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'dosearch'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Search Options", TEXT => "TIP: Set the maximum character limit to around 250, and add common words<br>&nbsp;&nbsp;&nbsp;&nbsp;in the 'Skip these words box' for an efficient search set-up");

    $html .= $SKIN->td_select( TEXT     => "Allow the use of search?:",

                               NAME     => 'ALLOW_SEARCH',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ALLOW_SEARCH'},

                               DATA     => [ { NAME => 'Yes',  VALUE => '1'      },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_input ( TEXT => 'No. of characters to store<br>&nbsp;&nbsp;&nbsp;&nbsp;(Leave blank to store complete post)', NAME => 'MAX_CHARS', VALUE=> "$INFO->{'MAX_CHARS'}" );

    $html .= $SKIN->td_textarea( TEXT => "Skip these words:<br>&nbsp;&nbsp;&nbsp;&nbsp;(Case Insensitive - One per line)",  NAME => 'SKIP_WORDS', VALUE => $INFO->{'SKIP_WORDS'} );

    $html .= $SKIN->td_input ( TEXT => "When the user searches for posts by a user in topics/profiles, how many days of posts should be shown?<br>&nbsp;&nbsp;&nbsp;&nbsp;(Enter 0 to show all posts)", NAME => 'USER_POST_SEARCH_SPAN', VALUE=> "$INFO->{'USER_POST_SEARCH_SPAN'}" );

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Search Options", PRINT => $html);
}

sub do_search {
    my ($obj, $search) = @_;

    my $OLD = Boardinfo->new();

    $OLD->{'ALLOW_SEARCH'} = $iB::IN{'ALLOW_SEARCH'} || 0;
    $OLD->{'MAX_CHARS'}    = $iB::IN{'MAX_CHARS'}    || 'all';

    $iB::IN{'SKIP_WORDS'} =~ s!\r!!;
    $iB::IN{'SKIP_WORDS'} =~ s!\n\n!!;
    $iB::IN{'SKIP_WORDS'} =~ s!<br>!|!ig;

    $OLD->{'SKIP_WORDS'}  = $iB::IN{'SKIP_WORDS'};

    # added by kevaholic00
    $OLD->{'USER_POST_SEARCH_SPAN'} = $iB::IN{'USER_POST_SEARCH_SPAN'} || 0;
    # end addition

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=search",
                           TITLE => "Search option information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Register Options ------------------------

sub register {
    my ($obj, $db) = @_;

    my $rules = $db->select(  TABLE  => 'forum_rules',
                              KEY    => '00',
                           );

    $rules->{'RULES_TEXT'} =~ s!<br>!\n!g;

    my $terms = $db->select(  TABLE  => 'templates',
                              KEY    => 'register',
                           );

    $terms->{'TEMPLATE'} =~ s!<br>!\n!g;

    my @words = split (/\|/, $INFO->{'SAVED_NAMES'});
    $INFO->{'SAVED_NAMES'} = join "\n", @words;

    my $html  = $SKIN->title( TITLE => 'Register Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'doregister'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Register Permissions" );

    $html .= $SKIN->td_select( TEXT     => "Allow new users to register?",
                               NAME     => 'ALLOW_REGISTER',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ALLOW_REGISTER'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Enable HRI (Human Readable Image) Secure Registration?",
                              NAME     => 'HRI',
                              SIZE     => 1,
                              REQ      => 1,
                              VALUES   => $iB::INFO->{'HRI'},
                              DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                            { NAME => 'No',  VALUE => '0' }, ]
                            );

    $html .= $SKIN->td_select( TEXT     => "Send email to validate registrations?",
                               NAME     => 'VALIDATE_REGISTER',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'VALIDATE_REGISTER'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Preview all registrations before enabling posting rights?",
                               NAME     => 'PREVIEW_REG',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'PREVIEW_REG'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Get notified via email for each new registration?",
                               NAME     => 'USER_NOTIFY',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'USER_NOTIFY'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "ALLOW multiple use of the same email address?",
                               NAME     => 'ALLOW_MULT_EMAIL',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ALLOW_MULT_EMAIL'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Send a welcome message to new members?",
                               NAME     => 'SEND_WELCOME',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'SEND_WELCOME'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    # added by kevaholic00
    my $WELC_MSG  = $db->select( TABLE => 'templates',
                                 KEY   => 'welcome',
                               );

    $html .= $SKIN->td_textarea( TEXT => "Welcome message (will be sent as a private message)<br><br>&nbsp;&nbsp;&nbsp;&nbsp;NAMEMEM = Member's name<br>&nbsp;&nbsp;&nbsp;&nbsp;ADDRCP = Address to their CP", NAME => 'WELC_MSG', VALUE => $WELC_MSG->{'TEMPLATE'} );

    $html .= $SKIN->td_input ( TEXT => 'Title of the welcome message PM',    NAME => 'WELC_NAME', VALUE=> $WELC_MSG->{'NAME'} );
    # end addition

    $html .= $SKIN->td_input ( TEXT => 'How long to allow validation via email?<br>&nbsp;&nbsp;&nbsp;&nbsp;(In days)', NAME => 'AUTHORISE_PRUNE', VALUE=> "$INFO->{'AUTHORISE_PRUNE'}" );

    $html .= $SKIN->section_header( TITLE => "Board Rules" );

    $html .= $SKIN->td_select( TEXT     => "Show board rules during registration?",
                               NAME     => 'SHOW_BOARD_RULES',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'SHOW_BOARD_RULES'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );
    $html .= $SKIN->td_input ( TEXT => 'Board Rules Title',    NAME => 'BOARD_RULES_NAME', VALUE=> $rules->{'RULES_TITLE'} );

    $html .= $SKIN->td_textarea( TEXT => "Edit board rules:",  NAME => 'BOARD_RULES_REG', VALUE => $rules->{'RULES_TEXT'} );
    $html .= $SKIN->td_textarea( TEXT => "Edit terms of service:",  NAME => 'TERMS_REG', VALUE => $terms->{'TEMPLATE'} );

    $html .= $SKIN->section_header( TITLE => "Things you want to require the user to fill to complete their registration" );

    $html .= $SKIN->td_select( TEXT     => "Show skin and language selection at registration?",
                               NAME     => 'SKIN_LANG_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'SKIN_LANG_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                           ]
                             );


    $html .= $SKIN->td_select( TEXT     => "Show gender selection at registration?",
                               NAME     => 'GENDER_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'GENDER_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' }, 
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show real name entry at registration?",
                               NAME     => 'MEMBER_NAME_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'MEMBER_NAME_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show location entry at Registration?",
                               NAME     => 'LOCAL_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'LOCAL_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show AIM name entry at registration?",
                               NAME     => 'AIM_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'AIM_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show ICQ name entry at registration?",
                               NAME     => 'ICQ_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ICQ_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show Yahoo! name entry at registration?",
                               NAME     => 'YAHO_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'YAHO_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show MSN name entry at registration?",
                               NAME     => 'MSN_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'MSN_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show web site entry at registration?",
                               NAME     => 'WEB_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'WEB_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show hide emails selection at registration?",
                               NAME     => 'MAIL_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'MAIL_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show signature entry at registration?",
                               NAME     => 'SIGN_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'SIGN_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show interests entry at Registration?",
                               NAME     => 'INTER_R',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'INTER_R'},
                               DATA     => [ { NAME => 'No',  VALUE => '0' },
                                             { NAME => 'Yes' ,  VALUE => '1' },
                                             { NAME => 'Required Field' ,  VALUE => '2' },
                                           ]
                             );

    $html .= $SKIN->section_header( TITLE => "Reserved Names", TEXT => "One name per line, add/edit/delete usernames in your reserved names list" );

    $html .= $SKIN->td_textarea( TEXT => "Reserved names:<br>&nbsp;&nbsp;&nbsp;&nbsp;(Case insensitive - one per line.)",  NAME => 'SAVED_NAMES', VALUE => $INFO->{'SAVED_NAMES'} );

    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Registration Options", PRINT => $html);

}

sub do_register {
    my ($obj, $db, $NEW, $i) = @_;

    if ($iB::IN{'HRI'} == 1) {
             $ADMIN->Error( DB => $db, STD => $std, MSG => "Can not enable $NEW->{$i}[0] without the perl module Image::Magick installed")
                unless (defined(eval{require Image::Magick}));
          }

    if ($iB::IN{'BOARD_RULES_REG'} and $iB::IN{'BOARD_RULES_NAME'}) {
        $db->update( TABLE  => 'forum_rules',
                     KEY    => '00',
                     VALUES => { RULES_TITLE => $iB::IN{'BOARD_RULES_NAME'},
                                 RULES_TEXT  => $iB::IN{'BOARD_RULES_REG'},
                                 LAST_UPDATE => time,
                               }
                   );
    }
    if ($iB::IN{'TERMS_REG'}){
        $iB::IN{'TERMS_REG'} =~ s!\n!<br>!g;

     $iB::IN{'TERMS_REG'}  = $txt->Convert_for_db( TEXT    => $iB::IN{'TERMS_REG'},
                                                   SMILIES => 0,
                                                   IB_CODE => 0,
                                                   HTML    => 0,
                                                 );

            $db->update( TABLE  => 'templates',
                         KEY    => 'register',
                         VALUES => { TEMPLATE => $iB::IN{'TERMS_REG'}
                                   }
                       );
    }
    my $OLD = Boardinfo->new();
    $OLD->{'SKIN_LANG_R'} = $iB::IN{'SKIN_LANG_R'} || 0;
    $OLD->{'GENDER_R'} = $iB::IN{'GENDER_R'} || 0;
    $OLD->{'LOCAL_R'} = $iB::IN{'LOCAL_R'} || 0;
    $OLD->{'AIM_R'} = $iB::IN{'AIM_R'} || 0;
    $OLD->{'ICQ_R'} = $iB::IN{'ICQ_R'} || 0;
    $OLD->{'YAHO_R'} = $iB::IN{'YAHO_R'} || 0;
    $OLD->{'MSN_R'} = $iB::IN{'MSN_R'} || 0;
    $OLD->{'WEB_R'} = $iB::IN{'WEB_R'} || 0;
    $OLD->{'MAIL_R'} = $iB::IN{'MAIL_R'} || 0;
    $OLD->{'SIGN_R'} = $iB::IN{'SIGN_R'} || 0;
    $OLD->{'INTER_R'} = $iB::IN{'INTER_R'} || 0;
    $OLD->{'MEMBER_NAME_R'} = $iB::IN{'MEMBER_NAME_R'} || 0;
    $OLD->{'ALLOW_REGISTER'}    = $iB::IN{'ALLOW_REGISTER'};
    $OLD->{'HRI'}               = $iB::IN{'HRI'} || 0;
    $OLD->{'VALIDATE_REGISTER'} = $iB::IN{'VALIDATE_REGISTER'} || 0;
    $OLD->{'PREVIEW_REG'}       = $iB::IN{'PREVIEW_REG'}       || 0;
    $OLD->{'SEND_WELCOME'}      = $iB::IN{'SEND_WELCOME'}      || 0;
    $OLD->{'USER_NOTIFY'}       = $iB::IN{'USER_NOTIFY'}       || 0;
    $OLD->{'SHOW_BOARD_RULES'}  = $iB::IN{'SHOW_BOARD_RULES'}  || 0;
    $OLD->{'AUTHORISE_PRUNE'}   = $iB::IN{'AUTHORISE_PRUNE'}   || 30;
    $OLD->{'ALLOW_MULT_EMAIL'}  = $iB::IN{'ALLOW_MULT_EMAIL'};

    $iB::IN{'SAVED_NAMES'} =~ s!\r!!;
    $iB::IN{'SAVED_NAMES'} =~ s!\n\n!!;
    $iB::IN{'SAVED_NAMES'} =~ s!<br>!|!ig;

    $OLD->{'SAVED_NAMES'}  = $iB::IN{'SAVED_NAMES'};

    # added by kevaholic00
    $db->update( TABLE  => 'templates',
                 KEY    => 'welcome',
                 VALUES => { TEMPLATE => $iB::IN{'WELC_MSG'},
                             NAME     => $iB::IN{'WELC_NAME'},
                           }
               );
    # end addition

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD,
                        );

    $ADMIN->static_screen( URL   => "act=ops&CODE=register",
                           TITLE => "Registration option changes applied",
                           TEXT  => "The changes were successful",
                         );
}

#+------------------------ Post Options ------------------------

sub post {
    my ($obj, $db) = @_;

    my @ext = split (/\|/, $INFO->{'IMG_EXT'});
    $INFO->{'IMG_EXT'} = join "\n", @ext;
    $INFO->{'FONT_COLOR_DEFAULT'} = $INFO->{'FONT_COLOR_DEFAULT'} || '#000000';
    # Re-arrange the word filter

    my @words = split (/\|/, $INFO->{'WORD_FILTER'});
    my $words_for_textarea;
    for (@words) {
        if (/(.+?)\:e\:(.+?)\Z/) {
            $words_for_textarea .= "{".$1."=".$2."}\n";
        }
        elsif (/(.+?)\:\:(.+?)\Z/) {
            $words_for_textarea .= $1."=".$2."\n";
        }
        elsif (/(.+?)\:e\:\Z/) {
            $words_for_textarea .= "{".$1."}\n";
        }
        elsif (/(.+?)\:\:\Z/) {
            $words_for_textarea .= $1."\n";
        }
    }

    my $html  = $SKIN->title( TITLE => 'Post Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'dopost'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Post Permissions" );
    $html .= $SKIN->td_input ( TEXT => 'Smilies per row in Clickable Table',    NAME => 'EMO_PER_ROW'     , VALUE=> $INFO->{'EMO_PER_ROW'} );

    $html .= $SKIN->td_select( TEXT     => "Allow polls?",
                               NAME     => 'ALLOW_POLLS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ALLOW_POLLS'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow images to be posted?",
                               NAME     => 'ALLOW_IMAGES',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ALLOW_IMAGES'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_input ( TEXT => 'Time (in seconds) that members have to edit posts. (300 = 5 mins)',
                               NAME => 'EDIT_TIME',
                               VALUE=> $INFO->{'EDIT_TIME'} );

    $html .= $SKIN->td_input ( TEXT => 'Max post length (in kb)',        NAME => 'MAX_POST_LENGTH', VALUE=> $INFO->{'MAX_POST_LENGTH'} );
    $html .= $SKIN->td_input ( TEXT => 'Maximum no. of images per post',    NAME => 'MAX_IMAGES'     , VALUE=> $INFO->{'MAX_IMAGES'} );
    $html .= $SKIN->td_input ( TEXT => 'Maximum no. of emoticons per post', NAME => 'MAX_EMOS'       , VALUE=> $INFO->{'MAX_EMOS'} );
    $html .= $SKIN->td_input ( TEXT => 'Maximum font size allowed (default is 10)', NAME => 'MAX_FONT'       , VALUE=> $INFO->{'MAX_FONT'} );
    $html .= $SKIN->td_input ( TEXT => 'Default post text color', NAME => 'FONT_COLOR_DEFAULT'       , VALUE=> $INFO->{'FONT_COLOR_DEFAULT'} );
    $html .= $SKIN->td_select( TEXT     => "Allow members to use the text color feature in their CP?",
                               NAME     => 'FONT_COLOR_ALLOW',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'FONT_COLOR_ALLOW'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_textarea( TEXT => "Allowed image extensions:<br>&nbsp;&nbsp;&nbsp;&nbsp;(Case insensitive, one per line.)",  NAME => 'IMG_EXT', VALUE => $INFO->{'IMG_EXT'} );

    # added by kevaholic00
    $html .= $SKIN->td_select( TEXT     => "What warning level must the user be under to be allowed to edit posts?",
                               NAME     => 'EDIT_WARN_MAX',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'EDIT_WARN_MAX'},
                               DATA     => [ { NAME => '1', VALUE => '1' },
                                             { NAME => '2', VALUE => '2' },
                                             { NAME => '3', VALUE => '3' },
                                             { NAME => '4', VALUE => '4' },
                                             { NAME => '5', VALUE => '5' }, ]
                             );
    # end addition

    $html .= $SKIN->section_header( TITLE => "Flash Permissions" );

    $html .= $SKIN->td_select( TEXT     => "Allow flash animations to be posted?",
                               NAME     => 'ALLOW_FLASH',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ALLOW_FLASH'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_input ( TEXT => 'Max Flash movie width',    NAME => 'MAX_W_FLASH', VALUE=> $INFO->{'MAX_W_FLASH'} );
    $html .= $SKIN->td_input ( TEXT => 'Max Flash movie height',   NAME => 'MAX_H_FLASH', VALUE=> $INFO->{'MAX_H_FLASH'} );

    $html .= $SKIN->section_header( TITLE => "Word filter", TEXT => "One entry per line in the following format<br>&nbsp;&nbsp;&nbsp;&nbsp;To match exactly, with a value to replace it with <u>{badword=goodword}</u><br>&nbsp;&nbsp;&nbsp;&nbsp;To match exactly, allowing '*' sign to blank out word: <u>{badword}</u><br>&nbsp;&nbsp;&nbsp;&nbsp;To match partly (badword 'hell' blanks hello: ****o) <u>badword</u><br>&nbsp;&nbsp;&nbsp;&nbsp;To match partly, with a word to be replaced <u>badword=goodword</u>" );

    $html .= $SKIN->td_textarea( TEXT => "Words:",  NAME => 'WORD_FILTER', VALUE => $words_for_textarea );

    $html .= $SKIN->section_header( TITLE => "New Topic Etiquette Filter", TEXT => "This enables you to automatically remove excess exclamation marks / question marks and to stop members 'SHOUTING LIKE THIS' in topic titles" );

    $INFO->{'ETFILTER_PUNCT'} ||= 0;
    $INFO->{'ETFILTER_SHOUT'} ||= 0;

    $html .= $SKIN->td_select( TEXT     => "Remove excess exclamation marks and question marks?",
                               NAME     => 'ETFILTER_PUNCT',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ETFILTER_PUNCT'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Stop members from SHOUTING?",
                               NAME     => 'ETFILTER_SHOUT',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'ETFILTER_SHOUT'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Post Options", PRINT => $html);
}

sub do_post {
    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();

    if ($iB::IN{'WORD_FILTER'}) {
        $iB::IN{'WORD_FILTER'} =~ s|&#123;|\{|g;
        $iB::IN{'WORD_FILTER'} =~ s|&#125;|\}|g;
        $iB::IN{'WORD_FILTER'} =~ s|\$|&#036;|g;

        my $word;
        for ( split (/<br>/, $iB::IN{'WORD_FILTER'}) ) {
            if (/\A{(.+?)=(.+?)}\Z/) {
                $word .= $1.":e:".$2."|";
            }
            elsif (/\A(.+?)=(.+?)\Z/) {
                $word .= $1."::".$2."|";
            }
            elsif (/\A{(.+?)}\Z/) {
                $word .= $1.":e:|";
            }
            elsif (/\A(.+?)\Z/) {
                $word .= $1.":e:|";
            }
            elsif (/\A(.+?)\Z/) {
                $word .= $1."::|";
            }
        }
        $OLD->{'WORD_FILTER'} = $word;
    } else {
        $OLD->{'WORD_FILTER'} = '';
    }

    $OLD->{'ALLOW_POLLS'}      = $iB::IN{'ALLOW_POLLS'};
    $OLD->{'MAX_IMAGES'}       = $iB::IN{'MAX_IMAGES'};
    $OLD->{'MAX_EMOS'}         = $iB::IN{'MAX_EMOS'};
    $OLD->{'MAX_FONT'}         = $iB::IN{'MAX_FONT'}|| 10;
    $OLD->{'ALLOW_IMAGES'}     = $iB::IN{'ALLOW_IMAGES'}     || 0;
    $OLD->{'ALLOW_FLASH'}      = $iB::IN{'ALLOW_FLASH'}       || 0;
    $OLD->{'MAX_H_FLASH'}      = $iB::IN{'MAX_H_FLASH'}       || 200;
    $OLD->{'MAX_W_FLASH'}      = $iB::IN{'MAX_W_FLASH'}      || 200;
    $OLD->{'MAX_POST_LENGTH'}  = $iB::IN{'MAX_POST_LENGTH'} || 75;
    $OLD->{'EMO_PER_ROW'}      = $iB::IN{'EMO_PER_ROW'} || 75;
    $OLD->{'FONT_COLOR_DEFAULT'} = $iB::IN{'FONT_COLOR_DEFAULT'};
    $OLD->{'FONT_COLOR_ALLOW'} = $iB::IN{'FONT_COLOR_ALLOW'};
    $OLD->{'ETFILTER_SHOUT'}   = $iB::IN{'ETFILTER_SHOUT'};
    $OLD->{'ETFILTER_PUNCT'}   = $iB::IN{'ETFILTER_PUNCT'};
    $OLD->{'EDIT_WARN_MAX'}    = $iB::IN{'EDIT_WARN_MAX'};
    $iB::IN{'IMG_EXT'} =~ s!\r!!g;
    $iB::IN{'IMG_EXT'} =~ s!\n{1,}!!g;
    $iB::IN{'IMG_EXT'} =~ s!<br>!|!ig;
    $iB::IN{'IMG_EXT'} =~ s!(?:\|+)$!!;

    $OLD->{'IMG_EXT'}         = $iB::IN{'IMG_EXT'};
    $OLD->{'EDIT_TIME'}       = $iB::IN{'EDIT_TIME'};

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=post",
                           TITLE => "Post option information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Member Options ------------------------

sub member {
    my ($obj, $db) = @_;

    my @ext = split (/\|/, $INFO->{'AV_EXT'});
    $INFO->{'AV_EXT'} = join "\n", @ext;

    my $html  = $SKIN->title( TITLE => 'Member Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'domember'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Member Permissions" );

    $html .= $SKIN->td_input ( TEXT => 'No. posts before the user can change their own member title<br>&nbsp;&nbsp;&nbsp;&nbsp;Leave blank if you do not want to let them change it.',  NAME => 'POST_TITLECHANGE', VALUE=> $iB::INFO->{'POST_TITLECHANGE'} );

    $html .= $SKIN->td_select( TEXT     => "Allow avatars?",
                               NAME     => 'AVATARS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'AVATARS'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Show the member's real name in his/her profile?",
                               NAME     => 'MEMBER_NAME_SP',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'MEMBER_NAME_SP'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow users to input a URL for an avatar?",
                               NAME     => 'AV_ALLOW_URL',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'AV_ALLOW_URL'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow HTML in signatures?",
                               NAME     => 'SIG_ALLOW_HTML',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'SIG_ALLOW_HTML'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow iB CODE in signatures?",
                               NAME     => 'SIG_ALLOW_IBC',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'SIG_ALLOW_IBC'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow smilies in signatures?",
                               NAME     => 'SIG_ALLOW_EMOTICONS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'SIG_ALLOW_EMOTICONS'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                             ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Send a \"happy birthday\" message to members on their birthdays?",
                               NAME     => 'HAPPY_BD',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'HAPPY_BD'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                             ]
                             );

    # added by kevaholic00
    my $BDAY_MSG  = $db->select( TABLE => 'templates',
                                 KEY   => 'birthday',
                               );

    $html .= $SKIN->td_textarea( TEXT => "Enter the happy birthday message<br><br>&nbsp;&nbsp;&nbsp;&nbsp;DATE = The date<br>&nbsp;&nbsp;&nbsp;&nbsp;NAMEMEM = Member's name<br>&nbsp;&nbsp;&nbsp;&nbsp;AGE = Member's age", NAME => 'BDAY_MSG', VALUE => $BDAY_MSG->{'TEMPLATE'} );

    $html .= $SKIN->td_input ( TEXT => "Title of the \"happy birthday\" private message",  NAME => 'BDAY_NAME', VALUE=> $BDAY_MSG->{'NAME'} );
    # end addition

    my ($av_w  , $av_h)   = split ("x", $INFO->{'AV_DIMS'});
    my ($d_av_w, $d_av_h) = split ("x", $INFO->{'DEF_AV_DIMS'});

    $html .= $SKIN->td_input ( TEXT => 'Maximum custom avatar Width (in px)',  NAME => 'AVATAR_WIDTH', VALUE=> $av_w, REQ => 1 );


    $html .= $SKIN->td_input ( TEXT => 'Maximum custom avatar Height (in px)', NAME => 'AVATAR_HEIGHT',VALUE=> $av_h, REQ => 1 );

    $html .= $SKIN->td_input ( TEXT => 'Preinstalled avatar width (in px)',  NAME => 'D_AVATAR_WIDTH', VALUE=> $d_av_w, REQ => 1 );

    $html .= $SKIN->td_input ( TEXT => 'Preinstalled avatar Height (in px)', NAME => 'D_AVATAR_HEIGHT',VALUE=> $d_av_h, REQ => 1 );

    $html .= $SKIN->td_input ( TEXT => 'Maximum signature length (in characters)', NAME => 'MAX_SIG_LENGTH',VALUE=> $INFO->{'MAX_SIG_LENGTH'}, REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Maximum interests length (in characters)', NAME => 'MAX_INTEREST_LENGTH',VALUE=> $INFO->{'MAX_INTEREST_LENGTH'}, REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Maximum location length  (in characters - cannot be greater than 128)', NAME => 'MAX_LOCATION_LENGTH',VALUE=> $INFO->{'MAX_LOCATION_LENGTH'}, REQ => 1 );

    $html .= $SKIN->td_textarea( TEXT => "Allowed avatar extensions:<br>&nbsp;&nbsp;&nbsp;&nbsp;(Case insensitive, one per line.)",  NAME => 'AV_EXT', VALUE => $INFO->{'AV_EXT'} );

    $html .= $SKIN->td_select( TEXT     => "Allow members to rate each other?",
                               NAME     => 'MEMBER_RATING',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'MEMBER_RATING'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                             ]
                             );

    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Member Options", PRINT => $html);
}

sub do_member {
    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();

    $iB::IN{'MAX_LOCATION_LENGTH'} = 128 if $iB::IN{'MAX_LOCATION_LENGTH'} > 128;

    $OLD->{'AVATARS'}             = $iB::IN{'AVATARS'};
    $OLD->{'AV_ALLOW_URL'}        = $iB::IN{'AV_ALLOW_URL'};
    $OLD->{'MAX_SIG_LENGTH'}      = $iB::IN{'MAX_SIG_LENGTH'}       || 500;
    $OLD->{'MAX_INTEREST_LENGTH'} = $iB::IN{'MAX_INTEREST_LENGTH'}  || 100;
    $OLD->{'MAX_LOCATION_LENGTH'} = $iB::IN{'MAX_LOCATION_LENGTH'}  || 128;

    $iB::IN{'AV_EXT'} =~ s!\r!!;
    $iB::IN{'AV_EXT'} =~ s!\n\n!!;
    $iB::IN{'AV_EXT'} =~ s!<br>!|!ig;

    $OLD->{'AV_DIMS'}     = $iB::IN{'AVATAR_WIDTH'}   ."x". $iB::IN{'AVATAR_HEIGHT'};
    $OLD->{'DEF_AV_DIMS'} = $iB::IN{'D_AVATAR_WIDTH'} ."x". $iB::IN{'D_AVATAR_HEIGHT'};
    $OLD->{'AV_EXT'}  = $iB::IN{'AV_EXT'};
    $OLD->{'SIG_ALLOW_IBC'}        = $iB::IN{'SIG_ALLOW_IBC'};
    $OLD->{'SIG_ALLOW_HTML'}       = $iB::IN{'SIG_ALLOW_HTML'};
    $OLD->{'SIG_ALLOW_EMOTICONS'}  = $iB::IN{'SIG_ALLOW_EMOTICONS'};
    $OLD->{'POST_TITLECHANGE'}     = $iB::IN{'POST_TITLECHANGE'} || '';
    $OLD->{'MEMBER_NAME_SP'}       = $iB::IN{'MEMBER_NAME_SP'};
    $OLD->{'HAPPY_BD'}             = $iB::IN{'HAPPY_BD'};
    $OLD->{'MEMBER_RATING'}        = $iB::IN{'MEMBER_RATING'};

    # added by kevaholic00
    $db->update( TABLE     => 'templates',
                 KEY       => 'birthday',
                 VALUES    => { TEMPLATE => $iB::IN{'BDAY_MSG'},
                                NAME     => $iB::IN{'BDAY_NAME'},
                              }
               );
    # end addition

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=member",
                           TITLE => "Member Option information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------------ Member Options ------------------------

sub pm {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Messenger Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'dopm'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Messenger Permissions" );

    $html .= $SKIN->td_select( TEXT     => "Allow HTML in private messages?",
                               NAME     => 'MSG_ALLOW_HTML',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'MSG_ALLOW_HTML'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Allow iB code in private messages?",
                               NAME     => 'MSG_ALLOW_CODE',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'MSG_ALLOW_CODE'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Send the content of the PM with the notification email when member chooses to receive a notification?",
                               NAME     => 'MSG_ALL_MESS_CONT',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'MSG_ALL_MESS_CONT'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_input ( TEXT => 'Maximum message size (in Kb)',           NAME => 'MAX_MSG_SIZE',   VALUE=> $INFO->{'MAX_MSG_SIZE'},  REQ => 1 );

    $html .= $SKIN->td_input ( TEXT => 'No. of days before messages are pruned', NAME => 'MSG_PRUNE_DAYS', VALUE=> $INFO->{'MSG_PRUNE_DAYS'}, REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'Maximum number of members it is possible to PM at the same time', NAME => 'MSG_MAX_SEND', VALUE=> $INFO->{'MSG_MAX_SEND'}, REQ => 1 );

    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Messenger Options", PRINT => $html);
}

sub do_pm {
    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();

    $OLD->{'MAX_MSG_SIZE'}      = $iB::IN{'MAX_MSG_SIZE'}    || 30;
    $OLD->{'MSG_ALLOW_HTML'}    = $iB::IN{'MSG_ALLOW_HTML'}  || 0;
    $OLD->{'MSG_ALL_MESS_CONT'} = $iB::IN{'MSG_ALL_MESS_CONT'}  || 0;
    $OLD->{'MSG_ALLOW_CODE'}    = $iB::IN{'MSG_ALLOW_CODE'}  || 0;
    $OLD->{'MSG_PRUNE_DAYS'}    = $iB::IN{'MSG_PRUNE_DAYS'}  || 30;
    $OLD->{'MSG_MAX_SEND'}      = $iB::IN{'MSG_MAX_SEND'}  || 10;

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=pm",
                           TITLE => "Messenger option information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

sub report {
    my ($obj, $db) = @_;

    $INFO->{'REPORT_POST_ENABLED'} ||= '0';
    $INFO->{'REPORT_POST_METHOD'}  ||= '0';

    my $message = qq~Reporting a post to a moderator:\n\n================================\n\nLink to Post: <#LINK TO POST#>\nTopic Title: <#TOPIC_TITLE#>\nForum: <#FORUM#>
                     Reported by: <#MEMBER NAME#>\n\nIP Address of sender: <#IP ADDRESS#>\n\nEmail address of sender: <#EMAIL#>\n\nReported on: <#DATE#>\n\nMessage:\n<#MESSAGE#>~;

    my $temp = $db->select( TABLE  => 'email_templates',
                            KEY    => 'report_post',
                          );

    $temp->{'TEMPLATE'} ||= $message;

    my $html  = $SKIN->title( TITLE => '"Report this post" setup', TEXT => 'This will enable you to define how the "Report this post to a moderator" feature works and acts.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'do_report'
                                      } );

    $html .= $SKIN->section_header( TITLE => "Configuration" );

    $html .= $SKIN->td_select( TEXT     => "Enable this feature?",
                               NAME     => 'REPORT_POST_ENABLED',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'REPORT_POST_ENABLED'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Which method do you wish to use to contact the moderator?",
                               NAME     => 'REPORT_POST_METHOD',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'REPORT_POST_METHOD'},
                               DATA     => [ { NAME => 'Via email and private message',  VALUE => '2' },
                                             { NAME => 'Via email'                    ,  VALUE => '1' },
                                             { NAME => 'Via private message'          ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_select( TEXT     => "Send the report to the super moderators if no moderators are available?",
                               NAME     => 'REPORT_POST_SUPMOD',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $INFO->{'REPORT_POST_SUPMOD'},
                               DATA     => [ { NAME => 'Yes',  VALUE => '1' },
                                             { NAME => 'No' ,  VALUE => '0' },
                                           ]
                             );

    $html .= $SKIN->td_textarea( TEXT => "Message to be sent to the moderators:<br>&nbsp;&nbsp;&nbsp;&nbsp;(Do not rename the &lt;#TAGS#&gt;)",  NAME => 'MESSAGE', VALUE => $temp->{'TEMPLATE'} );
    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Report post set up", PRINT => $html);
}

sub do_report {
    my ($obj, $db) = @_;
    my $OLD = Boardinfo->new();

    $OLD->{'REPORT_POST_ENABLED'}    = $iB::IN{'REPORT_POST_ENABLED'};
    $OLD->{'REPORT_POST_METHOD'}     = $iB::IN{'REPORT_POST_METHOD'};
    $OLD->{'REPORT_POST_SUPMOD'}     = $iB::IN{'REPORT_POST_SUPMOD'};

    # Update the DB

    my $temp = $db->select( TABLE  => 'email_templates',
                            KEY    => 'report_post',
                          );

    if ($temp->{'TEMPLATE'}) {
        $db->update( TABLE   => 'email_templates',
                     KEY     => 'report_post',
                     VALUES  => { TEMPLATE  => $iB::CGI->param('MESSAGE') },
                   );
    } else {
        $db->insert( TABLE   => 'email_templates',
                     VALUES  => { ID       => 'report_post',
                                  TYPE     => '1',
                                  TEMPLATE => $iB::CGI->param('MESSAGE'),
                                },
                   );
    }

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=report",
                           TITLE => "Report post information changes applied",
                           TEXT  => "The changes were successful"
                         );
}

sub event {
    my ($obj, $db) = @_;
    my $html  = $SKIN->title( TITLE => "Calendar Event Manager", TEXT => "This manager will allow you to adjust your settings for the event calendar.");

    $iB::INFO->{'EVENT_LIMIT'} ||= 15;
    $iB::INFO->{'EVENT_FRONT'} ||= "blue";
    $iB::INFO->{'EVENT_FORUM'} ||= "blue";
    $iB::INFO->{'EVENT_CALENDAR'} ||= "blue";
    $iB::INFO->{'EVENT_NAV'} ||= "blue";

    $html .= $SKIN->begin_table();
    $html .= $SKIN->form_start();
    $html .= $SKIN->hidden_fields( { act  => 'ops',
                                     CODE => 'do_event',
                                   } );
    $html .= $SKIN->td_select( TEXT     => "Do you wish to generate the news file?",
                               NAME     => 'CALENDAR_SSI',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'CALENDAR_SSI'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );
    $html .= $SKIN->td_input ( TEXT => 'How often do you want to generate the news file (in minutes)?', NAME => 'CALENDAR_SSI_TIME', VALUE=> $iB::INFO->{'CALENDAR_SSI_TIME'}, REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'What is the span of days that you would like to display on the front page?', NAME => 'EVENT_LIMIT', VALUE=> $iB::INFO->{'EVENT_LIMIT'}, REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => "In what color would you like to display the event on the topic's navigation bar?", NAME => 'EVENT_NAV', VALUE=> $iB::INFO->{'EVENT_NAV'}, REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'In what color would you like to display the event in the calendar?', NAME => 'EVENT_CALENDAR', VALUE=> $iB::INFO->{'EVENT_CALENDAR'}, REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'In what color would you like to display the event in forum view (topic list)?', NAME => 'EVENT_FORUM', VALUE=> $iB::INFO->{'EVENT_FORUM'}, REQ => 1 );
    $html .= $SKIN->td_input ( TEXT => 'In what color would you like to display the event on the front page (event in the next few days)?', NAME => 'EVENT_FRONT', VALUE=> $iB::INFO->{'EVENT_FRONT'}, REQ => 1 );

    my $a_forums = $db->query( TABLE     => 'forum_info',
                               SORT_KEY  => 'FORUM_ID',
                               SORT_BY   => 'A-Z',
                               MATCH     => 'ALL'
                             ) || die $db->{'error'};

    my @forums;
    for my $f (@{ $a_forums } ) {
        push @forums, { NAME => "&gt;--".$f->{'FORUM_NAME'}, VALUE => $f->{'FORUM_ID'} };
    }

    my @values = split(/&/,$iB::INFO->{'CALENDARF'});
    my $size = scalar @forums;

    $html .= $SKIN->td_select( TEXT     => 'In which forums do you wish to allow events to be posted?',
                               NAME     => 'CALENDARF',
                               SIZE     => $size,
                               REQ      => 1,
                               MULTIPLE => 1,
                               VALUES   => \@values,
                               DATA     => \@forums,
                             );

$html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
$html .= $SKIN->form_end();
$html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Calendar of event setup", PRINT => $html);
}

sub do_event {
    my ($obj, $db) = @_;

    my $OLD = Boardinfo->new();
    my ($where, $i);
    foreach ($iB::CGI->param('CALENDARF')) {
        $i++;
        $where .= "&" unless $i == 1;
        $where .= "$_";
    }

    $OLD->{'CALENDARF'}         = $where;
    $OLD->{'CALENDAR_SSI'}      = $iB::IN{'CALENDAR_SSI'};
    $OLD->{'CALENDAR_SSI_TIME'} = $iB::IN{'CALENDAR_SSI_TIME'};
    $OLD->{'EVENT_LIMIT'}       = $iB::IN{'EVENT_LIMIT'};
    $OLD->{'EVENT_FRONT'}       = $iB::IN{'EVENT_FRONT'};
    $OLD->{'EVENT_FORUM'}       = $iB::IN{'EVENT_FORUM'};
    $OLD->{'EVENT_CALENDAR'}    = $iB::IN{'EVENT_CALENDAR'};
    $OLD->{'EVENT_NAV'}         = $iB::IN{'EVENT_NAV'};

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );


    $ADMIN->static_screen( URL   => "act=ops&CODE=event",
                           TITLE => "The changes in the events calendar have been applied",
                           TEXT  => "The changes were successful"
                         );
           }
#+------------------ calendar of event end -----------------
#+------------------ password protection of admincp -----------------
sub password {
    my ($obj, $db) = @_;
    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You do not have permission for this action") unless $iB::MEMBER->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'};
    my $html  = $SKIN->title( TITLE => "Password Manager", TEXT => "This manager will allow you add password protection to the SQL Client, Database, File Manager, Member Groups, Forum Controls and Prune Members.");
    $html .= $SKIN->begin_table();
    $html .= $SKIN->form_start();
    $html .= $SKIN->hidden_fields( { act  => 'ops',
                                     CODE => 'do_password',
                                      } );
    if ($iB::INFO->{'ADMIN_PASSWORD'}) {
        $html .= $SKIN->section_header( TITLE => "Remove Password Protection" );
        $html .= $SKIN->td_input ( TEXT => 'Enter the old password', NAME => 'NEW_PASS', VALUE=> "", REQ => 1, TYPE => 'password' );
    } else {
        $html .= $SKIN->section_header( TITLE => "If you enter a password here it will be required that you enter this same password to gain access to the specified part of you Admin CP." );
        $html .= $SKIN->td_input ( TEXT => 'Enter the new password here (at least 5 characters)', NAME => 'NEW_PASS', VALUE=> "", REQ => 1, TYPE => 'password' );
    }

    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Password Setup", PRINT => $html);
}

sub do_password {
    my ($obj, $db) = @_;

    $ADMIN->Error( DB => $db, STD => $std, MSG => "Your new password is not long anough. Please try again.") unless length($iB::IN{'NEW_PASS'}) >= 5;
    my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
    my $new1 = $iB::IN{'NEW_PASS'};
    require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
    require 'Sources/ARC4.pm' or die "Cannot open ARC4";
    opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
    my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
    closedir(DIR);
    my @key  = grep { /.+?(\.pwd)\Z/ } @list;
    for my $f (@key) {
        my $ark4 = Crypt::ARC4->new($f);
        $new1 = MIME::Base64::encode_base64($ark4->ARC4($new1));# encrypting the new pass
    }
    if ($iB::INFO->{'ADMIN_PASSWORD'}) {
        for my $f (@key) {
            my $ark4 = Crypt::ARC4->new($f);
            $admin_pwd = $ark4->ARC4( MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
        }
        $ADMIN->Error( DB => $db, STD => $std, MSG => "Your old password does not match what we have in our records. Please try again.") unless ($iB::IN{'NEW_PASS'} eq $admin_pwd);
        my $OLD = Boardinfo->new();
        $OLD->{'ADMIN_PASSWORD'} = "0";
        $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                             PKG_NAME => 'Boardinfo',
                             VALUES   => $OLD
                           );
        $ADMIN->static_screen( URL   => "act=ops&CODE=password",
                               TITLE => "The changes to your password protection of the Admin CP have been applied",
                               TEXT  => "You password has been deleted"
                             );

    }
# no errors so it's ok to proceed.
    my $OLD = Boardinfo->new();
    $new1 =~ s!\n\Z!!;
    $OLD->{'ADMIN_PASSWORD'} = $new1;
    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );
    $OLD = Boardinfo->new();

    $ADMIN->static_screen( URL   => "act=ops&CODE=password",
                           TITLE => "The changes to your password protection of the Admin CP have been applied",
                           TEXT  => "The vital parts of your Admin CP are now protected."
                         );
}

sub password_set {
    my ($obj, $db) = @_;
    $ADMIN->Error( DB=>,"", STD=>"", MSG => "You do not have permission for this action") unless $iB::MEMBER->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'};
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        my $new1 = $iB::IN{'PASSWRD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records. Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
        } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '') {

        my $html  = $SKIN->title( TITLE => "Password Settings", TEXT => ".");
        $html .= $SKIN->begin_table();
        $html .= $SKIN->form_start();
        $html .= $SKIN->hidden_fields( { act  => 'ops',
                                         CODE => 'password_set',
                                          } );
        $html .= $SKIN->section_header( TITLE => "This feature is password protected!" );
        $html .= $SKIN->td_input ( TEXT => 'Enter the the admin password here', NAME => 'PASSWRD', VALUE=> "", REQ => 1, TYPE => 'password');
        $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
        $html .= $SKIN->form_end();
        $html .= $SKIN->end_table();

        $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Protected Area!", PRINT => $html);

    }
    SKIPED:

    my $html  = $SKIN->title( TITLE => "Password Manager", TEXT => "Select the section of Admin CP where you want the password protection to be applied.");
    $html .= $SKIN->begin_table();
    $html .= $SKIN->form_start();
    $html .= $SKIN->hidden_fields( { act  => 'ops',
                                     CODE => 'do_password_set',
                                     PASSWRD => $iB::IN{'PASSWRD'},
                                   } );
    $html .= $SKIN->td_select( TEXT     => "Do you wish to protect the member groups settings?",
                               NAME     => 'P_MEM_GRPS',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'P_MEM_GRPS'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );
    $html .= $SKIN->td_select( TEXT     => "Do you wish to protect the file manager?",
                               NAME     => 'P_FILE_MAN',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'P_FILE_MAN'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );
    $html .= $SKIN->td_select( TEXT     => "Do you wish to protect the SQL client?",
                               NAME     => 'P_SQL_CLIENT',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'P_SQL_CLIENT'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );
    $html .= $SKIN->td_select( TEXT     => "Do you wish to protect the database?",
                               NAME     => 'P_DATABASE',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'P_DATABASE'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );
    $html .= $SKIN->td_select( TEXT     => "Do you wish to protect the prune members function?",
                               NAME     => 'P_PRUNE_MEM',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'P_PRUNE_MEM'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );
    $html .= $SKIN->td_select( TEXT     => "Do you wish to protect the forum control?",
                               NAME     => 'P_FORUMS_SETUP',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'P_FORUMS_SETUP'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );
    $html .= $SKIN->td_select( TEXT     => "Do you wish to protect the category control?",
                               NAME     => 'P_CATEG',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'P_CATEG'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No',  VALUE => '0' }, ]
                             );

    $html .= $SKIN->td_submit( NAME => '', VALUE => 'Apply Changes' );
    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "Password Setup", PRINT => $html);

}

sub do_password_set {
my ($obj, $db) = @_;
    if ($iB::INFO->{'ADMIN_PASSWORD'} and $iB::IN{'PASSWRD'}) {
        my $admin_pwd = $iB::INFO->{'ADMIN_PASSWORD'};
        my $new1 = $iB::IN{'PASSWRD'};
        require 'Sources/MIME/Base64.pm' or die "Cannot open Base64";
        require 'Sources/ARC4.pm' or die "Cannot open ARC4";
        opendir (DIR, $iB::INFO->{'IKON_DIR'}.'Data');
        my @list = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
        closedir(DIR);
        my @key  = grep { /.+?(\.pwd)\Z/ } @list;
            for my $f (@key) {
                my $ark4 = Crypt::ARC4->new($f);
                $admin_pwd = $ark4->ARC4(MIME::Base64::decode_base64($admin_pwd));# decrypting the pass
            }
            $ADMIN->Error( DB => $db, STD => $std, MSG => "Your password does not match what we have in our records. Please try again.") unless ($iB::IN{'PASSWRD'} eq $admin_pwd);
            goto SKIPED;
    } elsif ($iB::INFO->{'ADMIN_PASSWORD'} && $iB::IN{'PASSWRD'} eq '') {

        $obj->password_set();
    }

    SKIPED:

    my $OLD = Boardinfo->new();

    $OLD->{'P_CATEG'}      = $iB::IN{'P_CATEG'};
    $OLD->{'P_FORUMS_SETUP'} = $iB::IN{'P_FORUMS_SETUP'};
    $OLD->{'P_PRUNE_MEM'}       = $iB::IN{'P_PRUNE_MEM'};
    $OLD->{'P_MEM_GRPS'}       = $iB::IN{'P_MEM_GRPS'};
    $OLD->{'P_FILE_MAN'}       = $iB::IN{'P_FILE_MAN'};
    $OLD->{'P_SQL_CLIENT'}    = $iB::IN{'P_SQL_CLIENT'};
    $OLD->{'P_DATABASE'}         = $iB::IN{'P_DATABASE'};

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );


    $ADMIN->static_screen( URL   => "act=ops&CODE=password_set",
                           TITLE => "The changes to the password settings have been applied",
                           TEXT  => "The changes were successful"
                         );
}

#+------------------ password setup end -----------------

sub coppa {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'COPPA Options', TEXT => 'Please double check all the data before submitting the changes.' );
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'ops',
                                        CODE  => 'do_coppa'
                                      } );

    $html .= $SKIN->section_header( TITLE => "General COPPA Settings");

    $html .= $SKIN->td_select( TEXT     => "Enable COPPA-regulated registrations?",
                               NAME     => 'COPPA',
                               SIZE     => 1,
                               REQ      => 1,
                               VALUES   => $iB::INFO->{'COPPA'},
                               DATA     => [ { NAME => 'Yes', VALUE => '1' },
                                             { NAME => 'No' , VALUE => '0' }, ]
                             );

    $html .= $SKIN->section_header( TITLE => "COPPA Contact Information", TEXT => "Provide your contact details so that parents can send you the COPPA form");

    $html .= $SKIN->td_input ( TEXT => 'Fax Name', NAME => 'COPPA_FAX_NAME', VALUE => "$INFO->{'COPPA_FAX_NAME'}");

    $html .= $SKIN->td_input ( TEXT => 'Fax Phone Number', NAME => 'COPPA_FAX_NUMBER', VALUE => "$INFO->{'COPPA_FAX_NUMBER'}");

    $html .= $SKIN->td_input ( TEXT => 'Mailing Address', NAME => 'COPPA_MAIL_ADDR', VALUE => "$INFO->{'COPPA_MAIL_ADDR'}");

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply Changes' );

    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    $ADMIN->Output( WHERE => 'OPTIONS', NAV_ONE => "COPPA Options", PRINT => $html);
}

sub do_coppa {
    my ($obj, $db) = @_;

    my $NEW = [
        'COPPA',
        'COPPA_FAX_NAME',
        'COPPA_FAX_NUMBER',
        'COPPA_MAIL_ADDR',
    ];

    my $OLD = Boardinfo->new();

    for (@{ $NEW }) {
        $OLD->{ $_ } = $iB::CGI->param($_);
    }

    # Update the Boardinfo.cgi file

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->static_screen( URL   => "act=ops&CODE=coppa",
                           TITLE => "COPPA options saved",
                           TEXT  => "The changes were successful"
                         );
}

sub process {
    my ($obj, $db) = @_;

    my $CodeNo = $iB::IN{'CODE'};

    my %Mode = ( 'showPaths'    => \&show_paths,
                 'doPaths'      => \&do_paths,

                 'showOps'      => \&show_ops,
                 'doOps'        => \&do_ops,

                 'forum'        => \&forum,
                 'doforum'      => \&do_forum,

                 'topic'        => \&topic,
                 'dotopic'      => \&do_topic,

                 'email'        => \&email,
                 'doemail'      => \&do_email,

                 'search'       => \&search,
                 'dosearch'     => \&do_search,

                 'register'     => \&register,
                 'doregister'   => \&do_register,

                 'post'         => \&post,
                 'dopost'       => \&do_post,

                 'member'       => \&member,
                 'domember'     => \&do_member,

                 'memberlist'   => \&memberlist,
                 'domemberlist' => \&domemberlist,

                 'pm'           => \&pm,
                 'dopm'         => \&do_pm,

                 'defaults'     => \&defaults,
                 'dodefaults'   => \&do_defaults,

                 'active'       => \&active,
                 'do_active'    => \&do_active,

                 'report'       => \&report,
                 'do_report'    => \&do_report,

                 'event'        => \&event,
                 'do_event'     => \&do_event,

                 'password'        => \&password,
                 'do_password'     => \&do_password,
                 'password_set'    => \&password_set,
                 'do_password_set' => \&do_password_set,

                 'coppa'        => \&coppa,
                 'do_coppa'     => \&do_coppa,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj,$db) : error($obj,$db);
}

sub error {
    my ($obj, $db) = @_;
    die "Error!";
}

1;
