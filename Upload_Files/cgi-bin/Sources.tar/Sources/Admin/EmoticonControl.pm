package Admin::EmoticonControl;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# EmoticonControl: Smiley manipulation
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Lib/ADMIN.pm';
    require 'Admin/SKIN.pm';
    require 'Boardinfo.cgi' or die "Cannot load Module: $!";
}

my $SKIN  = Admin::SKIN->new();
my $std   = FUNC::STD->new();
my $ADMIN = FUNC::ADMIN->new();
my $INFO  = Boardinfo->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub splash {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Emoticon Control');

    $html .= qq~<script language='JavaScript'>
                <!--
                function PopUp(url, name, width,height,center,resize,scroll,posleft,postop) {
                    if (posleft != 0) { x = posleft }
                    if (postop  != 0) { y = postop  }

                    if (!scroll) { scroll = 1 }
                    if (!resize) { resize = 1 }

                    if ((parseInt (navigator.appVersion) >= 4 ) && (center)) {
                      X = (screen.width  - width ) / 2;
                      Y = (screen.height - height) / 2;
                    }
                    if (scroll != 0) { scroll = 1 }

                    var Win = window.open( url, name, 'width='+width+',height='+height+',top='+Y+',left='+X+',resizable='+resize+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no');
                }
                //-->
                </script>
                ~;

       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'emoticon',
                                        CODE  => 'edit'
                                      } );

    #+-----------------------------------
    $html .= $SKIN->section_header( TITLE => "Please Edit the emoticons below",TEXT=> qq~Or leave both fields blank to remove<br>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&AD=1&act=emoticon&CODE=viewall','HelpCard','200','400','0','1','1','1')">View All Emoticons</a>~ );
    $html .= qq~
    <tr>
    <td bgcolor='#EEEEEE' width='40%' align='left' valign='top'><font class='t'><b>Text</b></font></td>
    <td bgcolor='#EEEEEE' width='60%' align='left'><font class='t'><b>Insert into Clickable Table?      ::      Converted To</b></font></td>
    </tr>
    ~;

    my $cnt = 0;
    for my $e (split (/\|&\|/,$INFO->{'EMOTICONS'}) ) {
        my ($type, $image, $p_inc) = split (/\|/,$e);
        next unless $type and $image;

        my $click = "<select name='INC_$cnt' class='forminput' style='width:60px'>";
        $click .= $p_inc
                ? "<option value='1' selected>Yes</option><option value='0'>No</option>"
                : "<option value='1'>Yes</option><option value='0' selected>No</option>";

        $html .= qq~
            <tr>
            <td bgcolor='#FFFFFF' width='40%' align='left'><input type='text' name="TEXT_$cnt" value='$type' class='forminput'></td>
            <td bgcolor='#FFFFFF' width='60%' align='left' valign='middle' nowrap>$click</select>&nbsp;&nbsp;<input type='text' name='IMG_$cnt' value='$image' class='forminput' style='width:350px'>&nbsp;&nbsp<img src="$iB::INFO->{'EMOTICONS_URL'}/$image" border="0" valign="absmiddle"></td>
            </tr>
        ~;
        $cnt++;

    }

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply these changes' );


    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'STYLES', NAV_ONE => 'Emoticon Control', PRINT => $html);

}

sub doedit {
    my ($obj, $db) = @_;
    my $smilies;

    my $OLD = Boardinfo->new();

    my @emo_in = grep { /^TEXT_(\d+)$/ } $iB::CGI->param();

    for my $e (@emo_in) {
        $e    =~ m#^TEXT_(\d+)$#;
        my $n = $1;
        next unless defined $iB::IN{'TEXT_'.$n} and defined $iB::IN{'IMG_'.$n};
        $iB::IN{'INC_'.$n} ||= 0;
        $smilies .= $iB::IN{'TEXT_'.$n}.'|'.$iB::IN{'IMG_'.$n}.'|'.$iB::IN{'INC_'.$n}.'|&|';
    }

    $OLD->{'EMOTICONS'} = $smilies;

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->write_log( TITLE => 'Emoticons Changed');

    $ADMIN->static_screen( URL   => "act=emoticon",
                           TITLE => "Emoticons edited",
                           TEXT  => "The changes were successful"
                         );
}


##########################################################################################
#
# ADDING EMOTICONS
#
##########################################################################################

sub add {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Emoticon Control');
    $html .= qq~<script language='JavaScript'>
                <!--
                function PopUp(url, name, width,height,center,resize,scroll,posleft,postop) {
                    if (posleft != 0) { x = posleft }
                    if (postop  != 0) { y = postop  }

                    if (!scroll) { scroll = 1 }
                    if (!resize) { resize = 1 }

                    if ((parseInt (navigator.appVersion) >= 4 ) && (center)) {
                      X = (screen.width  - width ) / 2;
                      Y = (screen.height - height) / 2;
                    }
                    if (scroll != 0) { scroll = 1 }

                    var Win = window.open( url, name, 'width='+width+',height='+height+',top='+Y+',left='+X+',resizable='+resize+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no');
                }
                //-->
                </script>
                ~;
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'emoticon',
                                        CODE  => 'doadd'
                                      } );

    #+-----------------------------------

    $html .= $SKIN->section_header( TITLE => "Current Emoticons");

    my $all_emoticons = " ";
    for my $e (split (/\|&\|/,$INFO->{'EMOTICONS'}) ) {
        my ($type, $image, $p_inc) = split (/\|/,$e);
        next unless $type and $image;
        $all_emoticons .= qq![ $type &nbsp; <img src="$iB::INFO->{'EMOTICONS_URL'}/$image" border="0" valign="absmiddle"> ] !;
    }

    $html .= qq~
        <tr>
        <td bgcolor='#FFFFFF' colspan='2' align='middle'><font class='t'>$all_emoticons</font></td>
        </tr>
    ~;

    $html .= $SKIN->section_header( TITLE => "Please use the spaces to below to add emoticons",TEXT=> qq~You do not have to use all the fields.<br>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&AD=1&act=emoticon&CODE=viewall','HelpCard','200','400','0','1','1','1')">View All Emoticons</a>~);

    $html .= qq~
    <tr>
    <td bgcolor='#EEEEEE' width='40%' align='left' valign='top'><font class='t'><b>Text</b></font></td>
    <td bgcolor='#EEEEEE' width='60%' align='left'><font class='t'><b>Insert into Clickable Table?      ::      Converted To</b></font></td>
    </tr>
    ~;

    foreach my $cnt (0 .. 10) {
        $html .= qq~
            <tr>
            <td bgcolor='#FFFFFF' width='40%' align='left'><input type='text' name="TEXT_$cnt" class='forminput'></td>
            <td bgcolor='#FFFFFF' width='60%' align='left' valign='middle' nowrap><select name='INC_$cnt' class='forminput' style='width:60px'><option value='1' selected>Yes</option><option value='0'>No</option></select>&nbsp;&nbsp;<input type='text' name='IMG_$cnt' class='forminput' style='width:350px'></td>
            </tr>
        ~;
        $cnt++;
    }

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply these Emoticons' );


    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'STYLES', NAV_ONE => 'Emoticon Control', PRINT => $html);

}

sub viewall {
    my ($obj, $db) = @_;

    # View all smilies in the emoticons directory

    opendir BAGPUSS, $iB::INFO->{'HTML_DIR'} . 'emoticons' or die $!;
    my @stuffed_cat = grep  {    !/^\./  && !/\.html$/  } readdir BAGPUSS;
    closedir BAGPUSS;

    my $html  = qq~<html><head><title>All Emoticons</title></head>
                   <body>
                   <table cellspacing='1' cellpadding='5' border='1' style='border:1px solid black'>
                   <tr>
                    <td bgcolor='#666699' class='t' width='20%'><span style='color:white'>Image</span></td>
                    <td bgcolor='#666699' class='t' width='80%'><span style='color:white'>Filename</span></td>
                   </tr>
                 ~;

    for my $e (@stuffed_cat) {
        $html .= qq~<tr>
                    <td bgcolor='#FFFFFF' class='t' width='20%'><img src="$iB::INFO->{'EMOTICONS_URL'}/$e" border="0" valign="middle" alt=''></td>
                    <td bgcolor='#FFFFFF' class='t' width='80%'><input type='text' name='blah' value='$e' onMouseOver="this.focus()" onFocus="this.select()"></td>
                   </tr>
                 ~;
    }
       $html .= qq~</table>~;
       $ADMIN->Print( DB     => $db,
                      STD    => $std,
                      OUTPUT => $html,
                    );
}

sub doadd {
    my ($obj, $db) = @_;

    my $smilies;

    my $OLD = Boardinfo->new();

    my @emo_in = grep { /^TEXT_(\d+)$/ } $iB::CGI->param();

    for my $e (@emo_in) {
        $e    =~ m#^TEXT_(\d+)$#;
        my $n = $1;
        next unless defined $iB::IN{'TEXT_'.$n} and defined $iB::IN{'IMG_'.$n};
        $iB::IN{'INC_'.$n} ||= 0;
        $smilies .= $iB::IN{'TEXT_'.$n}.'|'.$iB::IN{'IMG_'.$n}.'|'.$iB::IN{'INC_'.$n}.'|&|';
    }

    $OLD->{'EMOTICONS'} .= $smilies;

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->write_log( TITLE => 'Emoticons Added');

    $ADMIN->static_screen( URL   => "act=emoticon",
                           TITLE => "Emoticons Add",
                           TEXT  => "The changes were successful"
                         );
}

##########################################################################################
#
# UPLOADING EMOTICONS by KEVaholic00
#
##########################################################################################

sub upload {
   my ($obj, $db) = @_;

   my $html  = $SKIN->title( TITLE => 'Emoticon Control');

  $html .= $SKIN->begin_table();
  $html .= $SKIN->form_start();
  $html .= $SKIN->hidden_fields( { act   => 'emoticon',
CODE  => 'upload2'
 } );

#+-----------------------------------

$html .= $SKIN->section_header( TITLE => "Options");

   $html .= $SKIN->td_input ( TEXT     => 'How many emoticons do you want to upload?',
                              NAME     => 'num_to_upload',
                              VALUE    => '5',
                              REQ      => 1
                            );

$html .= $SKIN->td_submit(   NAME => '', VALUE => 'Proceed' );

   $html .= $SKIN->form_end();
   $html .= $SKIN->end_table();

#+-----------------------------------

$ADMIN->Output( WHERE => 'STYLES', NAV_ONE => 'Emoticon Control', PRINT => $html);
}

sub upload2 {
   my ($obj, $db) = @_;

   my $html  = $SKIN->title( TITLE => 'Emoticon Control');

      $html .= $SKIN->begin_table();

#+-----------------------------------

   $html .= $SKIN->section_header( TITLE => "Upload Emoticons", TEXT => "You do not have to use all of the fields, nor do they have to be in any special order", COLSPAN => "5");

   $html .= qq~
   <script language='javascript'>
   <!--
   function AddEmoticonChanger(item,id) {
       if (item.selectedIndex == 0) {
           document.forms.theForm['addAfterUploadCode_'+id].disabled = false;
       } else {
           document.forms.theForm['addAfterUploadCode_'+id].disabled = true;
           document.forms.theForm['addAfterUploadCode_'+id].value = '';
       }
   }

   function PicturePreview(pic,id) {
       document.images['preview_'+id].src = pic;
       var Array = pic.split('\\\\');
       document.forms.theForm['uploadFileName_'+id].value = Array[Array.length-1];
   }
   -->
   </script>
   <tr>
   <td bgcolor='#EEEEEE' width='35%' align='left'><font class='t'><b>File</b></font></td>
   <td bgcolor='#EEEEEE' width='15%' align='left'><font class='t'><b>Preview</b></font></td>
   <td bgcolor='#EEEEEE' width='15%' align='left'><font class='t'><b>Destination</b></font></td>
   <td bgcolor='#EEEEEE' width='15%' align='left'><font class='t'><b>Add to Emoticons?</b></font></td>
   <td bgcolor='#EEEEEE' width='20%' align='left'><font class='t'><b>Emoticon Code</b></td>
   </tr>
   <form method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}' enctype='multipart/form-data' name='theForm'>
   <input type='hidden' name='s' value='$iB::SESSION'>
   <input type='hidden' name='CP' value='1'>
   <input type='hidden' name='act' value='emoticon'>
   <input type='hidden' name='CODE' value='upload3'>
   ~;

   for (1 .. $iB::IN{'num_to_upload'}) {
       $html .= qq~
   <tr>
   <td bgcolor='#FFFFFF' width='35%' align='left'><input type='file' size='20' name='uploadFile_$_' onchange="PicturePreview(this.value,'$_')"></td>
   <td bgcolor='#FFFFFF' width='15%' align='left'><img id='preview_$_' src='$INFO->{'IMAGES_URL'}/transparent15x15.gif' border='0' alt='Image Preview'></td>
   <td bgcolor='#FFFFFF' width='15%' align='left'><input type='text' size='10' name='uploadFileName_$_' value=''></td>
   <td bgcolor='#FFFFFF' width='15%' align='left'><select name='addAfterUpload_$_' onchange="AddEmoticonChanger(this,'$_')"><option value='1'>Yes<option value='0' selected>No</select></td>
   <td bgcolor='#FFFFFF' width='20%' align='left'><input type='text' size='10' name='addAfterUploadCode_$_' value='' disabled></td>
   </tr>
       ~;
   }

   $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Upload these emoticons', COLSPAN => '5');
   $html .= $SKIN->form_end();
   $html .= $SKIN->end_table();

#+-----------------------------------

$ADMIN->Output( WHERE => 'STYLES', NAV_ONE => 'Emoticon Control', PRINT => $html);
}

sub upload3 {
   my ($obj, $db) = @_;

   my (@success, @failure, $smilies);

   for (grep /^uploadFile\_/i, $iB::CGI->param) {
       s:^uploadFile\_::gi;

       my $uploadFile         = $iB::CGI->param("uploadFile_$_");
       next if $uploadFile eq "";

       my $uploadFileName     = $iB::CGI->param("uploadFileName_$_");
       my $addAfterUpload     = $iB::CGI->param("addAfterUpload_$_");
       my $addAfterUploadCode = $iB::CGI->param("addAfterUploadCode_$_");

       unless ($uploadFileName) {
           my @path        = split /[\\\/]/, $uploadFile;
           $uploadFileName = pop @path;
       }

       if (-e "$iB::INFO->{'HTML_DIR'}/emoticons/$uploadFileName") {
           push @failure, "$uploadFileName (File already exists)";
       } else {

           if (open OUTFILE, ">$iB::INFO->{'HTML_DIR'}/emoticons/$uploadFileName") {

               binmode OUTFILE;
               while (read($uploadFile, my $buffer, 2048)) {
                   print OUTFILE $buffer;
               }
               close OUTFILE;

               push @success, "$uploadFileName";

           } else {
               push @failure, "$uploadFileName (Error opening and/or writing to file: $!)";
           }

       }

       if ($addAfterUpload == 1 and $addAfterUploadCode) {
           $smilies .= $addAfterUploadCode . '|' . $uploadFileName . '|0|&|';
       }
   }

   if ($smilies) {
       my $OLD              = Boardinfo->new;
       $OLD->{'EMOTICONS'} .= $smilies;

       $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                            PKG_NAME => 'Boardinfo',
                            VALUES   => $OLD
                          );
   }

$ADMIN->write_log( TITLE => 'Emoticons Uploaded');

   my $text  = "The following emoticons were successfully uploaded:<br><br>";
      $text .= join '<br>', @success;
      $text .= "<br><br>And the following were not:<br><br>";
      $text .= join '<br>', @failure;

$ADMIN->static_screen( URL   => "act=emoticon&CODE=upload",
  TITLE => "Emoticons uploaded",
  TEXT  => $text
);
}

sub quickreply {
    my ($obj, $db) = @_;

    my $html  = $SKIN->title( TITLE => 'Emoticon Control');
       $html .= $SKIN->begin_table();
       $html .= $SKIN->form_start();
       $html .= $SKIN->hidden_fields( { act   => 'emoticon',
                                        CODE  => 'doquickreply'
                                      } );

    #+-----------------------------------

    $html .= $SKIN->section_header( TITLE => "Quick Reply Emoticons", TEXT=> "Please choose below which 11 emoticons will appear in the quick reply box");

    foreach my $cnt (1 .. 11) {

        my $thisEmote = (split /\|\&\|/, $INFO->{'QR_EMOTICONS'})[$cnt - 1];

        my $allemotes = undef;

        for my $e (sort { lc ((split /\|/, $a)[1]) cmp lc ((split /\|/, $b)[1]) } split (/\|&\|/, $INFO->{'EMOTICONS'})) {
            my ($type, $image, $p_inc) = split (/\|/, $e);

            next unless $type and $image;

            my $selected = $thisEmote eq $image
                           ?
                           ' selected'
                           :
                           '';

            $allemotes .= qq(<option value="$image"${selected}>$type ($image)</option>);
        }

        my $image2 = $thisEmote
                     ?
                     "$iB::INFO->{'EMOTICONS_URL'}/$thisEmote"
                     :
                     "$INFO->{'IMAGES_URL'}/transparent15x15.gif";

        $html .= qq~
            <tr>
            <td bgcolor='#FFFFFF' width='5%' align='left'><font class='t'><b>&nbsp;&nbsp;&nbsp;&nbsp;$cnt</b></font></td>
            <td bgcolor='#FFFFFF' width='95%' align='left' valign='middle' nowrap><select name='emot_$cnt' class='forminput' style='width:50%' onchange="if(this.options[this.selectedIndex].value!=''){document.images['preview_$cnt'].src='$iB::INFO->{'EMOTICONS_URL'}/'+this.options[this.selectedIndex].value}else{document.images['preview_$cnt'].src='$INFO->{'IMAGES_URL'}/transparent15x15.gif'}"><option value=''>Please choose...$allemotes</select>&nbsp;&nbsp;&nbsp;&nbsp;<img id='preview_$cnt' name='preview_$cnt' src='$image2' border='0' alt='Emoticon Preview'></td>
            </tr>
        ~;
        $cnt++;
    }

    $html .= $SKIN->td_submit(   NAME => '', VALUE => 'Apply these Emoticons' );


    $html .= $SKIN->form_end();
    $html .= $SKIN->end_table();

    #+-----------------------------------

    $ADMIN->Output( WHERE => 'STYLES', NAV_ONE => 'Emoticon Control', PRINT => $html);
}

sub doquickreply {
    my ($obj, $db) = @_;

    my $OLD = $INFO;

    $OLD->{'QR_EMOTICONS'} = join ('|&|', ( map { $iB::CGI->param($_) } ( grep /^emot\_/i, $iB::CGI->param ) ) );

    $ADMIN->make_module( FILE     => "Boardinfo.cgi",
                         PKG_NAME => 'Boardinfo',
                         VALUES   => $OLD
                       );

    $ADMIN->write_log( TITLE => 'Quick Reply Emoticons Edited');

    $ADMIN->static_screen( URL   => "act=emoticon&CODE=quickreply",
                           TITLE => "Quick Reply Emoticons Edited",
                           TEXT  => "The changes were successful"
                         );
}

sub process {
    my ($obj, $db) = @_;

    my $CodeNo = $iB::IN{'CODE'};

    my %Mode = ( 'edit'        => \&doedit,
                 'add'         => \&add,
                 'doadd'       => \&doadd,
                 'upload'      => \&upload,
                 'upload2'     => \&upload2,
                 'upload3'     => \&upload3,
                 'viewall'     => \&viewall,
                 'quickreply'  => \&quickreply,
                 'doquickreply'=> \&doquickreply,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj,$db) : splash($obj,$db);
}

1;
