package Profile;
use strict;
use Time::Local;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Profile: Member profile editing and viewing functions
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
}

my $std       = FUNC::STD->new();
my $mem       = FUNC::Member->new();
my $output    = FUNC::Output->new();
my $txt       = iTextparser->new();
my $mail      = FUNC::Mailer->new();
$Profile::lang = $std->LoadLanguage('ProfileWords');

require $iB::SKIN->{'DIR'} . '/ProfileView.pm' or die $!;

sub new {
    my $pkg = shift;
    my $obj = { 'MEMBER' => $iB::MEMBER };
    bless $obj, $pkg;
    return $obj;
}

sub DoProfile {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'sig_too_long'
               ) if length($iB::CGI->param('Post')) > $iB::INFO->{'MAX_SIG_LENGTH'};

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'int_too_long'
               ) if length($iB::CGI->param('Interests')) > $iB::INFO->{'MAX_INTEREST_LENGTH'};

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'loc_too_long'
               ) if length($iB::CGI->param('Location')) > $iB::INFO->{'MAX_LOCATION_LENGTH'};

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'web_too_long'
               ) if length($iB::IN{'WebSite'}) > 120;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'photo_too_long'
               ) if length($iB::IN{'Photo'}) > 120;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'not_icq_number'
               ) if  $iB::IN{'ICQNumber'} && $iB::IN{'ICQNumber'} !~ m#\A\d{1,25}\Z#;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'not_aol_name'
               ) if $iB::IN{'AOLName'} && $iB::IN{'AOLName'} !~ m#\A[\d\w\_\-\s]+\Z#;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'not_yahoo_name'
               ) if $iB::IN{'YahooName'} && $iB::IN{'YahooName'} !~ m#\A[\d\w\_\-\s]+\Z#;

    unless ($iB::INFO->{'ALLOW_DYNAMIC_IMG'}) {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     STD     => $std,
                     MESSAGE => 'not_url_photo'
                    ) if $iB::IN{'Photo'} =~ /([\?\&\;])/;
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     STD     => $std,
                     MESSAGE => 'not_url_photo'
                    ) if $iB::IN{'Photo'} =~ /javascript(\:|\s)/i;
    }

    my $c_count;

    for (qw/day month year/) {
        ++$c_count if $iB::IN{$_};
    }

    if ($c_count and $c_count != 3) {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     STD     => $std,
                     MESSAGE => 'calendar_not_all'
                    );
    }

    $obj->{'MEMBER'}->{'GENDER'}        = $iB::IN{'SEX'};
    $obj->{'MEMBER'}->{'MEMBER_NAME_R'} = $iB::IN{'MEMBER_NAME_R'};
    $obj->{'MEMBER'}->{'WEBSITE'}       = $iB::IN{'WebSite'};
    $obj->{'MEMBER'}->{'ICQNUMBER'}     = $iB::IN{'ICQNumber'};
    $obj->{'MEMBER'}->{'AOLNAME'}       = $iB::IN{'AOLName'};
    $obj->{'MEMBER'}->{'YAHOONAME'}     = $iB::IN{'YahooName'};
    $obj->{'MEMBER'}->{'MSNNAME'}       = $iB::IN{'MSNName'};
    $obj->{'MEMBER'}->{'LOCATION'}      = $txt->Convert_for_db( TEXT    => $iB::IN{'Location'},
                                                                SMILIES => 0,
                                                                IB_CODE => 0,
                                                                HTML    => 0,
                                                              );
    $obj->{'MEMBER'}->{'INTERESTS'}    = $txt->Convert_for_db( TEXT    => $iB::IN{'Interests'},
                                                               SMILIES => 0,
                                                               IB_CODE => 0,
                                                               HTML    => 0,
                                                             );

    # Although we don't want to convert the signature to pure iBCode using iTextparser,
    # we do want to check for errors, so we simply use a dummy value with the signatures
    # information to collect any errors.
    $txt->{ERROR} = undef;
    my $test = $txt->Convert_for_db( TEXT    => $iB::IN{'Post'},
                                     SMILIES => $iB::INFO->{'SIG_ALLOW_EMOTICONS'},
                                     IB_CODE => $iB::INFO->{'SIG_ALLOW_IBC'},
                                     HTML    => $iB::INFO->{'SIG_ALLOW_HTML'},
                                     SIG     => 1,
                                     DB      => $db,
                                   );

    # If there are any errors, print them.
    if ($txt->{ERROR}) {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     STD     => $std,
                     MESSAGE => $txt->{ERROR}
                   );
    }


    $obj->{'MEMBER'}->{'SIGNATURE'}     = $test;
    $obj->{'MEMBER'}->{'PHOTO'}         = $iB::IN{'Photo'};
    $obj->{'MEMBER'}->{'LAST_UPDATE'}   = time;

    # Member title stuff

    if (
           ( ($iB::INFO->{POST_TITLECHANGE}) and ($obj->{'MEMBER'}->{'MEMBER_POSTS'} > $iB::INFO->{POST_TITLECHANGE}) )
              and
           ( $iB::IN{'member_title'} )
       )
    {
        $obj->{'MEMBER'}->{'MEMBER_TITLE'} = $iB::IN{'member_title'};
    }

    $obj->{'MEMBER'}->{'POST_FONT_COLOR'} = $iB::IN{'POST_FONT_COLOR'};

    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { WEBSITE       => $obj->{'MEMBER'}->{'WEBSITE'},
                               ICQNUMBER     => $obj->{'MEMBER'}->{'ICQNUMBER'},
                               AOLNAME       => $obj->{'MEMBER'}->{'AOLNAME'},
                               YAHOONAME     => $obj->{'MEMBER'}->{'YAHOONAME'},
                               MSNNAME       => $obj->{'MEMBER'}->{'MSNNAME'},
                               LOCATION      => $obj->{'MEMBER'}->{'LOCATION'},
                               INTERESTS     => $obj->{'MEMBER'}->{'INTERESTS'},
                               SIGNATURE     => $obj->{'MEMBER'}->{'SIGNATURE'},
                               PHOTO         => $obj->{'MEMBER'}->{'PHOTO'},
                               LAST_UPDATE   => $obj->{'MEMBER'}->{'LAST_UPDATE'},
                               MEMBER_TITLE  => $obj->{'MEMBER'}->{'MEMBER_TITLE'},
                               GENDER        => $obj->{'MEMBER'}->{'GENDER'},
                               MEMBER_NAME_R => $obj->{'MEMBER'}->{'MEMBER_NAME_R'},
                               POST_FONT_COLOR => $obj->{'MEMBER'}->{'POST_FONT_COLOR'},
                             }
                );

    my $calendar_info = $db->select( TABLE  => 'calendar',
                                     KEY    => $obj->{'MEMBER'}->{'MEMBER_ID'},
                                   );

    if ($calendar_info->{MEMBER_ID}) {
        #Update existing
        $db->update( TABLE  => 'calendar',
                     KEY    => $obj->{'MEMBER'}->{'MEMBER_ID'},
                     VALUES => {
                                 DAY          => $iB::IN{'day'},
                                 MONTH        => $iB::IN{'month'},
                                 YEAR         => $iB::IN{'year'},
                               }
                   );
    } else {
        #Create new entry
        $db->insert( TABLE  => 'calendar',
                     VALUES => {
                                 MEMBER_ID    => $obj->{'MEMBER'}->{'MEMBER_ID'},
                                 MEMBER_NAME  => $obj->{'MEMBER'}->{'MEMBER_NAME'},
                                 DAY          => $iB::IN{'day'},
                                 MONTH        => $iB::IN{'month'},
                                 YEAR         => $iB::IN{'year'},
                                 TIME_ADJUST  => "",
                                },
                   );
    }


    $output->redirect_screen( TEXT => $Profile::lang->{'profile_edited'}, URL => 'act=UserCP;CODE=01');
}



sub AddAvatar_installed {
    my ($obj, $db) = @_;

    $obj->AddAvatar_url($db) if defined $iB::IN{'URL'};

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 1,
                 MESSAGE =>'no_avatar_selected'
               ) unless $iB::IN{'useravatar'};

    my $ava_url;
    if ($iB::MEMBER->{'MEMBER_AVADIR'}) {
        $ava_url = $iB::MEMBER->{'MEMBER_AVADIR'} . "/";
    }

    opendir AVATARS, $iB::INFO->{'HTML_DIR'} . 'avatars/' . $ava_url or die $!;
    my %avatars =  map   {   $_ => 1  }
                   grep  {   !/^\./   } readdir AVATARS;
    closedir AVATARS;

    $iB::IN{'useravatar'} = 'noavatar' if $iB::IN{'useravatar'} eq '*';

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 1,
                 MESSAGE =>'no_avatar_selected'
               ) unless exists $avatars{ $iB::IN{'useravatar'} } or $iB::IN{'useravatar'} eq 'noavatar';

    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { MEMBER_AVATAR  => $ava_url . $iB::IN{'useravatar'} }
                );

    $output->redirect_screen( TEXT => $Profile::lang->{'profile_edited'}, URL => 'act=UserCP;CODE=01');

}


sub AddAvatar_url {
    my ($obj, $db) = @_;

    $obj->AddAvatar_installed($db) unless defined $iB::IN{'URL'};

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 1,
                 MESSAGE =>'no_avatar_selected'
               ) unless $iB::IN{'useravatar'};

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 1,
                 MESSAGE => 'avatar_invalid_url'
               ) unless $iB::IN{'useravatar'} =~ m#\Ahttp\://#i;

    my @valid_ext   = split /\|/, $iB::INFO->{'AV_EXT'};
    my @avatar_url  = split /\//, $iB::IN{'useravatar'};
    my $avatar_name = $avatar_url[$#avatar_url];

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 1,
                 MESSAGE => 'avatar_invalid_ext'
               ) unless $avatar_name =~ m#\.{1,1}($iB::INFO->{'AV_EXT'})$#ig;

    my $entered_ext = (split /\./, $avatar_name)[1];

    my $check;
    for (@valid_ext) {
        $check = 1 if $_ eq $entered_ext;
    }

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 1,
                 MESSAGE => 'avatar_invalid_ext'
               ) unless $check == 1;

    ($iB::INFO->{'AV_WIDTH'},$iB::INFO->{'AV_HEIGHT'}) = split ("x", $iB::INFO->{'AV_DIMS'});

    $iB::IN{'Avatar_width'}   = $iB::IN{'Avatar_width'}  > $iB::INFO->{'AV_WIDTH'}  ? $iB::INFO->{'AV_WIDTH'}  : $iB::IN{'Avatar_width'};
    $iB::IN{'Avatar_height'}  = $iB::IN{'Avatar_height'} > $iB::INFO->{'AV_HEIGHT'} ? $iB::INFO->{'AV_HEIGHT'} : $iB::IN{'Avatar_height'};
    $iB::IN{'Avatar_width'}   = $iB::INFO->{'AV_WIDTH'}   unless $iB::IN{'Avatar_width'};
    $iB::IN{'Avatar_height'}  = $iB::INFO->{'AV_HEIGHT'}  unless $iB::IN{'Avatar_height'};

    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { MEMBER_AVATAR  => $iB::IN{'useravatar'},
                               AVATAR_DIMS    => $iB::IN{'Avatar_width'}."x".$iB::IN{'Avatar_height'},
                             }
                );

    $output->redirect_screen( TEXT => $Profile::lang->{'profile_edited'}, URL => 'act=UserCP;CODE=01');
}


sub DoEmail {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 1,
                 MESSAGE => 'end_subs_value'
               ) unless $iB::IN{'end_subs'};

    for (qw[hide_email admin_send send_full_msg pm_reminder]) {
        $iB::IN{$_} = 0 unless $iB::IN{$_};
    }


    $iB::IN{'hide_email'}    = $std->IsNumber($iB::IN{'hide_email'});
    $iB::IN{'admin_send'}    = $std->IsNumber($iB::IN{'admin_send'});
    $iB::IN{'send_full_msg'} = $std->IsNumber($iB::IN{'send_full_msg'});
    $iB::IN{'pm_reminder'}   = $std->IsNumber($iB::IN{'pm_reminder'});
    $iB::IN{'end_subs'}      = $std->IsNumber($iB::IN{'end_subs'});
    $iB::IN{'send_once'}      = $std->IsNumber($iB::IN{'send_once'});

    # PM_REMINDER is a little special.
    # It has three characters, typically 1&1, 0&0, 1&0, 0&1
    # The first byte is set to 1 if we want a PM reminder
    # The last byte is set to 1 if we want a JS pop up window telling us
    # We have a new message.

    my $js_toggle = (split/&/,$obj->{'MEMBER'}->{'PM_REMINDER'})[1]; #Get the JS toggle byte

    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { HIDE_EMAIL         => $iB::IN{'hide_email'},
                               EMAIL_FULL_POST    => "$iB::IN{'send_full_msg'}&$iB::IN{'send_once'}",
                               PM_REMINDER        => $iB::IN{'pm_reminder'}.'&'.$js_toggle,
                               CANCEL_SUBS        => $iB::IN{'end_subs'},
                               ALLOW_ADMIN_EMAILS => $iB::IN{'admin_send'},
                             }
                );

    $output->redirect_screen( TEXT => $Profile::lang->{'profile_edited'}, URL => 'act=UserCP;CODE=00');
}



sub DoSettings {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'poss_hack_attempt'
               ) unless $iB::IN{'u_timezone'} =~ /[\-\d]/;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'poss_hack_attempt'
               ) if $iB::IN{'u_language'} =~ /\.\./;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'poss_hack_attempt'
               ) if $iB::IN{'u_skin'} =~ /\.\./;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'poss_hack_attempt'
               ) unless $iB::IN{'VIEW_IMG'} =~ /\d{1}/;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'poss_hack_attempt'
               ) unless $iB::IN{'VIEW_SIGS'} =~ /\d{1}/;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'poss_hack_attempt'
               ) unless $iB::IN{'VIEW_AVS'} =~ /\d{1}/;

    # PM_REMINDER is a little special.
    # It has three characters, typically 1&1, 0&0, 1&0, 0&1
    # The first byte is set to 1 if we want a PM reminder
    # The last byte is set to 1 if we want a JS pop up window telling us
    # We have a new message.

    my $email_pm = (split/&/,$obj->{'MEMBER'}->{'PM_REMINDER'})[0]; #Get the email setting


    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { TIME_ADJUST      => $iB::IN{'u_timezone'},
                               LANGUAGE         => $iB::IN{'u_language'},
                               MEMBER_SKIN      => $iB::IN{'u_skin'},
                               VIEW_AVS         => $iB::IN{'VIEW_AVS'},
                               VIEW_SIGS        => $iB::IN{'VIEW_SIGS'},
                               VIEW_IMG         => $iB::IN{'VIEW_IMG'},
                               PM_REMINDER      => $email_pm.'&'.$iB::IN{'DO_POPUP'}
                             }
                );
    # Look for entry..
    my $calendar_info = $db->select( TABLE  => 'calendar',
                                     KEY    => $obj->{'MEMBER'}->{'MEMBER_ID'},
                                   );

    if ($calendar_info->{MEMBER_ID}) {
        #Update existing
        $db->update( TABLE  => 'calendar',
                     KEY    => $obj->{'MEMBER'}->{'MEMBER_ID'},
                     VALUES => { TIME_ADJUST  => $iB::IN{'u_timezone'}, }
                   );
    } else {
        #Create new entry
        $db->insert( TABLE  => 'calendar',
                     VALUES => {
                                 MEMBER_ID    => $obj->{'MEMBER'}->{'MEMBER_ID'},
                                 MEMBER_NAME  => $obj->{'MEMBER'}->{'MEMBER_NAME'},
                                 DAY          => 0,
                                 MONTH        => 0,
                                 YEAR         => 0,
                                 TIME_ADJUST  => $iB::IN{'u_timezone'},
                                },
                   );
    }
    # Set the skin cookie..
    push @{$iB::COOKIES_OUT}, $iB::CGI->cookie( -name => $iB::INFO->{'COOKIE_ID'}.'skin', -value => $iB::IN{'u_skin'}, -expires => '+1y', -path => $iB::INFO->{'COOKIE_PATH'}, -domain => $iB::INFO->{'COOKIE_DOMAIN'} );
    # Set the language cookie..
    push @{$iB::COOKIES_OUT}, $iB::CGI->cookie( -name => $iB::INFO->{'COOKIE_ID'}.'lang', -value => $iB::IN{'u_language'}, -expires => '+1y', -path => $iB::INFO->{'COOKIE_PATH'}, -domain => $iB::INFO->{'COOKIE_DOMAIN'} );

    $output->redirect_screen( TEXT => $Profile::lang->{'profile_edited'}, URL => 'act=UserCP;CODE=04');
}




sub DoChangeAccount {
    my ($obj, $db) = @_;
    $iB::IN{'s_email'} ? $obj->do_email_change($db) : $obj->change_pass($db);
}



sub do_email_change ($) {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'invalid_email'
               ) unless length($iB::IN{'u_email'}) > 5;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'invalid_email'
               ) unless $std->CheckEmail($iB::IN{'u_email'});

    unless ($iB::INFO->{'ALLOW_MULT_EMAIL'}) {
        my $email_check = $mem->Check_Mem_Email( DB =>$db, EMAIL =>$iB::IN{'u_email'} );
        $std->Error( DB      => $db,
                     STD     => $std,
                     LEVEL   => 1,
                     MESSAGE => "email_exists"
                   ) if $email_check->{'MEMBER_EMAIL'};
    }

    $iB::INFO->{'VALIDATE_REGISTER'} ? $obj->_verify_mail($db, $iB::IN{'u_email'})
                                     : $obj->_reset_email($db, $iB::IN{'u_email'});
}

sub _verify_mail {
    my ($obj, $db, $new_mail) = @_;
    my $unique_id = $mail->my_gen_id();
    my $time      = time;

    my $new_id = $db->insert( TABLE   => 'authorisation',
                              VALUES  => {  UNIQUE_CODE   =>  $unique_id,
                                            DATE_ENTERED  =>  $time,
                                            MEMBER_ID     =>  $iB::MEMBER->{'MEMBER_ID'},
                                            MEMBER_NAME   =>  $iB::MEMBER->{'MEMBER_NAME'},
                                            THIS_IP       =>  $iB::IN{'IP_ADDRESS'},
                                            MEMBER_EMAIL  =>  $new_mail,
                                            '_WHERE'      =>  'email_change',

                                            MEMBER_GROUP  =>  $iB::MEMBER->{'MEMBER_GROUP'},
                                         },
                           );

    my $message = $mail->parse_template( ID     => 'E_CH',
                                         DB     => $db,
                                         VALUES => { THE_LINK    =>  "$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile&CODE=01&ID=$time&SID=$unique_id&EM=$new_mail",
                                                     MEMBER_NAME =>  $iB::MEMBER->{'MEMBER_NAME'},
                                                     UNTIL       =>  $iB::INFO->{'AUTHORISE_PRUNE'}
                                                   }
                                       );

    $mail->Send( TO      => $new_mail,
                 FROM    => '',
                 SUBJECT => $Profile::lang->{'change_email'},
                 MESSAGE => $message
               );

    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { MEMBER_GROUP  => $iB::INFO->{'AUTHORISE_GROUP'} }
                );

    my $print = ProfileView::show_authorise($iB::MEMBER, $new_mail);

    $output->print_ikonboard( DB      => $db,
                              STD     => $std,
                              TITLE   => "iB::".$Profile::lang->{'change_email'},
                              NAV_ONE => "$Profile::lang->{'change_email'}",
                              OUTPUT  => $print,
                            );

}

sub _reset_email {
    my ($obj, $db, $new_mail) = @_;
    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { MEMBER_EMAIL  => $new_mail }
                );

    $output->redirect_screen( TEXT => $Profile::lang->{'profile_edited'}, URL => 'act=UserCP;CODE=05');
}


sub validate {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 LEVEL   =>'1',
                 MESSAGE =>'data_incorrect'
               ) unless $iB::IN{'SID'}=~ /[\d\w]/;


    my $time = time;
    my $oldtime = $iB::INFO->{'AUTHORISE_PRUNE'} * 60 * 60 * 24;

    my $db_entry = $db->query( TABLE   => 'authorisation',
                               MATCH   => 'ONE',
                               WHERE   => qq[_WHERE eq "email_change" and UNIQUE_CODE eq "$iB::IN{'SID'}"],
                             );

    $std->Error(DB=>$db,LEVEL=>'1', MESSAGE=>'request_passed') unless $db_entry;

    my $member = $db->select( TABLE    => 'member_profiles',
                              KEY      => $db_entry->{'MEMBER_ID'},
                              ID       => $db_entry->{'MEMBER_ID'},
                            );

    $std->Error(DB=>$db,LEVEL=>'1', MESSAGE=>'request_error') unless $member->{'MEMBER_NAME'};

    $db->update(              TABLE    => 'member_profiles',
                              KEY      => $db_entry->{'MEMBER_ID'},
                              ID       => $db_entry->{'MEMBER_ID'},
                              VALUES   => { MEMBER_GROUP  => $db_entry->{'MEMBER_GROUP'},
                                            MEMBER_EMAIL  => $db_entry->{'MEMBER_EMAIL'},
                                          }
               );

    $db->delete(             TABLE     => 'authorisation',
                             KEY       => $db_entry->{'ID'},
               );


    $db->update_index(  TABLE     => 'member_profiles',
                        INDEX_KEY => 'MEMBER_EMAIL',
                        R_KEY     => $member->{'MEMBER_EMAIL'},
                        REMOVE    => 1
                     );

    #Insert the new

    $db_entry->{'MEMBER_EMAIL'} = lc($db_entry->{'MEMBER_EMAIL'});

    $db->update_index(  TABLE     => 'member_profiles',
                        INDEX_KEY => 'MEMBER_EMAIL',
                        R_KEY     => $db_entry->{'MEMBER_EMAIL'},
                        R_VALUE   => $db_entry->{'MEMBER_ID'}
                     );

    $output->redirect_screen( TEXT => $Profile::lang->{'profile_edited'}, URL => 'act=UserCP;CODE=05');
}





sub change_pass ($) {
    my ($obj, $db) = @_;

    my $new_pass = $mem->MD5($obj->{'MEMBER'}->{'MEMBER_NAME'}, $iB::IN{'u_new_pass_1'});

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'pass_blank'
               ) unless $iB::IN{'u_o_pass'};

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'pass_blank'
               ) unless $iB::IN{'u_new_pass_1'};

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'pass_blank'
               ) unless $iB::IN{'u_new_pass_2'};

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'pass_too_short'
               ) unless length($iB::IN{'u_new_pass_1'}) >= 5;

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'pass_no_match'
               ) unless $iB::IN{'u_new_pass_1'} eq $iB::IN{'u_new_pass_2'};

    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 5,
                 MESSAGE => 'wrong_pass'
               ) unless $mem->MD5($obj->{'MEMBER'}->{'MEMBER_NAME'},$iB::IN{'u_o_pass'}) eq $obj->{'MEMBER'}->{'MEMBER_PASSWORD'};

    $db->update( TABLE    => 'member_profiles',
                 ID       => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 KEY      => $obj->{'MEMBER'}->{'MEMBER_ID'},
                 VALUES   => { MEMBER_PASSWORD  => $new_pass }
                );

    $db->update( TABLE  => 'active_sessions',
                 KEY    => $iB::SESSION,
                 VALUES => { MEMBER_PASSWORD  => $new_pass  }
               );

    push @{$iB::COOKIES_OUT}, $iB::CGI->cookie( NAME => $iB::INFO->{'COOKIE_ID'}.'iBPassWord', VALUE => $new_pass, EXPIRES => '+30d', PATH => $iB::INFO->{'COOKIE_PATH'});

    $output->redirect_screen( TEXT => $Profile::lang->{'profile_edited'}, URL => 'act=UserCP;CODE=05');
}



sub get_daily ($) {
   my ($obj, $member) = @_;
   return unless $member->{'MEMBER_POSTS'};
   my $diff = time - $member->{'MEMBER_JOINED'};
   my $days = ($diff / 3600) / 24;
   $days = 1 if $days < 1;
   return sprintf '%.2f', $member->{'MEMBER_POSTS'} / $days;
}


sub ShowProfile {
    my ($obj, $db) = @_;
    $std->Error( DB      => $db,                 STD     => $std,                LEVEL   => 1,               MESSAGE =>'no_user'               ) unless $iB::IN{'MID'};
    $std->Error( DB      => $db,                 STD     => $std,                LEVEL   => 1,               MESSAGE =>'incorrect_use'             ) unless $iB::IN{'MID'} =~ /^(?:[\d\-\_]+)$/;
    # Can we view others profile information??
    if ($iB::IN{'MID'} ne $iB::MEMBER->{'MEMBER_ID'}) {
    unless ($iB::MEMBER_GROUP->{'MEM_INFO'}) {
            $std->Error( LEVEL => 1, DB => $db, MESSAGE => 'cant_use_feature');
        }
    }
    my $member = $db->select( TABLE  => 'member_profiles',
                              ID     => $iB::IN{'MID'},
                              KEY    => $iB::IN{'MID'},
                            );
    $std->Error( DB      => $db,
                 STD     => $std,
                 LEVEL   => 1,
                 MESSAGE =>'profile_guest'
               ) unless $member->{'MEMBER_ID'};
    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE', 'TEAM_ICON'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );
    my %temp_table = map { $_->{'ID'} => { TITLE  => $_->{'TITLE'},
                                      ICON   => $_->{'TEAM_ICON'}
                                         }
                         } @{$mem_groups};
    $obj->{'group_table'} = \%temp_table;
    if ($iB::INFO->{'MEMBER_NAME_SP'}){
        $member->{'MEMBER_NAME_R'} = $member->{'MEMBER_NAME_R'};
    } else {
        $member->{'MEMBER_NAME_R'} = $Profile::lang->{'adminnotshow'};
    }
    $member->{'MEMBER_TITLE'} = $member->{'MEMBER_TITLE'};
     my $mem_num = $db->query( TABLE      => 'member_profiles',

                               WHERE      => "MEMBER_JOINED < $member->{'MEMBER_JOINED'}",
                               COLUMNS    => ['MEMBER_GROUP'],
                               SORT_KEY   => "MEMBER_JOINED",
                               SORT_BY    => 'A-Z',
                               MATCH      => 'WITH COUNT',
                             );
      $member->{'MEMBER_NUM'} = $db->matched_records + 1;
    for (qw[personal_header send_pm add_book hidden_email send_email]) {
        $Profile::lang->{$_} =~ s!<# NAME #>!$member->{'MEMBER_NAME'}!g;
    }

    my $mem_titles = $db->query( TABLE      => 'member_titles',
                                 COLUMNS    => ['ID', 'TITLE', 'POSTS', 'PIPS'],
                                 SORT_KEY   => 'POSTS',
                                 SORT_BY    => 'Z-A',
                               );

    unless( $obj->{'group_table'}->{ $member->{'MEMBER_GROUP'} }->{'ICON'} ) {
      for my $m (@{$mem_titles}) {
        if ($member->{'MEMBER_POSTS'} >= $m->{'POSTS'}) {
          $member->{'MEMBER_PIPS_IMG'} = qq!$iB::SKIN->{'A_STAR'}! x $m->{'PIPS'};
          last;
        }
      }
    } else {
      $member->{'MEMBER_PIPS_IMG'} = qq!<img src="$iB::INFO->{'TEAM_ICON_URL'}/$obj->{'group_table'}->{ $member->{'MEMBER_GROUP'} }->{'ICON'}" border='0'>!;
    }


    $member->{'MEMBER_PASSWORD'} = undef;

    my ($last_forum, $last_topic, $last_time) = split /-/, $member->{'LAST_POST'};
    if ($last_forum) {
        my $this_last = $db->select( TABLE  => 'forum_topics',
                                     ID     => $last_forum,
                                     KEY    => $last_topic
                                   );

        my $this_forum = $db->select( TABLE => 'forum_info',
                                      KEY   => $last_forum
                                    );

        $member->{'LAST'} = $Profile::lang->{'last_post_text'};
        $member->{'LAST'} =~ s!<# FORUM #>!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF;f=$last_forum">$this_forum->{'FORUM_NAME'}</a>!ig;
        $member->{'LAST'} =~ s!<# MEMBER_NAME #>!$member->{'MEMBER_NAME'}!ig;
        $member->{'LAST'} =~ s!<# TOPIC #>!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$last_forum;t=$last_topic">$this_last->{'TOPIC_TITLE'}</a>!ig;
        $member->{'LAST'} =~ s!<# TIME #>!$std->get_date(TIME=>$last_time,METHOD=>'LONG')!eig;
        if ($this_forum->{'FORUM_VIEW_THREADS'} ne '*') {
            $member->{'LAST'} =  '' unless  grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$this_forum->{'FORUM_VIEW_THREADS'});
        }
    } else {
        $member->{'LAST'} = $Profile::lang->{'last_post_none'};
        $member->{'LAST'} =~ s!<# MEMBER_NAME #>!$member->{'MEMBER_NAME'}!ig;
    }

    $member->{'PHOTO'}        = $member->{'PHOTO'}
                              ? qq!<img src='$member->{'PHOTO'}' border='1' alt=''>!
                              : "$Profile::lang->{no_photo}";

    unless ($iB::INFO->{'ALLOW_DYNAMIC_IMG'}) {
        $member->{'PHOTO'} = "$Profile::lang->{no_photo}" if $member->{'PHOTO'} =~ /([\?\&\;])/;
        $member->{'PHOTO'} = "$Profile::lang->{no_photo}" if $member->{'PHOTO'} =~ /javascript(\:|\s)/i;
    }

    $member->{'MEMBER_EMAIL'}
        =  $member->{'HIDE_EMAIL'} ? $Profile::lang->{'hidden_email'}
                                   : qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Mail;CODE=00;MID=$member->{'MEMBER_ID'}">$Profile::lang->{'send_email'}</a>];


    $member->{'WEBSITE'}      = ($member->{'WEBSITE'} and $member->{'WEBSITE'} =~ m#\Ahttp://.+?\S\Z#i)
                              ? (qq[<a href='$member->{'WEBSITE'}' target='_blank'>$member->{'WEBSITE'}</a>])
                              : ('');

    $member->{'POST_AVERAGE'} = $member->{'MEMBER_POSTS'} > 0
                              ? $obj->get_daily($member)
                              : $Profile::lang->{'no_posts'};

    $member->{'MEMBER_POSTS'} = $Profile::lang->{'no_posts'} unless $member->{'MEMBER_POSTS'};

    $member->{'LAST_UPDATE'} = $member->{'MEMBER_JOINED'} unless $member->{'LAST_UPDATE'};

    $member->{'$days'} = int((time - $member->{'MEMBER_JOINED'}) / 86400);

    $member->{'$days'} = int((time - $member->{'MEMBER_JOINED'}) / 86400);

    $member->{'MEMBER_JOINED'}= $std->get_date( TIME  => $member->{'MEMBER_JOINED'},
                                                METHOD => 'LONG'
                                              );

    $member->{'LAST_UPDATE'}  = $std->get_date( TIME   => $member->{'LAST_UPDATE'},
                                                METHOD => 'LONG'
                                              );

if ($member->{'LAST_ACTIVITY'} ne 0) {
    $member->{'LAST_LOG_IN'} = $std->get_date( TIME   => $member->{'LAST_ACTIVITY'},
                                                METHOD => 'LONG'
                                              );
}
else {
    $member->{'LAST_LOG_IN'} = '';
}

    $member->{'MEMBER_GROUP'} = $obj->{'group_table'}->{ $member->{'MEMBER_GROUP'} };
    unless ($member->{'GENDER'} == 0 or $member->{'GENDER'} == '') {
        $member->{'GENDER'} = $member->{'GENDER'} == 1 ? $Profile::lang->{'Male'} : $Profile::lang->{'Female'};
    }

    if ($member->{'MEMBER_AVATAR'} eq "noavatar") {
                    $member->{'AVATAR'} = $Profile::lang->{'noavatar'};
                   }
            else {
                    my ($a_width   , $a_height)  = split "x", $iB::INFO->{'AV_DIMS'};
                    my ($d_a_width, $d_a_height) = split "x", $iB::INFO->{'DEF_AV_DIMS'};
                    my ($width  , $height)   = split "x", $member->{'AVATAR_DIMS'};
                    $member->{'AVATAR'} = "<img src='$iB::INFO->{'AVATARS_URL'}/$member->{'MEMBER_AVATAR'}' border='0' width='$d_a_width' height='$d_a_height' alt='Avatar'>";
                   }
            if ($member->{'MEMBER_AVATAR'} =~ m#\Ahttp\://#i){
              unless ($member->{'MEMBER_AVATAR'} =~ m#\.swf\Z#i) {
              my ($a_width   , $a_height)  = split "x", $iB::INFO->{'AV_DIMS'};
                    my ($width  , $height)   = split "x", $member->{'AVATAR_DIMS'};
                    $height ||= $a_height;
                    $width  ||= $a_width;
                    $member->{'AVATAR'} = "<img src='$member->{'MEMBER_AVATAR'}' border='0' width='$width' height='$height' alt='Avatar'>";
                   }
             }
            if ($member->{'MEMBER_AVATAR'} =~ m#\.swf\Z#i) {
              my ($a_width   , $a_height)  = split "x", $iB::INFO->{'AV_DIMS'};
                    my ($width  , $height)   = split "x", $member->{'AVATAR_DIMS'};
                    $height ||= $a_height;
                    $width  ||= $a_width;
                    $member->{'AVATAR'} = qq|<OBJECT CLASSID="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" WIDTH=$width HEIGHT=$height><PARAM NAME=MOVIE VALUE=$member->{'MEMBER_AVATAR'}><PARAM NAME=PLAY VALUE=TRUE><PARAM NAME=LOOP VALUE=TRUE><PARAM NAME=QUALITY VALUE=HIGH><EMBED SRC=$member->{'MEMBER_AVATAR'} WIDTH=$width HEIGHT=$height PLAY=TRUE LOOP=TRUE QUALITY=HIGH></EMBED></OBJECT>|;
                   }

    $member->{'SEARCH'} = qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Search;CODE=01;keywords=$member->{'MEMBER_NAME'};type=name;forums=all;search_in=all;prune=$iB::INFO->{'USER_POST_SEARCH_SPAN'}" title="$Topic::lang->{'search'}"><b>$Profile::lang->{'show_posts'} $member->{'MEMBER_NAME'}</b></a>];

    for (keys %{$member}) {
        $member->{$_} = $Profile::lang->{'no_information'} unless $member->{$_}
    }


 # Member Ratings.
   if ($iB::MEMBER->{'MEMBER_ID'} && ($iB::MEMBER->{'MEMBER_GROUP'} != $iB::INFO->{'AUTHORISE_GROUP'})) {
        my @ratings = split /\|/, $member->{'RATINGS'};

        my ($total, $count);
        for (@ratings) {
            $count++;
            $total += $_;
        }

        if ($count > 0) {
            my $rating                     = $total / $count;
            $member->{'MEMBER_RATING_PCT'} = $rating * 20 . '%';
            $member->{'MEMBER_RATING_NUM'} = substr($rating, 0, 4);
        } else {
            $member->{'MEMBER_RATING_PCT'} = '0%';
            $member->{'MEMBER_RATING_NUM'} = $Profile::lang->{'member_not_rated'};
        }

        # Are we allowing members to rate each other, and is "show
        # in profile" enabled?
        if ($iB::INFO->{'MEMBER_RATING'}) {
            $member->{'MEMBER_RATING'} = ProfileView::MemberRating( $member );
        }
        # end addition
    }


    if ($iB::INFO->{'CALENDAR'}) {
    my $bd = $db->select( TABLE     => 'calendar',
                          KEY       => $member->{'MEMBER_ID'},
                          MEMBER_ID => $member->{'MEMBER_ID'},
                              );

       if ($bd->{'DAY'} and $bd->{'MONTH'} and $bd->{'YEAR'}) {
            my @data  = localtime;
            # ALLOW FOR FEB 29 BIRTHDAY (puts Feb 29th birthday for leap year on the 28th if not a leap year)
            my $year_check = &IsLeapYear($data[5]+1900); 
      		$bd->{'DAY'} = '28' if $bd->{'DAY'} eq '29' and $bd->{'MONTH'} eq '2' and $year_check == 1;
      		# END FEB 29 BIRTHDAY
            my $utime   = timelocal(0,0,0,$bd->{'DAY'},($bd->{'MONTH'}-1),$data[5]+1900);
            my $age = $data[5] + 1900 - $bd->{'YEAR'};
            if (($data[4] + 1) < $bd->{'MONTH'}) {
                $age--;
            } elsif (($data[4] + 1) == $bd->{'MONTH'}) {
                if ($data[3] < $bd->{'DAY'}) {
                    $age--;
                }
            }
           $member->{'MEMBER_BD'} = "$bd->{DAY} $Profile::lang->{'M_'.$bd->{'MONTH'} } $bd->{'YEAR'}";
           $member->{'BIRTHDAY'} = "                <tr>\n";
           $member->{'BIRTHDAY'}.= "                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%'><b>$Profile::lang->{'b_date'}</b></td>\n";
           $member->{'BIRTHDAY'}.= "                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='50%'>$member->{'MEMBER_BD'} ($age)</td>\n";
           $member->{'BIRTHDAY'}.= "                </tr>\n";

       } else {
           $member->{'BIRTHDAY'} = "";
       }
    }

    my $FIELDS = { PERSONAL => {}, CONTACT => {} };
    my %MEMFIELDS = ( LOCAL_R      => 'LOCATION',
                      SIGN_R       => 'SIGNATURE',
                      WEB_R        => 'WEBSITE',
                      INTER_R      => 'INTERESTS',
                      MEMBER_NAME_R=> 'MEMBER_NAME_R',
                      AIM_R        => 'AOLNAME',
                      ICQ_R        => 'ICQNUMBER',
                      MSN_R        => 'MSNNAME',
                      YAHO_R       => 'YAHOONAME',
                    );
    for ('LOCAL_R','SIGN_R','WEB_R','INTER_R','MEMBER_NAME_R') {
        $FIELDS->{PERSONAL}->{$_} = 0;
        if ($iB::INFO->{ $_ } == 2 or ($iB::INFO->{ $_ } == 1 and $member->{ $MEMFIELDS{$_} })) {
            $FIELDS->{PERSONAL}->{$_} = 1;
        }
    }
    for ('AIM_R','ICQ_R','MSN_R','YAHO_R') {
        $FIELDS->{CONTACT}->{$_} = 0;
        if ($iB::INFO->{ $_ } == 2 or ($iB::INFO->{ $_ } == 1 and $member->{ $MEMFIELDS{$_} })) {
            $FIELDS->{CONTACT}->{$_} = 1;
        }
    }

    $member->{'THEIR_TIME'} = $std->get_date( METHOD => 'LONG',
    TIME => (time + ($member->{'TIME_ADJUST'} * 3600) - ($iB::MEMBER->{'TIME_ADJUST'} * 3600))
    );

  # Current time of member
    $member->{'THEIR_TIME'} = $std->get_date( METHOD => 'LONG',
    TIME => (time + ($member->{'TIME_ADJUST'} * 3600) - ($iB::MEMBER->{'TIME_ADJUST'} * 3600))
    );
  # End of current time

    $output->print_ikonboard( DB         => $db,
                              STD        => $std,
                              OUTPUT     => ProfileView::ShowProfile($member, $FIELDS),
                              JAVASCRIPT => 1,
                              TITLE      => "iB::".$Profile::lang->{'viewing_profile'},
                              NAV        => [ $Profile::lang->{'viewing_profile'} ]
                            );

}

# Contact Info added by Method

sub ShowContactInfo {
my ($obj, $db) = @_;


$std->Error( DB      => $db,
STD     => $std,
LEVEL   => 1,
MESSAGE =>'no_user'
  ) unless $iB::IN{'MID'};

$std->Error( DB      => $db,
STD     => $std,
LEVEL   => 1,
MESSAGE =>'incorrect_use'
  ) unless $iB::IN{'MID'} =~ /^(?:[\d\-\_]+)$/;

# Can we view others profile information??
if ($iB::IN{'MID'} ne $iB::MEMBER->{'MEMBER_ID'}) {
unless ($iB::MEMBER_GROUP->{'MEM_INFO'}) {
$std->Error( LEVEL => 1, DB => $db, MESSAGE => 'cant_use_feature');
}
}

my $member = $db->select( TABLE  => 'member_profiles',
 ID     => $iB::IN{'MID'},
 KEY    => $iB::IN{'MID'},
);

$std->Error( DB      => $db,
STD     => $std,
LEVEL   => 1,
MESSAGE =>'profile_guest'
  ) unless $member->{'MEMBER_ID'};


$member->{'MEMBER_EMAIL'}
=  $member->{'HIDE_EMAIL'} ? $Profile::lang->{'hidden_email'}
  : qq[<a href="javascript:to_old_win('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Mail;CODE=00;MID=$member->{'MEMBER_ID'}')">$Profile::lang->{'send_email'}</a>];


for (keys %{$member}) {
$member->{$_} = $Profile::lang->{'no_information'} unless $member->{$_}
}


my $FIELDS = { PERSONAL => {}, CONTACT => {} };
my %MEMFIELDS = (
 AIM_R        => 'AOLNAME',
 ICQ_R        => 'ICQNUMBER',
 MSN_R        => 'MSNNAME',
 YAHO_R       => 'YAHOONAME',
);

for ('AIM_R','ICQ_R','MSN_R','YAHO_R') {
$FIELDS->{CONTACT}->{$_} = 0;
if ($iB::INFO->{ $_ } == 2 or ($iB::INFO->{ $_ } == 1 and $member->{ $MEMFIELDS{$_} })) {
$FIELDS->{CONTACT}->{$_} = 1;
}
}

    $output->print_popup( STD        => $std,
           OUTPUT     => ProfileView::contact_info($member, $FIELDS),
                             TITLE      => "$iB::INFO->{'BOARDNAME'}::".$Profile::lang->{'contact_header'},
                            );

}


sub UploadAvatar {
    my ($obj, $db) = @_;

    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'not_allowed_to_upl_avatar') unless $iB::MEMBER_GROUP->{'UPLOAD_AVATARS'} and $iB::MEMBER_GROUP->{'ATTACH_MAX'} > 0;
    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'upload_avatar_need_filename') unless $iB::CGI->param('avatar_filename');

    my @path = split /[\/\\]/, $iB::CGI->param('avatar_filename');
    my $ext  = pop @path;

    my $check = 0;
    for (split /\|/, $iB::INFO->{'AV_EXT'}) {
        $check = 1 if lc($_) eq lc((split /\./, $ext)[1]);
    }

    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'avatar_invalid_ext') unless $check;

    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'upl_avatar_file_exists') if (-e $iB::INFO->{'HTML_DIR'}.'/avatars/uploaded_'.$ext);
    my $size = 0;
    open UPLOAD, '>'.$iB::INFO->{'HTML_DIR'}.'/avatars/uploaded_'.$ext or die "Unable to create your new avatar: $!";
    binmode UPLOAD;
    while (my $bytesread = read($iB::CGI->param('avatar_filename'), my $buffer, 10524)) {
        $size += $bytesread;
        print UPLOAD $buffer;
    }
    close UPLOAD;

    if ($size > ($iB::MEMBER_GROUP->{'ATTACH_MAX'} * 1024)) {
        unlink ($iB::INFO->{'HTML_DIR'}.'/avatars/uploaded_'.$ext);
        $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'avatar_too_big');
    }

    $output->redirect_screen( TEXT => $Profile::lang->{'upl_avatar_successful'},
                              URL  => "act=UserCP;CODE=01;MODE=1"
                            );
}


sub RateMember {
    my ($obj, $db) = @_;

    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'user_rating_no_user_entered') if $iB::IN{'MID'} eq "";
    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'user_rating_none_selected') unless $iB::IN{'rating'};
    # Don't want the user to rate him/herself, so let's catch
    # them before they do!
    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'user_rating_cant_rate_self') if $iB::IN{'MID'} eq
$iB::MEMBER->{'MEMBER_ID'};

    # Grab the member's database entry. Good thing PERL doesn't
    # have sexuality regulations. o_O
    my $member = $db->select( TABLE    => 'member_profiles',
                              KEY      => $iB::IN{'MID'},
                              ID       => $iB::IN{'MID'},
                            );

    # Did we find a user?
    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'user_rating_no_user_found') unless $member->{'MEMBER_ID'};

    # Have we already rated him or her?
    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE => 'user_rating_already_rated') if ( grep { $_ eq $iB::IN{'MID'} } ( split( /\|\&\|/, $iB::MEMBER->{'RATED'} ) ) );

    # Yes? Then let's add the rating to their lengthy list.

    my   @ratings = split /\|/, $member->{'RATINGS'};
    push @ratings,  $iB::IN{'rating'};

    my $rate      = join '|', @ratings;

    # Update the user's database entry.
    $db->update( TABLE     => 'member_profiles',
                 ID        => $member->{'MEMBER_ID'},
                 KEY       => $member->{'MEMBER_ID'},
                 VALUES    => { RATINGS => $rate
                              }
               );

    # Make sure we can't rate this user anymore
    my $NEW = $iB::MEMBER;

    my @rated = split( /\|\&\|/, $NEW->{'RATED'} );
    push @rated, $iB::IN{'MID'};

    $NEW->{'RATED'} = join '|&|', @rated;

    $db->update( TABLE     => 'member_profiles',
                 ID        => $iB::MEMBER->{'MEMBER_ID'},
                 KEY       => $iB::MEMBER->{'MEMBER_ID'},
                 VALUES    => $NEW
               );

    # Send them back where they came from! Get off my lawn!
    my $url = "";

    if ($iB::IN{'dest'} eq 'profile') {
        $url = "act=Profile&CODE=03&MID=$iB::IN{'MID'}";
    } elsif ($iB::IN{'dest'} eq 'topic') {
        $url = "act=ST&f=$iB::IN{'f'}&t=$iB::IN{'t'}&st=$iB::IN{'st'}#entry$iB::IN{'entry'}";
    }

    $output->pure_redirect( URL => $url );
}

sub Process {
    my ($obj, $db) = @_;
    my $CodeNo = $std->CheckCodeNo($iB::IN{'CODE'});
    my %Mode = ( '01'     => \&validate,
                 '02'     => \&DoProfile,
                 '03'     => \&ShowProfile,
                 '04'     => \&DoEmail,
                 '05'     => \&DoSettings,
                 '06'     => \&DoChangeAccount,
                 '07'      => \&ShowContactInfo,

                 '10'     => \&AddAvatar_installed,
                 '11'     => \&AddAvatar_url,
                 '12'     => \&UploadAvatar,
                 '13'     => \&RateMember,

               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : ProfileError();
}


sub ProfileError  { $std->Error(LEVEL=>'1',MESSAGE=>'No Action has been specified') }

sub IsLeapYear
{
  my $year = shift;
  return 1 if $year % 4;
  return 0 if $year % 100;
  return 1 if $year % 400;
  return 0;
}

1;


__END__
