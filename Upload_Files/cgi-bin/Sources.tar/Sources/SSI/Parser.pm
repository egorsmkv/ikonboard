package SSI::Parser;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# Parser: SSI file creator
#
#################################################################################

BEGIN {
   require 'Lib/FUNC.pm';
}

my $std       = FUNC::STD->new();
$Post::lang = $std->LoadLanguage('PostWords');

$SSI::Parser::Error = undef;

sub parse {

    my %args = (
                 VALUES   => {},
                 DB       => "",
                 TEMPLATE => "",
                 EXTRA    => {},
                 @_
               );

    my $db = $args{'DB'};

    #Lets load the template, or return upon failure

    my $template = $db->select( TABLE    => 'ssi_templates',
                                KEY      => $args{'TEMPLATE'}
                              );

    return if $db->{'error'};


    if ($args{'TEMPLATE'} eq 'news') {
        return unless defined $iB::INFO->{'NEWS_FORUM'} and $iB::INFO->{'NEWS_TOPICS'};

        my $that;
        my @total;
        my $topics;
        my @totaltopics;
        my @forums = split(/&/, $iB::INFO->{'NEWS_FORUM'});
        if ($iB::INFO->{'DB_DRIVER'} ne 'DBM') {
            my ($where,$i);
            foreach(@forums) {
            $i++;
            $where .= " or " unless $i == 1;
            $where .= "FORUM_ID == \'$_\'";
            }

          @total = $db->query( TABLE    => 'forum_topics',
                               WHERE    => "$where and APPROVED == '1'",
                               RANGE    => "0 to $iB::INFO->{'NEWS_TOPICS'}",
                               SORT_BY  => 'Z-A',
                               SORT_KEY => 'TOPIC_START_DATE'
                              );
                                       }
else {
foreach my $f(@forums) {
           $topics = $db->query( TABLE    => 'forum_topics',
                                 ID       => $f,
                                 WHERE    => "FORUM_ID == '$f' and APPROVED == '1'",
                                 RANGE    => "0 to $iB::INFO->{'NEWS_TOPICS'}",
                                 SORT_BY  => 'Z-A',
                                 SORT_KEY => 'TOPIC_START_DATE'
                              );

foreach my $s (@{$topics}) {
    push (@totaltopics, $s);
                           }
                        }
foreach my $s (sort {$b->{'TOPIC_START_DATE'} <=> $a->{'TOPIC_START_DATE'} } @totaltopics)  {
     push (@total,  $s);
     }
}
        return unless scalar @total > 0;

        my $count = 0;

        for my $t (@total) {
            $count++;
            my $temp_output = $template->{'TEMPLATE'};
            my $post = $db->query(  TABLE    => 'forum_posts',
                                    DBID     => 'f'.$t->{'FORUM_ID'},
                                    ID       => $t->{'TOPIC_ID'},
                                    WHERE    => "FORUM_ID == $t->{'FORUM_ID'} and TOPIC_ID == $t->{'TOPIC_ID'} and QUEUED == '0'",
                                    SORT_KEY => 'POST_DATE',
                                    SORT_BY  => 'A-Z',
                                    RANGE    => '0 to 1',
                                 );
            $post->[0]->{'POST'} =~ s!<font color=['"].+?['"]>!!isg;
            $post->[0]->{'POST'} =~ s!</font>!!isg;
            if ($iB::INFO->{'NEWS_LIMIT'}) {
                if (length($post->[0]->{'POST'}) > $iB::INFO->{'NEWS_LIMIT'}) {
                     $post->[0]->{'POST'} = substr($post->[0]->{'POST'}, 0, $iB::INFO->{'NEWS_LIMIT'}) . '....';
                }
            }
            my $mem = FUNC::Member->new();
            my $avatar;
            my $starter =  $t->{'TOPIC_STARTER'};
            my $recUser = $mem->LoadMember( DB => $db, KEY => $starter, METHOD => 'by id');
            if ($recUser->{'MEMBER_AVATAR'} eq "noavatar") {
                          $avatar = '';
                         }
            else {
                    $avatar = "<img src='$iB::INFO->{'AVATARS_URL'}/$recUser->{'MEMBER_AVATAR'}' border='0' alt=''>";
                  }
            if ($recUser->{'MEMBER_AVATAR'} =~ m#\Ahttp\://#i){
                    $avatar = "<img src='$recUser->{'MEMBER_AVATAR'}' border='0' alt=''>";
             }
            if ($recUser->{'MEMBER_AVATAR'} =~ m#\.swf#i and ($iB::INFO->{'ALLOW_FLASH'})) {
            my ($a_width   , $a_height)  = split "x", $iB::INFO->{'AV_DIMS'};
            my ($width  , $height)   = split "x", $recUser->{'AVATAR_DIMS'};
                $height ||= $a_height;
                $width  ||= $a_width;
                $avatar = qq|<OBJECT CLASSID="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" WIDTH=$width HEIGHT=$height><PARAM NAME=MOVIE VALUE=$recUser->{'MEMBER_AVATAR'}><PARAM NAME=PLAY VALUE=TRUE><PARAM NAME=LOOP VALUE=TRUE><PARAM NAME=QUALITY VALUE=HIGH><EMBED SRC=$recUser->{'MEMBER_AVATAR'} WIDTH=$width HEIGHT=$height PLAY=TRUE LOOP=TRUE QUALITY=HIGH></EMBED></OBJECT>|;
             }
            $temp_output =~ s!<#TITLE#>!$t->{'TOPIC_TITLE'}!g;
            $temp_output =~ s!<#TDESC#>!$t->{'TOPIC_DESC'}!g;
            $temp_output =~ s!<#POST_DATE#>!$std->get_date( TIME => $t->{'TOPIC_START_DATE'}, METHOD => 'LONG' )!eg;
            $temp_output =~ s!<#POSTER_NAME#>!$t->{'TOPIC_STARTER_N'}!g;
            $temp_output =~ s!<#AVATAR#>!$avatar!g;
            $temp_output =~ s!<#NUMBER_COMMENTS#>!$t->{'TOPIC_POSTS'}!g;
            $temp_output =~ s!<#PROFILE_LINK#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile&CODE=03&MID=$t->{'TOPIC_STARTER'}!g;
            $temp_output =~ s!<#THE_POST#>!$post->[0]->{'POST'}!g;
            $temp_output =~ s!<#POST_LINK#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST&f=$t->{'FORUM_ID'}&t=$t->{'TOPIC_ID'}!g;
            $temp_output =~ s!<#PRINT_LINK#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Print&f=$t->{'FORUM_ID'}&t=$t->{'TOPIC_ID'}!g;
            $temp_output =~ s!<#NEWS_FORUM_LINK#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SF&f=$t->{'FORUM_ID'}!g;

            $that .= $temp_output;
            last if $count == $iB::INFO->{'NEWS_TOPICS'};
        }

        $template->{'TEMPLATE'} = $that;

        goto 'OUTPUT';
    }

    if ($args{'TEMPLATE'} eq 'tiker') {
        return unless defined $iB::INFO->{'WHERE_TIKER'} and $iB::INFO->{'TIKER_LIMIT'};

        my $that;
        my @totaltopics;
        my $topics;
        my @total;
        my @forums1 = split(/&/, $iB::INFO->{'WHERE_TIKER'});
        if ($iB::INFO->{'DB_DRIVER'} ne 'DBM') {
            my ($where,$i);
            foreach(@forums1) {
            $i++;
            $where .= " or " unless $i == 1;
            $where .= "FORUM_ID == \'$_\'";
            }

          @total = $db->query( TABLE    => 'forum_topics',
                                 WHERE    => "$where and APPROVED == '1'",
                                 RANGE    => "0 to $iB::INFO->{'TIKER_LIMIT'}",
                                 SORT_BY  => 'Z-A',
                                 SORT_KEY => 'TOPIC_LAST_DATE'
                              );

     }
        else {
        foreach my $f(@forums1) {
          $topics = $db->query( TABLE    => 'forum_topics',
                                ID       => $f,
                                WHERE    => "FORUM_ID == '$f' and APPROVED == '1'",
                                RANGE    => "0 to $iB::INFO->{'TIKER_LIMIT'}",
                                SORT_BY  => 'Z-A',
                                SORT_KEY => 'TOPIC_LAST_DATE'
                              );
      foreach my $s (@{$topics}) {
      push (@totaltopics, $s);
                           }
                        }
     foreach my $s (sort {$b->{'TOPIC_LAST_DATE'} <=> $a->{'TOPIC_LAST_DATE'} } @totaltopics)  {
     push (@total,  $s);
     }
     }
     my $count = 0;

     for my $t (@total) {
        $count ++;
            my $nbpost;
            if ($t->{'TOPIC_POSTS'} > 0){
                $nbpost = qq!<i>($Post::lang->{'rep'}$t->{'TOPIC_POSTS'})</i>!;
                                       }
           my $temp_output = $template->{'TEMPLATE'};
              $temp_output =~ s!<#LAST_POST_BY#>!$t->{'TOPIC_LASTP_N'}!g;
              $temp_output =~ s!<#LAST_POST_LINK#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile&CODE=03&MID=$t->{'TOPIC_LAST_POSTER'}!g;

            $temp_output =~ s!<#POSTER_NAME#>!$t->{'TOPIC_STARTER_N'}!g;
            $temp_output =~ s!<#TITLE#>!$t->{'TOPIC_TITLE'}!g;
            $temp_output =~ s!<#NUMBER_COMMENTS#>!$nbpost!g;
            $temp_output =~ s!<#POST_DATE#>!$std->get_date( TIME => $t->{'TOPIC_LAST_DATE'}, METHOD => 'SHORT' )!eg;
            $temp_output =~ s!<#PROFILE_LINK#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile&CODE=03&MID=$t->{'TOPIC_STARTER'}!g;
            $temp_output =~ s!<#POST_LINK#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST&f=$t->{'FORUM_ID'}&t=$t->{'TOPIC_ID'}!g;

            $that .= $temp_output;
            last if $count == $iB::INFO->{'TIKER_LIMIT'};
            }
        $that =~ s!\s*\n\s*!\n!isg;
        $that =~ s!(\r|\t|\f| )+! !isg;


        $template->{'TEMPLATE'} = $that;

        goto 'OUTPUT';
    }



    if ($args{'TEMPLATE'} eq 'ONLINE_LIST') {
        my $that;
        my $ext = $db->select( TABLE    => 'ssi_templates',
                               KEY      => 'ONLINE_FORMAT'
                             );

        for my $v (keys %{$args{'EXTRA'}}) {
            my $this = $ext->{'TEMPLATE'};
            $this =~ s!<%member name%>!$v!g;
            $this =~ s!<%url to profile%>!$args{'EXTRA'}->{$v}!g;
            $that .= $this;
        }

        $args{'VALUES'}->{"list members"} = $that;

    }

    for (keys %{$args{'VALUES'}}) {

        $template->{'TEMPLATE'} =~ s!<%$_%>!$args{'VALUES'}->{$_}!g;

    }

#Calendar ssi
    if ($args{'TEMPLATE'} eq 'ACTIVITY_LISTF') {
        my $that;
        my $ext = $db->select( TABLE    => 'ssi_templates',
                               KEY      => 'ACTIVITY_LIST'
                             );
        for my $d (keys %{$args{'EXTRA'}}) {
            my $this = $ext->{'TEMPLATE'};
            $this =~ s!<%name of activity%>!$d!g;
            $this =~ s!<%url of activity%>!$args{'EXTRA'}->{$d}!g;
            $that .= $this;
            }

        $args{'VALUES'}->{"activity listf"} = $that;

    }

    for (keys %{$args{'VALUES'}}) {

        $template->{'TEMPLATE'} =~ s!<%$_%>!$args{'VALUES'}->{$_}!g;

    }

OUTPUT:

    #Print it to the file...

    open  SSIOUT, ">".$iB::INFO->{'HTML_DIR'}."ssi/$template->{'EXPORT_FILENAME'}" or ($SSI::Parser::Error = "Cannot open file: $!" and return);
    print SSIOUT $template->{'TEMPLATE'};
    close SSIOUT;

    chmod(0777, $iB::INFO->{'HTML_DIR'}."ssi/$template->{'EXPORT_FILENAME'}");

    return "0 but true";
}

1;

