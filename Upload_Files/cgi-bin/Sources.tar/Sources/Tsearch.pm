package Tsearch;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
# Tsearch: Search posts in a topic.
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
    require 'MimeTypes.cfg';
    require $iB::SKIN->{'DIR'} . '/TsearchView.pm' or die $!;
}

my $mime   = MimeTypes->new();
my $output = FUNC::Output->new();
my $std    = FUNC::STD->new();
my $mem    = FUNC::Member->new();
my $txt    = iTextparser->new();
$Tsearch::lang = $std->LoadLanguage('TsearchWords');

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub Process {
    my ($obj, $db) = @_;

    my $print;
    $obj->{'.topic_id'} = $std->IsNumber($iB::IN{'t'}) || 0;
    $obj->{'.forum_id'} = $std->IsNumber($iB::IN{'f'}) || 0;

    $obj->{'FORUM'} = $db->select( TABLE   => 'forum_info',
                                   KEY     => $obj->{'.forum_id'},
                                 ) || die $db->{'error'};


    $obj->{'TOPIC'} = $db->select( TABLE  => 'forum_topics',
                                   ID     => $obj->{'.forum_id'},
                                   KEY    => $obj->{'.topic_id'}
                                 ) || die $db->{'error'};

    $iB::IN{'search_q'} =~ s!\*!%!g;
    $iB::IN{'search_q'} =~ s![<>\!\@�\$\^&\+\=\-\(\)\{\}\[\]"':;\.,/]!!g;
    my $keywordsoutput  =  $iB::IN{'search_q'};

    $iB::IN{'search_q'} = lc $iB::IN{'search_q'};

    my $First = $iB::IN{'st'} || 0;

    my $entirethread = $db->query( TABLE    => 'forum_posts',
                                   DBID     => 'f'.$obj->{'.forum_id'},
                                   ID       => $obj->{'.topic_id'},
                                   WHERE    => "FORUM_ID == $obj->{'.forum_id'} and TOPIC_ID == $obj->{'.topic_id'} and QUEUED == 0",
                                   SORT_KEY => 'POST_DATE',
                                   SORT_BY  => 'A-Z',
                                 ) || $std->cgi_error($db->{'error'});

    my $count = $db->count( TABLE    => 'forum_posts',
                            DBID     => 'f'.$obj->{'.forum_id'},
                            ID       => $obj->{'.topic_id'},
                            WHERE    => "FORUM_ID == $obj->{'.forum_id'} and TOPIC_ID == $obj->{'.topic_id'} and QUEUED == 0 and POST LIKE /%$iB::IN{'search_q'}%/",
                            SORT_KEY => 'POST_DATE',
                            SORT_BY  => 'A-Z',
                          ) || $std->cgi_error($db->{'error'});

    my $post = $db->query( TABLE    => 'forum_posts',
                           DBID     => 'f'.$obj->{'.forum_id'},
                           ID       => $obj->{'.topic_id'},
                           WHERE    => "FORUM_ID == $obj->{'.forum_id'} and TOPIC_ID == $obj->{'.topic_id'} and QUEUED == 0 and POST LIKE /%$iB::IN{'search_q'}%/",
                           RANGE    => $First.' to '.($iB::INFO->{'DISPLAY_MAX_POSTS'} + ($First - 1)),
                           SORT_KEY => 'POST_DATE',
                           SORT_BY  => 'A-Z',
                         ) || $std->cgi_error($db->{'error'});

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'missing_files'
               ) unless ((defined $iB::IN{'t'}) and (defined $iB::IN{'f'}));

    if ($iB::IN{'search_q'} eq '') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'missing_keywords'
                   );
    }

    my $length_keywords = length $iB::IN{'search_q'};

    if ($length_keywords < 2) {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'keywords_too_short'
                   );
    }

    if ($post->[0]->{'POST_DATE'} == '') {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'no_posts_found'
                   );
    }

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE => 'missing_files'
               ) unless ($iB::IN{'f'} eq $obj->{'TOPIC'}->{'FORUM_ID'});

    my $check = $obj->Check_access($db);
    return if $check == 1;

    my $numberresults = $count;

    my $first = $First + 1;

    my $leftovers = scalar @{$post};

    my $last = ($iB::INFO->{'DISPLAY_MAX_POSTS'} + $First) - ($iB::INFO->{'DISPLAY_MAX_POSTS'} - $leftovers);

    my $pages;

    if ($numberresults > $iB::INFO->{'DISPLAY_MAX_POSTS'}) {
        ####################################
        # Generate the forum page span links
        ####################################
        $obj->{'TOPIC'}->{'SHOW_PAGES'}
            = $std->build_pagelinks( TOTAL_POSS  => $numberresults + 1,
                                     PER_PAGE    => $iB::INFO->{'DISPLAY_MAX_POSTS'},
                                     CUR_ST_VAL  => $iB::IN{'st'},
                                     L_SINGLE    => $Topic::lang->{'single_page_topic'},
                                     L_MULTI     => $Topic::lang->{'multi_page_topic'},
                                     BASE_URL    => "$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Tsearch;f=$iB::IN{'f'};t=$iB::IN{'t'}",
                                     KEYWORDS    => $iB::IN{'search_q'}
                                   );

        $pages = $Tsearch::lang->{'pages'} . ' ';
    }

    $Tsearch::lang->{'showing_results'} =~ s!<#FIRST#>!$first!gi;
    $Tsearch::lang->{'showing_results'} =~ s!<#LAST#>!$last!gi;
    $Tsearch::lang->{'showing_results'} =~ s!<#NUM#>!$numberresults!gi;

    $print .= TsearchView::Page_Links($pages, $obj->{'TOPIC'}->{'SHOW_PAGES'});

    $Tsearch::lang->{'search_results'} =~ s!<#KEYWORDS#>!$keywordsoutput!gi;
    $Tsearch::lang->{'search_results'} =~ s!<#TOPIC#>!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$obj->{'.forum_id'};t=$obj->{'.topic_id'};hl=$keywordsoutput">$obj->{'TOPIC'}->{'TOPIC_TITLE'}</a>!gi;
    $Tsearch::lang->{'search_results'} =~ s!<#FORUM#>!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF;f=$obj->{'.forum_id'}">$obj->{'FORUM'}->{'FORUM_NAME'}</a>!gi;

    $print .= TsearchView::SearchInfo();

    foreach my $searchposts (@{$post}) {
        my $ctr = 0;
        my $postnumber;
        my $pagenumber;
        for my $Bleh (@{$entirethread}) {
            $ctr++;
            $Bleh->{'ctr'} = $ctr;
            if ($searchposts->{'POST_ID'} == $Bleh->{'POST_ID'}) {
                   $postnumber    = $Bleh->{'ctr'};
                my $dirtymultiple = ($postnumber - 1) / $iB::INFO->{'DISPLAY_MAX_POSTS'};
                my $whatever      = int $dirtymultiple;
                   $pagenumber    = $whatever * $iB::INFO->{'DISPLAY_MAX_POSTS'};
            }
        }

        if ($searchposts->{'RATINGS'}) {
            my $topictitle = $obj->{'TOPIC'}->{'TOPIC_TITLE'};

            $Tsearch::lang->{'topic_rating'} =~ s!<#TITLE#>!$topictitle!gi;
            $Tsearch::lang->{'topic_rating'} =~ s!<#NUM#>!$searchposts->{'RATINGS'}!gi;

            $searchposts->{'RATINGS'} = "<img src=\"$iB::INFO->{'IMAGES_URL'}/images/$searchposts->{'RATINGS'}stars.gif\" align='top' alt='$Tsearch::lang->{'topic_rating'}'>";
        }

        if ($searchposts->{'ATTACH_ID'}) {
            $Topic::lang = $std->LoadLanguage('TopicWords');
            # Let there be attachments!
            # Is it an image, and are we just adding it to the post?

            require 'MimeTypes.cfg';
            my $mime     = MimeTypes->new();
            if (($iB::INFO->{'IMG_ATT_SHOW'}) and ($searchposts->{'ATTACH_TYPE'} eq "image/gif" or $searchposts->{'ATTACH_TYPE'} eq "image/jpeg" or $searchposts->{'ATTACH_TYPE'} eq "image/x-png" or $searchposts->{'ATTACH_TYPE'} eq "image/pjpeg") ) {

                my $at = $db->select( TABLE => 'attachments',
                                      KEY => $searchposts->{'ATTACH_ID'},
                                    );

                $searchposts->{'POST'} .= qq~<br><br>$Topic::lang->{'pic_attach'}<br><img src="$iB::INFO->{'UPLOAD_URL'}/$at->{'FILE_NAME'}" border='0' onload="if(this.width > screen.width-300)this.width = (screen.width-300)" alt="$Topic::lang->{'pic_attach'}">~;
            } else {
                $searchposts->{'POST'} .= qq~<br><br><img src="$iB::INFO->{'MIME_IMG'}/$mime->{ $searchposts->{'ATTACH_TYPE'} }[1]" border='0' alt=''><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Attach;ID=$searchposts->{'ATTACH_ID'};f=$searchposts->{'FORUM_ID'};t=$searchposts->{'TOPIC_ID'};p=$searchposts->{'POST_ID'}" >$Topic::lang->{'attach_dl'} [ $mime->{ $searchposts->{'ATTACH_TYPE'} }[2] ]</a><br>$Tsearch::lang->{'num_dl'} $searchposts->{'ATTACH_HITS'}~;
            }
        }

        my $mem_tot = $mem->LoadMember( DB     => $db,
                                        KEY    =>  $searchposts->{'AUTHOR'},
                                        METHOD => 'by id'
                                      );

        $searchposts->{'POST_DATE'} = $std->get_date( TIME => $searchposts->{'POST_DATE'}, METHOD => 'LONG');

        $searchposts->{'POST'} =~ s!(\s{1,3}|\A|<br>|\(|"|')($keywordsoutput)(\s{1,3}|\Z|<br>|,|\.|\!|\?|\)|"|')!$1<span style='color:#FF0000'><b>$2</b></span>$3!ig;

        if ($iB::INFO->{'ICON_TOP_VIEW'} == 1) {
            $searchposts->{'POST_ICON'}   = $searchposts->{'POST_ICON'}
                               ? "<img src=\"$iB::INFO->{'IMAGES_URL'}/PostIcons/icon$searchposts->{'POST_ICON'}.gif\" border='0' width='19' height='19' align='middle' alt='PostIcon'>"
                              : "<img src=\"$iB::INFO->{'IMAGES_URL'}/PostIcons/icon0.gif\" border='0' width='19' height='19' align='top' alt='PostIcon'>";
        } else {
            $searchposts->{'POST_ICON'}   = $searchposts->{'POST_ICON'}
                              ? "<img src=\"$iB::INFO->{'IMAGES_URL'}/PostIcons/icon$searchposts->{'POST_ICON'}.gif\" border='0' width='19' height='19' align='top' alt='PostIcon'>"
                              : "";
        }

        $print .= TsearchView::RenderRow($searchposts, $obj->{'.forum_id'}, $obj->{'.topic_id'}, $mem_tot, $obj->{'TOPIC'}, $pagenumber, $keywordsoutput);
    }

    $print .= TsearchView::PageBottom($pages, $obj->{'TOPIC'}->{'SHOW_PAGES'});

    $output->print_ikonboard( DB         => $db,
                              STD        => $std,
                              OUTPUT     => $print,
                              JAVASCRIPT => 1,
                              TITLE      => "IB::Topic::$obj->{'TOPIC'}->{'TOPIC_TITLE'}",
                              NAV        => [ "$obj->{'TOPIC'}->{'TOPIC_TITLE'}" ]
                            );
}

sub Check_access ($) {
    my ($obj, $db) = @_;

    if ($obj->{'FORUM'}->{'FORUM_PROTECT'}) {
        if (exists $iB::COOKIES->{ $iB::INFO->{'COOKIE_ID'}.'iBForum' . $obj->{'FORUM'}->{'FORUM_ID'} }) {
            return if $iB::COOKIES->{ $iB::INFO->{'COOKIE_ID'}.'iBForum' . $obj->{'FORUM'}->{'FORUM_ID'} } eq $obj->{'FORUM'}->{'FORUM_PROTECT'};
        }
        $output->redirect_screen( TEXT => "$Topic::lang->{'please_log_in'}", URL => "?act=SF;f=$iB::IN{'f'}");
        return 1;
    }

    if ($obj->{'FORUM'}->{'FORUM_VIEW_THREADS'} ne '*') {
        unless (grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$obj->{'FORUM'}->{'FORUM_VIEW_THREADS'}) ) {
            $std->Error(     DB      => $db,
                             LEVEL   => '2',
                             MESSAGE =>'forum_no_access'
                       );
        }
    }
    return 0;
}

1;
__END__
