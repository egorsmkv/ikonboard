package Register;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Register: Registration Functions.
#
#################################################################################

BEGIN {
   require 'Lib/FUNC.pm';
   require 'Boardinfo.cgi' or die "Cannot load Module: $!";
}

my $mail        = FUNC::Mailer->new();
my $INFO        = Boardinfo->new();
my $mem         = FUNC::Member->new();
my $std         = FUNC::STD->new();
my $output      = FUNC::Output->new();
my $txt         = iTextparser->new();
$UserCP::lang = $std->LoadLanguage('UserCPWords');
$Register::lang = $std->LoadLanguage('RegisterWords');


sub new {
  my $pkg = shift;
  my $obj = {};
  bless $obj, $pkg;
  return $obj;
}

my $CryptRegKey = crypt($iB::IN{'REG_KEY'}, "gen") if ($iB::IN{'REG_KEY'});

sub CreateAccount {
    my ($obj, $db) = @_;

    # Check to make sure the form was filled in correctly

    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'no_username')     unless $iB::IN{'UserName'};
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'username_short')  unless length($iB::IN{'UserName'}) >= 3;
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'username_long')   unless length($iB::IN{'UserName'}) <= 32;
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'pass_blank')      unless $iB::IN{'PassWord'};
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'pass_blank')      unless $iB::IN{'PassWord_Check'};
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'pass_no_match')   unless $iB::IN{'PassWord_Check'} eq $iB::IN{'PassWord'};
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'pass_too_short')  unless length($iB::IN{'PassWord'}) >= 5;
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'pass_too_long')   unless length($iB::IN{'PassWord'}) <= 32;
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'invalid_email')   unless $iB::IN{'EmailAddress'};
    if (($iB::INFO->{'HRI'} == 1)) {
      $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'reg_key_null')    unless $iB::IN{'REG_KEY'};
      $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'reg_key_wrong')   unless $iB::IN{'GEN_KEY'} =~ /$CryptRegKey/;
    }
    if ($IB::INFO->{'GENDER_R'} == 2) {
        $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'GENDER_R'};
    }
    if ($iB::INFO->{'LOCAL_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'LOCATION'};
    }
    if ($iB::INFO->{'AIM_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'AOLNAME'};
    }
    if ($iB::INFO->{'ICQ_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'ICQNUMBER'};
    }
    if ($iB::INFO->{'MSN_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'MSNNAME'};
    }
    if ($iB::INFO->{'SIGN_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'SIGNATURE'};
    }
    if ($iB::INFO->{'WEB_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'WEBSITE'};
    }
    if ($iB::INFO->{'YAHO_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'YAHOONAME'};
    }
    if ($iB::INFO->{'INTER_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'INTERESTS'};
    }
    if ($iB::INFO->{'MEMBER_NAME_R'} == 2) {
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'required')     unless $iB::IN{'MEMBER_NAME_R'};
    }
    $iB::IN{'MEMBER_NAME_R'} =~ s!^\s+!!g; # Make sure that there are no leading or trailing spaces
    $iB::IN{'MEMBER_NAME_R'} =~ s!\s+$!!g;

    #DNS attack check
   my $ip_add = $iB::IN{'IP_ADDRESS'};
   my $dir = $INFO->{'DB_DIR'};
   opendir (DIR, $dir.'Temp');
   my @list  = grep { !/\A\.{1,2}\Z/ } readdir(DIR);
   closedir(DIR);
   my @dns_list = grep { /.+?(\.dns)\Z/ } @list;
   my ($file, $mtime, $print, $ip_test);
   foreach my $ip_file (@dns_list){
       $file = $dir . 'Temp/' . $ip_file;
       $mtime = (stat($file))[9];
       if (time < $mtime + 6){
$ip_test = $ip_file;
           $ip_test =~ s!\.dns!!g;
           $ip_test =~ s!_!\.!g;
           if ($ip_test == $ip_add){
               my $time = time;
               $print = "$time, $iB::IN{'UserName'} \n";
               open FILE, ">>" . $file or die $!;
               print FILE $print;
               close FILE;
               $std->Error( DB       => $db,
                            LEVEL    => 5,
                            MESSAGE  => 'register_wait_time'
                           );
           }
       }
       else {
           unlink $file;
       }
   }
   my $time_limit = time - 6;
   my $ip_check = $db->query( TABLE   => 'member_profiles',
                              WHERE   => "MEMBER_JOINED > $time_limit and MEMBER_IP eq '$ip_add'",
                              COLUMNS => ['MEMBER_ID','MEMBER_IP','MEMBER_JOINED'],
                            );
  if ($ip_check->[0]->{'MEMBER_ID'}){
      my $time = time;
      my $ip_file = $ip_add;
      $ip_file =~ s!\.!_!g;
      $ip_file = $ip_file . '.dns';
      $print = "$time, $iB::IN{'UserName'} \n";
      open FILE, "+>".$dir . 'Temp/' . $ip_file or die $!;
      print FILE $print;
      close FILE;
      $std->Error( DB       => $db,
                   LEVEL    => 5,
                   MESSAGE  => 'register_wait_time',
                  );
  }
###


    # Make sure that there are no leading or trailing spaces in the username and password.

    $iB::IN{'UserName'} =~ s!^\s+!!g;
    $iB::IN{'UserName'} =~ s!\s+$!!g;
    $iB::IN{'PassWord'} =~ s!^\s+!!g;
    $iB::IN{'PassWord'} =~ s!\s+$!!g;

    # Do a case insensitive search to make sure that the name we want to register
    # with isn't already taken.

    my $name_check  = $mem->CheckName( DB =>$db, NAME =>$iB::IN{'UserName'} );
    $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>"user_exists")   if $name_check->{'MEMBER_NAME'};

    # Check to make sure that the email address is of a valid format

    my $validate_e  = $std->CheckEmail($iB::IN{'EmailAddress'});
    $std->Error(DB=>$db,LEVEL=>'2',MESSAGE=>'invalid_email') if $validate_e != 1;

    # If we are only allowing one email addy per registree, do a check now

    unless ($iB::INFO->{'ALLOW_MULT_EMAIL'}) {
        my $email_check = $mem->Check_Mem_Email( DB =>$db, EMAIL =>$iB::IN{'EmailAddress'} );
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     MESSAGE =>'email_exists'
                   )  if $email_check->{'MEMBER_EMAIL'};
    }

    # Check for reserved names..

    if ($iB::INFO->{'SAVED_NAMES'}) {
        for my $n (split(/\|/, $iB::INFO->{'SAVED_NAMES'})) {
            if ($iB::IN{'UserName'} =~ /$n/i) {
                $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>"user_exists");
                last;
            }
        }
    }

    #XXX Are they banned?
   if ($iB::INFO->{'IP_FILTER'}) {
       for my $ip (split /\|&\|/,$iB::INFO->{'IP_FILTER'}) {
           $ip =~ s/\\\*/.*/g;
           $std->Error( DB       => $db,
                        LEVEL    => 5,
                        MESSAGE  => 'you_are_banned'
                      ) if $iB::IN{'IP_ADDRESS'} =~ m#^$ip$#;
       }
   }

   #X Is their email addy banned?
  if ($iB::INFO->{'EMAIL_FILTER'}) {
      for my $em (split /\|&\|/,$iB::INFO->{'EMAIL_FILTER'}) {
      $em = "$em\$" if $em =~ s/\*//;
          $std->Error( DB       => $db, LEVEL    => 5, MESSAGE  => 'email_banned' ) if $iB::IN{'EmailAddress'} =~ /$em/i;
      }
  }

    # Build up a member hash

    my %Member;
    $Member{'MEMBER_NAME'}     = $iB::IN{'UserName'};
    $Member{'MEMBER_PASSWORD'} = $iB::IN{'PassWord'};
    $Member{'MEMBER_GROUP'}    = $iB::INFO->{'VALIDATE_REGISTER'} || ($iB::INFO->{PREVIEW_REG} or $iB::IN{'COPPA'} eq 'true') ? $iB::INFO->{'AUTHORISE_GROUP'} : $iB::INFO->{'MEMBER_GROUP'};
    $Member{'MEMBER_POSTS'}    = 0;
    $Member{'MEMBER_EMAIL'}    = $iB::IN{'EmailAddress'};
    $Member{'MEMBER_AVATAR'}   = 'noavatar.gif';
    $Member{'MEMBER_LEVEL'}    = 1;
    $Member{'MEMBER_JOINED'}   = time;
    $Member{'MEMBER_IP'}       = $iB::IN{'IP_ADDRESS'};
    $Member{'TIME_ADJUST'}     = 0;
    $Member{'VIEW_SIGS'}       = 1;
    $Member{'PM_REMINDER'}     = '1&1';
    $Member{'VIEW_IMG'}        = 1;
    $Member{'VIEW_AVS'}        = 1;
    $Member{'ALLOW_POST'}      = 1;
    $Member{'ALLOW_ADMIN_EMAILS'} = 1;
    $Member{'GENDER'}          = $iB::IN{'SEX'};
    $Member{'LOCATION'}        = $txt->Convert_for_db( TEXT    => $iB::IN{'LOCATION'},
                                                               SMILIES => 0,
                                                               IB_CODE => 0,
                                                               HTML    => 0,
                                                             );
    $Member{'INTERESTS'}      = $txt->Convert_for_db( TEXT    => $iB::IN{'INTERESTS'},
                                                               SMILIES => 0,
                                                               IB_CODE => 0,
                                                               HTML    => 0,
                                                             );
    $txt->{ERROR} = undef;
    $iB::IN{'SIGNATURE'} = $txt->Convert_for_db( TEXT    => $iB::IN{'SIGNATURE'},
                                             SMILIES => $iB::INFO->{'SIG_ALLOW_EMOTICONS'},
                                             IB_CODE => $iB::INFO->{'SIG_ALLOW_IBC'},
                                             HTML    => $iB::INFO->{'SIG_ALLOW_HTML'},
                                             SIG     => 1,
                                             DB      => $db,
                                            );

    # If there are any errors, print them.
    if ($txt->{ERROR}) {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     STD     => $std,
                     MESSAGE => $txt->{ERROR}
                   );
    }

    $Member{'SIGNATURE'}       = $iB::IN{'SIGNATURE'};
    $Member{'AOLNAME'}         = $iB::IN{'AOLNAME'};
    $Member{'ICQNUMBER'}       = $iB::IN{'ICQNUMBER'};
    $Member{'YAHOONAME'}       = $iB::IN{'YAHOONAME'};
    $Member{'MSNNAME'}         = $iB::IN{'MSNNAME'};
    $Member{'WEBSITE'}         = $iB::IN{'WEBSITE'};
    $Member{'LANGUAGE'}        = $iB::IN{'LANGUAGE'};
    $Member{'MEMBER_SKIN'}     = $iB::IN{'MEMBER_SKIN'};
    $Member{'HIDE_EMAIL'}      = $iB::IN{'HIDE_EMAIL'};
    $Member{'MEMBER_NAME_R'}   = $iB::IN{'MEMBER_NAME_R'};

    # Add the member to the database.
    # RULE 1: If we are previewing registrations via the adminCP, then lets
    #         add the member to the "authorise" group. Add in an entry to the
    #         authorise table "authorise" to denote that they have to be previewed
    #         first. The newly registered member will be in the authorise group
    #
    # RULE 2: If we are validating via an email, lets put the member into the
    #         authorise group and add an entry into the authorise table as "register"
    #         to denote that they have to validate the email.
    #
    # CHOICE: If we want to validate via email and preview all registrations, the member
    #         will be put in the authorise group, and the entry in the authorise table will
    #         be "register" once they've validated the email, then the entry in the authorise
    #         table will be changed to "authorise" so that an admin can preview the registration
    # CHOICE: If we want to validate via email, but don't want to preview registrations, the member
    #         group will be the authorise group. The authorise table entry will be 'register'. Upon
    #         successful email validation, they will be put into the member group, and the authorise
    #         table entry removed.
    # CHOICE: If we want to preview all registrations, but don't want to validate via email, the member
    #         group will be authorise group, the authorise table entry will be "authorise" to allow an
    #         admin to preview all registrations.
    # CHOICE: If we don't want to validate via email and we don't want to preview the registrations, then
    #         we put the member in the member group and don't write an entry into the authorise table.

    my $member_id = $mem->AddMember(DB => $db, STD=> $std, MEMBER=>\%Member);

    # added by Infection

    my $birthday = $db->insert( TABLE  => 'calendar',
                                VALUES => {
                                             MEMBER_ID    => $member_id,
                                             MEMBER_NAME  => $iB::IN{'UserName'},
                                             DAY          => '0',
                                             MONTH        => '0',
                                             YEAR         => '0',
                                          },
                              );

    # Take the time to clean out all expired account requests

    $obj->clean_registrations($db);

    # If we are validating via an email, add the member to the database

    my $unique_id = $mail->my_gen_id();
    my $time      = time;

    if ($iB::INFO->{'VALIDATE_REGISTER'}) {
        # We want to validate all regigistrations via email. If we then want to preview these registrations
        # we'll change the authorise table entry to "authorise" upon successful validation

        if (!$iB::INFO->{COPPA} || $iB::INFO->{COPPA} && $iB::IN{'COPPA'} ne 'true') {
           my $new_id = $db->insert( TABLE   => 'authorisation',
                                     VALUES  => {  UNIQUE_CODE   =>  $unique_id,
                                                   DATE_ENTERED  =>  $time,
                                                   MEMBER_ID     =>  $member_id,
                                                   MEMBER_NAME   =>  $Member{'MEMBER_NAME'},
                                                   THIS_IP       =>  $iB::IN{'IP_ADDRESS'},
                                                   MEMBER_EMAIL  =>  $iB::IN{'EmailAddress'},
                                                   '_WHERE'      =>  'register',
                                                 },
                                   );
           my $message = $mail->parse_template( ID     => 'REG',
                                                DB     => $db,
                                                VALUES => { THE_LINK    =>  "$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg&CODE=03&SID=$unique_id",
                                                            MEMBER_NAME =>  $Member{'MEMBER_NAME'},
                                                            PASSWORD    =>  $iB::IN{'PassWord'},
                                                            UNTIL       =>  $iB::INFO->{'AUTHORISE_PRUNE'},
                                                            MAN_LINK    =>  "$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg&CODE=05",
                                                            EMAIL       =>  $iB::IN{'EmailAddress'},
                                                            CODE        =>  $unique_id,
                                                          }
                                               );

           $mail->Send( TO      => $iB::IN{'EmailAddress'},
                        FROM    => '',
                        SUBJECT => "Registration at $iB::INFO->{'BOARDNAME'}",
                        MESSAGE => $message
                     );

           my $print = RegisterView::show_authorise(\%Member);
           $output->print_ikonboard( DB      => $db,
                                     STD     => $std,
                                     TITLE   => "iB::".$Register::lang->{reg_success},
                                     NAV_ONE => $Register::lang->{nav_reg},
                                     OUTPUT  => $print,
                                   );
       } else {
          # We want to preview all registrations, but we don't want to get the member to validate via email,
          # so we put them in the 'authorise' group.

          my $new_id = $db->insert( TABLE   => 'authorisation',
                                    VALUES  => {  UNIQUE_CODE   =>  $unique_id,
                                                  DATE_ENTERED  =>  $time,
                                                  MEMBER_ID     =>  $member_id,
                                                  MEMBER_NAME   =>  $Member{'MEMBER_NAME'},
                                                  THIS_IP       =>  $iB::IN{'IP_ADDRESS'},
                                                  MEMBER_EMAIL  =>  $iB::IN{'EmailAddress'},
                                                  '_WHERE'      =>  'coppa',
                                                },
                                  );
          my $time = $std->get_date( TIME => time, METHOD => 'LONG');
          if ($iB::INFO->{'USER_NOTIFY'}) {
              my $message = $mail->parse_template( ID     => 'USER_NOTIFY',
                                                   DB => $db,
                                                   VALUES => {
                                                               MEMBER_NAME =>  $Member{'MEMBER_NAME'},
                                                               DATE        =>  $time,
                                                             }
                                                 );
              $mail->Send( TO      => $iB::INFO->{'ADMIN_EMAIL_IN'},
                           FROM    => '',
                           SUBJECT => "New Registration at $iB::INFO->{'BOARDNAME'} (COPPA Auth needed)",
                           MESSAGE => $message
                        );
          }

          my $print = RegisterView::show_preview(\%Member);
          $output->print_ikonboard( DB      => $db,
                                    STD     => $std,
                                    TITLE   => "$iB::INFO->{'BOARDNAME'}::".$Register::lang->{reg_success},
                                    NAV_ONE => $Register::lang->{nav_reg},
                                    OUTPUT  => $print,
                                  );
       }
    } elsif ($iB::INFO->{COPPA} && $iB::IN{'COPPA'} eq 'true') {
       # We want to preview all registrations, but we don't want to get the member to validate via email,
       # so we put them in the 'authorise' group.

       my $new_id = $db->insert( TABLE   => 'authorisation',
                                 VALUES  => {  UNIQUE_CODE   =>  $unique_id,
                                               DATE_ENTERED  =>  $time,
                                               MEMBER_ID     =>  $member_id,
                                               MEMBER_NAME   =>  $Member{'MEMBER_NAME'},
                                               THIS_IP       =>  $iB::IN{'IP_ADDRESS'},
                                               MEMBER_EMAIL  =>  $iB::IN{'EmailAddress'},
                                               '_WHERE'      =>  'coppa',
                                             },
                               );
       my $time = $std->get_date( TIME => time, METHOD => 'LONG');
       if ($iB::INFO->{'USER_NOTIFY'}) {
           my $message = $mail->parse_template( ID     => 'USER_NOTIFY',
                                                DB => $db,
                                                VALUES => {
                                                            MEMBER_NAME =>  $Member{'MEMBER_NAME'},
                                                            DATE        =>  $time,
                                                          }
                                              );
           $mail->Send( TO      => $iB::INFO->{'ADMIN_EMAIL_IN'},
                        FROM    => '',
                        SUBJECT => "New Registration at $iB::INFO->{'BOARDNAME'} (COPPA Auth needed)",
                        MESSAGE => $message
                     );
       }

       my $print = RegisterView::show_preview(\%Member);
       $output->print_ikonboard( DB      => $db,
                                 STD     => $std,
                                 TITLE   => "$iB::INFO->{'BOARDNAME'}::".$Register::lang->{reg_success},
                                 NAV_ONE => $Register::lang->{nav_reg},
                                 OUTPUT  => $print,
                               );
    } elsif ($iB::INFO->{PREVIEW_REG}) {
        # We want to preview all registrations, but we don't want to get the member to validate via email,
        # so we put them in the 'authorise' group.

        my $new_id = $db->insert( TABLE   => 'authorisation',
                                  VALUES  => {  UNIQUE_CODE   =>  $unique_id,
                                                DATE_ENTERED  =>  $time,
                                                MEMBER_ID     =>  $member_id,
                                                MEMBER_NAME   =>  $Member{'MEMBER_NAME'},
                                                THIS_IP       =>  $iB::IN{'IP_ADDRESS'},
                                                MEMBER_EMAIL  =>  $iB::IN{'EmailAddress'},
                                                '_WHERE'      =>  'authorise',
                                              },
                                );
        my $time = $std->get_date( TIME => time, METHOD => 'LONG');
        if ($iB::INFO->{'USER_NOTIFY'}) {
            my $message = $mail->parse_template( ID     => 'USER_NOTIFY',
                                                 DB     => $db,
                                                 VALUES => {
                                                             MEMBER_NAME =>  $Member{'MEMBER_NAME'},
                                                             DATE        =>  $time,
                                                           }
                                               );
            $mail->Send( TO      => $iB::INFO->{'ADMIN_EMAIL_IN'},
                         FROM    => '',
                         SUBJECT => "New Registration at $iB::INFO->{'BOARDNAME'}",
                         MESSAGE => $message
                      );
        }

        my $print = RegisterView::show_preview(\%Member);
        $output->print_ikonboard( DB      => $db,
                                  STD     => $std,
                                  TITLE   => "iB::".$Register::lang->{reg_success},
                                  NAV_ONE => $Register::lang->{nav_reg},
                                  OUTPUT  => $print,
                                );
    } else {
        # We don't want to preview and we don't want to validate via email

        my $stats = {};
        $stats->{'TOTAL_MEMBERS'}      = '+1';
        $stats->{'LAST_REG_MEMBER_N'}  = $Member{'MEMBER_NAME'};
        $stats->{'LAST_REG_MEMBER_ID'} = $member_id;

        $std->ib_stats($stats);

        my $time = $std->get_date( TIME => time, METHOD => 'LONG');

        if ($iB::INFO->{'USER_NOTIFY'}) {

            my $message = $mail->parse_template( ID     => 'USER_NOTIFY',
                                                 DB     => $db,
                                                 VALUES => {
                                                             MEMBER_NAME =>  $Member{'MEMBER_NAME'},
                                                             DATE        =>  $time,
                                                           }
                                               );

            $mail->Send( TO      => $iB::INFO->{'ADMIN_EMAIL_IN'},
                         FROM    => '',
                         SUBJECT => "New Registration at $iB::INFO->{'BOARDNAME'}",
                         MESSAGE => $message
                      );
        }

        my $text = $iB::INFO->{'SHOW_BOARD_RULES'} ? $Register::lang->{done_reg_1}
                                                   : $Register::lang->{done_reg_2};

        my $url  = $iB::INFO->{'SHOW_BOARD_RULES'} ? 'act=Reg;CODE=04' : 'act=Login;CODE=00';
    if ($iB::INFO->{'SEND_WELCOME'}){
        my $mem_id = $mem->LoadMember( DB     => $db,
                                                    KEY    => $Member{'MEMBER_NAME'},
                                                    METHOD => 'by name'
                                                  );
            require 'Welcome.pm';
        my $mset    = Welcome->new();
        $mset->sender( {
                    DB     => $db,
                    MEMBER_NAME => $Member{'MEMBER_NAME'},
                    MEMBER_ID => $mem_id->{'MEMBER_ID'},
                    }
                );
    }
        $output->redirect_screen( TEXT      => $text,
                                  URL       => $url
                                );
    }
}


sub clean_registrations {
    my ($obj, $db) = @_;

    $iB::INFO->{'AUTHORISE_PRUNE'} ||= 30;

    my $t_q = time - $iB::INFO->{'AUTHORISE_PRUNE'} * 60 * 60 * 24;

    my $old_reg = $db->query( TABLE   => 'authorisation',
                              WHERE   => qq[DATE_ENTERED < "$t_q"],
                              COLUMNS => ['ID', 'MEMBER_ID', 'MEMBER_NAME', 'MEMBER_EMAIL', '_WHERE'],
                            );

    return unless scalar @{$old_reg} > 0;

    for my $i (@{$old_reg}) {
        if ($i->{'_WHERE'} eq 'register' or $i->{'_WHERE'} eq 'outdate') {
        $db->delete( TABLE  => 'member_profiles',
                     ID     => $i->{'MEMBER_ID'},
                     KEY    => $i->{'MEMBER_ID'}
                   );

        $db->delete( TABLE  => 'calendar',
                     KEY    => $i->{'MEMBER_ID'},
                   );

        $db->delete( TABLE  => 'member_notepads',
                     ID     => $i->{'MEMBER_ID'},
                     KEY    => $i->{'MEMBER_ID'},
                   );

    my $member_query = $db->query( TABLE    => 'forum_subscriptions',
                                   WHERE    => "MEMBER_ID == '$i->{'MEMBER_ID'}'",
                                   SORT_KEY => 'ID',
                                   SORT_BY  => 'Z-A'
                                   );

    if (scalar (@{$member_query}) > 0) {
        foreach my $m (@{$member_query}) {
            $db->delete( TABLE   => 'forum_subscriptions',
                         ID      => $m->{'ID'},
                         KEY     => $m->{'ID'},
                        );
                                        }
        }

            #Delete from Name index

            $db->update_index(  TABLE     => 'member_profiles',
                                INDEX_KEY => 'MEMBER_NAME',
                                R_KEY     => $i->{'MEMBER_NAME'},
                                REMOVE    => 1
                             );

            #Delete from Email index

            $db->update_index(  TABLE     => 'member_profiles',
                                INDEX_KEY => 'MEMBER_EMAIL',
                                R_KEY     => $i->{'MEMBER_EMAIL'},
                                REMOVE    => 1
                            );

            $db->delete( TABLE  => 'authorisation',
                         KEY    => $i->{'ID'},
                       );
        }
    }
}

sub validate_user {
    my ($obj, $db) = @_;


    $std->Error( DB      => $db,
                 LEVEL   =>'1',
                 MESSAGE =>'data_incorrect'
               ) unless $iB::IN{'SID'} =~ /[\d\w]/;


    my $time = time - ($iB::INFO->{'AUTHORISE_PRUNE'} * 60 * 60 * 24);

    my $db_entry = $db->query( TABLE   => 'authorisation',
                               MATCH   => 'ONE',
                               WHERE   => qq[_WHERE eq "register" and UNIQUE_CODE eq "$iB::IN{'SID'}"],
                             );
    if ($db_entry->{'MEMBER_ID'} eq '') {
       $db_entry = $db->query( TABLE   => 'authorisation',
                               MATCH   => 'ONE',
                               WHERE   => qq[_WHERE eq "outdate" and UNIQUE_CODE eq "$iB::IN{'SID'}"],
                             );
    }
    $std->Error(DB=>$db,LEVEL=>'1', MESSAGE=>'request_error') unless $db_entry->{'MEMBER_ID'};

    my $member = $db->select( TABLE    => 'member_profiles',
                              KEY      => $db_entry->{'MEMBER_ID'},
                              ID       => $db_entry->{'MEMBER_ID'},
                            );

    $std->Error(DB=>$db,LEVEL=>'1', MESSAGE=>'request_error') unless $member->{'MEMBER_ID'};

    # Do we want to get the admin to preview this reg?

    if ($db_entry->{'_WHERE'} eq "register") {
    $member->{'MEMBER_GROUP'} = $iB::INFO->{PREVIEW_REG} ? $iB::INFO->{'AUTHORISE_GROUP'} : $iB::INFO->{'MEMBER_GROUP'};

    $db->update(              TABLE    => 'member_profiles',
                              KEY      => $db_entry->{'MEMBER_ID'},
                              ID       => $db_entry->{'MEMBER_ID'},
                              VALUES   => $member
               );
    }
    # Delete or update the authorisation table entry for this member

    if ($iB::INFO->{PREVIEW_REG} and $db_entry->{'_WHERE'} eq "register") {
        # Update the authorisation table entry and print out the "the admin is hardcore and
        # wants to preview yo' ass" screen. *Actual words may differ from those advertised
        # here.

        $db->update(         TABLE     => 'authorisation',
                             KEY       => $db_entry->{'ID'},
                             VALUES    => { "_WHERE" => 'authorise' },
                   );
        if ($iB::INFO->{'USER_NOTIFY'} and $db_entry->{'_WHERE'} eq "register") {

            my $time = $std->get_date( TIME => time, METHOD => 'LONG');

            my $message = $mail->parse_template( ID     => 'USER_NOTIFY',
                                                 DB     => $db,
                                                 VALUES => {
                                                             MEMBER_NAME =>  $db_entry->{'MEMBER_NAME'},
                                                             DATE        =>  $time,
                                                            }
                                                );

            $mail->Send( TO      => $iB::INFO->{'ADMIN_EMAIL_IN'},
                         FROM    => '',
                         SUBJECT => "New Registration at $iB::INFO->{'BOARDNAME'}",
                         MESSAGE => $message
                       );
        }

        my $print = RegisterView::show_preview($member);

        $output->print_ikonboard( DB      => $db,
                                  STD     => $std,
                                  TITLE   => "iB::".$Register::lang->{reg_success},
                                  NAV_ONE => $Register::lang->{nav_reg},
                                  OUTPUT  => $print,
                                );
    } else {

        # Delete the table entry, and the new member to the total members tally
        # Send the admin notification (if switched on) and send the member on
        # their merry way.

        $db->delete(             TABLE     => 'authorisation',
                                 KEY       => $db_entry->{'ID'},
                   );

        my $stats = {};
        $stats->{'TOTAL_MEMBERS'}      = '+1' unless $db_entry->{'_WHERE'} eq "outdate";
        $stats->{'LAST_REG_MEMBER_N'}  = $db_entry->{'MEMBER_NAME'} unless $db_entry->{'_WHERE'} eq "outdate";
        $stats->{'LAST_REG_MEMBER_ID'} = $db_entry->{'MEMBER_ID'} unless $db_entry->{'_WHERE'} eq "outdate";

        $std->ib_stats($stats) unless $db_entry->{'_WHERE'} eq "outdate";

        if ($iB::INFO->{'USER_NOTIFY'} and $db_entry->{'_WHERE'} eq "register") {

            my $time = $std->get_date( TIME => time, METHOD => 'LONG');

            my $message = $mail->parse_template( ID     => 'USER_NOTIFY',
                                                 DB     => $db,
                                                 VALUES => {
                                                             MEMBER_NAME =>  $db_entry->{'MEMBER_NAME'},
                                                             DATE        =>  $time,
                                                            }
                                                );

            $mail->Send( TO      => $iB::INFO->{'ADMIN_EMAIL_IN'},
                         FROM    => '',
                         SUBJECT => "New Registration at $iB::INFO->{'BOARDNAME'}",
                         MESSAGE => $message
                       );
        }

        my $text = $iB::INFO->{'SHOW_BOARD_RULES'} ? $Register::lang->{done_reg_1}
                                                   : $Register::lang->{done_reg_2};

        my $url  = $iB::INFO->{'SHOW_BOARD_RULES'} ? 'act=Reg;CODE=04' : 'act=Login;CODE=00';
    if ($iB::INFO->{'SEND_WELCOME'}){
            my $mem_id = $mem->LoadMember( DB     => $db,
                                                    KEY    => $db_entry->{'MEMBER_NAME'},
                                                    METHOD => 'by name'
                                                  );

            require 'Welcome.pm';
        my $mset    = Welcome->new();
        $mset->sender( {
                    DB     => $db,
                    MEMBER_NAME => $db_entry->{'MEMBER_NAME'},
                    MEMBER_ID => $mem_id->{'MEMBER_ID'},
                }
                 );
    }
        $output->redirect_screen( TEXT      => $text,
                                  URL       => $url
                                );
    }
}

sub ShowCOPPA {
    my ($obj, $db) = @_;


    my $print = RegisterView::Show_COPPA( );

        $output->print_ikonboard(
                              DB      => $db,
                              STD     => $std,
                              OUTPUT  => $print,
                              TITLE   => "$Register::lang->{'COPPA_form'}
$iB::INFO->{'BOARDNAME'}",
                              NAV     => [$Register::lang->{'COPPA_info'}]
                           );
}

sub ShowCOPPAunderage {
    my ($obj, $db) = @_;


    my $print = RegisterView::Show_COPPA_underage( );

        $output->print_ikonboard(
                              DB      => $db,
                              STD     => $std,
                              OUTPUT  => $print,
                              TITLE   => "$Register::lang->{'COPPA_form'}
$iB::INFO->{'BOARDNAME'}",
                              NAV     => [$Register::lang->{'COPPA_info'}]
                           );
}

sub ShowCOPPApermission {
    my ($obj, $db) = @_;


    my $print = RegisterView::Show_COPPA_permission( );

    $output->print_popup( STD        => $std,
                          OUTPUT     => $print,
                          TITLE      => "$Register::lang->{'COPPA_permis'} $iB::INFO->{'BOARDNAME'}",
                        );

}

sub ShowPrivacy {
    my ($obj, $db) = @_;


    my $print = RegisterView::Show_Privacy( );

    $output->print_popup( STD        => $std,
                          OUTPUT     => $print,
                          TITLE      => "$Register::lang->{'Privacy_state'} $iB::INFO->{'BOARDNAME'}",
                        );

}

sub ShowForm {
    my ($obj, $db) = @_;
    my $text = $Register::lang->{'std_text'};

    $text .= "<br>". $Register::lang->{'email_validate_text'} if $iB::INFO->{'VALIDATE_REGISTER'};
    $text .= "<br><br>". $Register::lang->{'validate_COPPA'} if ($iB::INFO->{COPPA} && $iB::IN{'COPPA'} eq 'true');

    # Get the pre-registration rules
    my $rules = $db->select( TABLE => 'templates',
                             KEY   => 'register',
                           );

    $rules->{'TEMPLATE'} =~ s!</?(?:b|p|i|u|s)>!!ig;
    $rules->{'TEMPLATE'} =~ s!<br>!\n!g;


    my $print = RegisterView::ShowForm( { TEXT => $text, COPPA => $iB::IN{'COPPA'} } );

    if ($iB::INFO->{'MEMBER_NAME_R'}) {
    $print .= RegisterView::MemberNameReal( { TEXT => '' } );
    }

    if ($iB::INFO->{'GENDER_R'}) {
    my $sex = qq!<select name='SEX' class='forminput'>
                 <option value='1' selected>$UserCP::lang->{'Male'}</option>
                 <option value='2'>$UserCP::lang->{'Female'}</option>
                     !;
    $sex .= "</select>";

    $print .= RegisterView::ShowGender( { TEXT => $sex } );
    }
    if ($iB::INFO->{'SKIN_LANG_R'}) {
        my $lang_select = "<select name='LANGUAGE' class='forminput'>";

    my @languages = split( /\|\&\|/, $iB::INFO->{'LANGUAGES'} );

    for my $l (@languages) {
        @_ = split /\:/, $l;
        $lang_select .= $_[0] eq $iB::MEMBER->{'LANGUAGE'}
                      ? qq[<option value='$_[0]' selected>$_[1]\n]
                      : qq[<option value='$_[0]'>$_[1]\n];
    }
    $lang_select .= "</select>";
    #+-------------------------------------------------------------------------------
    my $skin_select;
        my @skins = split( /\|\&\|/, $iB::INFO->{'SKINS'} );
        $skin_select = "<select name='MEMBER_SKIN' class='forminput'>";
        $iB::MEMBER->{'MEMBER_SKIN'} ||= $iB::INFO->{DEFAULT_SKIN};
        for my $s (@skins) {
            @_ = split /\:/, $s;
            $skin_select .= $_[0] eq $iB::MEMBER->{'MEMBER_SKIN'}
                          ? qq[<option value='$_[0]' selected>$_[2]\n]
                          : qq[<option value='$_[0]'>$_[2]\n];
        }
    $skin_select .= "</select>";
    $print .= RegisterView::ShowSkinLang( { SKIN => $skin_select, LANG => $lang_select } );
    }
    if ($iB::INFO->{'LOCAL_R'}) {
    $print .= RegisterView::ShowLocal( { TEXT => '' } );
    }
    if ($iB::INFO->{'MAIL_R'}) {
    my $mail_r = qq!<select name='HIDE_EMAIL' class='forminput'>
                 <option value='1' selected>$UserCP::lang->{'yes'}</option>
                 <option value='0'>$UserCP::lang->{'no'}</option>
                     !;
    $mail_r .= "</select>";
    $print .= RegisterView::ShowMail( { TEXT => $mail_r } );
    }
    if ($iB::INFO->{'WEB_R'}) {
    $print .= RegisterView::ShowWeb( { TEXT => '' } );
    }
    if ($iB::INFO->{'AIM_R'}) {
    $print .= RegisterView::ShowAIM( { TEXT => '' } );
    }
    if ($iB::INFO->{'ICQ_R'}) {
    $print .= RegisterView::ShowICQ( { TEXT => '' } );
    }
    if ($iB::INFO->{'MSN_R'}) {
    $print .= RegisterView::ShowMSN( { TEXT => '' } );
    }
    if ($iB::INFO->{'YAHO_R'}) {
    $print .= RegisterView::ShowYAHO( { TEXT => '' } );
    }
    if ($iB::INFO->{'INTER_R'}) {
    $print .= RegisterView::ShowInter( { TEXT => '' } );
    }
    if ($iB::INFO->{'SIGN_R'}) {
    $print .= RegisterView::ShowSign( { TEXT => '' } );
    }
    $print .= RegisterView::SecureReg( { TEXT => '' } ) if ($iB::INFO->{'HRI'} == 1);
    $print .= RegisterView::Close_Form( { RULES => $rules->{'TEMPLATE'} } );

    $output->print_ikonboard(
                              DB      => $db,
                              STD     => $std,
                              OUTPUT  => $print,
                              TITLE   => $Register::lang->{'registration_form'},
                              NAV     => [$Register::lang->{'registration_form'}]
                            );
}

sub show_dumb_form {
    my ($obj, $db) = @_;

    $output->print_ikonboard(
                              DB      => $db,
                              STD     => $std,
                              OUTPUT  => &RegisterView::show_dumb_form(),
                              TITLE   => $Register::lang->{'registration_form'},
                              NAV     => [$Register::lang->{'registration_form'}]
                           );
}

sub show_board_rules {
    my ($obj, $db) = @_;
    my $rules = $db->select( TABLE => 'forum_rules',
                             KEY    => '00',
                         );
    $std->Error( DB => $db, STD => $std, LEVEL => '1', MESSAGE=>'missing_files') unless $rules;

    $rules->{'RULES_TEXT'} = $std->TextTidy($rules->{'RULES_TEXT'});

    $output->print_ikonboard(
                             DB     => $db,
                             STD     => $std,
                             OUTPUT => RegisterView::show_rules($rules),
                             TITLE => $Register::lang->{'board_rules'},
                             NAV     => [$Register::lang->{'board_rules'}]
                         );
}

sub checkCOPPA {
    my ($obj, $db) = @_;

    $iB::INFO->{COPPA} ? $obj->ShowCOPPA($db) : $obj->ShowForm($db);
}

sub Process {
    my ($obj, $db) = @_;
    my $CodeNo = $std->CheckCodeNo($iB::IN{'CODE'});
    $std->Error(DB => $db, LEVEL=>'1', MESSAGE=>'no_register') unless $iB::INFO->{'ALLOW_REGISTER'};
    require $iB::SKIN->{'DIR'} . '/RegisterView.pm' or die $!;
    my %Mode = ( '00'     => \&checkCOPPA,
                 '01'     => \&ShowForm,
                 '02'     => \&CreateAccount,
                 '03'     => \&validate_user,
                 '04'     => \&show_board_rules,
                 '05'     => \&show_dumb_form,
                 '06'     => \&check_dumb_form,
                 '10'     => \&ShowCOPPApermission,
                 '11'     => \&ShowPrivacy,
                 '12'     => \&ShowCOPPAunderage,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : RegisterError($obj, $db);
}

sub RegisterError  { my ($obj, $db) = @_; $std->Error(DB=>$db,LEVEL=>'1',MESSAGE=>'no_action'); }

1;
