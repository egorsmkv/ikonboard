package Boards;
use strict;
use Time::Local;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
# Boards: Display the board summary
#
##################################################################################

BEGIN { require 'Lib/FUNC.pm'; }

my $std    = FUNC::STD->new();
my $output = FUNC::Output->new();

my $cats_printed = {};

sub new {
    my $pkg = shift;
    my $obj = { '_html' => undef, 'nav' => [] };
    $iB::INFO->{'CN'} = '5';
    if ($iB::INFO->{'MOD_DROP_DOWN'}) { $iB::INFO->{'CN'} = '6'; }
    bless $obj, $pkg;
    return $obj;
}

sub ShowStart {
    my ($obj, $db) = @_;

    $Boards::lang = $std->LoadLanguage('BoardWords');
    require $iB::SKIN->{'DIR'} . '/BoardsView.pm' or die $!;


    $obj->{'_html'} .= BoardsView::PageTop();

    $obj->{'TOTAL_CATS'}   = $db->query(TABLE     => 'categories',
                                        SORT_KEY  => 'CAT_POS',
                                        SORT_BY   => 'A-Z',
                                        MATCH     => 'ALL',
                                      ) || die $db->{'error'};

    $obj->{'MODERATORS'}   = $db->query(TABLE     => 'forum_moderators',
                                        SORT_KEY  => 'MEMBER_NAME',
                                        SORT_BY   => 'A-Z',
                                        MATCH     => 'ALL'
                                      ) || die $db->{'error'};


    $obj->{'TOTAL_FORUMS'} = $db->query(TABLE     => 'forum_info',
                                        SORT_KEY  => 'FORUM_POSITION',
                                        SORT_BY   => 'A-Z',
                                        MATCH     => 'ALL'
                                      ) || die $db->{'error'};

    unless (-e $iB::INFO->{'IKON_DIR'}.'Data/ForumJump.pm') {

        $std->build_forumjump( DB     => $db,
                               CATS   => $obj->{'TOTAL_CATS'},
                               FORUMS => $obj->{'TOTAL_FORUMS'}
                             );
    }

    # Build up a list of categories that contain a sub category.

    $obj->{subcat} = {};

    my $i = 0;
    for (@{$obj->{TOTAL_CATS}}) {
        if ($_->{SUB_CAT_ID}) {
            unless ($obj->{subcat}->{$_->{SUB_CAT_ID}}) {
                $obj->{subcat}->{$_->{SUB_CAT_ID}} = [];
            }
            push @{$obj->{subcat}->{$_->{SUB_CAT_ID}}}, {
                                                          ID  => $_->{CAT_ID},
                                                          IDX => $i
                                                        };
        }
        ++$i;
    }

    # Are we printing a total list of all the forums and
    # categories, or just the category only?

    $iB::IN{'act'} eq 'SC' ? $obj->show_cat($db) : $obj->show_list($db);

    # Print the footer stuff based on the users prefs

    if ($iB::INFO->{'SHOW_ONLINE'}) {
        my $Names;
        # Get the formatting options
        my %format;
        for (split /\|/, $iB::INFO->{AU_FORMAT}) {
            /^(\d+)\~(.+?),(.+?)$/;
            $format{ $1 } = { ST  => $2, END => $3 };
        }
        foreach (@{ $iB::ACTIVE->{'NAMES'} }) {
            if ($iB::INFO->{'ADMINS_SEE_ANON'} == 1 && $_->{ANON} == 1) {
                if ($iB::MEMBER_GROUP->{'ACCESS_CP'} == 1) {
                    $Names .= qq! <span id='highlight'>&gt;</span><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$_->{'ID'}'><b>[</b>$format{ $_->{GROUP} }->{ST}$_->{'NAME'}$format{ $_->{GROUP} }->{END}<b>]</b></a>!;
                }
            } else {
                $Names .= qq! <span id='highlight'>&gt;</span><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$_->{'ID'}'>$format{ $_->{GROUP} }->{ST}$_->{'NAME'}$format{ $_->{GROUP} }->{END}</a>!;
            }
        }

        my $link = $iB::INFO->{'ALLOW_ONLINE_LIST'} ? qq|&nbsp;&nbsp;[ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Online;CODE=listall">$Boards::lang->{'browser_user_list'}</a> ]| : '';

         #added by Method
        my $teamlist = $iB::INFO->{'ALLOW_TEAM_LIST'} ? qq|&nbsp;&nbsp;[ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Team">$Boards::lang->{'team_list'}</a> ]| : '';

        $obj->{'_html'} .= BoardsView::ActiveUsers($Names,
                                  $link,
                                  $teamlist,
                                  $iB::ACTIVE->{'MEMBERS'} || 0,
                                  $iB::ACTIVE->{'GUESTS'}  || 0,
                                  $iB::ACTIVE->{'ANON'}    || 0,
                                  $iB::ACTIVE->{'MEMBERS'} + $iB::ACTIVE->{'GUESTS'} + $iB::ACTIVE->{'ANON'} || 0,
                                );

        if ($iB::INFO->{'CALENDAR'}) {
            my $file = "$iB::INFO->{'IKON_DIR'}Database/Temp/calendar.lock";
            my $mtime = (stat($file))[9];
            if (($mtime + 3600) < time){
                open LOCK, ">".$iB::INFO->{'IKON_DIR'}.'Database/Temp/calendar.lock';
                print LOCK time;
                close LOCK;
                my @data  = localtime;
                my $day   = $data[3];
                my $month = $data[4] + 1; #because months begin from 0 to 11 in array!
                my $year;
                my $data  = time + ($iB::INFO->{'TIME_ZONE'} * 3600) + ($iB::MEMBER->{'TIME_ADJUST'}*3600);
                my @dat   = localtime($data);
                my $time = time - 86400;
                my $birth_users =   $db->query( TABLE => 'calendar',
                                                WHERE => qq[(MONTH == '$month' and DAY == '$day') or (UTIME > $time)],
                                                SORT_KEY  => 'UTIME',
                                                SORT_BY   => 'A-Z',
                                                );
                my ($time_adjust,$dat,$newdata,$birthusers,$i,$e,$activity,$activity1,$actdate,$actdate2,@acttotal,@birthd,$age_old);
                my $offset = ($iB::INFO->{'TIME_ZONE'} * 3600)+($iB::MEMBER->{'TIME_ADJUST'} * 3600);
                foreach my $w (@{$birth_users}) {
                    if ($w->{'YEAR'}) {
                        $year = $data[5] + 1900 - $w->{'YEAR'};
                        $age_old = $year;
                        $year = "(<b>".$year."</b>)";
                    }
                    $dat   = timelocal(0,0,0,$w->{'DAY'},($w->{'MONTH'}-1),$data[5]+1900);
                    if ($w->{'UTIME'} and $w->{'MEMBER_ID'}=~ m#\Af\=#i) {
                        unless ((($w->{'UTIME'} - ($w->{'TIME_ADJUST'}*3600)) >= $data + (86400 * $iB::INFO->{'EVENT_LIMIT'})) or ($w->{'UTIME'} - $w->{'TIME_ADJUST'} < $data - 86400)) {
                            $actdate  = $std->get_date( TIME    => ($w->{'UTIME'} - $offset), METHOD    => 'SHORT' );
                            $actdate2 = $std->get_date( TIME    => ($w->{'UTIME'} - $offset), METHOD    => 'SHORT' );

                             $e++;
                            $activity  .= qq~<span id='highlight'>&gt;</span><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST;$w->{'MEMBER_ID'}'><font color='$iB::INFO->{'EVENT_FRONT'}' >$w->{'MEMBER_NAME'} \- $actdate</font></a> ~;
                            $activity1 = "$w->{'MEMBER_NAME'} \- $actdate2";
                            push (@acttotal, {NAME => $activity1, URL => $w->{'MEMBER_ID'}});
                        }
                    }
                     elsif ($dat[3] == $w->{'DAY'} and $dat[4] == $w->{'MONTH'}-1) {
                        unless ($w->{'MEMBER_ID'}=~ m#\Af\=#i){
                            $i++;
                            $birthusers .= qq~<span id='highlight'>&gt;</span><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$w->{'MEMBER_ID'}' >$w->{'MEMBER_NAME'}</a> $year ~;
                            if ($w->{'UTIME'} + 86500 < time and $iB::INFO->{'HAPPY_BD'}) {
                                require 'Happybd.pm';
                                my $happy = Happybd->new();
                                $happy->sender({DB => $db, MEMBER_ID => $w->{'MEMBER_ID'}, MEMBER_NAME => $w->{'MEMBER_NAME'}, AGE => $age_old});
                            }
                        }
                    }
                }
                my $total_act;
                foreach my $a (@acttotal) {
                    $total_act .= $a->{'NAME'} . "|:|" . $a->{'URL'};
                    $total_act .= "|&|";
                }

              chmod (0777, $iB::INFO->{'IKON_DIR'}.'Data/calendar.cgi');

                open CAL, ">".$iB::INFO->{'IKON_DIR'}.'Data/calendar.cgi' or die "cannot open stats file ($!)";

                print CAL "package cal;\n".
                            "sub new {\n".
                            "  my \$pkg = shift;\n".
                            "  my \$obj = {\n".
                            "    NUMBER_BIRTH       => q!$i!,     \n".
                            "    NUMBER_EVENT       => q!$e!,      \n".
                            "    TOTAL_ACTIVITY     => q!$total_act!,     \n".
                            "    LIST_ACTIVITY      => q!$activity!,\n".
                            "    LIST_BIRTH         => q!$birthusers!, \n".
                            "  };".
                            "  bless \$obj, \$pkg;\n".
                            "  return \$obj;\n".
                            "}\n".
                            "1;\n";
                close CAL;

              chmod (0666, $iB::INFO->{'IKON_DIR'}.'Data/calendar.cgi');

                if (@acttotal) {
                }
            }
            my $birth_lang;
            my $l_event;
            return {} unless (-e $iB::INFO->{'IKON_DIR'}.'Data/calendar.cgi');
            return {} unless (-s $iB::INFO->{'IKON_DIR'}.'Data/calendar.cgi' > 0);
            do $iB::INFO->{'IKON_DIR'}.'Data/calendar.cgi';
            my $s = cal->new();

            if ($s->{'NUMBER_BIRTH'} > 0) {
                $birth_lang = ($i > 1)?$Boards::lang->{'birth_users'}:$Boards::lang->{'birth_user'};
            } else {
                $birth_lang = $Boards::lang->{'no_birth_users'};
            }

            my $birthday = BoardsView::birthday( $s->{'LIST_BIRTH'}, $s->{'NUMBER_BIRTH'}, $birth_lang );

            $obj->{'_html'} =~ s#<!--BIRTHDAY HTML-->#$birthday#i;

            if ($s->{'NUMBER_EVENT'} > 0) {
                $l_event = ($s->{'NUMBER_EVENT'} > 1)?"$Boards::lang->{'two_events'}$iB::INFO->{'EVENT_LIMIT'}$Boards::lang->{'days'}":"$Boards::lang->{'one_event'}$iB::INFO->{'EVENT_LIMIT'}$Boards::lang->{'days'}";
            } else {
                $l_event = "$Boards::lang->{'no_event'}$iB::INFO->{'EVENT_LIMIT'}$Boards::lang->{'days'}";
            }
            my $events = BoardsView::events( $s->{'LIST_ACTIVITY'}, $s->{'NUMBER_EVENT'}, $l_event );
            $obj->{'_html'} =~ s#<!--EVENT HTML-->#$events#i;

            if ($iB::INFO->{'CALENDAR_SSI'} == 1) {
                my $file = "$iB::INFO->{'IKON_DIR'}Database/Temp/activity_count.lock";
                my $mtime = (stat($file))[9];
                if (($mtime + ($iB::INFO->{'CALENDAR_SSI_TIME'} * 60)) < time){
                    open LOCK, ">".$iB::INFO->{'IKON_DIR'}.'Database/Temp/activity_count.lock';
                    print LOCK time;
                    close LOCK;
                    require SSI::Parser;
                    my @avtivit = split( /\|\&\|/, $s->{'TOTAL_ACTIVITY'} );
                    my @acttot;
                    foreach my $u (@avtivit) {
                        @_ = split /\|\:\|/, $u;
                         push @acttot, { NAME => $_[0], URL => $_[1] };
                    }
                    my $avtivitytotal = {};
                    foreach my $a (@acttot) {
                        $avtivitytotal->{ $a->{'NAME'} } = qq~$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST;$a->{'URL'}~;
                    }

                   SSI::Parser::parse( DB       => $db,
                                       TEMPLATE => 'ACTIVITY_LISTF',
                                       EXTRA    =>  $avtivitytotal
                                      );
                   SSI::Parser::parse( DB       => $db,
                                       TEMPLATE => 'ACTIVITY_COUNT',
                                       VALUES   => { "text for activity"  => $l_event,
                                                     "number of activity" => $s->{'NUMBER_EVENT'}
                                                   }
                                     );
                }
            }
    }
}

    if ($iB::INFO->{'USE_SSI'}) {
        my $file = "$iB::INFO->{'IKON_DIR'}Database/Temp/online_list.lock";
        my $mtime = (stat($file))[9];
        if (($mtime + 60) < time){
            open LOCK, ">".$iB::INFO->{'IKON_DIR'}.'Database/Temp/online_list.lock';
            print LOCK time;
            close LOCK;
            require SSI::Parser;
            my $names = {};
            foreach (@{ $iB::ACTIVE->{'NAMES'} }) {
                $names->{ $_->{'NAME'} } = qq~$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$_->{'ID'}~;
            }

            SSI::Parser::parse( DB       => $db,
                                TEMPLATE => 'ONLINE_LIST',
                                EXTRA    => $names
                              );

            SSI::Parser::parse( DB       => $db,
                                TEMPLATE => 'ONLINE_COUNT',
                                VALUES   => { "number of guests"  => $iB::ACTIVE->{'GUESTS'},
                                              "number of members" => $iB::ACTIVE->{'MEMBERS'},
                                              "total online"      => $iB::ACTIVE->{'MEMBERS'} + $iB::ACTIVE->{'GUESTS'} + $iB::ACTIVE->{'ANON'} || 0
                                            }
                              );
        }
    }

    if ($iB::INFO->{'SHOW_STATS'}) {
        my $stats = $std->ib_stats;
        $stats->{'M_ONLINE_COUNT'} ||= 0;
       # Do we have more users on this time than ever before?
        my $current_user_count = $iB::ACTIVE->{'MEMBERS'} + $iB::ACTIVE->{'GUESTS'} + $iB::ACTIVE->{'ANON'};
        if ($current_user_count > $stats->{'M_ONLINE_COUNT'}) {
            $std->ib_stats( { M_ONLINE_COUNT => $current_user_count, M_ONLINE_DATE  => time } );
            $stats->{'M_ONLINE_COUNT'} = $current_user_count;
            $stats->{'M_ONLINE_DATE'}  = time;

        }

        $stats->{'M_ONLINE_DATE'} = $std->get_date( TIME => $stats->{'M_ONLINE_DATE'}, METHOD => 'LONG');
        $Boards::lang->{'most_online'} =~ s!<#NUM#>!$stats->{'M_ONLINE_COUNT'}!;
        $Boards::lang->{'most_online'} =~ s!<#DATE#>!$stats->{'M_ONLINE_DATE'}!;
        $obj->{'_html'} .= BoardsView::ShowStats($stats);
    }

    $obj->{'_html'} .= BoardsView::Invite_Friend() if ($iB::INFO->{'INVITE_FRIEND'} and $iB::MEMBER_GROUP->{'INVITE_FRIEND'});
    $obj->{'_html'} .= BoardsView::Web_Ring();
    $obj->{'_html'} .= BoardsView::BoardInformation() if ($iB::INFO->{'BOARD_LEGEND'});  # added by Method
    $obj->{'_html'} .= BoardsView::Board_footer(); # added by Method

    $output->print_ikonboard( DB => $db, STD => $std, OUTPUT  => $obj->{'_html'}, TITLE => $iB::INFO->{'BOARDNAME'}, NAV => $obj->{'nav'});
    undef $obj->{'_html'};
}


sub show_list {
    my ($obj, $db) = @_;

    for my $this_cat (@{ $obj->{'TOTAL_CATS'} }) {

        # Is it on?

        next unless $this_cat->{CAT_STATE};

        # If it's a sub category, don't print it yet.
        next if $this_cat->{SUB_CAT_ID};

        #XXX Skip it if the category has already been printed or we don't have permission to view the category

        #next if exists $cats_printed->{ $this_cat->{'CAT_ID'} };

        if ($this_cat->{'VIEW'} ne '*') {
            next unless grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split (/,/, $this_cat->{'VIEW'}) );
        }

        #XXX Grab all the forums in this main category

        my @these_cat_forums = grep { $_->{'CATEGORY'} == $this_cat->{'CAT_ID'} } @{ $obj->{'TOTAL_FORUMS'} };
        $this_cat->{CAT_SPONSOR} = '&nbsp;';
        if ($this_cat->{URL} and $this_cat->{IMAGE}) {
            $this_cat->{IMAGE}       = "<img src='$this_cat->{IMAGE}' border='0' alt=''>";
            $this_cat->{CAT_SPONSOR} = "<a href='$this_cat->{URL}' target='_blank'>$this_cat->{IMAGE}</a>";
        }

        $obj->{'_html'} .= BoardsView::CatHeader_Expanded($this_cat);

        #XXX Grab any sub categories in this main category

        if (exists $obj->{subcat}->{$this_cat->{'CAT_ID'}}) {
            for (@{$obj->{subcat}->{$this_cat->{'CAT_ID'}}}) {
                next unless $obj->{TOTAL_CATS}->[ $_->{IDX} ]->{'DISP_POS'} == 1; # added by kevaholic00
                $obj->{'_html'} .= $obj->render_subcat( @{$obj->{TOTAL_CATS}}[ $_->{IDX} ] );
            }
        }

        #XXX Print the rest of the forums (if there are any!)

        for my $this_forum (@these_cat_forums) {

            $obj->{'_html'} .= $obj->render_forum($this_forum);

        }

        # added by kevaholic00
        if (exists $obj->{subcat}->{$this_cat->{'CAT_ID'}}) {
            for (@{$obj->{subcat}->{$this_cat->{'CAT_ID'}}}) {
                next unless $obj->{TOTAL_CATS}->[ $_->{IDX} ]->{'DISP_POS'} == 2; # added by kevaholic00
                $obj->{'_html'} .= $obj->render_subcat( @{$obj->{TOTAL_CATS}}[ $_->{IDX} ] );
            }
        }
        # end addition
    }
}

sub show_cat {
    my ($obj, $db) = @_;

    $std->Error( DB => $db, STD => $std, MESSAGE => 'no_action') unless defined $iB::IN{'c'};

    my $this_cat = $db->select( TABLE => 'categories',
                                KEY   => $iB::IN{'c'}
                              );

    if ($this_cat->{'VIEW'} ne '*') {
        unless ( grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split (/,/, $this_cat->{'VIEW'}) ) ) {
            $std->Error( DB => $db, STD => $std, MESSAGE => 'no_permission');
        }
    }

    my @these_cat_forums = grep { $_->{'CATEGORY'} == $this_cat->{'CAT_ID'} } @{ $obj->{'TOTAL_FORUMS'} };

    if ($this_cat->{'SUB_CAT_ID'}) {
        my $sub_cat = $db-> select( TABLE => 'categories',
                                    KEY   => $this_cat->{'SUB_CAT_ID'}
                                  );
        push @{ $obj->{'nav'} }, qq[<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SC;c=$sub_cat->{'CAT_ID'}" class='nav'>$sub_cat->{'CAT_NAME'}</a>];
    }

    push @{ $obj->{'nav'} }, qq!$this_cat->{'CAT_NAME'}!;

    $obj->{'_html'} .= BoardsView::CatHeader_Expanded($this_cat);

    #XXX Grab any sub categories in this main category

    if (exists $obj->{subcat}->{$this_cat->{'CAT_ID'}}) {
        for (@{$obj->{subcat}->{$this_cat->{'CAT_ID'}}}) {
            next unless $obj->{TOTAL_CATS}->[ $_->{IDX} ]->{'DISP_POS'} == 1; # added by kevaholic00
            $obj->{'_html'} .= $obj->render_subcat( @{$obj->{TOTAL_CATS}}[ $_->{IDX} ] );
        }
    }

    for my $this_forum (@these_cat_forums) {

        $obj->{'_html'} .= $obj->render_forum($this_forum);

    }

    # added by kevaholic00
    if (exists $obj->{subcat}->{$this_cat->{'CAT_ID'}}) {
        for (@{$obj->{subcat}->{$this_cat->{'CAT_ID'}}}) {
            next unless $obj->{TOTAL_CATS}->[ $_->{IDX} ]->{'DISP_POS'} == 2; # added by kevaholic00
            $obj->{'_html'} .= $obj->render_subcat( @{$obj->{TOTAL_CATS}}[ $_->{IDX} ] );
        }
    }
    # end addition
}

####################################################################
#
# Parses all the info and returns the created HTML for a cat entry
#
####################################################################

sub render_subcat {
    my ($obj, $subcat) = @_;

    #XXX: Grab all the forums for this sub category

    my @these_sub_cat_forums = grep { $_->{'CATEGORY'} == $subcat->{'CAT_ID'} } @{ $obj->{'TOTAL_FORUMS'} };

    my $active_user_count = 0;
    for my $forum (@these_sub_cat_forums) {
        if ($forum->{'FORUM_VIEW_THREADS'} ne '*') {
            next unless grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$forum->{'FORUM_VIEW_THREADS'});
        }
        $subcat->{'TOTAL_FORUMS'} += 1;
        $subcat->{'POSTS'}        += $forum->{'FORUM_POSTS'};
        $subcat->{'TOPICS'}       += $forum->{'FORUM_TOPICS'};
        if ($forum->{'FORUM_LAST_POST'} > $subcat->{'LAST_POST'}) {
            $subcat->{'LAST_POST'}         = $forum->{'FORUM_LAST_POST'};
            $subcat->{'LAST_POSTER_N'}     = $forum->{'FORUM_LAST_POSTER_N'};
            $subcat->{'LAST_POSTER'}       = $forum->{'FORUM_LAST_POSTER'};
            $subcat->{'TOPIC_TITLE'}       = $forum->{'L_TOPIC_TITLE'};
            $subcat->{'FORUM_ID'}          = $forum->{'FORUM_ID'};
            $subcat->{'TOPIC_ID'}          = $forum->{'L_TOPIC_ID'};
            $subcat->{'NEW_POST_IMG'}      = $obj->new_cat_posts($forum);
            $subcat->{'_is_private'}       = $forum->{'FORUM_PROTECT'};
        }
# added by kevaholic00
        $active_user_count += $iB::ACTIVE->{'FORUMS'}->{ $forum->{'FORUM_ID'} };
# end addition
    }

    # Make sure we have a last post image:
    $subcat->{'NEW_POST_IMG'}      ||= $obj->new_cat_posts({FORUM_LAST_POST => $subcat->{'LAST_POST'}});

# added by kevaholic00
    $subcat->{'FORUM_USERS'} = $active_user_count || 0;
# end addition

    $subcat->{'LAST_POST'}  = $std->get_date( TIME => $subcat->{'LAST_POST'}, METHOD => 'LONG');
    $subcat->{'LAST_POST'}  = '--' unless $subcat->{'LAST_POST'};
    $subcat->{'N_LINK'}     = ($subcat->{'TOPIC_TITLE'} and defined $subcat->{'TOPIC_ID'})
                              ? qq[<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=NW;f=$subcat->{'FORUM_ID'};t=$subcat->{'TOPIC_ID'}'>$subcat->{'TOPIC_TITLE'}</a>]
                              : $Boards::lang->{'f_none'};

    if ($subcat->{'LAST_POSTER_N'}) {
        $subcat->{'P_LINK'} = $subcat->{'LAST_POSTER'} ? qq[<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$subcat->{'LAST_POSTER'}'>$subcat->{'LAST_POSTER_N'}</a>]
                                                           : $subcat->{'LAST_POSTER_N'};
    }


    if ($subcat->{'_is_private'}) {
        $subcat->{'N_LINK'} = $Boards::lang->{'f_protected'};
        $subcat->{'P_LINK'} = '--';
        $subcat->{'LAST_POST'} = '--';
    }

    $subcat->{'P_LINK'} = $Boards::lang->{'f_none'} unless $subcat->{'P_LINK'};

    # Because in perl, 1 minus 1 equals -1 (can't be zero as zero is 'nothing') we need
    # to make it human readable..
    $subcat->{'POSTS'} = 0  if $subcat->{'POSTS'} < 0;
    $subcat->{'TOPICS'} = 0 if $subcat->{'TOPICS'} < 0;

    #XXX Are there any forums in this category that we're allowed to see?
    #XXX If not, there's no point printing it...

    $cats_printed->{ $subcat->{'CAT_ID'} } = 1;

    if ($subcat->{'TOTAL_FORUMS'} > 0) {
        return BoardsView::CatHeader_Collapsed($subcat);
    }
}

####################################################################
#
# Parses all the info and returns the created HTML for a forum entry
#
####################################################################

sub render_forum {
    my ($obj, $this_forum) = @_;

    # Double check the validity of the BD
    next unless defined $this_forum->{'FORUM_ID'};

    if ($this_forum->{'FORUM_VIEW_THREADS'} ne '*') {
        next unless grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$this_forum->{'FORUM_VIEW_THREADS'});
    }

    $this_forum->{'N_LINK'} = ($this_forum->{'L_TOPIC_TITLE'} and defined $this_forum->{'L_TOPIC_ID'})
                            ? qq[<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=NW;f=$this_forum->{'FORUM_ID'};t=$this_forum->{'L_TOPIC_ID'}' class='misc'>$this_forum->{'L_TOPIC_TITLE'}</a>]
                            : $Boards::lang->{'f_none'};

    if ($this_forum->{'FORUM_LAST_POSTER_N'}) {
        $this_forum->{'P_LINK'} = $this_forum->{'FORUM_LAST_POSTER'} ? qq[<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$this_forum->{'FORUM_LAST_POSTER'}' class='misc'>$this_forum->{'FORUM_LAST_POSTER_N'}</a>]
                                                                 : $this_forum->{'FORUM_LAST_POSTER_N'};
    } else {
        $this_forum->{'P_LINK'} = $Boards::lang->{'f_none'};
    }

    $this_forum->{'NEW_POST_IMG'}       = $obj->new_posts($this_forum);
    $this_forum->{'FORUM_LAST_POST'}    = $std->get_date( TIME => $this_forum->{'FORUM_LAST_POST'}, METHOD => 'LONG');
    $this_forum->{'FORUM_USERS'}        = $iB::ACTIVE->{'FORUMS'}->{ $this_forum->{'FORUM_ID'} } || 0;

    if ($this_forum->{'FORUM_PROTECT'}) {
        next unless $iB::MEMBER->{'MEMBER_ID'};
        $this_forum->{'N_LINK'} = qq[$Boards::lang->{'f_protected'}];
        $this_forum->{'P_LINK'} = '--';
        $this_forum->{'FORUM_LAST_POST'} = '--';
    }

   my @mods;
    for ( grep { $this_forum->{'FORUM_ID'} == $_->{'FORUM_ID'} } @{ $obj->{'MODERATORS'} } ) {
        if ($iB::INFO->{'MOD_DROP_DOWN'} == 1) {
            push @mods, "<option value='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$_->{'MEMBER_ID'}'>$_->{'MEMBER_NAME'}</option>";
        } elsif ($iB::INFO->{'MOD_DROP_DOWN'} == 2) {
            push @mods, "<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$_->{'MEMBER_ID'}'>$_->{'MEMBER_NAME'}</a>";
        } else {
            push @mods, "<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$_->{'MEMBER_ID'}'>$_->{'MEMBER_NAME'}</a>";
        }
    }

    #$this_forum->{'MODERATOR'} = $Boards::lang->{'forum_leader'} . join ", ", @mods if @mods > 0;
    $this_forum->{'MODERATOR'} = join ", ", @mods if @mods > 0;
    if (!$iB::INFO->{'MOD_DROP_DOWN'} and @mods > 0) {
        $this_forum->{'MODERATOR'} = $Boards::lang->{'forum_leader'} . $this_forum->{'MODERATOR'};
    }
    # Because in perl, 1 minus 1 equals -1 (can't be zero as zero is 'nothing') we need
    # to make it human readable..
    $this_forum->{'FORUM_TOPICS'} = 0  if $this_forum->{'FORUM_TOPICS'} < 0;
    $this_forum->{'FORUM_POSTS'}  = 0  if $this_forum->{'FORUM_POSTS'}  < 0;


    return BoardsView::ForumRow($this_forum);
}

sub new_cat_posts {
    my ($obj, $this_forum) = @_;
    my $fcookie   = $iB::COOKIES->{ $iB::INFO->{COOKIE_ID}.'forum-'.$this_forum->{FORUM_ID} };
    my $lastvisit = $fcookie && $fcookie > $iB::last_visit ? $fcookie : $iB::last_visit;
    return $iB::SKIN->{'C_OFF_CAT'} unless $this_forum->{'FORUM_POSTS'} > 0 or $lastvisit;
    return $this_forum->{'FORUM_LAST_POST'} > $lastvisit  ? $iB::SKIN->{'C_ON_CAT'}
                                                          : $iB::SKIN->{'C_OFF_CAT'};
}

sub new_posts ($) {
    my ($obj, $this_forum) = @_;
    return $iB::SKIN->{'C_LOCKED'} unless $this_forum->{'FORUM_STATUS'};

    my $fcookie   = $iB::COOKIES->{ $iB::INFO->{COOKIE_ID}.'forum-'.$this_forum->{FORUM_ID} };
    my $lastvisit = $fcookie && $fcookie > $iB::last_visit ? $fcookie : $iB::last_visit;

    if ($this_forum->{'FORUM_PROTECT'}) {
        return $this_forum->{'FORUM_LAST_POST'} > $lastvisit  ? $iB::SKIN->{'C_ON_RES'}
                                                              : $iB::SKIN->{'C_OFF_RES'};
    }
    return $iB::SKIN->{'C_OFF'} unless $lastvisit;
    return $this_forum->{'FORUM_LAST_POST'} > $lastvisit  ? $iB::SKIN->{'C_ON'}
                                                          : $iB::SKIN->{'C_OFF'};
}

1;
