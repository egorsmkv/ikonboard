package Misc::Track;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Track: Track a topic
#
#################################################################################

BEGIN {
   require 'Lib/FUNC.pm';
}

my $mem         = FUNC::Member->new();
my $std         = FUNC::STD->new();
my $output      = FUNC::Output->new();
$Track::lang = $std->LoadLanguage('MailFunctionsWords');


sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}


sub Process {
    my ($obj, $db) = @_;

    #Require Valid forum_id
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'incorrect_use'
               ) unless defined $std->IsNumber($iB::IN{'f'});

    #Require Valid Topic_id
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'incorrect_use'
               ) unless defined $std->IsNumber($iB::IN{'t'});

    #Require Member ID
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'not_registered'
               ) unless $iB::MEMBER->{'MEMBER_ID'};


    #Are we already subscribed?

    my $sub = $db->query( TABLE => 'forum_subscriptions',
                          MATCH => 'ONE',
                          WHERE => "FORUM_ID == $iB::IN{'f'} and TOPIC_ID == $iB::IN{'t'} and MEMBER_ID eq '$iB::MEMBER->{'MEMBER_ID'}'"
                        );

    if ($sub->{'ID'}) {
        $std->Error( DB      => $db,
                     LEVEL   => 1,
                     STD     => $std,
                     MESSAGE => 'already_sub'
                   );
    }

    # Do we have permission to subscribe to this thread?

    my $forum = $db->select( TABLE => 'forum_info',
                             KEY   =>  $iB::IN{'f'}
                           );

    if ($forum->{'FORUM_VIEW_THREADS'} ne '*') {
        unless (grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$forum->{'FORUM_VIEW_THREADS'}) ) {
            $std->Error(     DB      => $db,
                             LEVEL   => '2',
                             MESSAGE =>'forum_no_access'
                       );
        }
    }

    #Insert the new subscription

    $iB::MEMBER->{'CANCEL_SUBS'} ||= 30;
    my $full = (split/&/, $iB::MEMBER->{'EMAIL_FULL_POST'})[0]; # if you want the full post first byte
    my $once = (split/&/, $iB::MEMBER->{'EMAIL_FULL_POST'})[1]; # if you want the reminder once secound byte

    $db->insert( TABLE   => 'forum_subscriptions',
                 VALUES  => { MEMBER_ID     => $iB::MEMBER->{'MEMBER_ID'},
                              MEMBER_NAME   => $iB::MEMBER->{'MEMBER_NAME'},
                              EMAIL_ADDRESS => $iB::MEMBER->{'MEMBER_EMAIL'},
                              FORUM_ID      => $iB::IN{'f'},
                              TOPIC_ID      => $iB::IN{'t'},
                              DATE_STARTED  => time,
                              SEND_ONCE     => $once,
                              PRUNE         => $iB::MEMBER->{'CANCEL_SUBS'},
                              rFULL         => $full,
                            }
                );

      

if (($iB::IN{'t'}) eq 0) {
    $output->redirect_screen( TEXT => $Track::lang->{'sub_added'}, URL => "act=SF&f=$iB::IN{'f'}");
}
 else {
   $output->redirect_screen( TEXT => $Track::lang->{'sub_added'}, URL => "act=ST&f=$iB::IN{'f'}&t=$iB::IN{'t'}&st=$iB::IN{'st'}");
}
}

sub subs {
    my $obj = shift;
    my $IN  = {                         
                FORUM  => "",
                DB     => "",
                TOPIC  => "", 
                MEMBER => "",
                @_,
              };
    my $db       = $IN->{'DB'};
    my $topic    = $IN->{'TOPIC'};
    my $forum_s  = $IN->{'FORUM'};
    my $member   = $IN->{'MEMBER'};

    my $sub = $db->query( TABLE => 'forum_subscriptions',
                          MATCH => 'ONE',
                          WHERE => "FORUM_ID == $forum_s and TOPIC_ID == $topic and MEMBER_ID eq $member->{'MEMBER_ID'}"
                        );

    if ($sub->{'ID'}) {
    return;    
        }

    # Do we have permission to subscribe to this thread?

    my $forum = $db->select( TABLE => 'forum_info',
                             KEY   =>  $forum_s
                           );

    if ($forum->{'FORUM_VIEW_THREADS'} ne '*') {
        unless (grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$forum->{'FORUM_VIEW_THREADS'}) ) {
            $std->Error(     DB      => $db,
                             LEVEL   => '2',
                             MESSAGE =>'forum_no_access'
                       );
        }
    }

    #Insert the new subscription

    $member->{'CANCEL_SUBS'} ||= 30;
    my $full = (split/&/, $member->{'EMAIL_FULL_POST'})[0]; # if you want the full post first byte
    my $once = (split/&/, $member->{'EMAIL_FULL_POST'})[1]; # if you want the reminder once secound byte

    $db->insert( TABLE   => 'forum_subscriptions',
                 VALUES  => { MEMBER_ID     => $member->{'MEMBER_ID'},
                              MEMBER_NAME   => $member->{'MEMBER_NAME'},
                              EMAIL_ADDRESS => $member->{'MEMBER_EMAIL'},
                              FORUM_ID      => $forum_s,
                              TOPIC_ID      => $topic,
                              DATE_STARTED  => time,
                              SEND_ONCE     => $once,
                              PRUNE         => $member->{'CANCEL_SUBS'},
                              rFULL         => $full,
                            }
                );
}

1;
