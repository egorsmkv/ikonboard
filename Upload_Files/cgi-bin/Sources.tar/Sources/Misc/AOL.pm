package Misc::AOL;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# AOL: AIM pager
#
#################################################################################

BEGIN {
   require 'Lib/FUNC.pm';
}

my $std         = FUNC::STD->new();
my $output      = FUNC::Output->new();
require $iB::SKIN->{'DIR'} . '/PagerView.pm' or die $!;

my $html = undef;

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}


sub Process {
    my ($obj, $db) = @_;
    
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'no_user'
               ) unless $iB::IN{'MID'};


    my $member = $db->select( TABLE  => 'member_profiles',
                              ID     => $iB::IN{'MID'},
                              KEY    => $iB::IN{'MID'},
                             );

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'no_user'
               ) unless $member->{'MEMBER_ID'};

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'no_aol'
               ) unless $member->{'AOLNAME'};


    $html  = PagerView::aol_body( { AOLNAME => $member->{'AOLNAME'} } );
 

    $output->print_popup( STD        => $std,
                          OUTPUT     => $html,
                          TITLE      => "iB::".$Pager::lang->{'aol_title'},
                        );

}

1;


__END__
