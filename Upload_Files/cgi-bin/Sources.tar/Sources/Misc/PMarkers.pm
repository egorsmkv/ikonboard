package Misc::PMarkers;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# PMarkers: Post markers resetter
#
#################################################################################

BEGIN {
   require 'Lib/FUNC.pm';
}

my $std         = FUNC::STD->new();
my $output      = FUNC::Output->new();


sub new {
  my $pkg = shift;
  my $obj = {};
  bless $obj, $pkg;
  return $obj;
}


sub Process {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 STD     => $std,
                 MESSAGE => 'not_registered'
               ) unless $iB::MEMBER->{'MEMBER_ID'};


    $db->update( TABLE  => 'member_profiles',
                 ID     => $iB::MEMBER->{'MEMBER_ID'},
                 KEY    => $iB::MEMBER->{'MEMBER_ID'},
                 VALUES => { LAST_LOG_IN => time }
               );

    push @{$iB::COOKIES_OUT}, $iB::CGI->cookie( -name => $iB::INFO->{'COOKIE_ID'}.'lastvisit', -value => time, -expires => '+1y', -path => $iB::INFO->{'COOKIE_PATH'}, -domain => $iB::INFO{'COOKIE_DOMAIN'} );

    $output->redirect_screen( TEXT  => 'The Post Markers have been marked as read', URL => "");

}

1;


__END__
