package Misc::Cookies;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# Cookies: Resetting Ikonboard cookies
#
#################################################################################

BEGIN {
   require 'Lib/FUNC.pm';
}

my $std         = FUNC::STD->new();
my $output      = FUNC::Output->new();

$Universal::lang = $std->LoadLanguage("UniversalWords");


sub new {
  my $pkg = shift;
  my $obj = {};
  bless $obj, $pkg;
  return $obj;
}


sub Process {
    my ($obj, $db) = @_;
    my $toilets = 'Cookies';

    if ($iB::IN{f}) {
        push @{$iB::COOKIES_OUT}, $iB::CGI->cookie( -name => $iB::INFO->{COOKIE_ID}."forum-$iB::IN{f}", -value => time, -path => $iB::INFO->{'COOKIE_PATH'}, -domain => $iB::INFO->{'COOKIE_DOMAIN'}, -expires => '+1y' );
        $output->redirect_screen( TEXT  => $Universal::lang->{forum_read}, URL => "act=SF;f=$iB::IN{'f'}");
    } else { 
        for (keys %{$iB::COOKIES}) {
            next unless /$iB::INFO->{'COOKIE_ID'}/;
            push @{$iB::COOKIES_OUT}, $iB::CGI->cookie( -name => $_, -value => '-', -expires=>'+1d', -path => $iB::INFO->{'COOKIE_PATH'}, -domain => $iB::INFO->{'COOKIE_DOMAIN'} );
        
        }
    $output->redirect_screen( TEXT  => $Universal::lang->{cookies_flushed}, URL => "");
    }


}

1;


__END__
