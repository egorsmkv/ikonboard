package Statistics;
use strict;

############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
# Statistics: Stats page functions
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'Data/Boardinfo.cgi';
}

require $iB::SKIN->{'DIR'} . '/StatisticsView.pm' or die $!;

# Standard board routines
my $std        = FUNC::STD->new();
# Member routines, such as LoadMember
my $mem        = FUNC::Member->new();
# Our printing library
my $output     = FUNC::Output->new();
# Loading our language
$Statistics::lang = $std->LoadLanguage('StatisticsWords');
$Statistics::MOMENT;

sub new {
        my $pkg = shift;
        my $obj = {};
        bless $obj, $pkg;

        return $obj;
}


#------------------------------------------------------
# Our subroutine
# Continuing the example, lets write the subroutine that
# takes a UNIX timestamp and returns a nicely formatted
# date for our script to use.
#------------------------------------------------------

sub TopPosters {
        my ($obj, $db) = @_;

        # Here we load the information from database ...


        my $total_members = $db->query(
                                         TABLE                => 'member_profiles',
                                        WHERE                => 'MEMBER_POSTS > 0',
                                        RANGE          => '0 to 9',
                                        SORT_KEY        => 'MEMBER_POSTS',
                                        SORT_BY        => 'Z-A'
                               );

        my $Print;

        my $count = 0;

        my ($top,$i);

        for my $Row (@{$total_members}) {

                $count++;

                if ($count == 1) { $top = $Row->{MEMBER_POSTS}; }

                for ($i=0; $i<($Row->{MEMBER_POSTS} * 10)/$top; $i++) { $Row->{PIP} .= qq[<img src="$iB::INFO->{'IMAGES_URL'}/images/pip.gif" border='0'  alt=''>]; }

                $Print .= StatisticsView::TopPosters($count,$Row);

        }

        $output->print_ikonboard(
                                        DB         => $db,
                                        STD        => $std,
                                        OUTPUT     => StatisticsView::info_menu($Print),
                                        JAVASCRIPT => 1,
                                        TITLE      => $Statistics::lang->{'top_posters'},
                                        NAV        => [
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics" class='nav'> $Statistics::lang->{'stats'}</a>|,
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics&CODE=TopPosters" class='nav'> $Statistics::lang->{'top_posters'} </a>|,
                                                         ]
                            );



}

sub TopLogin {
        my ($obj, $db) = @_;

        # Here we load the information from database ...


        my $total_members = $db->query(
                                         TABLE                => 'member_profiles',
                                        RANGE          => '0 to 9',
                                        SORT_KEY        => 'LAST_LOG_IN',
                                        SORT_BY        => 'Z-A'
                               );

        my $Print;

        my $count = 0;

        my ($top,$i);

        for my $Row (@{$total_members}) {

                $count++;

                $Row->{LAST_LOG_IN}= $std->get_date( TIME  => $Row->{LAST_LOG_IN},
                                                                                                METHOD => 'LONG'
                                                                                          );

                $Print .= StatisticsView::TopLogin($count,$Row);

        }

        $output->print_ikonboard(
                                        DB         => $db,
                                        STD        => $std,
                                        OUTPUT     => StatisticsView::info_menu($Print),
                                        JAVASCRIPT => 1,
                                        TITLE      => $Statistics::lang->{'top_login'},
                                        NAV        => [
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics" class='nav'>$Statistics::lang->{'stats'}</a>|,
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics&CODE=TopLogin" class='nav'>$Statistics::lang->{'top_login'} </a>|,
                                                         ]
                            );



}

sub TopTopics {
       my ($obj, $db) = @_;

       # Here we load all the most replied topics ...
       # Because with DBM database, we need ID so we have to load all of forums here ...
       # If you know another faster way, tell me ...

       my $total_forums = $db->query(
                                        TABLE                => 'forum_info',
                                        COLUMNS   => ['FORUM_ID', 'FORUM_PROTECT', 'FORUM_VIEW_THREADS'],

                               );

       my ($i, $j, $Print);

       my $top_topics;

       my $count = 0;

       for my $MyForum (@{$total_forums}) {

          if ($MyForum->{'FORUM_PROTECT'}) {
               if (exists $iB::COOKIES->{ $iB::INFO->{'COOKIE_ID'}.'iBForum' . $MyForum->{'FORUM_ID'} }) {
                   next unless $iB::COOKIES->{ $iB::INFO->{'COOKIE_ID'}.'iBForum' . $MyForum->{'FORUM_ID'} } eq $MyForum->{'FORUM_PROTECT'};
               } else {
                   next;
               }
           }

           if ($MyForum->{'FORUM_VIEW_THREADS'} ne '*') {
               unless (grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$MyForum->{'FORUM_VIEW_THREADS'}) ) {
                   next;
               }
           }

               my $total_topics = $db->query(
                                                TABLE                => 'forum_topics',
                                               ID             => $MyForum->{FORUM_ID},
                                               WHERE            => "FORUM_ID == $MyForum->{FORUM_ID}",
                                               RANGE          => '0 to 9',
                                               SORT_KEY        => 'TOPIC_POSTS',
                                               SORT_BY        => 'Z-A'
                              );

               for my $Row (@{$total_topics}) {

                       $count++; $top_topics->{$count} = $Row;

                       #+---------------------------------------------------------
                       #         Check for viewing access
                       #+---------------------------------------------------------

                       my $check = Check_access($MyForum);

                       if ($check == 0) {
                               $top_topics->{$count}->{TOPIC_TITLE} = $Statistics::lang->{'topic_view_no_permission'};
                       }
               }
       }
       for ($i=1; $i<=$count; $i++) {

               # By the way, we create pip for our top topics here ...



               for ($j=1; $j<=$i; $j++) {

                       if ($top_topics->{$i}->{TOPIC_POSTS} > $top_topics->{$j}->{TOPIC_POSTS}) {

                               my $mid = $top_topics->{$i};
                               $top_topics->{$i} = $top_topics->{$j};
                               $top_topics->{$j} = $mid;

                       }
               }
       }

       for ($i=1; $i<=10; $i++) {
         if ({$i}->{TOPIC_POSTS} ==0) { $Print .= () } else {
               for (my $k=0; $k<($top_topics->{$i}->{TOPIC_POSTS} * 10)/$top_topics->{1}->{TOPIC_POSTS}; $k++) { $top_topics->{$i}->{PIP} .= qq[<img src="$iB::INFO->{'IMAGES_URL'}/images/pip.gif" border='0'  alt=''>]; }
                    }
               $Print .= StatisticsView::TopTopics($i, $top_topics->{$i});
       }

       $output->print_ikonboard(
                                       DB         => $db,
                                       STD        => $std,
                                       OUTPUT     => StatisticsView::info_menu($Print),
                                       JAVASCRIPT => 1,
                                       TITLE      => $Statistics::lang->{'top_topics'},
                                       NAV        => [
                                                       qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics" class='nav'>$Statistics::lang->{'stats'} </a>|,
                                                       qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics&CODE=TopTopics" class='nav'> $Statistics::lang->{'top_topics'} </a>|,
                                                        ]
                           );




}

sub TotalMembers {
        my ($obj, $db) = @_;

        # Here we load the information from database ...

        my $total_members = $db->query(
                                         TABLE                => 'member_profiles',
                               );

        my $Print;

        my $Info;

        ($Info->{total_count},$Info->{count_male},$Info->{count_female},$Info->{count_posted},$Info->{count_noavatar},$Info->{count_sign},$Info->{count_realname},$Info->{count_yahooname},$Info->{count_aolname},$Info->{count_icqnumber}) = (0,0,0,0,0,0,0,0,0,0);

        for my $Row (@{$total_members}) {

                $Info->{total_count}++;

                if ($Row->{GENDER} == 1) { $Info->{count_male}++; } else { if ($Row->{GENDER} == 2) { $Info->{count_female}++; } }

                if ($Row->{MEMBER_POSTS} >= 1) { $Info->{count_posted}++; }

                if ($Row->{MEMBER_AVATAR} eq "noavatar") { $Info->{count_noavatar}++; }

                if ($Row->{SIGNATURE}) { $Info->{count_sign}++; }

                if ($Row->{MEMBER_NAME_R}) { $Info->{count_realname}++; }

                if ($Row->{YAHOONAME}) { $Info->{count_yahooname}++; }

                if ($Row->{AOLNAME}) { $Info->{count_aolname}++; }

                if ($Row->{ICQNUMBER}) { $Info->{count_icqnumber}++; }

        }

        $Info->{count_hic} = $Info->{total_count} - $Info->{count_male} - $Info->{count_female};

        $Print .= StatisticsView::TotalMembers($Info);

        $output->print_ikonboard(
                                        DB         => $db,
                                        STD        => $std,
                                        OUTPUT     => StatisticsView::info_menu($Print),
                                        JAVASCRIPT => 1,
                                        TITLE      => $Statistics::lang->{'total_members'},
                                        NAV        => [
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics" class='nav'> $Statistics::lang->{'stats'} </a>|,
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics&CODE=TotalMembers" class='nav'> $Statistics::lang->{'total_members'} </a>|,
                                                         ]
                            );



}

sub TopNewestMembers {
        my ($obj, $db) = @_;

        # Here we load the information from database ...


        my $total_members = $db->query(
                                         TABLE                => 'member_profiles',
                                        RANGE          => '0 to 9',
                                        SORT_KEY        => 'MEMBER_JOINED',
                                        SORT_BY        => 'Z-A'
                               );

        my $Print;

        my $count = 0;

        my ($top,$i);

        for my $Row (@{$total_members}) {

                $count++;
                $Row->{'MEMBER_JOINED'}= $std->get_date( TIME  => $Row->{'MEMBER_JOINED'},
                                                                                                METHOD => 'LONG'
                                                                                          );


                $Print .= StatisticsView::TopNewestMembers($count,$Row);

        }

        $output->print_ikonboard(
                                        DB         => $db,
                                        STD        => $std,
                                        OUTPUT     => StatisticsView::info_menu($Print),
                                        JAVASCRIPT => 1,
                                        TITLE      => $Statistics::lang->{'top_newest_members'},
                                        NAV        => [
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics" class='nav'> $Statistics::lang->{'stats'} </a>|,
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics&CODE=TopPosters" class='nav'> $Statistics::lang->{'top_newest_members'} </a>|,
                                                         ]
                            );


}

sub RandomMembers {
        my ($obj, $db) = @_;


        # Here we load the information from database ...

        my $total_members = $db->query(
                                         TABLE                => 'member_profiles',
                                        WHERE                => 'MEMBER_AVATAR ne "noavatar"',
                               );

        my ($Print, $this_member);

        my ($found, $count) = 0;

        $count++;

        my $random_member = rand(@{$total_members});
        $this_member = @{$total_members}[$random_member];

        $this_member->{MEMBER_JOINED} = $std->get_date( TIME  => $this_member->{MEMBER_JOINED},
                                                                                        METHOD => 'LONG'
                                                                                          );

        #$this_member->{MEMBER_GROUP} = $obj->{'group_table'}->{ $this_member->{'MEMBER_GROUP'} };
        $this_member->{MEMBER_AVATAR} = get_avatar($this_member);

        $Print .= StatisticsView::RandomMembers($this_member, $db);

        $output->print_ikonboard(
                                        DB         => $db,
                                        STD        => $std,
                                        OUTPUT     => StatisticsView::info_menu($Print),
                                        JAVASCRIPT => 1,
                                        TITLE      => $Statistics::lang->{'moment_title'},
                                        NAV        => [
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics" class='nav'> $Statistics::lang->{'stats'} </a>|,
                                                        qq|<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Statistics&CODE=RandomMembers" class='nav'> $Statistics::lang->{'moment_title'} </a>|,
                                                         ]
                            );


}




sub Process {
        my ($obj, $db) = @_;
        my $CodeNo = $iB::IN{'CODE'};

        if ($CodeNo eq "") { $CodeNo = "TopPosters"; }

        my %Mode = (        'TopPosters'                =>         \&TopPosters,
                        'TopLogin'                =>         \&TopLogin,
                        'TopTopics'                =>         \&TopTopics,
                        'TotalMembers'        =>         \&TotalMembers,
                        'TopNewestMembers'        =>         \&TopNewestMembers,
                        'RandomMembers'        =>         \&RandomMembers,
               );

        $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : FatalError();



}

sub FatalError { die "IkonBoard Statistics Error.." }

sub Check_access ($) {
    my ($MyForum) = @_;

        my $result = 1;

        if ($MyForum->{FORUM_VIEW_THREADS} ne '*') {
                unless (grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$MyForum->{FORUM_VIEW_THREADS}) ) {
                        $result = 0;
               }
        }

        return $result;
}

sub get_avatar {
    my ($this_member) = @_;

    return unless $iB::INFO->{'AVATARS'}
              and $this_member->{MEMBER_AVATAR}
              and $iB::MEMBER->{'VIEW_AVS'};

    return if $this_member->{MEMBER_AVATAR} eq 'noavatar';
    return '' if $this_member->{MEMBER_AVATAR} =~ m#\.swf#i and $iB::INFO->{'ALLOW_FLASH'} != 1;
    my ($a_width   , $a_height)  = split "x", $iB::INFO->{'AV_DIMS'};
    my ($d_a_width, $d_a_height) = split "x", $iB::INFO->{'DEF_AV_DIMS'};
    if ($this_member->{MEMBER_AVATAR} =~ m#\Ahttp\://#i) {
        if ($iB::INFO->{'AV_ALLOW_URL'}) {
            my ($width  , $height)   = split "x", $this_member->{'AVATAR_DIMS'};
            $height ||= $a_height;
            $width  ||= $a_width;
            return $this_member->{MEMBER_AVATAR} =~ m#\.swf\Z#i ? qq|<OBJECT CLASSID="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" WIDTH=$width HEIGHT=$height><PARAM NAME=MOVIE VALUE=$this_member->{MEMBER_AVATAR}><PARAM NAME=PLAY VALUE=TRUE><PARAM NAME=LOOP VALUE=TRUE><PARAM NAME=QUALITY VALUE=HIGH><EMBED SRC=$this_member->{MEMBER_AVATAR} WIDTH=$width HEIGHT=$height PLAY=TRUE LOOP=TRUE QUALITY=HIGH></EMBED></OBJECT>|
                                                                      : qq|<img src='$this_member->{MEMBER_AVATAR}' border='0' width='$width' height='$height' alt=''>|;
        }
    }
    return qq|<img src='$iB::INFO->{'AVATARS_URL'}/$this_member->{MEMBER_AVATAR}' border='0' width='$d_a_width' height='$d_a_height' alt=''>| unless $this_member->{MEMBER_AVATAR} =~ m#\Ahttp\://#i;
}


1;
