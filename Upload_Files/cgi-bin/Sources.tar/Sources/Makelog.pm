package Makelog;

############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################

use Carp;
use iDatabase;
use Boardinfo;

my $INFO  = Boardinfo->new();
my $db    = iDatabase->new();


sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    $obj->{'ARGS'} = { INDEX=>"",DATA=>"",@_ };
    return $obj;
}



sub add_log ($) {
    my $obj = shift;
    $db->connect('Logging/'.$obj->{'ARGS'}->{'INDEX'},$obj->{'ARGS'}->{'INDEX'});
    my $sth = $db->prepare(INSERT=>$obj->{'ARGS'}->{'DATA'},WHERE=>'at bottom');
    $sth->execute();
    $sth->done();
    $db->disconnect($sth);
}



1;

__END__
