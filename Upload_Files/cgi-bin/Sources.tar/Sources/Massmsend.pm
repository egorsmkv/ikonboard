package Massmsend;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Messenger: Messenger Mass Send Functions.
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
}

my $mail         = FUNC::Mailer->new();
my $output       = FUNC::Output->new();
my $mem          = FUNC::Member->new();
my $std          = FUNC::STD->new();
my $txt          = iTextparser->new();
$Messenger::lang = $std->LoadLanguage('MessengerWords');

sub new {
  my $pkg = shift;
  my $obj = { R_MEMBER => $iB::MEMBER, NEW_MSG_DATA => '', '.to_member' => '', '.html' => '' };
  bless $obj, $pkg;
  return $obj;
}


sub send {
    my ($obj, $db) = @_;

    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'moderate_no_permission') unless ($obj->{'R_MEMBER'}->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'});
    if ($iB::IN{'save'}) {
        $obj->notepad($db);
    }
    if ($iB::IN{'preview'}) {
    $obj->mass_pm_form($db);
    }
    $iB::IN{'MODE'} ? $obj->send_mass($db) : $obj->mass_pm_form($db);
}



sub send_mass {
    my ($obj,$db) = @_;

    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'moderate_no_permission') unless ($obj->{'R_MEMBER'}->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'});

    $iB::IN{'iconid'} ||= 0;

    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'incorrect_use')    unless $iB::IN{'MODE'} == '01';
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_msg_title')     unless $iB::IN{'msg_title'};
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_msg')           unless $iB::IN{'Post'};
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_chosen_group')  unless $iB::IN{'to_groups'};

     my $add_sent = 1;
     my $r_mem = $obj->{'R_MEMBER'}->{'MEMBER_ID'};
     my $rn_mem = $obj->{'R_MEMBER'}->{'MEMBER_NAME'};
     my $re_mem = $obj->{'R_MEMBER'}->{'MEMBER_EMAIL'};
     my $msg_title = $iB::IN{'msg_title'};
     my $iconid = $iB::IN{'iconid'};
     my $track = $iB::IN{'add_tracking'};
     my $msg_allow_code = IB_CODE => $iB::INFO->{'MSG_ALLOW_CODE'};
     my $msg_allow_html = $iB::INFO->{'MSG_ALLOW_HTML'};
     my ($refused_list, $full_list);
     my $post = $iB::IN{'Post'};
     my @valu;
     my ($where,$i);
     foreach($iB::CGI->param('to_groups')) {
     $i++;
     $where .= " or " unless $i == 1;
     $where .= "MEMBER_GROUP == \'$_\'";
     if ($_ eq 'ALL') {
     $where = "";
     last;
     }
     }
     my $member;
     if ($where eq '') {
                 $member = $db->query( TABLE   => 'member_profiles',
                                       MATCH   => "ALL",
                                       );
                    }
            else {
                 $member = $db->query( TABLE   => 'member_profiles',
                                       WHERE   => "$where",
                                      );
                  }
    my @to_names;
    foreach my $who1 (@{$member}) {
             undef $who1->{'MEMBER_PASSWORD'};
            if ($who1->{'ALLOW_ADMIN_EMAILS'} == 0) {
                $refused_list .= "$who1->{'MEMBER_NAME'}, ";
            }

            my $msg_stats = { };
            $msg_stats = $db->select( TABLE => 'message_stats',
                                      ID    => $who1->{'MEMBER_ID'},
                                      KEY   => $who1->{'MEMBER_ID'},
                                    );

            if ($msg_stats->{'MEMBER_ID'}) {
                if($obj->{'group_table'}->{ $who1->{'MEMBER_GROUP'} }->{'MAX_SIZE'} && $msg_stats->{'TOTAL_MESSAGES'} >= $obj->{'group_table'}->{ $who1->{'MEMBER_GROUP'} }->{'MAX_SIZE'}) {
# Target member can not receive anymore PMs per Board setting (max pms)
                $full_list .= "$who1->{'MEMBER_NAME'}, ";
                       next;
                }
            }
# collects the aproved members
               push @to_names, $who1;
     }
     my $sent_to_mem;
     my $quote_name_to = "$Messenger::lang->{'message_to_group'} ";
     my $groups;
     $i = 0;
     foreach($iB::CGI->param('to_groups')) {
     $i++;
     $groups .= " or " unless $i == 1;
     $groups .= "ID == \'$_\'";
     }
     my $mem_groups = $db->query( TABLE    => 'mem_groups',
                                  COLUMNS  => ['ID', 'TITLE', 'MAX_MESSAGES'],
                                  WHERE    => $groups,
                                  SORT_KEY => 'TITLE',
                                  SORT_BY  => 'A-Z',
                               );
    my %temp_groups = map { $_->{'ID'} => { MAX_SIZE => $_->{'MAX_MESSAGES'},
                            ID       => $_->{'ID'},
                                          }
                          } @{$mem_groups};
    $obj->{'group_table'} = \%temp_groups;

     $i = 0;
     foreach(@{$mem_groups}){
        $i++;
        $quote_name_to .= ", $_->{'TITLE'}" unless $i == 1;
        $quote_name_to .= "$_->{'TITLE'}" unless $i > 1;
     }
     my $text_to_admin = qq~<br>$Messenger::lang->{'message_refused'}$refused_list <br>~;
     $text_to_admin .= "$Messenger::lang->{'box_full'}$full_list";
     my $txt_to = qq|[QUOTE]|. $quote_name_to . qq|[/QUOTE]\n|;
     $quote_name_to .= $text_to_admin;
     $text_to_admin = qq|[QUOTE]|. $quote_name_to . qq|[/QUOTE]\n|;
     $text_to_admin .= $post;
     $txt_to .= $post;
     $post = $txt_to;
     my $mess1 = $txt->Convert_for_db( TEXT    => $post,
                                       SMILIES => 1,
                                       IB_CODE => $msg_allow_code,
                                       HTML    => $msg_allow_html,
                                       USER    => ,
                                     ) if $post;

     my $b = 0;
     if ($add_sent) {
          my $temp_msg_stats = { };
          $temp_msg_stats = $db->select( TABLE => 'message_stats',
                                         ID    => $r_mem,
                                         KEY   => $r_mem,
                                       );

        if ($temp_msg_stats->{'MEMBER_ID'}) {
            if($obj->{'group_table'}->{ $iB::MEMBER_GROUP->{'ID'} }->{'MAX_SIZE'} && $temp_msg_stats->{'TOTAL_MESSAGES'} >= $obj->{'group_table'}->{ $iB::MEMBER_GROUP->{'ID'} }->{'MAX_SIZE'}) {
# The sender can not receive anymore PMs per Board setting (max pms)
                $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'max_message_from');
            }
        }
      }
       foreach my $p(@to_names){
        my $show_popup = (split/&/, $p->{'PM_REMINDER'})[1];

        my $trackingid = 0;
 #   Are we tracking this ?
        if ($track) {
            $trackingid = -1;
        }
        my $msg_stats = { };
       $msg_stats = $db->select( TABLE => 'message_stats',
                                 ID    => $p->{'MEMBER_ID'},
                                 KEY   => $p->{'MEMBER_ID'},
                               );

        my $new_id = $db->insert( TABLE  => 'message_data',
                                  ID     => $p->{'MEMBER_ID'},
                                  VALUES => { DATE              => time,
                                              READ_STATE        => $trackingid,
                                              TITLE             => $msg_title,
                                              MESSAGE           => $post,
                                              MESSAGE_ICON      => $iconid,
                                              FROM_ID           => $r_mem,
                                              FROM_NAME         => $rn_mem,
                                              REPLY             => '',
                                              REPLY_DATE        => '',
                                              VIRTUAL_DIR       => 'in',
                                              MEMBER_ID         => $p->{'MEMBER_ID'},
                                              RECIPIENT_ID      => $p->{'MEMBER_ID'},
                                              RECIPIENT_NAME    => $p->{'MEMBER_NAME'},
                                            }
                                 );
            my $reminder = (split/&/, $p->{'PM_REMINDER'})[0]; # Get the first byte
            if ($reminder == 1) {
                unless ($iB::INFO->{'MSG_ALL_MESS_CONT'} == 1) {
                    $mess1 = '';
                }
                my $mail_message = $mail->parse_template( ID     => 'MEM_TO_MEM',
                                                          DB     => $db,
                                                          VALUES => { FROM_NAME   =>  "$Messenger::lang->{'email_from'}$rn_mem",                                                                  MEMBER_NAME =>  $p->{'MEMBER_NAME'},
                                                                      MESSAGE     =>  $mess1,
                                                               }
                                                    );
                my $subject = "$Messenger::lang->{'email_subject'}$msg_title";

                $mail->Send( TO      => $p->{'MEMBER_EMAIL'},
                             FROM    => '',
                             SUBJECT => $subject,
                             MESSAGE => $mail_message,
                          ) if $p->{'MEMBER_EMAIL'};
        }

        if ($msg_stats->{'MEMBER_ID'}) {

            $msg_stats->{'TOTAL_MESSAGES'}++;
            $msg_stats->{'NEW_MESSAGES'}++;

            $db->update(  TABLE  => 'message_stats',
                          ID     => $p->{'MEMBER_ID'},
                          KEY    => $p->{'MEMBER_ID'},
                          VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'},
                                      NEW_MESSAGES   => $msg_stats->{'NEW_MESSAGES'},
                                      LAST_FROM_NAME => $rn_mem,
                                      LAST_FROM_ID   => $r_mem,
                                      LAST_SENT      => time,
                                      LAST_MSG_ID    => $new_id,
                                      LAST_MSG_TITLE => $msg_title,
                                      SHOW_POPUP     => $show_popup,
                                    }
                       );

        } else {
            $db->insert(  TABLE  => 'message_stats',
                          ID     =>  $p->{'MEMBER_ID'},
                          KEY    =>  $p->{'MEMBER_ID'},
                          VALUES => { MEMBER_ID          => $p->{'MEMBER_ID'},
                                      LAST_READ          => '',
                                      NEW_MESSAGES       => 1,
                                      LAST_FROM_NAME     => $rn_mem,
                                      LAST_FROM_ID       => $r_mem,
                                      LAST_MSG_ID        => $new_id,
                                      LAST_MSG_TITLE     => $msg_title,
                                      LAST_SENT          => time,
                                      TOTAL_MESSAGES     => 1,
                                      VIRTUAL_DIR        => "in:Inbox|sent:Sent Items|",
                                      SHOW_POPUP         => $show_popup,
                                     }
                        );
        }
#  Are we adding this to our sent items folder?
    $b++;

            my $my_msg_stats = { };
            $my_msg_stats = $db->select( TABLE => 'message_stats',
                                         ID    => $r_mem,
                                         KEY   => $r_mem,
                                       );

            if ($my_msg_stats->{'MEMBER_ID'}) {
                $my_msg_stats->{'TOTAL_MESSAGES'}++;
                $db->update( TABLE  => 'message_stats',
                             ID     => $r_mem,
                             KEY    => $r_mem,
                             VALUES => { TOTAL_MESSAGES => $my_msg_stats->{'TOTAL_MESSAGES'} }
                           ) unless ($b > 1);
            } else {
                $db->insert( TABLE  => 'message_stats',
                             ID     => $r_mem,
                             KEY    => $r_mem,
                             VALUES => { TOTAL_MESSAGES => 1 }
                           ) unless ($b > 1);
         }

            $db->insert( TABLE  => 'message_data',
                         ID     => $r_mem,
                         VALUES => { DATE              => time,
                                     READ_STATE        => 0,
                                     TITLE             => $Messenger::lang->{'saved_sent_msg'}.' '.$msg_title,
                                     MESSAGE           => $text_to_admin,
                                     MESSAGE_ICON      => $iconid,
                                     FROM_ID           => $r_mem,
                                     FROM_NAME         => $rn_mem,
                                     REPLY             => '',
                                     REPLY_DATE        => '',
                                     VIRTUAL_DIR       => 'in',
                                     MEMBER_ID         => $r_mem,
                                     RECIPIENT_ID      => $p->{'MEMBER_ID'},
                                     RECIPIENT_NAME    => $p->{'MEMBER_NAME'}
                                   }
                        ) unless ($b > 1);
       }
   $Messenger::lang->{'sent_text'} =~ s!<#FROM_MEMBER#>!$rn_mem!;
   $Messenger::lang->{'sent_text'} =~ s!<#TO_MEMBER#>!$b $Messenger::lang->{'members'}!;
   $Messenger::lang->{'sent_text'} =~ s!<#MESSAGE_TITLE#>!$msg_title!;

    $obj->{'.html'} .= MessengerView::sent_screen();
    $obj->{'.html'} .= MessengerView::CP_end();

    $output->print_ikonboard( DB      => $db,
                              TITLE   => $Messenger::lang->{'t_welcome'},
                              NAV     => [qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>!],
                              OUTPUT  => $obj->{'.html'}
                            );
}


sub notepad {
        my ($obj, $db) = @_;

       my $s_post = $iB::IN{'Post'} || '';

       my $is_already_in = $db->select( TABLE => 'member_notepads',
                                        KEY   => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                        WHERE => qq!MEMBER_ID eq "$obj->{'R_MEMBER'}->{'MEMBER_ID'}"!,
                                        MATCH => 'ONE',
                                      );

       if ($is_already_in->{'MEMBER_ID'}) {
           $db->update(  TABLE  => 'member_notepads',
                         ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                         KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                         VALUES => { SAVED_M => $s_post},
                      ) || die $db->{'error'};
       } else {
           $db->insert(  TABLE  => 'member_notepads',
                         VALUES => { MEMBER_ID    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                     SAVED_M => $s_post,
                                   },
                      ) || die $db->{'error'};
       }

       $output->redirect_screen( TEXT => $Messenger::lang->{'save_successful'}, URL => "act=NotePad;CODE=04" );

    }

sub td_select {
    my $obj = shift;

    my %IN = ( TEXT     => "",
               NAME     => "",
               SIZE     => "",
               MULTIPLE => "",
               DATA     => [],
               VALUES   => undef,
               REQ      => "",
               JS       => "",
               @_
             );

    my $req = $IN{'REQ'} ? " <font class='h'>*</font>" : '';

    my $text = $IN{'MULTIPLE'} ? $Messenger::lang->{'method_select'} : '';

    $IN{'SIZE'}     = "size='$IN{'SIZE'}'" if $IN{'SIZE'};
    $IN{'MULTIPLE'} = 'multiple' if $IN{'MULTIPLE'};

    my $return = qq!<select name='$IN{'NAME'}' $IN{'SIZE'} $IN{'MULTIPLE'} class='forminput' $IN{'JS'}>\n!;

    if (ref($IN{'VALUES'}) eq 'ARRAY') {
        my @values = @{ $IN{'VALUES'} };
        $IN{'VALUES'} = {};
        for (@values) {
            $IN{'VALUES'}->{$_} = 1;
        }
    } else {
        my $value = $IN{'VALUES'};
        $IN{'VALUES'} = {};
        $IN{'VALUES'}->{$value} = 1;
    }

    for my $i (@{ $IN{'DATA'} }) {
        my $selected = ' selected' if $i->{'VALUE'} ne '' and exists $IN{'VALUES'}->{ $i->{'VALUE'} };
        $return .= qq! <option value="$i->{'VALUE'}"$selected>$i->{'NAME'}</option>\n!;
    }

    $return .= '</select>';

    return qq~
    <tr>
    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' align='left' valign='top'><font class='t'>$IN{'TEXT'}$req</font></td>
    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='60%' align='left'>$return $text</td>
    </tr>
    ~;
}

sub mass_pm_form {
    my ($obj, $db) = @_;

    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'moderate_no_permission') unless ($obj->{'R_MEMBER'}->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'});

    my $in_post   = $txt->Convert_for_db( TEXT    => $iB::IN{'Post'},
                                          SMILIES => 1,
                                          IB_CODE => $iB::INFO->{'MSG_ALLOW_CODE'},
                                          HTML    => $iB::INFO->{'MSG_ALLOW_HTML'},
                                          USER    => ,
                                        ) if $iB::IN{'Post'};

    require $iB::SKIN->{'DIR'} . '/PostView.pm' or $std->cgi_error($!);
    $Post::lang = $std->LoadLanguage('PostWords');

    $Messenger::lang->{'max_msg'}     =~ s!<#MAX_MSG_SIZE#>!$iB::INFO->{'MAX_MSG_SIZE'}!;
    $Messenger::lang->{'the_max_msg'} = $iB::INFO->{'MAX_MSG_SIZE'} * 1024;

    my ($old_message, $old_title);

    my @val;
    if ($in_post) {
        $obj->{'.html'}  = MessengerView::preview($in_post);
        $obj->{'.html'} .= $obj->Show_menu($db);
        $old_title = $iB::IN{'msg_title'};
        my ($who, $i, $name1);
        foreach($iB::CGI->param('to_groups')) {
            $i++;
            $who .= "&" unless $i == 1;
            $who .= $_;
        }
    @val = split(/&/,$who);
    $old_message = $iB::IN{'Post'};
    $old_message =~ s!<br>!\n!g;
    }
    my $mem_groups = $db->query( TABLE    => 'mem_groups',
                                 COLUMNS  => ['ID', 'TITLE'],
                                 SORT_KEY => 'TITLE',
                                 SORT_BY  => 'A-Z',
                              );

    my @mem_group;
    for my $group (@{ $mem_groups }) {
       push @mem_group, { NAME => $group->{'TITLE'}, VALUE => $group->{'ID'} } if $group->{'TITLE'} ne 'Guests';
    }
    my $size = scalar @mem_group;
          my $groups = $obj->td_select( TEXT     => $Messenger::lang->{'select_group'},
                                        NAME     => 'to_groups',
                                        SIZE     => $size,
                                        MULTIPLE => 1,
                                        VALUES   => \@val,
                                        DATA     => \@mem_group,
                                     );

    $obj->{'.html'} .= MessengerView::Send_form_mass(
                                                 {
                                                    CONTACTS => $groups,
                                                    MEMBER   => $obj->{'R_MEMBER'},
                                                    O_TITLE  => $old_title
                                                 }
                                                );
    $Post::lang->{'the_max_length'} = $iB::INFO->{'MAX_MSG_SIZE'} * 1024;
    $Post::lang->{'ib_state'}   = $iB::INFO->{'MSG_ALLOW_CODE'}  ? $Post::lang->{'ib_on'}   : $Post::lang->{'ib_off'};
    $Post::lang->{'html_state'} = $iB::INFO->{'MSG_ALLOW_HTML'}  ? $Post::lang->{'html_on'} : $Post::lang->{'html_off'};
    $obj->{'.html'} .= PostView::PostIcons() . PostView::postbox_buttons($old_message);
    $obj->{'.html'} .= MessengerView::send_form_footer();
    $obj->{'.html'} .= MessengerView::CP_end();

    my $smilies = qq~<tr align='center'>\n~;
    my $cnt = 0;
    my $show_table = 0;
    for my $e (split (/\|&\|/,$iB::INFO->{'EMOTICONS'}) ) {
        my ($type, $image, $p_inc) = split (/\|/,$e);
        next unless $type and $image;
        next unless $p_inc;

        $cnt++;
        $show_table++;
        $smilies .= qq~<td><a href="javascript:emoticon('$type')"><img src="$iB::INFO->{'EMOTICONS_URL'}/$image" alt="smilie" border="0"></a>&nbsp;</td>\n~;

        if ($cnt == $iB::INFO->{'EMO_PER_ROW'}) {
            $smilies .= qq~</tr>\n\n<tr align='center'>\n~;
            $cnt = 0;
        }
    }

    if ($cnt != $iB::INFO->{'EMO_PER_ROW'}) {
        $cnt++;
        for ($cnt .. $iB::INFO->{'EMO_PER_ROW'}) {
            $smilies .= qq~<td>&nbsp;</td>\n~;
        }
        $smilies .= qq~</tr>~;
    }

    my $table = PostView::smilie_table();
    if ($show_table) {
        $table =~ s:<!--THE SMILIES-->:$smilies:;
        $obj->{'.html'} =~ s:<!--SMILIE TABLE-->:$table:;
    }

    $output->print_ikonboard( DB         => $db,
                              TITLE      => $Messenger::lang->{'t_welcome'},
                              JAVASCRIPT => 1,
                              NAV        => [qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>!],
                              OUTPUT     => $obj->{'.html'}
                            );
}
 
sub Show_menu ($) {
    my ($obj, $db) = @_;

    if ($obj->{'R_MEMBER'}->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}){
        my $Nav_tabs = { '00' => 'splash', '01' => 'in_box', '02' => 'contact', '07' => 'prefs', '04' => 'send', '13' => 'send2'};
        my $Nav_color = { };
        for (qw[splash in_box contact prefs send send2]) { $Nav_color->{$_} = $iB::SKIN->{'USERNAV_OFF'} }
        $Nav_color->{ $Nav_tabs->{ $iB::IN{'CODE'} } } = $iB::SKIN->{'USERNAV_ON'};
    return MessengerView::Menu_bar_admin($Nav_color);
    }
    my $Nav_tabs = { '00' => 'splash', '01' => 'in_box', '02' => 'contact', '07' => 'prefs', '04' => 'send'};
    my $Nav_color = { };
    for (qw[splash in_box contact prefs send]) { $Nav_color->{$_} = $iB::SKIN->{'USERNAV_OFF'} }
    $Nav_color->{ $Nav_tabs->{ $iB::IN{'CODE'} } } = $iB::SKIN->{'USERNAV_ON'};
    return MessengerView::Menu_bar($Nav_color);
}
 

sub Process {
    my ($obj, $db) = @_;
    $std->Error(LEVEL=>'1',MESSAGE=>'Wha.....?') unless (defined $iB::IN{'CODE'});
    $obj->SetSession($db);
    my $CodeNo = $std->CheckCodeNo($iB::IN{'CODE'});
    my %Mode = (
                 '13'     => \&send,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : MessengerError($obj,$db);
}

sub SetSession {
    my ($obj, $db) = @_;

    # Display an "error" if we are not allowed to use the messenger
    unless ($iB::MEMBER_GROUP->{'USE_PM'}) {
        $std->Error( DB => $db, LEVEL => 1, MESSAGE => 'no_use_messenger' );
        return "0 but true";
    }
    require $iB::SKIN->{'DIR'} . '/MessengerView.pm' or $std->cgi_error($!);
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_guest_posting')  unless $obj->{'R_MEMBER'}->{'MEMBER_ID'};
    $obj->{'.html'} = $obj->Show_menu($db);
}


sub MessengerError  {
    my ($obj, $db) = @_; $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'incorrect_use')
    }


1;
