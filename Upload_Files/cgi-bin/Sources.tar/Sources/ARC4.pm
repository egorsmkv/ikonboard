#------------------------------------------------------#
#  This is free software and may be modified and/or
#  redistributed under the same terms as Perl itself.
#------------------------------------------------------#

package Crypt::ARC4;

use strict;
use vars qw(@ISA @EXPORT $MAX_CHUNK_SIZE );

$MAX_CHUNK_SIZE = 1024 unless $MAX_CHUNK_SIZE;

require Exporter;

@ISA     = qw(Exporter);
@EXPORT  = qw(ARC4);

sub new {
    my ( $class, $key )  = @_;
    my $self = bless {}, $class;
    $self->{state} = Setup( $key );
    $self->{x} = 0;
    $self->{y} = 0;
    $self;
}

sub ARC4 {
    my $self;
    my( @state, $x, $y );
    if ( ref $_[0] ) {
        $self = shift;
    @state = @{ $self->{state} };
    $x = $self->{x};
    $y = $self->{y};
    } else {
        @state = Setup( shift );
    $x = $y = 0;
    }
    my $message = shift;
    my $num_pieces = do {
    my $num = length($message) / $MAX_CHUNK_SIZE;
    my $int = int $num;
    $int == $num ? $int : $int+1;
    };
    for my $piece ( 0..$num_pieces - 1 ) {
    my @message = unpack "C*", substr($message, $piece * $MAX_CHUNK_SIZE, $MAX_CHUNK_SIZE);
    for ( @message ) {
        $x = 0 if ++$x > 255;
        $y -= 256 if ($y += $state[$x]) > 255;
        @state[$x, $y] = @state[$y, $x];
        $_ ^= $state[( $state[$x] + $state[$y] ) % 256];
    }
    substr($message, $piece * $MAX_CHUNK_SIZE, $MAX_CHUNK_SIZE) = pack "C*", @message;
    }
    if ($self) {
        $self->{state} = \@state;
     $self->{x} = $x;
        $self->{y} = $y;
    }
    $message;
}

sub Setup {
    my @k = unpack( 'C*', shift );
    my @state = 0..255;
    my $y = 0;
    for my $x (0..255) {
    $y = ( $k[$x % @k] + $state[$x] + $y ) % 256;
    @state[$x, $y] = @state[$y, $x];
    }
    wantarray ? @state : \@state;
}


1;
__END__

# process an entire file, one line at a time
# (Warning: Encrypted file leaks line lengths.)
#  $ref = Crypt::ARC4->new( $passphrase );
#  while (<FILE>) {
#      chomp;
#      print $ref->ARC4($_), "\n";
#  }


