package Posters;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Posters: Shows who posted in a topic in a popup window.
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require $iB::SKIN->{'DIR'} . '/PostersView.pm' or die $!;
}

my $output  = FUNC::Output->new();
my $std     = FUNC::STD->new();
my $output  = FUNC::Output->new();
$Pos::lang = $std->LoadLanguage('PostersWords');

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}


sub showposter {
    my ($obj, $db) = @_;

    return unless ((defined $iB::IN{'t'}) and (defined $iB::IN{'f'}));
    my $forum_id = $std->IsNumber($iB::IN{'f'}) || 0;
    my $topic_id = $std->IsNumber($iB::IN{'t'}) || 0;
    my $membid      = $iB::MEMBER->{'MEMBER_ID'};
    my $Cnt = 0;
    my $target = '';
    my $last;
    $obj->{'TOPIC'} = $db->select(  TABLE => 'forum_topics',
                                    ID    => $forum_id,
                                    KEY   => $topic_id
                                 );
    my $total_posts = $db->query( TABLE    => 'forum_posts',
                                  DBID     => 'f'.$forum_id,
                                  ID       => $topic_id,
                                  WHERE    => "TOPIC_ID == $topic_id and QUEUED != '1'",
                                  SORT_KEY => 'AUTHOR',
                                  SORT_BY  => 'Z-A',
                                    );
        my %surname_freq = ();
    foreach my $sets (@{$total_posts}) {
            $surname_freq{$sets->{'AUTHOR'}}++;
    }
    my ($html, $who);

    $html = PostersView::start($db);

    my @names = {ID => "", NUMBER => ""};
    foreach my $surname (sort{$surname_freq{$b}<=>$surname_freq{$a} } keys %surname_freq){
                    push (@names, {ID => $surname, NUMBER => $surname_freq{$surname}});
    }
    my ($where,$i);
    foreach my $mi (@names) {
            $i++;
            $where .= " or " unless $i == 1;
            $where .= qq!MEMBER_ID eq "$mi->{'ID'}"!;
     }

    my $mem_tot = $db->query( TABLE      => 'member_profiles',
                              WHERE      => qq[$where],
                              SORT_KEY   => "MEMBER_ID",
                              SORT_BY    => 'A-Z',
                             );
    foreach my $mem (@names) {
        foreach my $id (@{$mem_tot}) {
            if ($mem->{'ID'} eq $id->{'MEMBER_ID'}) {
                $html .= PostersView::do_row($id->{'MEMBER_ID'}, $id->{'MEMBER_NAME'}, $mem->{'NUMBER'});
                next;
            }
        }
    }
    $html .= PostersView::end($forum_id, $topic_id);

        $output->print_popup( STD        => $std,
                              OUTPUT     => $html,
                              TITLE      => "$Pos::lang->{'who_post'}$obj->{'TOPIC'}->{'TOPIC_TITLE'}",
                             );
}


1;
