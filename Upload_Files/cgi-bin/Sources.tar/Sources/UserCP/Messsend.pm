package UserCP::Messsend;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# Messenger: Messenger Send Functions.
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
}

my $mail         = FUNC::Mailer->new();
my $output       = FUNC::Output->new();
my $mem          = FUNC::Member->new();
my $std          = FUNC::STD->new();
my $txt          = iTextparser->new();
$Messenger::lang = $std->LoadLanguage('MessengerWords');

sub new {
  my $pkg = shift;
  my $obj = { R_MEMBER => $iB::MEMBER, NEW_MSG_DATA => '', '.to_member' => '', '.html' => '' };
  bless $obj, $pkg;
  return $obj;
}

#+------------------------------------------------------------------------------------------------------

sub send {
    my ($obj, $db) = @_;
    my $post = $iB::IN{'Post'};
    $post = $txt->Convert_for_db( TEXT    => $post,
                                  SMILIES => 1,
                                  IB_CODE => $iB::INFO->{'MSG_ALLOW_CODE'},
                                  HTML    => $iB::INFO->{'MSG_ALLOW_HTML'},
                                  USER    => $obj->{'R_MEMBER'}->{'MEMBER_NAME'},
                                  DB      => $db,
                                  );
    if ($txt->{'ERROR'}) {
        $Post::lang = $std->LoadLanguage('PostWords');
        $post = $Post::lang->{$txt->{'ERROR'}};
        $obj->send_form($db, $post);
    }

    if ($iB::IN{'save'}) {
        $obj->notepad($db);
    }
    if ($iB::IN{'preview'}) {
    $obj->send_form($db);
    }
    $iB::IN{'MODE'} ? $obj->send_msg($db) : $obj->send_form($db);
}

sub send_msg {
    my ($obj,$db) = @_;
    $iB::IN{'iconid'} ||= 0;

    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'incorrect_use')    unless $iB::IN{'MODE'} == '01';
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_msg_title')     unless $iB::IN{'msg_title'};
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_msg')           unless $iB::IN{'Post'};
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_chosen_member') unless $iB::IN{'entered_name'} or $iB::IN{'from_contact'};
    $iB::IN{'from_contact'} ||= '-';

    $std->Error( DB      => $db,
                STD     => $std,
                LEVEL   => 5,
                MESSAGE => 'referrer_fail'
              ) unless lc($ENV{'REQUEST_METHOD'}) eq 'post';

    my $add_sent = $iB::IN{'add_sent'};
    my $r_mem = $obj->{'R_MEMBER'}->{'MEMBER_ID'};
    my $rn_mem = $obj->{'R_MEMBER'}->{'MEMBER_NAME'};
    my $re_mem = $obj->{'R_MEMBER'}->{'MEMBER_EMAIL'};
    my $msg_title = $iB::IN{'msg_title'};
    my $iconid = $iB::IN{'iconid'};
    my $track = $iB::IN{'add_tracking'};
    my $msg_allow_code = IB_CODE => $iB::INFO->{'MSG_ALLOW_CODE'};
    my $msg_allow_html = $iB::INFO->{'MSG_ALLOW_HTML'};

    my $post = $iB::IN{'Post'};

    my $groups = $db->query(    TABLE   => 'mem_groups',
                    COLUMNS => ['ID', 'MAX_MESSAGES', 'USE_PM'],
                   );
    my %temp_groups = map { $_->{'ID'} => { MAX_SIZE => $_->{'MAX_MESSAGES'},
                                            CAN_PM => $_->{'USE_PM'},
                                            ID       => $_->{'ID'},
                                          }
                          } @{$groups};
    $obj->{'group_table'} = \%temp_groups; 

    my @valu;
    my @to_names;
    my ($who, $i);
    my $t = 0;
    if ($iB::IN{'entered_name'}) {
        $who = $iB::IN{'entered_name'};
        $who =~ s!<br>!&&&!g;
        my @valu = split(/&&&/,$who);
        # this code removes duplicate entry
        my %surname_freq = ();
        foreach my $surname (@valu){
        $surname_freq{$surname}++;
        }
        # this sends them in a loop to see if your allowd to send them a message
        foreach my $surname (sort{$surname_freq{$a}<=>$surname_freq{$b} } keys %surname_freq){
            my $who1 = $mem->LoadMember( DB => $db, KEY => $surname , METHOD => 'by name');
            undef $who1->{'MEMBER_PASSWORD'};
        # if the member dosn't exists you receive a message
            $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_to_member')     unless $who1->{'MEMBER_ID'};
            $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_send_to_member')     unless $obj->{'group_table'}->{ $who1->{'MEMBER_GROUP'} }->{'CAN_PM'};

            my $can_msg = $db->query( TABLE  => 'address_books',
                                      WHERE  => "IN_MEMBER_ID eq '$r_mem' and MEMBER_ID eq '$who1->{'MEMBER_ID'}'",
                                      MATCH  => 'ONE',
                                    );
        # you receive an error message if your on that target member list and can't send them a message
            if ($can_msg->{'IN_MEMBER_ID'}) {
                $std->Error( DB => $db, LEVEL=>'1',MESSAGE=> 'msg_blocked') unless $can_msg->{'RECEIVE_MSG'};
            }
            
            my $msg_stats = { };
            $msg_stats = $db->select( TABLE => 'message_stats',
                                      ID    => $who1->{'MEMBER_ID'},
                                      KEY   => $who1->{'MEMBER_ID'},
                                    );
    
                if ($msg_stats->{'MEMBER_ID'}) {
                if($obj->{'group_table'}->{ $who1->{'MEMBER_GROUP'} }->{'MAX_SIZE'} && $msg_stats->{'TOTAL_MESSAGES'} >= $obj->{'group_table'}->{ $who1->{'MEMBER_GROUP'} }->{'MAX_SIZE'}) {
# Target member can not receive anymore PMs per Board setting (max pms)
                    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'max_message_to');
                }
            }
# collects the aproved members
            push @to_names, $who1;
            $t++;
        }
   } 
    else { 
            foreach($iB::CGI->param('from_contact')){
                my $who1 = $mem->LoadMember( DB => $db, KEY => $_ , METHOD => 'by id');
                undef $who1->{'MEMBER_PASSWORD'};
                $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_to_member')     unless $who1->{'MEMBER_ID'};
                $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_send_to_member')     unless $obj->{'group_table'}->{ $who1->{'MEMBER_GROUP'} }->{'CAN_PM'};
                my $can_msg = $db->query( TABLE  => 'address_books',
                                          WHERE  => "IN_MEMBER_ID eq '$r_mem' and MEMBER_ID eq '$who1->{'MEMBER_ID'}'",
                                          MATCH  => 'ONE',
                                        );
        
                    if ($can_msg->{'IN_MEMBER_ID'}) {
                    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'msg_blocked') unless $can_msg->{'RECEIVE_MSG'};
                }
            
                my $msg_stats = { };
                $msg_stats = $db->select( TABLE => 'message_stats',
                                          ID    => $who1->{'MEMBER_ID'},
                                          KEY   => $who1->{'MEMBER_ID'},
                                        );
    
                    if ($msg_stats->{'MEMBER_ID'}) {
                    if($obj->{'group_table'}->{ $who1->{'MEMBER_GROUP'} }->{'MAX_SIZE'} && $msg_stats->{'TOTAL_MESSAGES'} >= $obj->{'group_table'}->{ $who1->{'MEMBER_GROUP'} }->{'MAX_SIZE'}) {
# Target member can not receive anymore PMs per Board setting (max pms)
                        $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'max_message_to');
                    }
                }
                push @to_names, $who1;
                $t++;
            }
     }
    my $txt_to;
    my $sent_to_mem;
    if ($t > 1) {
    my $quote_name_to = "$Messenger::lang->{'message_to'}: ";
    $i = 0;
    foreach(@to_names){
        $i++;
        $quote_name_to .= ", $_->{'MEMBER_NAME'}" unless $i == 1;
        $quote_name_to .= "$_->{'MEMBER_NAME'}" unless $i > 1;
    }
    $txt_to = qq|[QUOTE]|. $quote_name_to . qq|[/QUOTE]\n|;
    }
    if ($t == 1) {
        $txt_to = '';
    }
    $txt_to .= $post;
    $post = $txt_to;
    my $mess1 = $txt->Convert_for_db( TEXT    => $post,
                                  SMILIES => 1,
                                  IB_CODE => $msg_allow_code,
                                  HTML    => $msg_allow_html,
                                  USER    => ,
                                  DB      => $db,
                                ) if $post;
    my $b = 0;
    if ($add_sent) {
        my $temp_msg_stats = { };
        $temp_msg_stats = $db->select( TABLE => 'message_stats',
                                       ID    => $r_mem,
                                       KEY   => $r_mem,
                                     );
                      
        if ($temp_msg_stats->{'MEMBER_ID'}) {
            if($obj->{'group_table'}->{ $iB::MEMBER_GROUP->{'ID'} }->{'MAX_SIZE'} && $temp_msg_stats->{'TOTAL_MESSAGES'} >= $obj->{'group_table'}->{ $iB::MEMBER_GROUP->{'ID'} }->{'MAX_SIZE'}) {
# Current member can not receive anymore PMs per Board setting (max pms)
                $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'max_message_from');
            }
        }
    }
    $iB::INFO->{'MSG_MAX_SEND'} = $iB::INFO->{'MSG_MAX_SEND'} || 10;
    if (scalar @to_names > $iB::INFO->{'MSG_MAX_SEND'}) {
        $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'max_message_total', EXTRA => $iB::INFO->{'MSG_MAX_SEND'});
    }
    foreach my $p(@to_names){
        $b++;
        my $show_popup = (split/&/, $p->{'PM_REMINDER'})[1];
        
        my $trackingid = 0;
#    Are we tracking this ?
        if ($track) {
            $trackingid = -1;
        }
       my $msg_stats = { };
       $msg_stats = $db->select( TABLE => 'message_stats',
                                 ID    => $p->{'MEMBER_ID'},
                                 KEY   => $p->{'MEMBER_ID'},
                               );

            my $new_id = $db->insert( TABLE  => 'message_data',
                                  ID     => $p->{'MEMBER_ID'},
                                  VALUES => { DATE              => time,
                                              READ_STATE        => $trackingid,
                                              TITLE             => $msg_title,
                                              MESSAGE           => $post,
                                              MESSAGE_ICON      => $iconid,
                                              FROM_ID           => $r_mem,
                                              FROM_NAME         => $rn_mem,
                                              REPLY             => '',
                                              REPLY_DATE        => '',
                                              VIRTUAL_DIR       => 'in',
                                              MEMBER_ID         => $p->{'MEMBER_ID'},
                                              RECIPIENT_ID      => $p->{'MEMBER_ID'},
                                              RECIPIENT_NAME    => $p->{'MEMBER_NAME'},
                                            }
                                 );
            my $reminder = (split/&/, $p->{'PM_REMINDER'})[0]; # Get the first byte
            if ($reminder == 1) {
                unless ($iB::INFO->{'MSG_ALL_MESS_CONT'} == 1) {
                    #$mess1 = '';
                }
                my $mail_message = $mail->parse_template( ID     => 'MEM_TO_MEM',
                                                          DB     => $db,
                                                          VALUES => { FROM_NAME   =>  "$Messenger::lang->{'email_from'}$rn_mem",
                                                                      MEMBER_NAME =>  $p->{'MEMBER_NAME'},
                                                                      MESSAGE     =>  $mess1,
                                                               }
                                                    );
                 my $subject = "$Messenger::lang->{'email_subject'}$msg_title";

            $mail->Send( TO      => $p->{'MEMBER_EMAIL'},
                         FROM    => $re_mem,
                         SUBJECT => $subject,
                         MESSAGE => $mail_message,
                         HIDDEN  => $obj->{'R_MEMBER'}->{'HIDE_EMAIL'},
                       );
        }
 
            if ($msg_stats->{'MEMBER_ID'}) {

                $msg_stats->{'TOTAL_MESSAGES'}++;
            $msg_stats->{'NEW_MESSAGES'}++;
      
            $db->update(  TABLE  => 'message_stats',
                          ID     => $p->{'MEMBER_ID'},
                          KEY    => $p->{'MEMBER_ID'},
                          VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'},
                                      NEW_MESSAGES   => $msg_stats->{'NEW_MESSAGES'},
                                      LAST_FROM_NAME => $rn_mem,
                                      LAST_FROM_ID   => $r_mem,
                                      LAST_SENT      => time,
                                      LAST_MSG_ID    => $new_id,
                                      LAST_MSG_TITLE => $msg_title,
                                      SHOW_POPUP     => $show_popup,
                                    }
                       );

            } else {
            $db->insert(  TABLE  => 'message_stats',
                          ID     =>  $p->{'MEMBER_ID'},
                          KEY    =>  $p->{'MEMBER_ID'},
                          VALUES => { MEMBER_ID          => $p->{'MEMBER_ID'},
                                      LAST_READ          => '',
                                      NEW_MESSAGES       => 1,
                                      LAST_FROM_NAME     => $rn_mem,
                                      LAST_FROM_ID       => $r_mem,
                                      LAST_MSG_ID        => $new_id,
                                      LAST_MSG_TITLE     => $msg_title,
                                      LAST_SENT          => time,
                                      TOTAL_MESSAGES     => 1,
                                      VIRTUAL_DIR        => "in:Inbox|sent:Sent Items|",
                                      SHOW_POPUP         => $show_popup,
                                     }
                        );
        }
# #    Are we adding this to our sent items folder?

            if ($add_sent) {
        
            my $my_msg_stats = { };
            $my_msg_stats = $db->select( TABLE => 'message_stats',
                                         ID    => $r_mem,
                                         KEY   => $r_mem,
                                       );

                if ($my_msg_stats->{'MEMBER_ID'}) {
                $my_msg_stats->{'TOTAL_MESSAGES'}++;
                $db->update( TABLE  => 'message_stats',
                             ID     => $r_mem,
                             KEY    => $r_mem,
                             VALUES => { TOTAL_MESSAGES => $my_msg_stats->{'TOTAL_MESSAGES'} }
                           ) unless ($b > 1);
            } else {
                $db->insert( TABLE  => 'message_stats',
                             ID     => $r_mem,
                             KEY    => $r_mem,
                             VALUES => { TOTAL_MESSAGES => 1 }
                           ) unless ($b > 1);
            }
       
            $db->insert( TABLE  => 'message_data',
                         ID     => $r_mem,
                         VALUES => { DATE              => time,
                                     READ_STATE        => 0,
                                     TITLE             => $Messenger::lang->{'saved_sent_msg'}.' '.$msg_title,
                                     MESSAGE           => $post,
                                     MESSAGE_ICON      => $iconid,
                                     FROM_ID           => $r_mem,
                                     FROM_NAME         => $rn_mem,
                                     REPLY             => '',
                                     REPLY_DATE        => '',
                                     VIRTUAL_DIR       => 'sent',
                                     MEMBER_ID         => $r_mem,
                                     RECIPIENT_ID      => $p->{'MEMBER_ID'},
                                     RECIPIENT_NAME    => $p->{'MEMBER_NAME'},
                                   }
                   ) unless ($b > 1);
   }
   if ($b == 1){
   $sent_to_mem = $p->{'MEMBER_NAME'};
   } else {
   $sent_to_mem .= ", $p->{'MEMBER_NAME'}";
   }
 }
   $Messenger::lang->{'sent_text'} =~ s!<#FROM_MEMBER#>!$rn_mem!;
    $Messenger::lang->{'sent_text'} =~ s!<#TO_MEMBER#>!$sent_to_mem!;
    $Messenger::lang->{'sent_text'} =~ s!<#MESSAGE_TITLE#>!$msg_title!;
# 
    $obj->{'.html'} .= MessengerView::sent_screen();
    $obj->{'.html'} .= MessengerView::CP_end();

    $output->print_ikonboard( DB      => $db,
                              TITLE   => $Messenger::lang->{'t_welcome'},
                              NAV     => [qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>!],
                              OUTPUT  => $obj->{'.html'}
                            );
}

sub notepad {
        my ($obj, $db) = @_;

       my $s_post = $iB::IN{'Post'} || '';

       my $is_already_in = $db->select( TABLE => 'member_notepads',
                                        KEY   => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                        WHERE => qq!MEMBER_ID eq "$obj->{'R_MEMBER'}->{'MEMBER_ID'}"!,
                                        MATCH => 'ONE', 
                                      );

       if ($is_already_in->{'MEMBER_ID'}) {
           $db->update(  TABLE  => 'member_notepads',
                         ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                         KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                         VALUES => { SAVED_M => $s_post},
                      ) || die $db->{'error'};
       } else {
           $db->insert(  TABLE  => 'member_notepads',
                         VALUES => { MEMBER_ID    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                     SAVED_M => $s_post,
                                   },
                      ) || die $db->{'error'};
       }

       $output->redirect_screen( TEXT => $Messenger::lang->{'save_successful'}, URL => "act=NotePad;CODE=04" );
    }

sub td_select {
    my $obj = shift;

    my %IN = ( TEXT     => "",
               NAME     => "",
               SIZE     => "",
               MULTIPLE => "",
               DATA     => [],
               VALUES   => undef,
               REQ      => "",
               JS       => "",
               @_,
             );

    my $req = $IN{'REQ'} ? " <font class='h'>*</font>" : '';

    my $text = $IN{'MULTIPLE'} ? $Messenger::lang->{'method_select'} : '';

    $IN{'SIZE'}     = "size='$IN{'SIZE'}'" if $IN{'SIZE'};
    $IN{'MULTIPLE'} = 'multiple' if $IN{'MULTIPLE'};

    my $return = qq!<select name='$IN{'NAME'}' $IN{'SIZE'} $IN{'MULTIPLE'} class='forminput' $IN{'JS'}>\n!;

    if (ref($IN{'VALUES'}) eq 'ARRAY') {
        my @values = @{ $IN{'VALUES'} };
        $IN{'VALUES'} = {};
        for (@values) {
            $IN{'VALUES'}->{$_} = 1;
        }
    } else {
        my $value = $IN{'VALUES'};
        $IN{'VALUES'} = {};
        $IN{'VALUES'}->{$value} = 1;
    }

    for my $i (@{ $IN{'DATA'} }) {
        my $selected = ' selected' if $i->{'VALUE'} ne '' and exists $IN{'VALUES'}->{ $i->{'VALUE'} };
        $return .= qq! <option value="$i->{'VALUE'}"$selected>$i->{'NAME'}</option>\n!;
    }

    $return .= '</select>';
                  
    return qq~
    <font class='t'>$IN{'TEXT'}$req</font><br>$return $text
    ~;
}

sub send_form {
    my ($obj, $db, $error) = @_;
    my $use_pfc = $iB::MEMBER->{'POST_FONT_COLOR'} ? 1 : 0;
    my $in_post   = $txt->Convert_for_db( TEXT    => $iB::IN{'Post'},
                                          SMILIES => 1,
                                          IB_CODE => $iB::INFO->{'MSG_ALLOW_CODE'},
                                          HTML    => $iB::INFO->{'MSG_ALLOW_HTML'},
                                          USER    => ,
                                          ADD_POST_COLOR => $use_pfc,
                                          POST_COLOR     => $iB::MEMBER->{'POST_FONT_COLOR'},
                                          DB             => $db,
                                        ) if $iB::IN{'Post'} and $error == '';
    require $iB::SKIN->{'DIR'} . '/PostView.pm' or $std->cgi_error($!);
    $Post::lang = $std->LoadLanguage('PostWords');


    $Messenger::lang->{'max_msg'}     =~ s!<#MAX_MSG_SIZE#>!$iB::INFO->{'MAX_MSG_SIZE'}!;
    $Messenger::lang->{'the_max_msg'} = $iB::INFO->{'MAX_MSG_SIZE'} * 1024;

    my ($name_to_enter, $old_message, $old_title);

    if ($iB::IN{'MID'}) {
            my $temp_mem = $mem->LoadMember( DB => $db, KEY => $iB::IN{'MID'}, METHOD => 'by id');
            $name_to_enter = $temp_mem->{'MEMBER_NAME'} if $temp_mem->{'MEMBER_ID'};
    }

    if ($iB::IN{'MSID'}) {
        unless ($in_post) {
                my $temp = $db->select( TABLE   => 'message_data',
                                        ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                        KEY     => $iB::IN{'MSID'}
                                      ) unless ($in_post);
                $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_such_msg') unless $temp->{'MEMBER_ID'} == $iB::MEMBER->{'MEMBER_ID'};
            if ($name_to_enter) {
                my $date = $std->get_date( TIME => $temp->{'DATE'}, METHOD => 'LONG');
                $old_message = qq|[QUOTE=$temp->{'FROM_NAME'},$date]|. $temp->{'MESSAGE'} . qq|[/QUOTE]\n|;
                $old_message =~ s!<br>!\n!g;
                $old_title = $Messenger::lang->{'repl'} . $temp->{'TITLE'};
                # Make sure we don't get loads of 'Re:' in the title
                $old_title =~ s!^(?:$Messenger::lang->{'repl'}){1,}!$Messenger::lang->{'repl'}!g;
                # mark as a reply
                $db->update(       TABLE   => 'message_data',
                          KEY     => $iB::IN{'MSID'},
                          ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                          VALUES  => { REPLY => 1,
                                       REPLY_DATE => time,}
                );

            } else {
                my $temp = $db->select( TABLE   => 'message_data',
                                        ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                        KEY     => $iB::IN{'MSID'}
                                      ) unless ($in_post);
                my $date = $std->get_date( TIME => $temp->{'DATE'}, METHOD => 'LONG');
                $old_message = qq|[QUOTE=$temp->{'FROM_NAME'},$date]|. $temp->{'MESSAGE'} . qq|[/QUOTE]\n|;
                $old_message =~ s!<br>!\n!g;
                $old_title = $Messenger::lang->{'fwd'} . $temp->{'TITLE'};
                # Make sure we don't get loads of 'Fwd:' in the title
    #           $old_title =~ s!^(?:Fwd\:){1,}!Fwd:!g;
                $old_title =~ s!^(?:$Messenger::lang->{'fwd'}){1,}!$Messenger::lang->{'fwd'}!g;
                $db->update(       TABLE   => 'message_data',
                          KEY     => $iB::IN{'MSID'},
                          ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                          VALUES  => { REPLY => 2,
                                       REPLY_DATE => time,}
                );
            }
        }
    }
# added for preview
    my @val;
    if ($in_post) {
        if ($error) {
            $in_post = $error;
        }
        $obj->{'.html'}  = MessengerView::preview($in_post);
        $obj->{'.html'} .= $obj->Show_menu($db);
        $old_title = $iB::IN{'msg_title'};
        if ($iB::IN{'entered_name'}) {
        $name_to_enter = $iB::IN{'entered_name'};
        $name_to_enter =~ s!<br>!\n!g;
        } else { 
            my ($who, $i, $name1);
            foreach($iB::CGI->param('from_contact')) {
            $i++;
            $who .= "&" unless $i == 1;
            $who .= $_;
            }
        @val = split(/&/,$who);
        $name_to_enter = '';
        }
    $old_message = $iB::IN{'Post'};
    $old_message =~ s!<br>!\n!g;
   }
    my $contact;
    my $address = $db->query( TABLE    => 'address_books',
                              WHERE    => "MEMBER_ID eq '$iB::MEMBER->{'MEMBER_ID'}'",
                              SORT_KEY => 'IN_MEMBER_NAME',
                            );
    my @contacts;
    my $size = scalar @{$address};
    if ($size > 0) {
        if ($size > 5){
        $size = 5;
        }
        for (@{$address}) {
            push @contacts,      { NAME => $_->{'IN_MEMBER_NAME'}, VALUE => $_->{'IN_MEMBER_ID'} };
            }
            $contact = $obj->td_select( TEXT     => $Messenger::lang->{'select_to'},
                                        NAME     => 'from_contact',
                                        SIZE     => $size,
                                        MULTIPLE => 1,
                                        VALUES   => \@val,
                                        DATA     => \@contacts,
                                     );
    } else {
        $contact = $Messenger::lang->{'address_list_empty'};
    }

    $obj->{'.html'} .= MessengerView::Send_form( 
                                                 {
                                                    CONTACTS => $contact,
                                                    MEMBER   => $obj->{'R_MEMBER'},
                                                    N_ENTER  => $name_to_enter,
                                                    O_TITLE  => $old_title,
                                                 }
                                                );

    # added to filter bad words from the old message
    # by KEVaholic00
    if ($iB::INFO->{'WORD_FILTER'}) {
        my @words = split /\|/, $iB::INFO->{'WORD_FILTER'};

        for (@words) {
            my ($original, $method, $replacement) = split /\:/, $_;
            #$replacement = "#" x length($original) unless $replacement;
            $replacement = '*' x length($original) unless $replacement;

            if ($method eq 'e') {
                $old_message =~ s!(\A|\b)$original(\b|\Z|\!|\?|\.)!$replacement!ig;
            } else {
                $old_message =~ s!\Q$original\E!$replacement!ig;
            }
        }
    }
    # end

    $Post::lang->{'the_max_length'} = $iB::INFO->{'MAX_MSG_SIZE'} * 1024;
    $Post::lang->{'ib_state'}   = $iB::INFO->{'MSG_ALLOW_CODE'}  ? $Post::lang->{'ib_on'}   : $Post::lang->{'ib_off'};
    $Post::lang->{'html_state'} = $iB::INFO->{'MSG_ALLOW_HTML'}  ? $Post::lang->{'html_on'} : $Post::lang->{'html_off'};
    $obj->{'.html'} .= PostView::PostIcons() . PostView::postbox_buttons($old_message);
    $obj->{'.html'} .= MessengerView::send_form_footer();
    $obj->{'.html'} .= MessengerView::CP_end();

    my $smilies = qq~<tr align='center'>\n~;
    my $cnt = 0;
    my $show_table = 0;
    for my $e (split (/\|&\|/,$iB::INFO->{'EMOTICONS'}) ) {
        my ($type, $image, $p_inc) = split (/\|/,$e);
        next unless $type and $image;
        next unless $p_inc;

        $cnt++;
        $show_table++;
        $smilies .= qq~<td><a href="javascript:emoticon('$type')"><img src="$iB::INFO->{'EMOTICONS_URL'}/$image" alt="smilie" border="0"></a>&nbsp;</td>\n~;

        if ($cnt == $iB::INFO->{'EMO_PER_ROW'}) {
            $smilies .= qq~</tr>\n\n<tr align='center'>\n~;
            $cnt = 0;
        }
    }

    if ($cnt != $iB::INFO->{'EMO_PER_ROW'}) {
        $cnt++;
        for ($cnt .. $iB::INFO->{'EMO_PER_ROW'}) {
            $smilies .= qq~<td>&nbsp;</td>\n~;
        }
        $smilies .= qq~</tr>~;
    }
    
    my $table = PostView::smilie_table();
    if ($show_table) {
        $table =~ s:<!--THE SMILIES-->:$smilies:;
        $obj->{'.html'} =~ s:<!--SMILIE TABLE-->:$table:;
    }

    $output->print_ikonboard( DB         => $db,
                              TITLE      => $Messenger::lang->{'t_welcome'},
                              JAVASCRIPT => 1,
                              NAV        => [qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>!],
                              OUTPUT     => $obj->{'.html'}
                            );
}

sub get_avatar {
    my $obj = shift;
    return unless $iB::MEMBER->{'MEMBER_AVATAR'};
    return if $iB::MEMBER->{'MEMBER_AVATAR'} eq 'noavatar';
    my ($a_width, $a_height) = split "x", $iB::INFO->{'AV_DIMS'};
    my ($d_a_width, $d_a_height) = split "x", $iB::INFO->{'DEF_AV_DIMS'};
    if ($iB::MEMBER->{'MEMBER_AVATAR'} =~ m#\Ahttp\://#i) {
        if ($iB::INFO->{'AV_ALLOW_URL'}) {
            my ($width  , $height)   = split "x", $iB::MEMBER->{'AVATAR_DIMS'};
            $height ||= $a_height;
            $width  ||= $a_width;
            return $iB::MEMBER->{'MEMBER_AVATAR'} =~ m#\.swf\Z#i ? qq|<OBJECT CLASSID="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" WIDTH=$width HEIGHT=$height><PARAM NAME=MOVIE VALUE=$iB::MEMBER->{'MEMBER_AVATAR'}><PARAM NAME=PLAY VALUE=TRUE><PARAM NAME=LOOP VALUE=TRUE><PARAM NAME=QUALITY VALUE=HIGH><EMBED SRC=$iB::MEMBER->{'MEMBER_AVATAR'} WIDTH=$width HEIGHT=$height PLAY=TRUE LOOP=TRUE QUALITY=HIGH></EMBED></OBJECT>|
                                                                 : qq|<img src='$iB::MEMBER->{'MEMBER_AVATAR'}' border='0' width='$width' height='$height' alt=''>|;
        }
    }
    return qq|<img src='$iB::INFO->{'AVATARS_URL'}/$iB::MEMBER->{'MEMBER_AVATAR'}' border='0' width='$d_a_width' height='$d_a_height' alt=''>| unless $iB::MEMBER->{'MEMBER_AVATAR'} =~ m#\Ahttp\://#i;
} 

sub Show_menu ($) {
    my ($obj, $db) = @_;
    my $the_current_avatar = $obj->get_avatar;
    if ($obj->{'R_MEMBER'}->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}){
        my $Nav_tabs = { '00' => 'splash', '01' => 'in_box', '02' => 'contact', '07' => 'prefs', '04' => 'send', '13' => 'send2'};
        my $Nav_color = { };
        for (qw[splash in_box contact prefs send send2]) { $Nav_color->{$_} = $iB::SKIN->{'USERNAV_OFF'} }
        $Nav_color->{ $Nav_tabs->{ $iB::IN{'CODE'} } } = $iB::SKIN->{'USERNAV_ON'};
    
        return MessengerView::Menu_bar_admin($Nav_color,$the_current_avatar);
    }
    my $Nav_tabs = { '00' => 'splash', '01' => 'in_box', '02' => 'contact', '07' => 'prefs', '04' => 'send'};
    my $Nav_color = { };
    for (qw[splash in_box contact prefs send]) { $Nav_color->{$_} = $iB::SKIN->{'USERNAV_OFF'} }
    $Nav_color->{ $Nav_tabs->{ $iB::IN{'CODE'} } } = $iB::SKIN->{'USERNAV_ON'};
    return MessengerView::Menu_bar($Nav_color,$the_current_avatar);
}
   
sub Process {
    my ($obj, $db) = @_;
    $std->Error(LEVEL=>'1',MESSAGE=>'Wha.....?') unless (defined $iB::IN{'CODE'});

    $obj->SetSession($db);
    my $CodeNo = $std->CheckCodeNo($iB::IN{'CODE'});
    my %Mode = ( 
                 '04'     => \&send,
                 '13'     => \&send2,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : MessengerError($obj,$db);
} 

sub SetSession {
    my ($obj, $db) = @_;

    # Display an "error" if we are not allowed to use the messenger
    unless ($iB::MEMBER_GROUP->{'USE_PM'}) {
        $std->Error( DB => $db, LEVEL => 1, MESSAGE => 'no_use_messenger' );
        return "0 but true";
    }
    require $iB::SKIN->{'DIR'} . '/MessengerView.pm' or $std->cgi_error($!);
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_guest_posting')  unless $obj->{'R_MEMBER'}->{'MEMBER_ID'};
    $obj->{'.html'} = $obj->Show_menu($db);
}

sub MessengerError  { 
    my ($obj, $db) = @_; $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'incorrect_use')
    }

1;
