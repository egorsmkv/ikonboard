package UserCP::Messenger;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Messenger: Other Messenger Functions.
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
}

my $output       = FUNC::Output->new();
my $mem          = FUNC::Member->new();
my $std          = FUNC::STD->new();
my $txt          = iTextparser->new();
$Messenger::lang = $std->LoadLanguage('MessengerWords');

sub new {
  my $pkg = shift;
  my $obj = { R_MEMBER => $iB::MEMBER, NEW_MSG_DATA => '', '.to_member' => '', '.html' => '' };
  bless $obj, $pkg;
  return $obj;
}

#+------------------------------------------------------------------------------------------------------

sub Splash ($) {
    my ($obj, $db) = @_;
    $obj->{'MSG_DATA'} = $obj->Check_new($db);
    $obj->{'MSG_DATA'}->{'ICON'} = $obj->{'MSG_DATA'}->{'NEW_MESSAGES'} ? $iB::SKIN->{M_NEW} : $iB::SKIN->{M_NNEW};
    $obj->{'MSG_DATA'}->{'TEXT'} = $obj->{'MSG_DATA'}->{'NEW_MESSAGES'} ? $Messenger::lang->{'msg_new'} : $Messenger::lang->{'msg_no_new'};
    $obj->{'MSG_DATA'}->{'TEXT'} =~ s!<#NEW_MESSAGES#>!$obj->{'MSG_DATA'}->{'NEW_MESSAGES'}!;
    if ($obj->{'MSG_DATA'}->{'NEW_MESSAGES'}) {
        $obj->{'MSG_DATA'}->{'LAST_SENT'} = $std->get_date( TIME => $obj->{'MSG_DATA'}->{'LAST_SENT'}, METHOD => 'LONG');
        $obj->{'MSG_DATA'}->{'LAST_TEXT'} = $Messenger::lang->{'last_txt'};
        $obj->{'MSG_DATA'}->{'LAST_TEXT'} =~ s!<#LAST_FROM_NAME#>!<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$obj->{'MSG_DATA'}->{'LAST_FROM_ID'}'><u><b>$obj->{'MSG_DATA'}->{'LAST_FROM_NAME'}</b></u></a>!;
        $obj->{'MSG_DATA'}->{'LAST_TEXT'} =~ s!<#LAST_MSG_TITLE#>!<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSV;CODE=03;MODE=3;MSID=$obj->{'MSG_DATA'}->{'LAST_MSG_ID'}'><u><b>$obj->{'MSG_DATA'}->{'LAST_MSG_TITLE'}</b></u></a>!;
        $obj->{'MSG_DATA'}->{'LAST_TEXT'} =~ s!<#LAST_SENT#>!$obj->{'MSG_DATA'}->{'LAST_SENT'}!;
        $obj->{'MSG_DATA'}->{'LAST_TEXT'} = qq[<br>$obj->{'MSG_DATA'}->{'LAST_TEXT'}];
    }
# Start stats
    my $v_dir = $iB::IN{'VID'} || 'in';

    $obj->my_get_stats($db);
    
    my $sort_key   = $iB::IN{'sort_key'}   || 'DATE';
    my $sort_order = $iB::IN{'sort_order'} || 'Z-A';
    
    # A "bug" in earlier versions of messenger.pm didn't remove messages that were deleted
    # from the total messages counter, so we'll need to do a quick count check.
    
    my $all_messages   = [];
    my $msg_count      = 0;

    my $total_messages = $db->query(  TABLE    => 'message_data',
                                      ID       => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                      WHERE    => qq[MEMBER_ID eq '$obj->{'R_MEMBER'}->{'MEMBER_ID'}'],
                                      SORT_KEY => $sort_key,
                                      SORT_BY  => $sort_order,
                                   );
                                   
    # Count and filter out messages not in this virtual folder
    
    for (@{$total_messages}) {
        ++$msg_count;
        if ($_->{VIRTUAL_DIR} eq $obj->{'R_MEMBER'}->{'CURRENT_ID'}) {
            push @{$all_messages}, $_;
        }
    }
    
    # Check to see if the "real" message count equals the stored one.
    
    unless ($obj->{'.cur_stats'}->{'_FAKED'}) {
        # Member has stored stats...
        # so, lets check the counter
        if ($msg_count != $obj->{'.cur_stats'}->{TOTAL_MESSAGES}) {
            $obj->{'.cur_stats'}->{TOTAL_MESSAGES} = $msg_count;
            #Save out the real count
            $db->update( TABLE  => 'message_stats',
                         ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                         KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                         VALUES => { TOTAL_MESSAGES => $msg_count }
                       );
        }
    }
    
    # sort out some stats.
    
    $Messenger::lang->{c_msg_total} =~ s!<#NUM#>!$msg_count!g;
   
    if ($iB::MEMBER_GROUP->{'MAX_MESSAGES'}) {
        if ($obj->{'.cur_stats'}->{TOTAL_MESSAGES} >= $iB::MEMBER_GROUP->{'MAX_MESSAGES'}) {
            $Messenger::lang->{c_msg_info} = $Messenger::lang->{c_msg_full};
        } else {
            my $t_cnt = $iB::MEMBER_GROUP->{'MAX_MESSAGES'} - $msg_count;
            $Messenger::lang->{c_msg_info} =~ s!<#NUM#>!$t_cnt!g;
        }
    } else {
        $Messenger::lang->{c_msg_info} = $Messenger::lang->{'c_msg_unl'};
    }

        if ($iB::MEMBER_GROUP->{'MAX_MESSAGES'}) {
     if ($obj->{'.cur_stats'}->{TOTAL_MESSAGES} > 0) {
         my $mess_no = (( $obj->{'.cur_stats'}->{TOTAL_MESSAGES} * 100) / ($iB::MEMBER_GROUP->{'MAX_MESSAGES'}));
     $obj->{'MESS'} =  qq[
                        <table cellpadding='0' cellspacing='1' width='33%' align='right' border='0'>
                          <tr>
                            <td>
                              <table cellpadding='4' cellspacing='0' width='100%' align='center' border='1' bordercolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                               <tr>
                                <td class='row1' align='left' colspan='3'>Your folders are $mess_no % full</td>
                               </tr>
                               <tr>
                                <td align='left' valign='middle' class='row2' colspan='3'><img src='http://swarf.net/public_html/release/rate.gif' border='0' width='$mess_no%' height='11' align='middle' alt=''><img src='style_images/bluebox-905/bar.gif' border='0' width='6' height='11' align='middle' alt=''><img src='style_images/bluebox-905/bar_right.gif' border='0' width='4' height='11' align='middle' alt=''></td>
                               </tr>
                               <tr>
                                 <td class='row1' width='33%' align='left' valign='middle'>0%</td>
                                 <td class='row1' width='33%' align='center' valign='middle'>50%</td>
                                 <td class='row1' width='33%' align='right' valign='middle'>100%</td>
                               </tr>
                              </table>
                             </td>
                            </tr>
                          </table>
     
                        ];
                        }
                    }


    $obj->{'.html'} .= MessengerView::inbox_header($obj->{'R_MEMBER'}, $obj->{'.jump_html'}, $obj->{'MESS'});
    $obj->{'.html'} .= MessengerView::splash($obj->{'R_MEMBER'},$obj->{'MSG_DATA'});


# end stats
    $obj->{'.html'} .= MessengerView::CP_end();

    $output->print_ikonboard( DB      => $db,
                              TITLE   => $Messenger::lang->{'t_welcome'},
                              NAV     => [qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>!],
                              OUTPUT  => $obj->{'.html'}
                            );
}

sub Check_new ($$) {
    my ($obj, $db) = @_;
    my $stats;
    $stats = $db->select(TABLE => 'message_stats', ID => $obj->{'R_MEMBER'}->{'MEMBER_ID'}, KEY => $obj->{'R_MEMBER'}->{'MEMBER_ID'} );
    return $stats->{'NEW_MESSAGES'} ? $stats : { NEW_MESSAGES => 0 };
}

#+------------------------------------------------------------------------------------------------------

sub _get_new ($$) {
    my ($obj, $db) = @_;
    $obj->{'NEW_MSG_DATA'} = $db->select(TABLE => 'message_stats', ID => $obj->{'R_MEMBER'}->{'MEMBER_ID'}, KEY => $obj->{'R_MEMBER'}->{'MEMBER_ID'} );
}

#+------------------------------------------------------------------------------------------------------

sub _get_blank ($$) {
    my ($obj, $db) = @_;
    $obj->{'NEW_MSG_DATA'} = { NEW_MESSAGES => 0 };
}


sub delete {
    my ($obj, $db) = @_;

    $iB::IN{'VID'} ||= 'in';

    $std->Error( DB => $db,  LEVEL => 1, MESSAGE => 'no_msg_chosen') unless $iB::IN{'MSID'};

    $db->delete(  TABLE   => 'message_data',
                  ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                  KEY     => $iB::IN{'MSID'},
               ) || die $db->{'error'};
               
    my $msg_stats = { };
    $msg_stats = $db->select( TABLE  => 'message_stats',
                              ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                              KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                            );
    if ($msg_stats->{'MEMBER_ID'}) {
        $msg_stats->{'TOTAL_MESSAGES'}--;
        $db->update(  TABLE  => 'message_stats',
                      ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                      KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                      VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'} }
                   );
    }

    $output->pure_redirect( URL => "act=Msg;CODE=01;VID=$iB::IN{'VID'}" );
}


sub multiact {
    my ($obj, $db) = @_;

    $iB::IN{'VID'} ||= 'in';

    my @ids = map  {    (split/-/)[1]   } 
              grep {   /^msgid-(\d+)$/  } $iB::CGI->param();

    $std->Error( DB => $db,  LEVEL => 1, MESSAGE => 'no_msg_chosen') unless @ids > 0;

    if ($iB::IN{'delete'}) {

        $db->delete(  TABLE   => 'message_data',
                      ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                      KEY     => \@ids,
                   ) || die $db->{error};
                   
        my $msg_stats = { };
        $msg_stats = $db->select( TABLE  => 'message_stats',
                                  ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                  KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                );
        if ($msg_stats->{'MEMBER_ID'}) {
            my $count = scalar @ids;
            $msg_stats->{'TOTAL_MESSAGES'} -= $count;
            $db->update(  TABLE  => 'message_stats',
                          ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                          KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                          VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'} }
                       );
        }

        $output->pure_redirect( URL => "act=Msg;CODE=01;VID=$iB::IN{'VID'}" );

    }
    elsif ($iB::IN{'move'}) {
        for my $id (@ids) {
            $db->update(  TABLE   => 'message_data',
                          ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                          KEY     => $id,
                          VALUES  => { VIRTUAL_DIR => $iB::IN{'VID'} }
                       );
        }
        $output->pure_redirect( URL => "act=Msg;CODE=01;VID=$iB::IN{'VID'}" );
    }
    else {
        $std->Error( DB => $db,  LEVEL => 1, MESSAGE => 'no_msg_chosen');
    }
        

}


sub prefs {
    my ($obj, $db) = @_;

    $obj->my_get_stats($db);

    $obj->{'.html'} .= MessengerView::prefs_header();

    my $cnt = 0;

    for my $i (@{$obj->{'R_MEMBER'}->{'DIR_DATA'}}) {
            my $extra;
            if ($i->{'ID'} eq 'in' or $i->{'ID'} eq 'sent') {
                $extra = "&nbsp;&nbsp;( ".$i->{'REAL'}." - $Messenger::lang->{'cannot_remove'} )";
            }
            $obj->{'.html'} .= MessengerView::prefs_row( { ID => $i->{'ID'}, REAL => $i->{'REAL'}, EXTRA => $extra } );
            ++$cnt;
    }

    $obj->{'.html'} .= MessengerView::prefs_add_dirs();

    for ($cnt .. $cnt+3) {
        $obj->{'.html'} .= MessengerView::prefs_row( { ID => 'dir_'.$_ , REAL => '' } );
    }

    $obj->{'.html'} .= MessengerView::prefs_footer();

    $obj->{'.html'} .= MessengerView::CP_end();

    $output->print_ikonboard( DB      => $db,
                              TITLE   => $Messenger::lang->{'t_welcome'},
                              NAV     => [
                                           qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>!,
                                         ],
                              OUTPUT  => $obj->{'.html'}
                            );
}


sub do_prefs {
    my ($obj, $db) = @_;

    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE => 'cannot_remove_dir'
               ) unless $iB::IN{'in'} and $iB::IN{'sent'};

    my $v_dirs = 'in:'.$iB::IN{'in'}.'|sent:'.$iB::IN{'sent'};

    my @dirs   = grep { /^dir_\d+$/ } keys %iB::IN;

    for my $d (@dirs) {
        next unless $iB::IN{$d};
        $v_dirs .= '|'.$d.':'.$iB::IN{$d};
    }
    $db->update( TABLE  => 'message_stats',
                 ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                 KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                 VALUES => { VIRTUAL_DIR => $v_dirs }
               );

    $output->pure_redirect( URL => "act=Msg;CODE=07" );
}



sub my_get_stats {
    my ($obj, $db) = @_;

    $obj->{'R_MEMBER'}->{'DIR_DATA'} = [];

    my $v_dir = $iB::IN{'VID'} || 'in';

    $obj->{'.jump_html'} = qq[<select name='VID' class='forminput'>\n];

    my $stats = $db->select(  TABLE  => 'message_stats',
                              ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                              KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'}
                           );

    $stats = undef unless $stats->{'MEMBER_ID'};

    $obj->{'.cur_stats'} = $stats || { MEMBER_ID    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                       NEW_MESSAGES => 0,
                                       VIRTUAL_DIR  => "in:Inbox|sent:Sent Items|",
                                       '_FAKED'     => 1,
                                     };

    for (split (/\|/, $obj->{'.cur_stats'}->{'VIRTUAL_DIR'}) ) {
        my ($id, $real) = split /\:/, $_;
            push @{$obj->{'R_MEMBER'}->{'DIR_DATA'}}, { ID => $id, REAL => $real };
        if ($v_dir eq $id) {
            $obj->{'R_MEMBER'}->{'CURRENT_DIR'} = $real;
            $obj->{'R_MEMBER'}->{'CURRENT_ID'}  = $id;
            $obj->{'.jump_html'} .= qq[<option value='$id' selected>$real\n];
        } else {
            $obj->{'.jump_html'} .= qq[<option value='$id'>$real\n];
        }
    }
        
    $obj->{'.jump_html'} .= qq[</select>];
}



sub msg_list ($$) {
    my ($obj, $db) = @_;
    
    my $v_dir = $iB::IN{'VID'} || 'in';

    # Pagnation
    my $First       = defined($iB::IN{'st'}) ? $iB::IN{'st'} : 0;
    $iB::IN{'st'} = $First;
    my $Last = $iB::INFO->{'DISPLAY_MAX_TOPICS'} + ($First - 1);
    # End pagnation

    $obj->my_get_stats($db);
    
    my $sort_key   = $iB::IN{'sort_key'}   || 'DATE';
    my $sort_order = $iB::IN{'sort_order'} || 'Z-A';
    
    # A "bug" in earlier versions of messenger.pm didn't remove messages that were deleted
    # from the total messages counter, so we'll need to do a quick count check.
    
    my $all_messages   = [];
    my $msg_count      = 0;

   my $all_messages = $db->query(  TABLE    => 'message_data',
                                   ID       => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                   WHERE    => qq[(MEMBER_ID eq '$obj->{'R_MEMBER'}->{'MEMBER_ID'}') and (VIRTUAL_DIR eq '$v_dir')],
                                   RANGE    => $First." to ".$Last,
                                   SORT_KEY => $sort_key,
                                   SORT_BY  => $sort_order,
                                   MATCH    => 'WITH COUNT',
                                );
                                   
  # Count and filter out messages not in this virtual folder
   my $msg_count = $db->matched_records;

   # sort out some stats.

   $Messenger::lang->{c_msg_total} =~ s!<#NUM#>!$obj->{'.cur_stats'}->{TOTAL_MESSAGES}!g;

   if ($iB::MEMBER_GROUP->{'MAX_MESSAGES'}) {
       if ($obj->{'.cur_stats'}->{TOTAL_MESSAGES} >= $iB::MEMBER_GROUP->{'MAX_MESSAGES'}) {
           $Messenger::lang->{c_msg_info} = $Messenger::lang->{c_msg_full};
       } else {
           my $t_cnt = $iB::MEMBER_GROUP->{'MAX_MESSAGES'} - $obj->{'.cur_stats'}->{TOTAL_MESSAGES};
           $Messenger::lang->{c_msg_info} =~ s!<#NUM#>!$t_cnt!g;
       }
   } else {
       $Messenger::lang->{c_msg_info} = "";
   }

   $obj->{'R_MEMBER'}->{'SHOW_PAGES'}
       = $std->build_pagelinks( TOTAL_POSS  => $msg_count,
                                PER_PAGE    => $iB::INFO->{'DISPLAY_MAX_TOPICS'},
                                CUR_ST_VAL  => $iB::IN{'st'},
                                L_SINGLE    => $Messenger::lang->{'single_page_forum'},
                                L_MULTI     => $Messenger::lang->{'multi_page_forum'},
                                BASE_URL    => "$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=01;VID=$v_dir",
                              );



    $obj->{'.html'} .= MessengerView::inbox_header($obj->{'R_MEMBER'}, $obj->{'.jump_html'});
    if ($v_dir =~/^sent/i) {
         $obj->{'.html'} .= MessengerView::sent_table_header($obj->{'R_MEMBER'});
    } else {
         $obj->{'.html'} .= MessengerView::inbox_table_header($obj->{'R_MEMBER'});
    }



    if (scalar @{$all_messages} > 0) {

        for my $this_message (@{$all_messages}) {

            $this_message->{'ICON'}     = $this_message->{'READ_STATE'} == 1 ? $iB::SKIN->{M_READ} : $iB::SKIN->{M_UNREAD};
            $this_message->{'DATE'}     = $std->get_date( TIME => $this_message->{'DATE'}, METHOD => 'LONG');

            if ($v_dir =~/^sent/i) {
                $obj->{'.html'} .= MessengerView::sent_row(
                                                            {
                                                              MSG    => $this_message,
                                                              MEMBER => $obj->{'R_MEMBER'}
                                                            }
                                                           );
             } else {
                $obj->{'.html'} .= MessengerView::inbox_row(
                                                            {
                                                              MSG    => $this_message,
                                                              MEMBER => $obj->{'R_MEMBER'}
                                                            }
                                                           );
             };
        }
    } else {

        $obj->{'.html'} .= MessengerView::No_msg_inbox();

    }
   
    my $sorted_by = 'from_'.$sort_key ;
    $obj->{'.html'} .= MessengerView::end_inbox($obj->{'.jump_html'});

    if ($obj->{'R_MEMBER'}->{'CURRENT_ID'} eq 'in') {  
        $db->update(  TABLE  => 'message_stats',
                      ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                      KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                      VALUES => { NEW_MESSAGES => 0 }
                   );
    }

    $obj->{'.html'} .= MessengerView::CP_end();

    $output->print_ikonboard( DB      => $db,
                              TITLE   => $Messenger::lang->{'t_welcome'},
                              NAV     => [ qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>! ],
                              OUTPUT  => $obj->{'.html'}
                            );
}

sub add_member ($) {
    my ($obj, $db) = @_;

    $std->Error( DB     => $db,
                 LEVEL  => '1',
                 MESSAGE=>'no_user'
               ) unless $iB::IN{'mem_name'};

 
    my $mem_to_add = $mem->LoadMember( DB     => $db,
                                       KEY    => $iB::IN{'mem_name'},
                                       METHOD => 'by name'
                                     );

    $std->Error( DB     => $db,
                 LEVEL  => '1',
                 MESSAGE=>'no_user'
               ) unless $mem_to_add->{'MEMBER_ID'};

    my $check = $db->query( TABLE     => 'address_books',
                            ID        => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                            WHERE     => qq[MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}" and IN_MEMBER_ID eq "$mem_to_add->{'MEMBER_ID'}"],
                          ) || die $db->{'error'};

    $std->Error( DB     => $db,
                 LEVEL  => '1',
                 MESSAGE=>'member_in_add_book'
               ) if scalar @{$check} > 0;
 

    $iB::IN{'allow_msg'} =  $iB::IN{'allow_msg'} eq 'yes' ? 1 : 0;

    $db->insert( TABLE   => 'address_books',
                 ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                 VALUES  => { MEMBER_ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                              IN_MEMBER_NAME => $iB::IN{'mem_name'},
                              RECEIVE_MSG    => $iB::IN{'allow_msg'},
                              IN_MEMBER_DESC => $iB::IN{'mem_desc'},
                              IN_MEMBER_ID   => $mem_to_add->{'MEMBER_ID'}
                           },
                );
  
    $output->pure_redirect( URL => "act=Msg;CODE=02" );
}

sub del_member {
    my ($obj, $db) = @_;

    $std->Error( DB     => $db,
                 LEVEL  => '1',
                 MESSAGE=>'no_user'
               ) unless $iB::IN{'MID'};
    
    $db->delete( TABLE   => 'address_books',
                 ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                 WHERE   => "IN_MEMBER_ID eq '$iB::IN{'MID'}'"
               );

    $output->pure_redirect( URL => "act=Msg;CODE=02" );
}


sub edit_member {
    my ($obj, $db) = @_;

    $std->Error( DB     => $db,
                 LEVEL  => '1',
                 MESSAGE=>'no_user'
               ) unless $iB::IN{'MID'};
    
    my $addressee = $db->query( TABLE   => 'address_books',
                                MATCH   => 'ONE',
                                WHERE  => "IN_MEMBER_ID eq '$iB::IN{'MID'}' and MEMBER_ID eq '$iB::MEMBER->{'MEMBER_ID'}'"
                             );

    my $s_html = qq[<select name='allow_msg' class='forminput'>];

    if ($addressee->{'RECEIVE_MSG'}) {
        $s_html .= qq[<option value='yes' selected>$Messenger::lang->{'yes'}<option value='no'>$Messenger::lang->{'no'}];
    } else {
        $s_html .= qq[<option value='yes'>$Messenger::lang->{'yes'}<option value='no' selected>$Messenger::lang->{'no'}];
    }

    $s_html .= "</select>";

    $obj->{'.html'} .= MessengerView::address_edit( 
                                                    {
                                                      SELECT => $s_html,
                                                      MEMBER => $addressee
                                                    }
                                                  );
    $obj->{'.html'} .= MessengerView::CP_end();

    $output->print_ikonboard( DB      => $db,
                              TITLE   => $Messenger::lang->{'t_welcome'},
                              NAV     => [
                                           qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>!,
                                           qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=02">$Messenger::lang->{'t_book'}</a>!,
                                         ],
                              OUTPUT  => $obj->{'.html'}
                            );
}

sub do_edit {
    my ($obj, $db) = @_;

    $std->Error( DB     => $db,
                 LEVEL  => '1',
                 MESSAGE=>'no_user'
               ) unless $iB::IN{'MID'};

    $iB::IN{'allow_msg'} =  $iB::IN{'allow_msg'} eq 'yes' ? 1 : 0;

    my $entry = $db->query( TABLE  => 'address_books',
                            MATCH  => 'ONE',
                            WHERE  => "IN_MEMBER_ID eq '$iB::IN{'MID'}' and MEMBER_ID eq '$iB::MEMBER->{'MEMBER_ID'}'"
                          );

    $std->Error( DB     => $db,
                 LEVEL  => '1',
                 MESSAGE=>'no_user'
               ) unless $entry->{'ID'};
    
    $db->update( TABLE   => 'address_books',
                 KEY     => $entry->{'ID'},
                 VALUES  => { IN_MEMBER_DESC  => $iB::IN{'mem_desc'},
                              RECEIVE_MSG     => $iB::IN{'allow_msg'}
                            }
               );

    $output->pure_redirect( URL => "act=Msg;CODE=02" );
}


sub contact {
    my ($obj, $db) = @_;

    $obj->{'.html'} .= MessengerView::Address_header();

    my $address = $db->query( TABLE    => 'address_books',
                              WHERE    => "MEMBER_ID eq '$iB::MEMBER->{'MEMBER_ID'}'",
                              SORT_KEY => 'IN_MEMBER_NAME',
                            ) || die $db->{'error'};

    if (scalar @{$address} > 0) {
        $obj->{'.html'} .=  MessengerView::Address_table_header();
        
        for my $entry (@{$address}) {
            $entry->{'TEXT'} = $entry->{'RECEIVE_MSG'}
                             ? $Messenger::lang->{'can_contact'}
                             : $Messenger::lang->{'cannot_contact'};
            $obj->{'.html'} .=  MessengerView::render_address_row($entry);
        }
    
        $obj->{'.html'} .=  MessengerView::end_address_table();
        
    } else {
        $obj->{'.html'} .=  MessengerView::Address_none();
    }

    my $name_to_enter;
    if ($iB::IN{'MID'}) {
        my $temp_mem = $mem->LoadMember( DB     => $db,
                                         METHOD => 'by id',
                                         KEY    => $iB::IN{'MID'}
                                        );

        $name_to_enter = $temp_mem->{'MEMBER_NAME'} if $temp_mem->{'MEMBER_ID'};
    }

    $obj->{'.html'} .= MessengerView::address_add($name_to_enter);
    $obj->{'.html'} .= MessengerView::CP_end();

    $output->print_ikonboard( DB      => $db,
                              TITLE   => $Messenger::lang->{'t_welcome'},
                              NAV     => [ qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00">$Messenger::lang->{'t_title'}</a>! ],
                              OUTPUT  => $obj->{'.html'}
                            );
}

  

sub Show_menu ($) {
    my ($obj, $db) = @_;

    if ($obj->{'R_MEMBER'}->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}){
        my $Nav_tabs = { '00' => 'splash', '01' => 'in_box', '02' => 'contact', '07' => 'prefs', '04' => 'send', '13' => 'send2'};
        my $Nav_color = { };
        for (qw[splash in_box contact prefs send send2]) { $Nav_color->{$_} = $iB::SKIN->{'USERNAV_OFF'} }
        $Nav_color->{ $Nav_tabs->{ $iB::IN{'CODE'} } } = $iB::SKIN->{'USERNAV_ON'};
    return MessengerView::Menu_bar_admin($Nav_color);
    }
    my $Nav_tabs = { '00' => 'splash', '01' => 'in_box', '02' => 'contact', '07' => 'prefs', '04' => 'send'};
    my $Nav_color = { };
    for (qw[splash in_box contact prefs send]) { $Nav_color->{$_} = $iB::SKIN->{'USERNAV_OFF'} }
    $Nav_color->{ $Nav_tabs->{ $iB::IN{'CODE'} } } = $iB::SKIN->{'USERNAV_ON'};
    return MessengerView::Menu_bar($Nav_color);
}
   

sub Process {
    my ($obj, $db) = @_;
    $std->Error(LEVEL=>'1',MESSAGE=>'Wha.....?') unless (defined $iB::IN{'CODE'});
    $obj->SetSession($db);
    my $CodeNo = $std->CheckCodeNo($iB::IN{'CODE'});
    my %Mode = ( '00'     => \&Splash,
                 '01'     => \&msg_list,
                 '02'     => \&contact,
                 '05'     => \&delete,
                 '06'     => \&multiact,
                 '07'     => \&prefs,
                 '08'     => \&do_prefs,
                 '09'     => \&add_member,
                 '10'     => \&del_member,
                 '11'     => \&edit_member,
                 '12'     => \&do_edit,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : MessengerError($obj,$db);
} 


sub SetSession {
    my ($obj, $db) = @_;

    # Display an "error" if we are not allowed to use the messenger
    unless ($iB::MEMBER_GROUP->{'USE_PM'}) {
        $std->Error( DB => $db, LEVEL => 1, MESSAGE => 'no_use_messenger' );
        return "0 but true";
    }
    require $iB::SKIN->{'DIR'} . '/MessengerView.pm' or $std->cgi_error($!);
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_guest_posting')  unless $obj->{'R_MEMBER'}->{'MEMBER_ID'};
    $obj->{'.html'} = $obj->Show_menu($db);
}


sub MessengerError  { 
    my ($obj, $db) = @_; $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'incorrect_use')
    }

1;
