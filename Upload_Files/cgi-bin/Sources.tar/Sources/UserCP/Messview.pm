package UserCP::Messview;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
#################################################################
# Messenger: Messenger View Functions.
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
    # added by kevaholic00
    require 'Boardinfo.cgi' or die $!;
    # end addition
}

my $output       = FUNC::Output->new();
my $mem          = FUNC::Member->new();
my $std          = FUNC::STD->new();
my $txt          = iTextparser->new();
# added by kevaholic00
my $INFO         = Boardinfo->new();
# end addition
$Messenger::lang = $std->LoadLanguage('MessengerWords');

sub new {
  my $pkg = shift;
  my $obj = { R_MEMBER => $iB::MEMBER, NEW_MSG_DATA => '', '.to_member' => '', '.html' => '' };
  bless $obj, $pkg;
  return $obj;
}

#+------------------------------------------------------------------------------------------------------

sub view_msg ($$$) {
    my ($obj,$db, $mode) = @_;

    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_such_msg')    unless $iB::IN{'MSID'};

    my $Row = $db->select( TABLE   => 'message_data',
                           ID      => $iB::MEMBER->{'MEMBER_ID'},
                           KEY     => $iB::IN{'MSID'}
                         );
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_such_msg')    unless $Row->{'MEMBER_ID'} == $iB::MEMBER->{'MEMBER_ID'};

    $obj->my_get_stats($db);

    if ($Row->{'READ_STATE'} < 1) {
        if ($Row->{'READ_STATE' } < 0) {
            # this message is being tracked. Send return receipt
            my $memb1 = $mem->LoadMember( DB => $db, KEY => $Row->{'FROM_ID'}, METHOD => 'by id');
            my $rr_show_popup = (split/&/, $memb1->{'PM_REMINDER'})[1];
            my $rr_id = $db->insert( TABLE  => 'message_data',
                                     ID     => $Row->{'FROM_ID'},
                                     VALUES => { DATE         => time,
                                                 READ_STATE   => 0,
                                                 TITLE        => $Messenger::lang->{read_rec_title}.' '.$Row->{'TITLE'},
                                                 MESSAGE      => "<b>$Messenger::lang->{read_rec_text} ".$std->get_date( TIME => $Row->{'DATE'}, METHOD => 'LONG').':</b><BR>'.$Row->{'MESSAGE'}."<br><br><b>".$obj->{R_MEMBER}->{MEMBER_NAME}." $Messenger::lang->{mem_read_msg}</b>",
                                                 MESSAGE_ICON => '',
                                                 FROM_ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                                 FROM_NAME    => $obj->{'R_MEMBER'}->{'MEMBER_NAME'},
                                                 REPLY        => '',
                                                 REPLY_DATE   => '',
                                                 VIRTUAL_DIR  => 'in',
                                                 MEMBER_ID    => $Row->{'FROM_ID'}
                                   }
                        );
             my $msg_stats = { };
             $msg_stats = $db->select( TABLE  => 'message_stats',
                                       ID     => $Row->{'FROM_ID'},
                                       KEY    => $Row->{'FROM_ID'},
                                     );
             if ($msg_stats->{'MEMBER_ID'}) {
                 $msg_stats->{'TOTAL_MESSAGES'}++;
                 $msg_stats->{'NEW_MESSAGES'}++;
                 $db->update(  TABLE  => 'message_stats',
                               ID     => $Row->{'FROM_ID'},
                               KEY    => $Row->{'FROM_ID'},
                               VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'},
                                           NEW_MESSAGES   => $msg_stats->{'NEW_MESSAGES'},
                                           LAST_FROM_NAME => $obj->{'R_MEMBER'}->{'MEMBER_NAME'},
                                           LAST_FROM_ID   => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                           LAST_SENT      => time,
                                           LAST_MSG_ID    => $rr_id,
                                           LAST_MSG_TITLE => $Messenger::lang->{read_rec_title}.' '.$Row->{'TITLE'},
                                           SHOW_POPUP     => $rr_show_popup,
                                         }
                            );
             } else {
                 $db->insert(  TABLE  => 'message_stats',
                               ID     =>  $Row->{'FROM_ID'},
                               KEY    =>  $Row->{'FROM_ID'},
                               VALUES => { MEMBER_ID          => $Row->{'FROM_ID'},
                                           LAST_READ          => '',
                                           NEW_MESSAGES       => 1,
                                           LAST_FROM_NAME     => $obj->{'R_MEMBER'}->{'MEMBER_NAME'},
                                           LAST_FROM_ID       => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                           LAST_MSG_ID        => $rr_id,
                                           LAST_MSG_TITLE     => $Messenger::lang->{read_rec_title}.' '.$Row->{'TITLE'},
                                           LAST_SENT          => time,
                                           TOTAL_MESSAGES     => 1,
                                           VIRTUAL_DIR        => "in:Inbox|sent:Sent Items|",
                                           SHOW_POPUP         => $rr_show_popup,
                                         }
                           );
             }
       } #// end read state = -1

       # Read state must be 0 - lets make it 1 to inform the member that
       # they have read this message already

       $db->update(       TABLE   => 'message_data',
                          KEY     => $iB::IN{'MSID'},
                          ID      => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                          VALUES  => { READ_STATE => 1 }
                  );
   }

    $Row->{'DATE'}    = $std->get_date( TIME => $Row->{'DATE'}, METHOD => 'LONG');


    $Row->{'MESSAGE_ICON'} = $Row->{'MESSAGE_ICON'}
                           ? $iB::INFO->{'IMAGES_URL'}.'/PostIcons/icon'.$Row->{'MESSAGE_ICON'}.'.gif'
                           : $iB::INFO->{'IMAGES_URL'}.'/PostIcons/icon0.gif';

    #+---------------------------------------------------------
    # Grab the member groups and push into a hash
    #+---------------------------------------------------------

    my $mem_groups = $db->query( TABLE      => 'mem_groups',
                                 COLUMNS    => ['ID', 'TITLE', 'TEAM_ICON'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );

    my %temp_table = map { $_->{'ID'} => { TITLE  => $_->{'TITLE'},
                                           ICON   => $_->{'TEAM_ICON'}
                                         }
                         } @{$mem_groups};
    $obj->{'group_table'} = \%temp_table;
    #+---------------------------------------------------------
    # Grab the member titles and push into a hash
    #+---------------------------------------------------------

    my $mem_titles = $db->query( TABLE      => 'member_titles',
                                 COLUMNS    => ['ID', 'TITLE', 'PIPS'],
                                 SORT_KEY   => 'TITLE',
                                 SORT_BY    => 'A-Z',
                               );

    my %temp_titles = map { $_->{'ID'} => { TITLE => $_->{'TITLE'},
                                            PIPS  => $_->{'PIPS'}
                                          }
                          } @{$mem_titles};
    $obj->{'title_table'} = \%temp_titles;

    my $member = {};

    # MEMBER_ID 001 is reserved by internal ikonboard functions such
    # as the "report this post to a moderator feature" - we create a dummy profile for this "member"


    if ($Row->{FROM_ID} eq '001') {
        $member = { MEMBER_NAME   => $Messenger::lang->{'ikon_bot'},
                    MEMBER_ID     => "001",
                    MEMBER_GROUP  => "--",
                    MEMBER_POSTS  => "--",
                  };
    } else {
        $member = $db->select( TABLE    => 'member_profiles',
                               ID       => $Row->{'FROM_ID'},
                               KEY      => $Row->{'FROM_ID'}
                             );

        $member->{'MEMBER_GROUP_ID'} = $member->{'MEMBER_GROUP'};
        $member = $obj->do_member( $db, $member, $obj->{'group_table'}, $obj->{'title_table'} );
    }
    unless ($member->{'POST_FONT_COLOR'}) {
        $member->{'POST_FONT_COLOR'} = $iB::INFO->{'FONT_COLOR_DEFAULT'};
    }
    unless ($iB::INFO->{'FONT_COLOR_ALLOW'} == 1) {
        $member->{'POST_FONT_COLOR'} = $iB::INFO->{'FONT_COLOR_DEFAULT'};
    }
    my $use_pfc = $iB::MEMBER->{'POST_FONT_COLOR'} ? 1 : 0;
    $Row->{'MESSAGE'} = $txt->Convert_for_db( TEXT    => $Row->{'MESSAGE'},
                                          SMILIES => 1,
                                          IB_CODE => $iB::INFO->{'MSG_ALLOW_CODE'},
                                          HTML    => $iB::INFO->{'MSG_ALLOW_HTML'},
                                          USER    => $member->{MEMBER_NAME},
                                          ADD_POST_COLOR => $use_pfc,
                                          POST_COLOR     => $member->{'POST_FONT_COLOR'}
                                        );


    # Fix up the siggie

    $member->{'SIGNATURE'} = "" unless $obj->{'R_MEMBER'}->{'VIEW_SIGS'};
    $member->{'ONLINE'} = &mem_stat($member->{'MEMBER_NAME'});

    $member->{'VID'}    = $obj->{'R_MEMBER'}->{'CURRENT_ID'};

    $obj->{'.html'} .= MessengerView::Render_msg(
                                                  {
                                                    MSG    => $Row,
                                                    MEMBER => $member,
                                                    JUMP   => $obj->{'.jump_html'},
                                                    NEXT   => $obj->{'new_mess'}
                                                  }
                                                );

    $obj->{'.html'} .= MessengerView::CP_end();

    $output->print_ikonboard( DB      => $db,
                              TITLE   => $Messenger::lang->{'t_welcome'},
                              JAVASCRIPT => 1,
                              NAV     => [
                                           qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00" class='nav'>$Messenger::lang->{'t_title'}</a>!,
                                           qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=01;VID=$obj->{'R_MEMBER'}->{'CURRENT_ID'}" class='nav'>$obj->{'R_MEMBER'}->{'CURRENT_DIR'}</a>!,
                                           "$Row->{'TITLE'}",
                                         ],
                              OUTPUT  => $obj->{'.html'}
                            );
}


sub my_get_stats {
    my ($obj, $db) = @_;

    $obj->{'R_MEMBER'}->{'DIR_DATA'} = [];

    my $v_dir = $iB::IN{'VID'} || 'in';

    $obj->{'.jump_html'} = qq[<select name='VID' class='forminput'>\n];

    my $stats = $db->select(  TABLE  => 'message_stats',
                              ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                              KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'}
                           );
    my $new_m = $stats->{'NEW_MESSAGES'} -1;
    $new_m = $new_m > 0 ? $new_m : 0;
    my $new_mess = $db->query(  TABLE    => 'message_data',
                                ID       => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                WHERE    => qq[MEMBER_ID eq '$obj->{'R_MEMBER'}->{'MEMBER_ID'}' and READ_STATE == 0 and VIRTUAL_DIR eq 'in'],
                                SORT_KEY => 'DATE',
                                SORT_BY  => 'A-Z',
                                );

     $db->update(  TABLE  => 'message_stats',
                   ID     => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                   KEY    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                   VALUES => { NEW_MESSAGES   => $new_m,
                               LAST_FROM_NAME => $new_mess->[1]->{'FROM_NAME'},
                               LAST_FROM_ID   => $new_mess->[1]->{'FROM_ID'},
                               LAST_SENT      => $new_mess->[1]->{'DATE'},
                               LAST_MSG_ID    => $new_mess->[1]->{'MESSAGE_ID'},
                               LAST_MSG_TITLE => $new_mess->[1]->{'TITLE'},
                               SHOW_POPUP     => 0,
                             }
                );
    $stats = undef unless $stats->{'MEMBER_ID'};

    $obj->{'.cur_stats'} = $stats || { MEMBER_ID    => $obj->{'R_MEMBER'}->{'MEMBER_ID'},
                                       NEW_MESSAGES => 0,
                                       VIRTUAL_DIR  => "in:Inbox|sent:Sent Items|",
                                       '_FAKED'     => 1,
                                     };

    for (split (/\|/, $obj->{'.cur_stats'}->{'VIRTUAL_DIR'}) ) {
        my ($id, $real) = split /\:/, $_;
            push @{$obj->{'R_MEMBER'}->{'DIR_DATA'}}, { ID => $id, REAL => $real };
        if ($v_dir eq $id) {
            $obj->{'R_MEMBER'}->{'CURRENT_DIR'} = $real;
            $obj->{'R_MEMBER'}->{'CURRENT_ID'}  = $id;
            $obj->{'.jump_html'} .= qq[<option value='$id' selected>$real\n];
        } else {
            $obj->{'.jump_html'} .= qq[<option value='$id'>$real\n];
        }
    }
    if ($obj->{'R_MEMBER'}->{'CURRENT_ID'} eq 'in' and $new_mess->[1]->{'MESSAGE_ID'}) {
        $obj->{'new_mess'} = qq[<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSV;CODE=03;MODE=3;MSID=$new_mess->[1]->{'MESSAGE_ID'}'>$iB::SKIN->{'M_NEWUNR'}</a>];
    } else {
        $obj->{'new_mess'} = '';
    }

    $obj->{'.jump_html'} .= qq[</select>];
}


sub Show_menu ($) {
    my ($obj, $db) = @_;

    if ($obj->{'R_MEMBER'}->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}){
        my $Nav_tabs = { '00' => 'splash', '01' => 'in_box', '02' => 'contact', '07' => 'prefs', '04' => 'send', '13' => 'send2'};
        my $Nav_color = { };
        for (qw[splash in_box contact prefs send send2]) { $Nav_color->{$_} = $iB::SKIN->{'USERNAV_OFF'} }
        $Nav_color->{ $Nav_tabs->{ $iB::IN{'CODE'} } } = $iB::SKIN->{'USERNAV_ON'};
    return MessengerView::Menu_bar_admin($Nav_color);
    }
    my $Nav_tabs = { '00' => 'splash', '01' => 'in_box', '02' => 'contact', '07' => 'prefs', '04' => 'send'};
    my $Nav_color = { };
    for (qw[splash in_box contact prefs send]) { $Nav_color->{$_} = $iB::SKIN->{'USERNAV_OFF'} }
    $Nav_color->{ $Nav_tabs->{ $iB::IN{'CODE'} } } = $iB::SKIN->{'USERNAV_ON'};
    return MessengerView::Menu_bar($Nav_color);
}

#+------------------------------------------------------------------------------------------------------

sub Process {
    my ($obj, $db) = @_;
    $std->Error(LEVEL=>'1',MESSAGE=>'Wha.....?') unless (defined $iB::IN{'CODE'});

    $obj->SetSession($db);
    my $CodeNo = $std->CheckCodeNo($iB::IN{'CODE'});
    my %Mode = (
                '03'     => \&view_msg,
               );
    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : MessengerError($obj,$db);
}

#+------------------------------------------------------------------------------------------------------

sub SetSession {
    my ($obj, $db) = @_;

    # Display an "error" if we are not allowed to use the messenger
    unless ($iB::MEMBER_GROUP->{'USE_PM'}) {
        $std->Error( DB => $db, LEVEL => 1, MESSAGE => 'no_use_messenger' );
        return "0 but true";
    }
    require $iB::SKIN->{'DIR'} . '/MessengerView.pm' or $std->cgi_error($!);
    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_guest_posting')  unless $obj->{'R_MEMBER'}->{'MEMBER_ID'};
    $obj->{'.html'} = $obj->Show_menu($db);
}

#+------------------------------------------------------------------------------------------------------

sub get_avatar {
    my ($obj, $m_avatar, $av_dims) = @_;
    return unless $iB::INFO->{'AVATARS'}
              and $m_avatar
              and $iB::MEMBER->{'VIEW_AVS'};

    return if $m_avatar eq 'noavatar';
    return '' if $m_avatar =~ m#\.swf#i and $iB::INFO->{'ALLOW_FLASH'} != 1;
    my ($d_a_width, $d_a_height) = split "x", $iB::INFO->{'DEF_AV_DIMS'};
    if ($m_avatar =~ m#\Ahttp\://#i) {
        if ($iB::INFO->{'AV_ALLOW_URL'}) {
            my ($width  , $height)   = split "x", $av_dims;
            my ($a_width, $a_height) = split "x", $iB::INFO->{'AV_DIMS'};
            $height ||= $a_height;
            $width  ||= $a_width;
            return $m_avatar =~ m#\.swf\Z#i ? qq|<OBJECT CLASSID="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" WIDTH=$width HEIGHT=$height><PARAM NAME=MOVIE VALUE=$m_avatar><PARAM NAME=PLAY VALUE=TRUE><PARAM NAME=LOOP VALUE=TRUE><PARAM NAME=QUALITY VALUE=HIGH><EMBED SRC=$m_avatar WIDTH=$width HEIGHT=$height PLAY=TRUE LOOP=TRUE QUALITY=HIGH></EMBED></OBJECT>|
                                            : qq|<img src='$m_avatar' border='0' width='$width' height='$height'>|;
        }
    }
    return qq|<img src='$iB::INFO->{'AVATARS_URL'}/$m_avatar' border='0' width='$d_a_width' height='$d_a_height'>| unless $m_avatar =~ m#\Ahttp\://#i;
}

    sub mem_stat {
    my $name = shift;
    my $status = 'off';
    foreach  (@{ $iB::ACTIVE->{'NAMES'} }) {
       if ($_->{'NAME'} eq $name) {
         return $iB::SKIN->{'ONLINE'};
        }
    }
    return $iB::SKIN->{'OFFLINE'};
}

sub do_member ($$) {
    my ($obj, $db, $member, $mem_group, $mem_title) = @_;

    # Get the member info from the relevant tables

    #Get the members Avatar
    $member->{'MEMBER_AVATAR'} = $obj->get_avatar($member->{'MEMBER_AVATAR'}, $member->{'AVATAR_DIMS'});

    #Sort out the member title
    $member->{'MEMBER_TITLE'} = $member->{'MEMBER_TITLE'} ? $member->{'MEMBER_TITLE'}
                                                          : $mem_title->{ $member->{'MEMBER_LEVEL'} }->{'TITLE'};

unless( $obj->{'group_table'}->{ $member->{'MEMBER_GROUP_ID'} }->{'ICON'} ) {

       $member->{'MEMBER_PIPS'} = $obj->{'title_table'}->{  $member->{'MEMBER_LEVEL'}  }->{'PIPS'};
       if (defined $member->{'MEMBER_PIPS'}) {
           if ($member->{'MEMBER_PIPS'} !~ /^\d+$/) {
                $member->{'MEMBER_PIPS_IMG'} = qq!<img src="$INFO->{'IMAGES_URL'}/team_icons/$member->{'MEMBER_PIPS'}" border='0'>!;
           } else {
                $member->{'MEMBER_PIPS_IMG'} = qq!$iB::SKIN->{'A_STAR'}! x $member->{'MEMBER_PIPS'};
           }
       }
   } else {
       $member->{'MEMBER_PIPS_IMG'} = qq!<img src="$INFO->{'IMAGES_URL'}/team_icons/$obj->{'group_table'}->{ $member->{'MEMBER_GROUP_ID'} }->{'ICON'}" border='0'>!
   }


    $member->{'MEMBER_JOINED'} = $Messenger::lang->{'m_joined'}.' '.$std->get_date( TIME => $member->{'MEMBER_JOINED'}, METHOD => 'JOINED');


    if ($member->{'SIGNATURE'} and $iB::MEMBER->{'VIEW_SIGS'}) {
        $member->{'SIGNATURE'} = qq[<!--Signature--><br><br>--------------<br><span id='signature'>$member->{'SIGNATURE'}</span><!--E Signature-->];
    }

    $member->{'MEMBER_GROUP'} = $Messenger::lang->{'m_group'}.' '.$mem_group->{ $member->{'MEMBER_GROUP'} }->{'TITLE'};
    $member->{'MEMBER_POSTS'} = $Messenger::lang->{'m_posts'}.' '.$member->{'MEMBER_POSTS'};

    $member->{'PROFILE_ICON'} = qq!<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$member->{'MEMBER_ID'}" title="$Messenger::lang->{'profile'}">$iB::SKIN->{'P_PROFILE'}</a>!;

    $member->{'CONTACT_ICON'}
       = qq!<a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=07;MID=$member->{'MEMBER_ID'}','Contact','420','280','0','1','1','1')" title="$Topic::lang->{'contact'}">$iB::SKIN->{'P_CONTACTINFO'}</a>&nbsp;!;

    $member->{'WEBSITE_ICON'} = ($member->{'WEBSITE'} and $member->{'WEBSITE'} =~ m#\Ahttp://.+?\S\Z#i)
                              ? (qq[<a href='$member->{'WEBSITE'}' title="$Messenger::lang->{'website'}">$iB::SKIN->{'P_WEBSITE'}</a>])
                              : ('');
   return $member;
}


sub MessengerError  { my ($obj, $db) = @_; $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'incorrect_use') }



1;
