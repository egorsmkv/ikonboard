package Team;
use strict;

############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
# Team: Mods & admins list functions
# Written by Sly
#
#################################################################################

BEGIN { require 'Lib/FUNC.pm'; 
		require $iB::SKIN->{'DIR'} . '/TeamView.pm' or die $!;
	  }

my $std		= FUNC::STD->new();
my $output	= FUNC::Output->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}

sub staff {
  my ($obj, $db) = @_;

	my $moderators = $db->query(TABLE	  => 'forum_moderators',
				 				SORT_KEY  => 'MEMBER_NAME',
								SORT_BY	  => 'A-Z',
								MATCH	  => 'ALL'
							   ) || die $db->{'error'};

    #+---------------------------------------------------------
    # Grab the forums and push into a hash
    #+---------------------------------------------------------

    my $forums =	 $db->query( TABLE      => 'forum_info',
                                 COLUMNS    => ['FORUM_ID', 'FORUM_NAME', 'FORUM_DESC', 'FORUM_VIEW_THREADS'],
                                 SORT_KEY   => 'FORUM_ID',
                                 SORT_BY    => 'A-Z',
                               ) || die $db->{'error'};

    my %temp_forums = map { $_->{'FORUM_ID'} => { NAME => $_->{'FORUM_NAME'},
												  DESC => $_->{'FORUM_DESC'},
												  VIEW => $_->{'FORUM_VIEW_THREADS'}
												}
                          } @{$forums};
    $obj->{'forum_table'} = \%temp_forums;

	my $admins =	$db->query( TABLE      => 'member_profiles',
                                 COLUMNS    => ['MEMBER_ID', 'MEMBER_NAME'],
								 WHERE		=> "MEMBER_GROUP == $iB::INFO->{'SUPAD_GROUP'}",
                                 SORT_KEY   => 'MEMBER_NAME',
                                 SORT_BY    => 'A-Z',
                               ) || die $db->{'error'};

	my $mem_groups = $db->query( TABLE      => 'mem_groups',
								 COLUMNS    => ['ID', 'TITLE','TEAM_ICON', 'IS_SUPMOD'],
								 SORT_KEY   => 'ID',
								 SORT_BY    => 'A-Z',
								 MATCH		=> 'ALL'
							   );
    my %temp_table = map { $_->{'ID'} => { TITLE  => $_->{'TITLE'},
                                           ICON   => $_->{'TEAM_ICON'}
                                         }
                         } @{$mem_groups};
    $obj->{'group_table'} = \%temp_table;

	my ($html, $forum_name, $forum_desc, $old_name, $new_name, $pm_link);

# Admins

	if (scalar @{$admins} > 0) {
		$html .= TeamView::admin_header();
		foreach my $ad (@{$admins}) {
		  $html .= TeamView::admin_row($ad);
		}
		$html .= TeamView::admin_footer();
	}

# Super Mods

	my ($where, $i);
	foreach my $supmod (@{$mem_groups}) {
		if ($supmod->{'IS_SUPMOD'} == 1) {
			$i++;
			$where .= "(" if $i == 1;
			$where .= " or " unless $i == 1;
			$where .= "MEMBER_GROUP == $supmod->{'ID'}"; 
		}
	}
	$where .= ") && MEMBER_GROUP != $iB::INFO->{'SUPAD_GROUP'}";
    my $sup_mod = $db->query( TABLE      => 'member_profiles',
                              WHERE      => qq!$where!,
                              SORT_KEY   => "MEMBER_NAME",
                              SORT_BY    => 'A-Z',
                             );	
	if (scalar @{$sup_mod} > 0) {
		$html .= TeamView::sup_mod_header();
		foreach my $sup (@{$sup_mod}) {
			$html .= TeamView::sup_mod_row($sup);
		}
		$html .= TeamView::sup_mod_footer();
	}

# Moderators

	if (scalar @{$moderators} > 0) {
		$html .= TeamView::moderator_header();
		foreach my $mod (@{$moderators}) {
			if ($obj->{'forum_table'}->{ $mod->{'FORUM_ID'} }->{'VIEW'} ne '*') {
				unless (grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$obj->{'forum_table'}->{ $mod->{'FORUM_ID'} }->{'VIEW'}) ) {
					next;
				}
			}
			$forum_name = $obj->{'forum_table'}->{  $mod->{'FORUM_ID'}  }->{'NAME'};
			$forum_desc = $obj->{'forum_table'}->{  $mod->{'FORUM_ID'}  }->{'DESC'};
			if ($old_name eq $mod->{'MEMBER_NAME'}) {
			  $old_name = $mod->{'MEMBER_NAME'};
			  $mod->{'MEMBER_NAME'} = '';
			  $pm_link = '';
			} else {
			  $old_name = $mod->{'MEMBER_NAME'};
			  $pm_link = qq~<span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSS;CODE=04;MID=$mod->{'MEMBER_ID'}">$iB::SKIN->{'P_MSG'}</a>~;
			}
			$html .= TeamView::moderator_row($mod, $forum_name, $forum_desc, $pm_link);
		}
		$html .= TeamView::moderator_footer();
	}
	$output->print_ikonboard( DB	  => $db,
							  STD	  => $std,
							  TITLE	  => "iB::Staff list",
							  NAV_ONE => "Board Staff",
							  OUTPUT  => $html,
							);
}

sub Process {
    my ($obj, $db) = @_;
	my $html;
		&staff($obj, $db); 
}
sub PagesError { die "EEK!!" }

1;
