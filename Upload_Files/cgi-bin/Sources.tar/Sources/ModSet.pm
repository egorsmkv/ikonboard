package	ModSet;
use	strict;
use	Time::localtime;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Post: Moderators Notifications functions for Moderated Forums.
#
#################################################################################

BEGIN {
	require 'Lib/FUNC.pm';
	require 'iTextparser.pm';
}

my $output      = FUNC::Output->new();
my $mem         = FUNC::Member->new();
my $mail        = FUNC::Mailer->new();
my $std         = FUNC::STD->new();
my $txt         = iTextparser->new();
$ModCP::lang	= $std->LoadLanguage('ModCPWords');


sub	new {
	my $pkg = shift;
	my $obj = { 'html' => undef, 'PASSED' => 0 };
	bless $obj, $pkg;
	return $obj;
}


sub	splash {
	my ($obj, $db) = @_;
	$obj->{html} = ModCPView::startcp_set($ModCP::lang->{'setti_prefs_hed'});
# 	unless ($iB::IN{'f'}) {
# 		require 'ModCP.pm';
# 		my $modcp = ModCP->new();
# 		$modcp->_main_splash($db);
# 	}
# 	if ($iB::IN{'f'}) {
		$obj->_settings_splash($db);
# 	}
	$obj->{html} .= ModCPView::endcp();

}

sub	_settings_splash {
	my ($obj, $db) = @_;

	unless ($obj->{type} eq 'all') {
		$std->Error( DB      => $db,
					 LEVEL   => 1,
					 MESSAGE =>'moderate_no_permission'
				   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
	}
	my $settings  = $db->query( TABLE    => 'mod_email',
								WHERE    => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!,
								SORT_KEY => 'FORUM_ID',
								SORT_BY  => 'A-Z',
							   );

	my $other_set = $db->query( TABLE    => 'mod_email',
								WHERE    => qq!MEMBER_ID ne "$iB::MEMBER->{'MEMBER_ID'}"!,
								SORT_KEY => 'FORUM_ID',
								SORT_BY  => 'A-Z',
							   );
	$obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;
	if ($iB::MEMBER->{'MEMBER_GROUP'} == $iB::INFO->{'SUPAD_GROUP'}) {
		my $action= $ModCP::lang->{'mod_name'};
		$obj->{html} .= ModCPView::show_setings($ModCP::lang->{'show_set_oth'}, $action);
		foreach my $oth (@{$other_set}) {
			$obj->{html} .= ModCPView::show_set_forum($oth);
		}
	}
	my $action= $ModCP::lang->{'mod_name'};
	$obj->{html} .= ModCPView::show_setings($ModCP::lang->{'show_set_me'}, $action);
	foreach my $me (@{$settings}) {
	$obj->{html} .= ModCPView::show_set_forum($me);
	}
}

sub	add {
	my ($obj, $db) = @_;

	unless ($obj->{type} eq 'all') {
		$std->Error( DB      => $db,
					 LEVEL   => 1,
					 MESSAGE =>'moderate_no_permission'
				   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
	}
	# if supermod, get all the forums
	my $forums;
	if ($obj->{type} eq 'all') {
	   $forums = $db->query(TABLE     => 'forum_info',
							SORT_KEY  => 'FORUM_POSITION',
							SORT_BY   => 'A-Z',
							MATCH     => 'ALL'
							) || die $db->{'error'};
	} else {
	# if not get just the relevent ones
		my $mods = $db->query( TABLE      => 'forum_moderators',
							   WHERE      => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!,
							 );
		my $forum = $db->query(TABLE     => 'forum_info',
							   SORT_KEY  => 'FORUM_POSITION',
							   SORT_BY   => 'A-Z',
							   MATCH     => 'ALL'
								) || die $db->{'error'};
		foreach my $sel (@{$mods}) {
			foreach my $fr(@{$forum}) {
				if ($fr->{'FORUM_ID'} == $sel->{'FORUM_ID'}) {
					push @{$forums} , $fr;
					last;
				}
			}
		}
	}
	my $settings  = $db->query( TABLE    => 'mod_email',
								WHERE    => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!,
								SORT_KEY => 'FORUM_ID',
								SORT_BY  => 'A-Z',
							   );
	$obj->{html} = ModCPView::startcp_set($ModCP::lang->{'setti_prefs_hed'});
	$obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;
	$obj->{html} .= ModCPView::add_email_header($ModCP::lang->{'add_settings'});
	if (scalar @{$settings} eq scalar @{$forums}) {
		$obj->{html} = undef;
		$output->redirect_screen( TEXT => $ModCP::lang->{'no_matches_set'}, URL => "act=ModSet&f=$iB::IN{'f'}" );
	}
	foreach my $f (@{$forums}) {
		foreach  (@{$settings}) {
			if ($_->{'FORUM_ID'} == $f->{'FORUM_ID'}) {
				goto PASS;
			}
		}
		my $select = qq!<select name='CHOICE_$f->{'FORUM_ID'}' class='forminput'>!;
		$select .= qq!<option value='leave' selected>$ModCP::lang->{'c_leave'}<option value='select'>* $ModCP::lang->{'c_select'} *!;
		$f->{'SELECT'} = $select . "</select>";
		$obj->{html} .= ModCPView::render_add_email( $f );
	PASS:
	}
	$obj->{html} .= ModCPView::message_box();
	$obj->{html} .= ModCPView::CheckBoxes();
	$obj->{html} .= ModCPView::endcp();
}

sub	do_add {
	my ($obj, $db) = @_;

	my $forums = $db->query(TABLE     => 'forum_info',
							SORT_KEY  => 'FORUM_ID',
							SORT_BY   => 'A-Z',
							MATCH     => 'ALL'
							) || die $db->{'error'};
	$iB::IN{'PM'}	 = $iB::IN{'PM'} eq '1' ? 1 : 0;
	my $method = $iB::IN{'PM'} eq '1' ? 1 : 0;
	$IB::IN{'ONCE'}  = $iB::IN{'ONCE'} eq 'once' ? 1 : 0;
	$iB::IN{'Post'}  = $txt->Convert_for_db( TEXT    => $iB::IN{'Post'},
											 SMILIES => $iB::IN{'PM'},
											 IB_CODE => $iB::IN{'PM'},
											 HTML    => 0,
											 );

	my $hehe;
	for my $forum (@{$forums}) {
		$hehe = "CHOICE_".$forum->{'FORUM_ID'};
		if ($iB::IN{$hehe} eq "select") {
			my $new_id = $db->insert( TABLE  => 'mod_email',
									  VALUES => {
												 FORUM_ID    => $forum->{'FORUM_ID'},
												 FORUM_NAME  => $forum->{'FORUM_NAME'},
												 EMAIL       => $iB::MEMBER->{'MEMBER_EMAIL'},
												 MEMBER_ID   => $iB::MEMBER->{'MEMBER_ID'},
												 MEMBER_NAME => $iB::MEMBER->{'MEMBER_NAME'},
												 TEXT        => $iB::IN{'Post'},
												 CHOICE      => $method,
												 WHENE        => $IB::IN{'ONCE'},
												 SENT        => '0',
												},
									) || die $db->{'error'};

		}
		}
	$obj->splash($db);
}


sub	del {
	my ($obj, $db) = @_;

	unless ($obj->{type} eq 'all') {
		$std->Error( DB      => $db,
					 LEVEL   => 1,
					 MESSAGE =>'moderate_no_permission'
				   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
	}
	my $settings  = $db->query( TABLE    => 'mod_email',
								WHERE    => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!,
								SORT_KEY => 'FORUM_ID',
								SORT_BY  => 'A-Z',
							   );

	$obj->{html} = ModCPView::startcp_set($ModCP::lang->{'setti_prefs_hed'});
	$obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;
	my $action= $ModCP::lang->{'tt_action'};
	$obj->{html} .= ModCPView::show_setings($ModCP::lang->{'show_set_me'}, $action);
	foreach my $me (@{$settings}) {
	$obj->{html} .= ModCPView::show_del_set($me);
	}
	$obj->{html} .= ModCPView::endcp();
}

sub	do_del {
	my ($obj, $db) = @_;
	unless ($obj->{type} eq 'all') {
		$std->Error( DB      => $db,
					 LEVEL   => 1,
					 MESSAGE =>'moderate_no_permission'
				   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
	}
	my $del = $iB::IN{'i'};
	$db->delete( TABLE  => 'mod_email',
				 KEY    => $del,
				 WHERE  => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"  and ID == $del!,
			   ) || die $db->{'error'};
	$output->pure_redirect( URL => "act=ModSet;CODE=del;f=$iB::IN{'f'}");
}

sub	edit_e {
	my ($obj, $db) = @_;
	unless ($obj->{type} eq 'all') {
		$std->Error( DB      => $db,
					 LEVEL   => 1,
					 MESSAGE =>'moderate_no_permission'
				   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
	}
	my $edit = $iB::IN{'i'};
	my $settings  = $db->select( TABLE  => 'mod_email',
								 KEY    => $edit,
								 WHERE  => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"  and ID == $edit!,
							   );
	$obj->{html} = ModCPView::startcp_set($ModCP::lang->{'setti_prefs_hed'});
	$obj->{html} =~ s/<!--menu goes here-->/&ModCPView::offline_menu/e;
	$obj->{html} .= ModCPView::edit_email_header($settings, $ModCP::lang->{'edit_notifi'});
	$obj->{html} .= ModCPView::message_box($settings->{'TEXT'});
	$obj->{html} .= ModCPView::CheckBoxes();
	$obj->{html} .= ModCPView::endcp();

}


sub	do_edit {
	my ($obj, $db) = @_;
	unless ($obj->{type} eq 'all') {
		$std->Error( DB      => $db,
					 LEVEL   => 1,
					 MESSAGE =>'moderate_no_permission'
				   ) unless exists $obj->{moderator}->{ $iB::IN{'f'} };
	}
	my $edit = $iB::IN{'i'};
	$iB::IN{'PM'}	 = $iB::IN{'PM'} eq '1' ? 1 : 0;
	my $method = $iB::IN{'PM'} eq '1' ? 1 : 0;
	$IB::IN{'ONCE'}  = $iB::IN{'ONCE'} eq 'once' ? 1 : 0;
	$iB::IN{'Post'}  = $txt->Convert_for_db( TEXT    => $iB::IN{'Post'},
											 SMILIES => $iB::IN{'PM'},
											 IB_CODE => $iB::IN{'PM'},
											 HTML    => 0,
											 );

	$db->update( TABLE  => 'mod_email',
				 KEY    => $edit,
				 WHERE  => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"  and ID == $edit!,
				 VALUES => {
							 TEXT        => $iB::IN{'Post'},
							 CHOICE      => $method,
							 WHENE        => $IB::IN{'ONCE'},
							 SENT        => 0,
							},
			   ) || die $db->{'error'};
	$output->pure_redirect( URL => "act=ModSet;CODE=del;f=$iB::IN{'f'}");
}

sub sender {
my $obj = shift;
my $data = { DB => "", ID => "", POST => "", MEMBER_NAME => "", TOPIC_TITLE => "", @_ };

	my $db = $data->{'DB'};
	my $forum = $data->{'ID'};
	my $post = $data->{'POST'};
	my $poster = $data->{'MEMBER_NAME'};
	my $title = $data->{'TOPIC_TITLE'};

	my $target  = $db->query( TABLE    => 'mod_email',
							  WHERE    => "FORUM_ID eq $forum",
							  SORT_KEY => 'MEMBER_NAME',
							  SORT_BY  => 'A-Z',
						   );

	if (scalar @{$target} > 0) {# do we have someone to send to
		foreach my $m (@{$target}) {# send to all target
			if ($m->{'CHOICE'} == 1) {# send to target that wants an email
				if ($m->{'WHENE'} == 0) {# wants a mail for every post

					my $mail_message = $m->{'TEXT'};
					$mail_message = $txt->Convert_for_email($mail_message);
					$mail_message =~ s!<#POST#>!$post!g;
					$mail_message =~ s!<#TITLE#>!$title!g;
					$mail_message =~ s!<#POSTER#>!$poster!g;
					$mail_message =~ s!<#ADDR#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$m->{'FORUM_ID'}!g;

					my $message = $txt->Convert_for_email($mail_message);

					$mail->Send( TO      => $m->{'EMAIL'},
								 FROM    => $m->{'EMAIL'},
								 SUBJECT => $ModCP::lang->{'mod_notif_mail'},
								 MESSAGE => $message,
								);
				}# wants a mail for every post CLOSE
				elsif ($m->{'WHENE'} == 1 and $m->{'SENT'} == 0) {# wants email once
					my $mail_message = $m->{'TEXT'};
					$mail_message = $txt->Convert_for_email($mail_message);
					$mail_message =~ s!<#POST#>!$post!g;
					$mail_message =~ s!<#TITLE#>!$title!g;
					$mail_message =~ s!<#POSTER#>!$poster!g;
					$mail_message =~ s!<#ADDR#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$m->{'FORUM_ID'}!g;

					my $message = $txt->Convert_for_email($mail_message);

					$mail->Send( TO      => $m->{'EMAIL'},
								 FROM    => $m->{'EMAIL'},
								 SUBJECT => $ModCP::lang->{'mod_notif_mail'},
								 MESSAGE => $message,
								);

					$db->update( TABLE  => 'mod_email',
								 KEY    => $m->{'ID'},
								 VALUES => {
											 SENT        => 1,
											},
							   ) || die $db->{'error'};# remember it is sent
				}
				else {# if wants an email and it was sent then skip
					next;
				}
		} # send to target that wants an email CLOSE
		else {# send to target that wants a PM
			if ($m->{'WHENE'} == 0){ # send to the ones that wants a pm for every posts
			my $mail_message = $m->{'TEXT'};
			$mail_message = $txt->Convert_for_email($mail_message);
			$mail_message =~ s!<#POST#>!$post!g;
			$mail_message =~ s!<#TITLE#>!$title!g;
			$mail_message =~ s!<#POSTER#>!$poster!g;
			$mail_message =~ s!<#ADDR#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$m->{'FORUM_ID'}!g;
			$mail_message  = $txt->Convert_for_db( TEXT    => $mail_message,
												   SMILIES => 1,
												   IB_CODE => 1,
												   HTML    => 0,
												);

			my $new_id = $db->insert( TABLE  => 'message_data',
									  ID     => $m->{'MEMBER_ID'},
									  VALUES => { DATE              => time,
												  READ_STATE        => 0,
												  TITLE             => $ModCP::lang->{'mod_notif_mail'},
												  MESSAGE           => $mail_message,
												  MESSAGE_ICON      => 10,
												  FROM_ID           => '001',
												  FROM_NAME         => $iB::INFO->{'BOARD_NAME'},
												  REPLY             => '',
												  REPLY_DATE        => '',
												  VIRTUAL_DIR       => 'in',
												  MEMBER_ID         => $m->{'MEMBER_ID'},
												  RECIPIENT_ID      => $m->{'MEMBER_ID'},
												  RECIPIENT_NAME    => $m->{'MEMBER_NAME'}
												}
									 );

			my $msg_stats = { };

			$msg_stats = $db->select( TABLE  => 'message_stats',
									  ID     => $m->{'MEMBER_ID'},
									  KEY    => $m->{'MEMBER_ID'},
									);

			if ($msg_stats->{'MEMBER_ID'}) {
				$msg_stats->{'TOTAL_MESSAGES'}++;
				$msg_stats->{'NEW_MESSAGES'}++;

				$db->update(  TABLE  => 'message_stats',
							  ID     => $m->{'MEMBER_ID'},
							  KEY    => $m->{'MEMBER_ID'},
							  VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'},
										  NEW_MESSAGES   => $msg_stats->{'NEW_MESSAGES'},
										  LAST_FROM_NAME => $iB::INFO->{'BOARD_NAME'},
										  LAST_FROM_ID   => '001',
										  LAST_SENT      => time,
										  LAST_MSG_ID    => $new_id,
										  LAST_MSG_TITLE => $ModCP::lang->{'mod_notif_mail'},
										  SHOW_POPUP     => 1,
										}
						   );

			} else {
				$db->insert(  TABLE  => 'message_stats',
							  ID     =>  $m->{'MEMBER_ID'},
							  VALUES => { MEMBER_ID          => $obj->{'MEMBER'}->{'MEMBER_ID'},
										  LAST_READ          => '',
										  NEW_MESSAGES       => 1,
										  LAST_FROM_NAME     => $iB::INFO->{'BOARD_NAME'},
										  LAST_FROM_ID       => '001',
										  LAST_MSG_ID        => $new_id,
										  LAST_MSG_TITLE     => $ModCP::lang->{'mod_notif_mail'},
										  LAST_SENT          => time,
										  TOTAL_MESSAGES     => 1,
										  VIRTUAL_DIR        => "in:Inbox|sent:Sent Items|",
										  SHOW_POPUP         => 1,
										 }
							);
			}

			} # send to the ones that wants a pm for every posts CLOSE
			elsif ($m->{'WHENE'} == 1 and $m->{'SENT'} == 0) { # send to the ones that wants a pm once

			my $mail_message = $m->{'TEXT'};
			$mail_message = $txt->Convert_for_email($mail_message);
			$mail_message =~ s!<#POST#>!$post!g;
			$mail_message =~ s!<#TITLE#>!$title!g;
			$mail_message =~ s!<#POSTER#>!$poster!g;
			$mail_message =~ s!<#ADDR#>!$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$m->{'FORUM_ID'}!g;
			$mail_message  = $txt->Convert_for_db( TEXT    => $mail_message,
												   SMILIES => 1,
												   IB_CODE => 1,
												   HTML    => 0,
												);


			my $new_id = $db->insert( TABLE  => 'message_data',
									  ID     => $m->{'MEMBER_ID'},
									  VALUES => { DATE              => time,
												  READ_STATE        => 0,
												  TITLE             => $ModCP::lang->{'mod_notif_mail'},
												  MESSAGE           => $mail_message,
												  MESSAGE_ICON      => 10,
												  FROM_ID           => '001',
												  FROM_NAME         => $iB::INFO->{'BOARD_NAME'},
												  REPLY             => '',
												  REPLY_DATE        => '',
												  VIRTUAL_DIR       => 'in',
												  MEMBER_ID         => $m->{'MEMBER_ID'},
												  RECIPIENT_ID      => $m->{'MEMBER_ID'},
												  RECIPIENT_NAME    => $m->{'MEMBER_NAME'}
												}
									 );

			my $msg_stats = { };

			$msg_stats = $db->select( TABLE  => 'message_stats',
									  ID     => $m->{'MEMBER_ID'},
									  KEY    => $m->{'MEMBER_ID'},
									);

			if ($msg_stats->{'MEMBER_ID'}) {
				$msg_stats->{'TOTAL_MESSAGES'}++;
				$msg_stats->{'NEW_MESSAGES'}++;

				$db->update(  TABLE  => 'message_stats',
							  ID     => $m->{'MEMBER_ID'},
							  KEY    => $m->{'MEMBER_ID'},
							  VALUES => { TOTAL_MESSAGES => $msg_stats->{'TOTAL_MESSAGES'},
										  NEW_MESSAGES   => $msg_stats->{'NEW_MESSAGES'},
										  LAST_FROM_NAME => $iB::INFO->{'BOARD_NAME'},
										  LAST_FROM_ID   => '001',
										  LAST_SENT      => time,
										  LAST_MSG_ID    => $new_id,
										  LAST_MSG_TITLE => $ModCP::lang->{'mod_notif_mail'},
										  SHOW_POPUP     => 1,
										}
						   );

			} else {
				$db->insert(  TABLE  => 'message_stats',
							  ID     =>  $m->{'MEMBER_ID'},
							  VALUES => { MEMBER_ID          => $m->{'MEMBER_ID'},
										  LAST_READ          => '',
										  NEW_MESSAGES       => 1,
										  LAST_FROM_NAME     => $iB::INFO->{'BOARD_NAME'},
										  LAST_FROM_ID       => '001',
										  LAST_MSG_ID        => $new_id,
										  LAST_MSG_TITLE     => $ModCP::lang->{'mod_notif_mail'},
										  LAST_SENT          => time,
										  TOTAL_MESSAGES     => 1,
										  VIRTUAL_DIR        => "in:Inbox|sent:Sent Items|",
										  SHOW_POPUP         => 1,
										 }
							);
			}
			$db->update( TABLE  => 'mod_email',
						 KEY    => $m->{'ID'},
						 VALUES => {
									 SENT        => 1,
									},
					   ) || die $db->{'error'};
			}# send to the ones that wants a pm once CLOSE
			else {# if wants a PM and it was sent then skip
				next;
			}
		}
	}# send to all target ret.
	}# if scalar
}# close sub


sub	Process {
	my ($obj, $db) = @_;

	require "$iB::SKIN->{'DIR'}" . '/ModCPView.pm';
	$obj->SetSession($db);
	my $CodeNo = $iB::IN{'CODE'};

	my %Mode = ( 'add'      => \&add,
				 'do_add'   => \&do_add,
				 'edit'     => \&edit,
				 'edit_e'   => \&edit_e,
				 'do_edit'  => \&do_edit,
				 'del'      => \&del,
				 'do_del'   => \&do_del,
				 'sender'     => \&sender,
			   );
	$Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : splash($obj, $db);

	unless ($obj->{bypass}) {
		$output->print_ikonboard( DB           => $db,
								  STD          => $std,
								  OUTPUT       => $obj->{html},
								  NAV          => [ qq|<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP'>$ModCP::lang->{'home'}</a>|,
								  					qq|<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet'>$ModCP::lang->{'welcome_prefs_hed'}</a>|,
								   ],
								  
								  
								  TITLE        => "iB::" . "$ModCP::lang->{'title'}"
								);
	}

}

sub	SetSession {
	my ($obj, $db) = @_;

	# As our Russian friends might say to non members trying
	# to gain access to our moderators CP: Pisky Ofsky.
	$std->Error( DB      => $db,
				 LEVEL   => 1,
				 MESSAGE =>'moderate_no_permission'
			   ) unless $iB::MEMBER->{'MEMBER_ID'};

	# Set the default moderator type to none
	$obj->{type} = 'n';

	# If we're superman...er supermod, then we get "all"
	if ($iB::MEMBER_GROUP->{'IS_SUPMOD'}) {
		$obj->{type} = 'all';
		return;
	}

	# Ok, lets see if this member is a moderator
	my @mods = $db->query( TABLE      => 'forum_moderators',
						   WHERE      => qq!MEMBER_ID eq "$iB::MEMBER->{'MEMBER_ID'}"!
						 );

	# Yes? cool, set the type and return
	if (scalar @mods > 0) {
		$obj->{type} = 'multiple';
		# Build our hash.
		$obj->{moderator} = {};
		for my $i (@mods) {
			$obj->{moderator}->{ $i->{'FORUM_ID'} } = { };
			for my $k (keys %{$i}) {
				next if $k eq 'FORUM_ID';
				$obj->{moderator}->{ $i->{'FORUM_ID'} }->{ $k } = $i->{ $k };
			}
		}
		return;
	}
	# Buh-bye our moderatory challenged friends
	$std->Error( DB      => $db,
				 LEVEL   => 1,
				 MESSAGE =>'moderate_no_permission'
			   ) if $obj->{type} eq 'n';


}


1;
