package Newest;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# Newest: This package will send you to the first unread post in the topic.
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
}

use Time::localtime;

my $std        = FUNC::STD->new();
my $output     = FUNC::Output->new();

sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    return $obj;
}


sub shownewest {
    my ($obj, $db) = @_;

    return unless ((defined $iB::IN{'t'}) and (defined $iB::IN{'f'}));
    my $First = 0;
    my $forum_id = $std->IsNumber($iB::IN{'f'}) || 0;
    my $topic_id = $std->IsNumber($iB::IN{'t'}) || 0;
    my $sort_by      = $iB::IN{'sort_by'} || $iB::INFO->{'TOPIC_SORT_ORDER'} || "Z-A";
    my $membid      = $iB::MEMBER->{'MEMBER_ID'};
    my $view1 = $db->query( TABLE  => 'topic_views',
                            ID     => $forum_id,
                            WHERE  => "TOPIC_ID == '$topic_id' and FORUM_ID eq '$forum_id' and MEMBER_ID eq '$membid'",
                        );
    $obj->prune_historic($db);
    my $Cnt = 0;
    my $target = '';
    my $last;
    unless ($iB::MEMBER->{'MEMBER_ID'}) {
        goto LAST;
    }
    if (scalar @{$view1} > 0){
        my $total_posts = $db->query( TABLE    => 'forum_posts',
                                        DBID     => 'f'.$forum_id,
                                        ID       => $topic_id,
                                        WHERE    => "TOPIC_ID == $topic_id and QUEUED != '1'",
                                        SORT_KEY => 'POST_DATE',
                                        SORT_BY  => $sort_by
                                        );

        foreach my $sets (@{$total_posts}) {
            $Cnt++;
            if ($Cnt > $iB::INFO->{'DISPLAY_MAX_POSTS'}) {
                $First = $First + $Cnt - 1;
                $Cnt = 1;
            }
            if (($target eq '') and ($sets->{'POST_DATE'} > $view1->[0]->{'VIEWED'})) {
                $target = $sets->{'POST_ID'}; # this is to find the newest post.
                last;
            }
            $last = $sets->{'POST_ID'};
        }
        if ($target eq '') {
            if ($view1->[0]->{'VIEWED'}) {
                $target = "#entry$last";
            } else {
            $target = "#top";
            }
        } else {

            $target = "#entry$target";
        }
    $output->pure_redirect( URL => "act=ST;f=$forum_id;t=$topic_id;st=$First;&$target");
} else {
    LAST:
    $output->pure_redirect( URL => "act=ST;f=$forum_id;t=$topic_id;&#top");
}
}

sub prune_historic {
        my ($obj, $db) = @_;
    my $file = $iB::INFO->{'DB_DIR'}.'Temp/prune_historic.cgi';
        my $mtime = (stat($file))[9];
        if (($mtime + 86400) < time){
        open CRONO, "+>".$iB::INFO->{'DB_DIR'}.'Temp/prune_historic.cgi' or die $!;
        print CRONO time;
        close CRONO;
        my $timer = time - ($iB::INFO->{'HISTORIC_LIMIT'} * 86400);
            my $forums = $db->query( TABLE     => 'forum_info',
                                 SORT_KEY  => 'FORUM_ID',
                                 SORT_BY   => 'A-Z',
                                 MATCH     => 'ALL'
                                 ) || die $db->{'error'};
        foreach my $f (@{$forums}) {
            my $hist_prune = $db->query(    TABLE    => 'topic_views',
                                ID       =>  $f->{'FORUM_ID'},
                                SORT_KEY => 'VIEWED',
                                ORDER_BY => 'A-Z',
                                WHERE    => "VIEWED < '$timer'",
                                );

            foreach (@{$hist_prune}){
                $db->delete(  TABLE   => 'topic_views',
                          ID      => $f->{'FORUM_ID'},
                          KEY     => $_->{'ID'},
                        ) || die $db->{error};
            }
        }
    }
}

1;

__END__
