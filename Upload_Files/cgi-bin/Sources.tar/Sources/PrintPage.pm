package PrintPage;
use strict;
############################################################################
#| Ikonboard 3.1.5A by Implux Designs
#|
#| No parts of this script can be used outside Ikonboard
#| without prior consent.
#| You must keep this header intact and all copyright links visible.
#| For support, visit http://impluxdesigns.com
#|
#| (c)2018 Implux Designs.
#| Web: <http://www.impluxdesigns.com>
#| #| Please read the license included in this release for more information.
#| 
################################################################
#
# PrintPage: Print page functions
#
#################################################################################

BEGIN {
    require 'Lib/FUNC.pm';
    require 'iTextparser.pm';
}

my $output = FUNC::Output->new();
my $std    = FUNC::STD->new();
my $mem    = FUNC::Member->new();
my $txt          = iTextparser->new();
$Print::lang = $std->LoadLanguage('PrintpageWords');
#+------------------------------------------------------------------------------------------------------

sub new {
  my $pkg = shift;
  my $obj = {};
  bless $obj, $pkg;
  return $obj;
}


#+------------------------------------------------------------------------------------------------------


sub splash {
    my ($obj, $db) = @_;

    $obj->{'.topic_id'} = $std->IsNumber($iB::IN{'t'}) || 0;
    $obj->{'.forum_id'} = $std->IsNumber($iB::IN{'f'}) || 0;

    require $iB::SKIN->{'DIR'} . '/PrintPageView.pm' or die $!;



    $obj->{'FORUM'} = $db->select( TABLE   => 'forum_info',
                                   KEY     => $obj->{'.forum_id'},
                                 ) || die $db->{'error'};


    $obj->{'TOPIC'} = $db->select( TABLE  => 'forum_topics',
                                   ID     => $obj->{'.forum_id'},
                                   KEY    => $obj->{'.topic_id'}
                                 ) || die $db->{'error'};



    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'missing_files'
               ) unless ((defined $iB::IN{'t'}) and (defined $iB::IN{'f'}));

    $std->Error( DB      => $db,
             LEVEL   => 1,
             MESSAGE => 'missing_files'
               ) unless ($iB::IN{'f'} eq $obj->{'TOPIC'}->{'FORUM_ID'});

    my $check = $obj->Check_access($db);
    return if $check == 1;

    my $print = PrintPageView::pp_header($obj->{'FORUM'}->{'FORUM_NAME'},
                                         $obj->{'TOPIC'}->{'TOPIC_TITLE'},
                                         $obj->{'TOPIC'}->{'TOPIC_STARTER_N'}
                                        );


    my $total_posts = $db->query( TABLE    => 'forum_posts',
                                  DBID     => 'f'.$obj->{'.forum_id'},
                                  ID       => $obj->{'.topic_id'},
                                  WHERE    => "QUEUED != 1 and FORUM_ID == '$obj->{'.forum_id'}' and TOPIC_ID == '$obj->{'.topic_id'}'",
                                  SORT_KEY => 'POST_DATE',
                                  SORT_BY  => 'A-Z'
                                 ) or $print = $db->{'error'};



    for my $Row (@{$total_posts}) {

        $obj->{'POSTER'} = $Row->{'AUTHOR_TYPE'} == 1 ? $mem->LoadMember( DB => $db, KEY => $Row->{'AUTHOR'}, METHOD => 'by id')
                                                      : $mem->SetUpGuest($Row->{'AUTHOR'});

        $Row->{'POST_DATE'} = $std->get_date( TIME => $Row->{'POST_DATE'}, METHOD => 'LONG');

        $Row->{'POST'} =~ s!(<a href=["'])(http|https|ftp|news)://(\S+?)["'].+?>(.+?)</a>!&lt; $4 &gt;!isg;

#       $Row->{'POST'} =~ s!<\!--c1-->(.+?)<\!--ec1-->!<br><br>---------------------CODE SAMPLE-------------------<br><i>!isg;
#       $Row->{'POST'} =~ s!<\!--c2-->(.+?)<\!--ec2-->!<br></i>---------------------CODE SAMPLE-------------------<br><br>!isg;
#       $Row->{'POST'} =~ s!<\!--QuoteBegin-->(.+?)<\!--QuoteEBegin-->!<br><br>---------------------QUOTE-------------------<br><i>!isg;
#       $Row->{'POST'} =~ s!<\!--QuoteBegin(.+?)-->(.+?)<\!--QuoteEBegin-->!<br><br>---------------------QUOTE BEGIN-------------------<br><i>!isg;
#       $Row->{'POST'} =~ s!<\!--QuoteEnd-->(.+?)<\!--QuoteEEnd-->!<br></i>---------------------QUOTE-------------------<br><br>!isg;

        $print .= PrintPageView::pp_postentry($obj->{'POSTER'}, $Row);

    }

    $print .= PrintPageView::pp_end();
    $print .= qq~
            


            <center>Powered by <a href="http://www.ikonboard.com" class="copyright" target='_blank'>Ikonboard</a> $iB::VERSION &copy; 2006 <a href='http://www.ikonboard.com' target='_blank'>Ikonboard</a></center>
                ~;

    print $iB::CGI->header();
    print $print;

    exit(0);
}

sub pm {
    my ($obj, $db) = @_;


    require $iB::SKIN->{'DIR'} . '/PrintPageView.pm' or die $!;



    my $Row = $db->select( TABLE   => 'message_data',
                           ID      => $iB::MEMBER->{'MEMBER_ID'},
                           KEY     => $iB::IN{'m'}
                         );

    $Row->{'MESSAGE'} = $txt->Convert_for_db( TEXT    => $Row->{'MESSAGE'},
                                              SMILIES => 1,
                                              IB_CODE => $iB::INFO->{'MSG_ALLOW_CODE'},
                                              HTML    => $iB::INFO->{'MSG_ALLOW_HTML'},
                                              USER    => $Row->{'FROM_NAME'},
                                        );
    $std->Error( DB      => $db,
                 LEVEL   => 1,
                 MESSAGE =>'missing_files'
               ) unless ((defined $iB::IN{'m'}) and (defined $iB::MEMBER->{'MEMBER_ID'}));

    $std->Error( DB => $db, LEVEL=>'1',MESSAGE=>'no_such_msg')    unless $Row->{'MEMBER_ID'} == $iB::MEMBER->{'MEMBER_ID'};

    my $date = $std->get_date( TIME => $Row->{'DATE'}, METHOD => 'LONG');

    my $print = PrintPageView::pp_header_m( $Row->{'FROM_NAME'}, $date, $Row->{'TITLE'} );

    $Row->{'MESSAGE'} =~ s!(<a href=["'])(http|https|ftp|news)://(\S+?)["'].+?>(.+?)</a>!&lt; $4 &gt;!isg;

    $Row->{'MESSAGE'} =~ s!<\!--c1-->(.+?)<\!--ec1-->!<br><br>---------------------CODE SAMPLE-------------------<br><i>!isg;
    $Row->{'MESSAGE'} =~ s!<\!--c2-->(.+?)<\!--ec2-->!<br></i>---------------------CODE SAMPLE-------------------<br><br>!isg;
    $Row->{'MESSAGE'} =~ s!<\!--QuoteBegin-->(.+?)<\!--QuoteEBegin-->!<br><br>---------------------QUOTE-------------------<br><i>!isg;
    $Row->{'MESSAGE'} =~ s!<\!--QuoteEnd-->(.+?)<\!--QuoteEEnd-->!<br></i>---------------------QUOTE-------------------<br><br>!isg;

    $print .= PrintPageView::pp_postentry_m($Row);


    $print .= PrintPageView::pp_end();

    $print .= qq~
    
            <center>Powered by <a href="http://www.ikonboard.com" class="copyright" target='_blank'>Ikonboard</a> $iB::VERSION &copy; 2006 <a href='http://www.ikonboard.com' target='_blank'>Ikonboard</a></center>
                ~;

    print $iB::CGI->header();
    print $print;

    exit(0);
}

#+------------------------------------------------------------------------------------------------------
#+------------------------------------------------------------------------------------------------------

sub Check_access ($) {
    my ($obj, $db) = @_;

    if ($obj->{'FORUM'}->{'FORUM_PROTECT'}) {
        if (exists $iB::COOKIES->{ $iB::INFO->{'COOKIE_ID'}.'iBForum' . $obj->{'FORUM'}->{'FORUM_ID'} }) {
            return if $iB::COOKIES->{ $iB::INFO->{'COOKIE_ID'}.'iBForum' . $obj->{'FORUM'}->{'FORUM_ID'} } eq $obj->{'FORUM'}->{'FORUM_PROTECT'};
        }
        $output->redirect_screen( TEXT => "$Topic::lang->{'please_log_in'}", URL => "?act=SF;f=$iB::IN{'f'}");
        return 1;
    }

    if ($obj->{'FORUM'}->{'FORUM_VIEW_THREADS'} ne '*') {
        unless (grep { $_ == $iB::MEMBER->{'MEMBER_GROUP'} } (split /,/,$obj->{'FORUM'}->{'FORUM_VIEW_THREADS'}) ) {
            $std->Error(     DB      => $db,
                             LEVEL   => '2',
                             MESSAGE =>'forum_no_access'
                       );
        }
    }
    return 0;
}

sub Process {
    my ($obj, $db) = @_;

    my $CodeNo = $iB::IN{'CODE'};

    my %Mode = ( 'pm'      => \&pm,
               );

    $Mode{$CodeNo} ? $Mode{$CodeNo}->($obj, $db) : splash($obj, $db);

}



1;
