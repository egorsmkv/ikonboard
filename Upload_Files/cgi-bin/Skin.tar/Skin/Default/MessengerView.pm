package MessengerView;

use strict;
my $base_url = qq[$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=];
my $ibc_flash = $iB::INFO->{'ALLOW_FLASH'} eq 'on'
                           ? qq[<a href='javascript:ibvoid()' onClick='IBCflash("$iB::INFO->{'MAX_W_FLASH'}","$iB::INFO->{'MAX_H_FLASH'}")'><img src='$iB::INFO->{'IMAGES_URL'}/images/ibc_flash.gif' border='0' height='20' width='76'></a> ]
                           : '';




sub address_edit {
                                                                my ($data) = @_;
return qq~

                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>$Messenger::lang->{'address_title'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $Messenger::lang->{'address_text'}</font></td>
                 </tr>
                  <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$Messenger::lang->{'member_edit'}</b></font></td>
                  </tr>
                  <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' valign='middle' colspan='2'>
                    <table cellspacing='1' cellpadding='2' width='100%' border='0'>
                    <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
                    <input type='hidden' name='act' value='Msg'>
                    <input type='hidden' name='CODE' value='12'>
                    <input type='hidden' name='s' value='$iB::SESSION'>
                    <input type='hidden' name='MID' value='$data->{'MEMBER'}->{'IN_MEMBER_ID'}'>
                    <tr>
                    <td valign='middle' align='left'><b>$data->{'MEMBER'}->{'IN_MEMBER_NAME'}</b></td>
                    <td valign='middle' align='left'>$Messenger::lang->{'enter_desc'}<br><input type='text' name='mem_desc' size='30' maxlength='60' value='$data->{'MEMBER'}->{'IN_MEMBER_DESC'}' class='forminput'></td>
                    <td valign='middle' align='left'>$Messenger::lang->{'allow_msg'}<br>$data->{'SELECT'}</td>
                    </tr>
                    <tr>
                    <td colspan='3' align='center'><input type="submit" value="$Messenger::lang->{'submit_address_edit'}" class='forminput'></td>
                    </tr>
                    </form>
                    </table>
                    </td>
                    </tr>
~;
}

sub CP_end {

return qq~
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
    </table></td></tr></table>
~;
}

sub prefs_row {
                                                                my $data = shift;
return qq~
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><input type='text' name='$data->{'ID'}' value='$data->{'REAL'}' class='forminput'>$data->{'EXTRA'}</td>
                 </tr>
~;
}

sub prefs_header {

return qq~

                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>&raquo; $Messenger::lang->{'prefs_title'}</b></td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp;</td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $Messenger::lang->{'prefs_text'}</td>
                 </tr>
   <tr>
        <td align='left' id='category' colspan='2'>$Messenger::lang->{'prefs_current'}</td>
   </tr>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>$Messenger::lang->{'prefs_text_a'}</td>
                 </tr>
                    <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
                    <input type='hidden' name='act' value='Msg'>
                    <input type='hidden' name='CODE' value='08'>
                    <input type='hidden' name='s' value='$iB::SESSION'>
~;
}

sub end_inbox {
                                                                my ($vdi_html, $sort) = @_;
return qq~
   <tr>
        <td align='center' id='category' colspan='5'> </td>
   </tr>
                  </table></td></tr>
                  <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' valign='middle' colspan='2'>
                  <table cellspacing='0' cellpadding='4' width='100%'>
                  <tr>
                  <td valign='middle' align='left'>
                    $iB::SKIN->{'M_READ'} $Messenger::lang->{'icon_read'}
                     $iB::SKIN->{'M_UNREAD'} $Messenger::lang->{'icon_unread'}
                  </td>
                  <td align='right' nowrap>
                     <input type='submit' name='move' value='$Messenger::lang->{'move_button'}' class='forminput'> $vdi_html $Messenger::lang->{'move_or_delete'} <input type='submit' name='delete' value='$Messenger::lang->{'delete_button'}' class='forminput'> $Messenger::lang->{'selected_msg'}
                  </td>
                  </tr>
                  </table>
                  </td>
                  </tr>
                  </form>
~;
}

sub Send_form {
                                                                my $data = shift;
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='REPLIER' onSubmit='return ValidateForm()'>
     <input type='hidden' name='act' value='MSS'>
     <input type='hidden' name='CODE' value='04'>
     <input type='hidden' name='MODE' value='01'>
     <input type='hidden' name='s' value='$iB::SESSION'>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlelarge'>&raquo; $Messenger::lang->{'send_title'}</font></td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_ONE'} colspan='2'>$iB::MEMBER->{'MEMBER_NAME'}</b> $Messenger::lang->{'send_header'}</td>
                </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'><b>$Messenger::lang->{'to_whom'}</b></td>
                 </tr>
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='left' width='40%'>$Messenger::lang->{'address_list'}</td>
                <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='left' width='60%' valign='top'>$data->{'CONTACTS'}</td>
                </tr>
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_ONE'} align='left' width='40%'>$Messenger::lang->{'enter_name'}</td>
                <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='left' width='60%' valign='top'><textarea cols='30' rows='3' wrap='soft' class='textinput'' name='entered_name' tabindex='1'>$data->{'N_ENTER'}</textarea></td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>&raquo; $Messenger::lang->{'enter_message'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_ONE'} align='left'  width='40%'>$Messenger::lang->{'msg_title'}</td>
                <td bgcolor=$iB::SKIN->{'MISCBACK_ONE'} align='left' width='60%' valign='top'><input type='text' name='msg_title' size='40' maxlength='40' value='$data->{'O_TITLE'}' class='forminput' tabindex='2'><br><b>$Messenger::lang->{'auto_sent_add'}</b> <input type='checkbox' name='add_sent' value='yes' unchecked tabindex='3'><br><b>$Messenger::lang->{'read_rec_notify'}</b> <input type='checkbox' name='add_tracking' value='1' tabindex='3'></td>
                </tr>
~;
}

sub prefs_footer {

return qq~
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' value='$Messenger::lang->{'prefs_submit'}' class='forminput'></td>
                 </tr>
~;
}

sub sent_row {
                                                                my ($data) = @_;
return qq~

                 <tr>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align='center' valign='middle'>$data->{'MSG'}->{'ICON'}</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align='left'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSV;CODE=03;VID=$data->{'MEMBER'}->{'CURRENT_ID'};MSID=$data->{'MSG'}->{'MESSAGE_ID'}'><strong>$data->{'MSG'}->{'TITLE'}</strong></a></td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align='left'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'MSG'}->{'RECIPIENT_ID'}'>$data->{'MSG'}->{'RECIPIENT_NAME'}</a> [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=02;act=Msg;MID=$data->{'MSG'}->{'RECIPIENT_ID'}'>$Messenger::lang->{'add_to_book'}</a> ]</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" align='left'>$data->{'MSG'}->{'DATE'}</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" align='left'><input type='checkbox' name='msgid-$data->{'MSG'}->{'MESSAGE_ID'}' value='yes' class='forminput'></td>
                 </tr>
~;
}

sub Address_none {

return qq~
      <tr>
      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='center'><b>$Messenger::lang->{'address_none'}</b></td>
      </tr>
~;
}

sub Menu_bar_admin {
                                                                    my $Nav_color = shift;
return qq~
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='6'>&raquo; Your Menu</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='6'> </td>
   </tr>
        <tr>
            <td bgcolor='$Nav_color->{'splash'}'    valign='middle' align='center' id='tabs' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00'><strong>$Messenger::lang->{'splash'}</strong></a></td>
            <td bgcolor='$Nav_color->{'in_box'}'    valign='middle' align='center' id='tabs' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=01'><strong>$Messenger::lang->{'in_box'}</strong></a></td>
            <td bgcolor='$Nav_color->{'contact'}'   valign='middle' align='center' id='tabs' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=02'><strong>$Messenger::lang->{'contact'}</strong></a></td>
            <td bgcolor='$Nav_color->{'prefs'}'     valign='middle' align='center' id='tabs' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=07'><strong>$Messenger::lang->{'prefs'}</strong></a></td>
            <td bgcolor='$Nav_color->{'send'}'      valign='middle' align='center' id='tabs' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSS;CODE=04'><strong>$Messenger::lang->{'send'}</strong></a></td>
            <td bgcolor='$Nav_color->{'send2'}'      valign='middle' align='center' id='tabs' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSM;CODE=13'><strong>$Messenger::lang->{'send_mass'}</strong></a></td>
    </tr>
   <tr>
        <td align='center' id='category' colspan='6'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='6' id='titlemedium'> </td>
     </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
<br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
<tr>
~;
}

sub render_address_row {
                                                                my ($entry) = @_;
return qq~

                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' valign='middle'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$entry->{'IN_MEMBER_ID'}'><b>$entry->{'IN_MEMBER_NAME'}</b></a>    [ $entry->{'IN_MEMBER_DESC'} ]</td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' valign='middle'>
                        [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=11;MID=$entry->{'IN_MEMBER_ID'}' class='misc'>$Messenger::lang->{'edit'}</a> ] :: [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=10;MID=$entry->{'IN_MEMBER_ID'}'>$Messenger::lang->{'delete'}</a> ]
                           ( $entry->{'TEXT'} )
                    </font>
                   </td>
                 </tr>
~;
}

sub address_add {
                                                                my ($mem_to_add) = @_;
return qq~
                  <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'><b>$Messenger::lang->{'member_add'}</b></font></td>
                  </tr>
                  <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' valign='middle' colspan='2'>
                    <table cellspacing='1' cellpadding='2' width='100%' border='0'>
                    <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
                    <input type='hidden' name='act' value='Msg'>
                    <input type='hidden' name='CODE' value='09'>
                    <input type='hidden' name='s' value='$iB::SESSION'>
                    <tr>
                    <td valign='middle' align='left'>$Messenger::lang->{'enter_a_name'}<br><input type='text' name='mem_name' size='20' maxlength='40' value='$mem_to_add' class='forminput'></td>
                    <td valign='middle' align='left'>$Messenger::lang->{'enter_desc'}<br><input type='text' name='mem_desc' size='30' maxlength='60' value='' class='forminput'></td>
                    <td valign='middle' align='left'>$Messenger::lang->{'allow_msg'}<br><select name='allow_msg' class='forminput'><option value='yes' selected>$Messenger::lang->{'yes'}<option value='no'>$Messenger::lang->{'no'}</select></td>
                    </tr>
                    <tr>
                    <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='3' align='center'><input type="submit" value="$Messenger::lang->{'submit_address'}" class='forminput'></td>
                    </tr>
                    </form>
                    </table>
                    </td>
                    </tr>
~;
}

sub inbox_table_header {
                    my $Data = shift;
return qq~
<tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>&raquo; $Messenger::lang->{'welcome'} $iB::MEMBER->{'MEMBER_NAME'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                 <!-- inbox folder -->
                     <script language='JavaScript'>
                     <!--
                     function CheckAll(cb) {
                         var fmobj = document.mutliact;
                         for (var i=0;i<fmobj.elements.length;i++) {
                             var e = fmobj.elements[i];
                             if ((e.name != 'allbox') && (e.type=='checkbox') && (!e.disabled)) {
                                 e.checked = fmobj.allbox.checked;
                             }
                         }
                     }
                     function CheckCheckAll(cb) {
                             var fmobj = document.mutliact;
                         var TotalBoxes = 0;
                         var TotalOn = 0;
                         for (var i=0;i<fmobj.elements.length;i++) {
                             var e = fmobj.elements[i];
                             if ((e.name != 'allbox') && (e.type=='checkbox')) {
                                 TotalBoxes++;
                                 if (e.checked) {
                                     TotalOn++;
                                 }
                             }
                         }
                         if (TotalBoxes==TotalOn) {fmobj.allbox.checked=true;}
                         else {fmobj.allbox.checked=false;}
                     }
                     //-->
                     </script>
                 <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=06;act=Msg" name='mutliact' method="post">
                 <input type='hidden' name='act' value='Msg'>
                 <input type='hidden' name='CODE' value='06'>
                 <input type='hidden' name='s'    value='$iB::SESSION'>
                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='top' colspan='2'>
                 <table bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' cellpadding='2' cellspacing='1' align='center' width='100%'>
                 <tr>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='5%'><b>$Messenger::lang->{'message_read_state'}</b></td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='40%'><b>$Messenger::lang->{'message_title'}</b></td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='30%'><b>$Messenger::lang->{'message_from'}</b></td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='20%'><b>$Messenger::lang->{'message_date'}</b></td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='5%'><input name="allbox" type="checkbox" value="Check All" onClick="CheckAll();"></td>
                 </tr>
   <tr>
        <td align='left' id='category' colspan='5'> $Data->{'SHOW_PAGES'}</</td>
   </tr>
~;
}

sub Render_msg {
                            my $data = shift;
return qq~

            <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' valign='middle' id='titlelarge'><b>$Messenger::lang->{'message_title'}: $data->{'MSG'}->{'TITLE'}</td>
            </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp;</td>
   </tr>
            <tr>
    <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' colspan='2'>
<table width='100%' cellpadding='4' cellspacing='1' bgcolor='$iB::SKIN->{'POST_COL_ONE'}'>
                <tr>
            <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' align='center' valign='top'  width='175'  nowrap  rowspan='2'>
<span id='normalname'>$data->{'MEMBER'}->{'MEMBER_NAME'}<br />
$data->{'MEMBER'}->{'ONLINE'}</span><br>
<span id="membertitle">$data->{'MEMBER'}->{'MEMBER_TITLE'}</span><br>
$data->{'MEMBER'}->{'MEMBER_AVATAR'}<br>
$data->{'MEMBER'}->{'MEMBER_PIPS_IMG'}<br>
$data->{'POSTER'}->{'WARN_GFX'}
<span id='postdetails'><br>
$data->{'MEMBER'}->{'MEMBER_GROUP'}<br>
$data->{'MEMBER'}->{'MEMBER_POSTS'}<br>
$data->{'MEMBER'}->{'MEMBER_JOINED'}</span>
<br><br>

</td>
                    <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' valign='top' width='100%' height='100%'>
                      <table width='100%' border='0'>
                        <tr><td valign='middle' align='left'><img src="$data->{'MSG'}->{'MESSAGE_ICON'}" border='0' width='19' height='19' align='ABSCENTER'></td><td valign='middle' align='left' width='100%'><font class='postdetails'><b>$Messenger::lang->{posted}:</b> $data->{'MSG'}->{'DATE'}</font></td>
                          <td align='right' valign='bottom' nowrap>$data->{'NEXT'}
            <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Print;CODE=pm;m=$data->{'MSG'}->{'MESSAGE_ID'}">$iB::SKIN->{'M_PRINT'}</a>
            <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=04;act=MSS;MSID=$data->{'MSG'}->{'MESSAGE_ID'}'>$iB::SKIN->{'M_FORWARD'}</a>
            <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=04;act=MSS;MID=$data->{'MEMBER'}->{'MEMBER_ID'};MSID=$data->{'MSG'}->{'MESSAGE_ID'}'>$iB::SKIN->{'M_REPLY'}</a>
            <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=02;act=Msg;MID=$data->{'MEMBER'}->{'MEMBER_ID'}'>$iB::SKIN->{'M_ADDMEM'}</a>
            <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=05;act=Msg;MSID=$data->{'MSG'}->{'MESSAGE_ID'};VID=$data->{'MEMBER'}->{'VID'}'>$iB::SKIN->{'M_DELETE'}</a></td>
                        </tr>
                       </table>
                        <hr size='1' style='border: 1 dotted $iB::SKIN->{'TABLE_BORDER_COL'}' width='100%'>
                        <span id='postcolor'>
                         $data->{'MSG'}->{'MESSAGE'}
                         $data->{'MEMBER'}->{'SIGNATURE'}
                        </span>
                  </td>
                </tr>
                <tr>
                <td class='bottom' bgcolor='$iB::SKIN->{'POST_COL_ONE'}' class='buttontext'><hr size='1' style='border: 1 dotted $iB::SKIN->{'TABLE_BORDER_COL'}' width='100%'>
                $data->{'MEMBER'}->{'PROFILE_ICON'}&nbsp;$data->{'MEMBER'}->{'CONTACT_ICON'}&nbsp;$data->{'MEMBER'}->{'WEBSITE_ICON'}</td>
                </tr>
                </table>
            </td>
        </tr>
         <tr>
       <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' colspan='2'>$data->{'NEXT'}
       <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Print;CODE=pm;m=$data->{'MSG'}->{'MESSAGE_ID'}">$iB::SKIN->{'M_PRINT'}</a>
       <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=04;act=MSS;MSID=$data->{'MSG'}->{'MESSAGE_ID'}'>$iB::SKIN->{'M_FORWARD'}</a>
       <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=04;act=MSS;MID=$data->{'MEMBER'}->{'MEMBER_ID'};MSID=$data->{'MSG'}->{'MESSAGE_ID'}'>$iB::SKIN->{'M_REPLY'}</a>
       <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=02;act=Msg;MID=$data->{'MEMBER'}->{'MEMBER_ID'}'>$iB::SKIN->{'M_ADDMEM'}</a>
       <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=05;act=Msg;MSID=$data->{'MSG'}->{'MESSAGE_ID'};VID=$data->{'MEMBER'}->{'VID'}'>$iB::SKIN->{'M_DELETE'}</a>
       </td>
       </tr>
<tr>
        <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='right'>
                     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=01;act=Msg" name='jump' method="post">
                     <input type='hidden' name='act' value='Msg'>
                     <input type='hidden' name='CODE' value='01'>
                     <input type='hidden' name='s'    value='$iB::SESSION'>
                     <font class='misc'><b>$Messenger::lang->{'goto_folder'}</b>  $data->{'JUMP'}
                     <input type='submit' name='submit' value='$Messenger::lang->{'goto_submit'}' class='forminput'>
                     </font></form>
            </td>
        </tr>
~;
}

sub sent_screen {
                                                                my ($member,$to_member, $msg) = @_;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>&raquo; $Messenger::lang->{'welcome'} $iB::MEMBER->{'MEMBER_NAME'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='category'>$Messenger::lang->{'sent_title'}</td>
                 </tr>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><img src='$iB::INFO->{'IMAGES_URL'}/images/msg_sent.gif' border='0' height='32' width='32'></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle'><b>$Messenger::lang->{'sent_text'}</b><br>[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00' class='misc'>$Messenger::lang->{'sent_url'}</a> ]</td>
                 </tr>
~;
}

sub send_form_footer {

return qq~
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$Messenger::lang->{'submit_send'}" tabindex='8' class='forminput' name='submit'>
                <input type="submit" name="preview" value="$Messenger::lang->{'button_preview'}" tabindex='9' class='forminput'>
                <input type="submit" name="save" value="$Messenger::lang->{'button_save'}" tabindex='10' class='forminput'>
                </td>
                </tr>
                </form>
~;
}

sub No_msg_inbox {

return qq~
      <tr>
      <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='5' align='center'><b>$Messenger::lang->{'inbox_no_msg'}</b></td>
      </tr>
~;
}

sub Address_table_header {

return qq~
                 <tr>
                 <td valign='top' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' >
                 <table cellpadding='4' cellspacing='0' align='center' width='100%'>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='60%'><b>$Messenger::lang->{'member_name'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='40%'><b>$Messenger::lang->{'enter_block'}</b></td>
                 </tr>
~;
}

sub end_address_table {

return qq~
</table></td></tr>
~;
}

sub preview {
                                                                            my $data = shift;
return qq~
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='0' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' valign='top' align='left'><b>&middot;&nbsp;$Messenger::lang->{'message_preview'}</b><br /><br /><span id='postcolor'>$data</span></td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
    <br>
~;
}

sub Menu_bar {
                                                                    my $Nav_color = shift;
return qq~
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='6'>&raquo; Your Menu</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='6'> </td>
   </tr>
        <tr>
            <td bgcolor='$Nav_color->{'splash'}'    valign='middle' align='center' id='tabs' width='20%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=00'><strong>$Messenger::lang->{'splash'}</a></strong></td>
            <td bgcolor='$Nav_color->{'in_box'}'    valign='middle' align='center' id='tabs' width='20%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=01'><strong>$Messenger::lang->{'in_box'}</strong></a></td>
            <td bgcolor='$Nav_color->{'contact'}'   valign='middle' align='center' id='tabs' width='20%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=02'><strong>$Messenger::lang->{'contact'}</strong></a></td>
            <td bgcolor='$Nav_color->{'prefs'}'     valign='middle' align='center' id='tabs' width='20%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=07'><strong>$Messenger::lang->{'prefs'}</strong></a></td>
            <td bgcolor='$Nav_color->{'send'}'      valign='middle' align='center' id='tabs' width='20%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSS;CODE=04'><strong>$Messenger::lang->{'send'}</strong></a></td>
    </tr>
   <tr>
        <td align='center' id='category' colspan='6'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='6' id='titlemedium'> </td>
     </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
<br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
<tr>
~;
}

sub sent_table_header {
                    my $Data = shift;
return qq~
<tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
                 <!-- Sent folder -->
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>&raquo; Your sent messages</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
<script language='JavaScript'>
<!--
function CheckAll(cb) {
var fmobj = document.mutliact;
for (var i=0;i<fmobj.elements.length;i++) {
var e = fmobj.elements[i];
if ((e.name != 'allbox') && (e.type=='checkbox') && (!e.disabled)) {
e.checked = fmobj.allbox.checked;
}
}
}
function CheckCheckAll(cb) {
var fmobj = document.mutliact;
var TotalBoxes = 0;
var TotalOn = 0;
for (var i=0;i<fmobj.elements.length;i++) {
var e = fmobj.elements[i];
if ((e.name != 'allbox') && (e.type=='checkbox')) {
TotalBoxes++;
if (e.checked) {
TotalOn++;
}
}
}
if (TotalBoxes==TotalOn) {fmobj.allbox.checked=true;}
else {fmobj.allbox.checked=false;}
}
//-->
</script>
                 <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=06;act=Msg" name='mutliact' method="post">
                 <input type='hidden' name='act' value='Msg'>
                 <input type='hidden' name='CODE' value='06'>
                 <input type='hidden' name='s'    value='$iB::SESSION'>
                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='top' colspan='2' >
                 <table bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' cellpadding='2' cellspacing='1' align='center' width='100%'>
                 <tr>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='5%'><b>$Messenger::lang->{'message_read_state'}</b></td>
                   <td id='titlemedium'  bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='40%'><b>$Messenger::lang->{'message_title'}</b></td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='30%'><b>$Messenger::lang->{'message_to'}</b></td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='20%'><b>$Messenger::lang->{'message_date'}</b></td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='5%'><input name="allbox" type="checkbox" value="Check All" onClick="CheckAll();"></td>
                 </tr>
   <tr>
        <td align='left' id='category' colspan='5'> $Data->{'SHOW_PAGES'}</td>
   </tr>
~;
}

sub Address_header {

return qq~

                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>&raquo; $Messenger::lang->{'address_title'}</b></td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $Messenger::lang->{'address_text'}</td>
                 </tr>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'><b>$Messenger::lang->{'address_current'}</b></td>
                 </tr>
~;
}

sub splash {
                                                                my ($member,$msg) = @_;
return qq~
<tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>&raquo; $Messenger::lang->{'welcome'} $iB::MEMBER->{'MEMBER_NAME'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $Messenger::lang->{'welcome_txt'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'><b>&raquo; $Messenger::lang->{'new_message'}</b></td>
                 </tr>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='center' width='10%'>$msg->{'ICON'}</td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle' width='90%'><b>$msg->{'TEXT'}</b>   [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Msg;CODE=01'>$Messenger::lang->{'inbox_url'}</a> ]$msg->{'LAST_TEXT'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'><b>&raquo; $Messenger::lang->{'quick_help'}</b></font></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
                   <b>$Messenger::lang->{'in_box'}:</b> $Messenger::lang->{'in_box_help'}
                   <br><br><b>$Messenger::lang->{'contact'}:</b> $Messenger::lang->{'contact_help'}
                   <br><br><b>$Messenger::lang->{'prefs'}:</b> $Messenger::lang->{'prefs_help'}
                   <br><br><b>$Messenger::lang->{'send'}:</b> $Messenger::lang->{'send_help'}
                   </td>
                 </tr>
~;
}

sub Send_form_mass {
                                                                my $data = shift;
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='REPLIER' onSubmit='return ValidateForm()'>
     <input type='hidden' name='act' value='MSM'>
     <input type='hidden' name='CODE' value='13'>
     <input type='hidden' name='MODE' value='01'>
     <input type='hidden' name='s' value='$iB::SESSION'>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlelarge'>&raquo; $Messenger::lang->{'send_title_mass'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'>$Messenger::lang->{'to_whom_mass'}</td>
                </tr>
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='left' width='40%'>$Messenger::lang->{'address_group'}</td>
                <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='left' width='60%' valign='top' tabindex='1'>$data->{'CONTACTS'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$Messenger::lang->{'enter_message'}</b></td>
                </tr>
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_ONE'} align='left'  width='40%'>$Messenger::lang->{'msg_title'}</td>
                <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='left' width='60%' valign='top' ><input type='text' name='msg_title' size='40' maxlength='40' value='$data->{'O_TITLE'}' class='forminput' tabindex='2'><br><b>$Messenger::lang->{'read_rec_notify'}</b> <input type='checkbox' name='add_tracking' value='1' tabindex='3'></td>
                </tr>
~;
}

sub inbox_header {
                                                                my ($member, $jump_html) = @_;
return qq~

                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>&raquo; $Messenger::lang->{'dir_title'} $member->{'CURRENT_DIR'}</b></td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>$Messenger::lang->{'dir_header'}<br>$Messenger::lang->{c_msg_total} $Messenger::lang->{c_msg_info}</td>
                 </tr>
                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' valign='middle'>
                     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=01;act=Msg" name='jump' method="post">
                     <input type='hidden' name='act' value='Msg'>
                     <input type='hidden' name='CODE' value='01'>
                     <input type='hidden' name='s'    value='$iB::SESSION'>
                     <font class='misc'><b>$Messenger::lang->{'goto_folder'}:</b>  $jump_html
                     <input type='submit' name='submit' value='$Messenger::lang->{'goto_submit'}' class='forminput'>
                     </font></form></td>
                  </tr>
~;
}

sub inbox_row {
                                                                my ($data) = @_;
return qq~

                 <tr>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align='center' valign='middle'>$data->{'MSG'}->{'ICON'}</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align='left'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSV;CODE=03;VID=$data->{'MEMBER'}->{'CURRENT_ID'};MSID=$data->{'MSG'}->{'MESSAGE_ID'}'><strong>$data->{'MSG'}->{'TITLE'}</strong></a></td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align='left'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'MSG'}->{'FROM_ID'}'>$data->{'MSG'}->{'FROM_NAME'}</a> [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CODE=02;act=Msg;MID=$data->{'MSG'}->{'FROM_ID'}'>$Messenger::lang->{'add_to_book'}</a> ]</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" align='left'>$data->{'MSG'}->{'DATE'}</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" align='left'><input type='checkbox' name='msgid-$data->{'MSG'}->{'MESSAGE_ID'}' value='yes' class='forminput'></td>
                 </tr>
~;
}

sub prefs_add_dirs {

return qq~

                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>&raquo; $Messenger::lang->{'prefs_new'}</b></td>
                 </tr>
                <tr>
                   <td id='category' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>$Messenger::lang->{'prefs_text_b'}</td>
                 </tr>
~;
}



1;