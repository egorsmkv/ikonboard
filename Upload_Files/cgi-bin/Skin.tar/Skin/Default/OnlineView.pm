package OnlineView;

use strict;




sub end {
    my $links = shift;
return qq~

          <br>
          <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
            <tr>
              <td valign='middle' align='left'>$links->{'SHOW_PAGES'}</td>
            </tr>
          </table>

~;
}

sub Page_header {
    my ($links) = @_;
return qq~

          <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
            <tr>
              <td valign='middle' align='left'>$links</td>
            </tr>
          </table>
          <br>
       <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='30%' id='titlemedium'>$Online::lang->{'member_name'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='30%' id='titlemedium'>$Online::lang->{'where'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='20%' id='titlemedium'>$Online::lang->{'time'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='10%' id='titlemedium'>$Online::lang->{'profile'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='10%' id='titlemedium'>$Online::lang->{'pm'}</td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='5'> </td>
   </tr>
~;
}

sub Page_end {
  my $current_user_count = shift;
      return qq~

            <!-- End content Table -->
            <tr>
            <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='5' id='category'>�</td>
            </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='left' colspan='5' id='titlemedium'>$current_user_count $Online::lang->{'total'} </td>
     </tr>
            </table>
            </td>
            </tr>
            </table>
<br />
<br />
~;
}

sub show_row {
    my $session = shift;
return qq~

              <!-- Entry for $session->{'MEMBER_NAME'} -->
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><strong>$session->{'MEMBER_NAME'}</strong> $session->{'MEMBER_IP'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_THREE'}'>$session->{'WHERE_LINE'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'>$session->{'RUNNING_TIME'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center'>$session->{'PROFILE_ICON'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center'>$session->{'MESSAGE_ICON'}</td>
              </tr>
              <!-- End of Entry -->
~;
}



1;