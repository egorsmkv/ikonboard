package StatisticsView;

sub info_menu {
               my ($Print) = @_;
               return qq~

               <table  align='center' cellpadding='5' cellspacing='0' width='90%' id="statsbox">
               <tr>
                       <td align='left' colspan='2' id="statstitle" >
                                &nbsp;&raquo;&nbsp;$Statistics::lang->{'hack_title'}
                       </td>
               </tr>
               <tr>
                       <td bgcolor='$iB::SKIN->{'MISCBACK_FIVE'}' valign='top' nowrap align='middle' width='30%'>
                       <table cellpadding='0' cellspacing='0' width='98%' bgcolor='$iB::SKIN->{'MISCBACK_FIVE'}'>
                               <tr><td valign='middle' bgcolor='$iB::SKIN->{'MISCBACK_FIVE'}'><fieldset><legend><span id='highlight'><b>$Statistics::lang->{'hall_of_lame'}</b></span></legend>
                               <ul>
                                       <li><a href='?act=Statistics&CODE=TopPosters'>$Statistics::lang->{'top_posters'} </a></li>
                                       <li><a href='?act=Statistics&CODE=TopLogin'>$Statistics::lang->{'top_login'} </a></li>
                                       <li><a href='?act=Statistics&CODE=TopTopics'>$Statistics::lang->{'top_topics'} </a></li>
                                       </ul>
                                       </fieldset>
                                       </td>
                               </tr>
                               <tr><td valign='middle' bgcolor='$iB::SKIN->{'MISCBACK_FIVE'}'>
                               <fieldset><legend><span id='highlight'><b>$Statistics::lang->{'member_info'}</b></span></legend>
                                       <ul>
                                   <li><a href='?act=Statistics&CODE=TotalMembers'>$Statistics::lang->{'total_members'}</a></li>
                                       <li><a href='?act=Statistics&CODE=TopNewestMembers'> $Statistics::lang->{'top_newest_members'}</a></li>
                                       <li><a href='?act=Statistics&CODE=RandomMembers'> $Statistics::lang->{'moment_title'}</a></li>
                                       </ul>
                                       </fieldset>
                                       </td>
                               </tr>

                       </table>
                       </td>

                       <td bgcolor='$iB::SKIN->{'MISCBACK_FIVE'}' valign='top' align='middle' width='70%'><fieldset><legend><span id='highlight'><b>Stats</b></span></legend>
                       <table border=0 cellspacing=0 border='0' width="98%">
                               <tr>
                                       <td>
                                       $Print
                                       </td>
                               </tr>
                       </table>
                       </fieldset>
                       </td>
                       <tr>
                       <td align='center' colspan='2' id="statsbottom" >&nbsp;</td>
               </tr>
               </tr>
               </table>

               ~;
       }

sub TopPosters {
               my ($count, $member) = @_;

               return qq~

                       <tr>
                               <td width='25%'>$count.</td>
                               <td width='25%'><a title='[MEMBER_INFORMATION]' href='?act=Profile&CODE=03&MID=$member->{MEMBER_ID}'>$member->{MEMBER_NAME}</a></td>
                               <td width='25%'> $member->{MEMBER_POSTS}</td>
    <td width='25%'> $member->{PIP}&nbsp;</td>
                       </tr>



               ~;
       }

sub TopLogin {
               my ($count, $member) = @_;

               return qq~

                       <tr>
                               <td width='15%'>$count.</td>
                               <td width='20%'><a title='[MEMBER_INFORMATION]' href='?act=Profile&CODE=03&MID=$member->{MEMBER_ID}'>$member->{MEMBER_NAME}</a></td>
                               <td width='30%' nowrap>$member->{LAST_LOG_IN}</td>
    <td width='35%' nowrap>$member->{PIP}&nbsp;</td>
                       </tr>


               ~;
       }

sub TopTopics {
               my ($count,$topic) = @_;

               return qq~

                       <tr>
                               <td width='10%'>$count.</td>
                               <td width='40%'><a title='[TOPIC_INFORMATION]' href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$topic->{FORUM_ID};t=$topic->{TOPIC_ID}'>$topic->{TOPIC_TITLE}</a></td>
                               <td width='10%'>$topic->{TOPIC_POSTS}</td>
    <td width='40%'>$topic->{PIP}&nbsp;</td>
                       </tr>


               ~;
       }


sub TotalMembers {
               my ($Info) = @_;

               return qq~
                       <tr>
                               <td>$Statistics::lang->{'total_members_num'}</td><td>$Info->{total_count}</td>
                       </tr>
                       <tr>
                               <td>$Statistics::lang->{'total_members_male'}</td><td>$Info->{count_male}</td>
                       </tr>
                       <tr>
                               <td>$Statistics::lang->{'total_members_female'}</td><td>$Info->{count_female}</td>
                       </tr>
                       <tr>
                               <td>$Statistics::lang->{'total_members_nosex'}</td><td>$Info->{count_hic}</td>
                       </tr>
                      <tr>
                               <td>$Statistics::lang->{'total_members_posted'}</td><td>$Info->{count_posted}</td>
                       </tr>
                      <tr>
                               <td>$Statistics::lang->{'total_members_noavatar'}</td><td>$Info->{count_noavatar}</td>
                       </tr>
                       <tr>
                               <td>$Statistics::lang->{'total_members_sign'}</td><td>$Info->{count_sign}</td>
                       </tr>
                       <tr>
                               <td>$Statistics::lang->{'total_members_realname'}</td><td>$Info->{count_realname}</td>
                       </tr>
                       <tr>
                               <td>$Statistics::lang->{'total_members_yahooname'}</td><td>$Info->{count_yahooname}</td>
                       </tr>
                       <tr>
                               <td>$Statistics::lang->{'total_members_aolname'}</td><td>$Info->{count_aolname}</td>
                       </tr>
                       <tr>
                               <td>$Statistics::lang->{'total_members_icqnumber'}</td><td>$Info->{count_icqnumber}</td>
                       </tr>
               ~;
       }

sub TopNewestMembers {
               my ($count, $member) = @_;

               return qq~

                       <tr>
                               <td width='25%'>$count.</td>
                               <td width='25%'><a title='[MEMBER_INFORMATION]' href='?act=Profile&CODE=03&MID=$member->{MEMBER_ID}'>$member->{MEMBER_NAME}</a></td>
                               <td width = '25%'> $member->{MEMBER_JOINED}</td>
    <td width = '25%'> $member->{PIP}&nbsp;</td>
                       </tr>

               ~;
       }

sub RandomMembers {
               my ($member, $db) = @_;
               my $mem_name_r;

               # Upgraded the language in 2004-11-11

               if ($member->{MEMBER_NAME_SP} == 1) {
                  $mem_name_r = q!<tr><td>$Statistics::lang->{'member_rname'}</td><td>  $member->{MEMBER_NAME_R} </td></tr>!;
               } else {
                  $mem_name_r = "<tr><td>$Statistics::lang->{'member_rname'}</td><td>". $Statistics::lang->{'name_private'} ;
               }

               my @mem_groups = $db->query( TABLE      => 'mem_groups',
                                            COLUMNS    => ['ID', 'TITLE'],
                                            SORT_KEY   => 'TITLE',
                                            SORT_BY    => 'A-Z',
                                          );

               my $GroupName = $member->{MEMBER_GROUP};
               for (@mem_groups) {
                  if ($_->{'ID'} == $member->{MEMBER_GROUP}) {
                     $GroupName = $_->{'TITLE'};
                  }
               }

               return qq~
               <tr>
                      <td align='center'valign='top' width='30%' rowspan='14'>
                      &raquo; $member->{MEMBER_NAME} <br> $member->{MEMBER_AVATAR}
                      </td>
                      $mem_name_r
                      <tr><td>$Statistics::lang->{'member_title'}</td><td>  $member->{MEMBER_TITLE} </td></tr>
                      <tr><td>$Statistics::lang->{'member_id'}</td><td> $member->{MEMBER_ID} </td></tr>
                      <tr><td width="15%">$Statistics::lang->{'member_joined'}</td><td> $member->{MEMBER_JOINED} </td></tr>
                      <tr><td>$Statistics::lang->{'member_group'}</td><td>  $GroupName </td></tr>
                      <tr><td>$Statistics::lang->{'member_posts'}</td><td>  $member->{MEMBER_POSTS} </td></tr>
                      <tr><td>$Statistics::lang->{'member_loc'}</td><td>    $member->{LOCATION} </td></tr>
                      <tr><td>$Statistics::lang->{'member_aol'}</td><td>    $member->{AOLNAME} </td></tr>
                      <tr><td>$Statistics::lang->{'member_icq'}</td><td>    $member->{ICQNUMBER} </td></tr>
                      <tr><td>$Statistics::lang->{'member_yahoo'}</td><td>  $member->{YAHOONAME} </td></tr>
                      <tr><td>$Statistics::lang->{'member_website'}</td><td><a href="$member->{WEBSITE}" target="_blank">$member->{WEBSITE}</a> </td></tr>
                      <tr><td>$Statistics::lang->{'member_sig'}</td><td>    $member->{SIGNATURE} </td></tr>
              </tr>

               ~;
}


1;