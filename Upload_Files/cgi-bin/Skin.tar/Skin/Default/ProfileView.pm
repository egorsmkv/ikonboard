package ProfileView;
use strict;

sub mem_stat {
my $name = shift;
my $status = 'offline';
        foreach (@{ $iB::ACTIVE->{'NAMES'} }) {
                if ($_->{'NAME'} eq $name) {
                        $status = 'online'; last;
        }
}
return qq~
<img src="$iB::INFO->{'IMAGES_URL'}/images/mem_$status.gif" border='0' align='absmiddle'>
~;
}

sub ShowProfile {
my ($Profile, $FIELDS, $member) = @_;
my $mem_stat = &mem_stat($Profile->{'MEMBER_NAME'});
return qq~
<br>
<table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
<tr>
<td>
<table cellpadding='4' cellspacing='0' border='0' width='100%'>
<tr colspan='2'>
<td width='50%' valign='middle' bgcolor="$iB::SKIN->{'TITLEBACK'}" width='100%' id="titlemedium"><b>&raquo; $Profile->{'MEMBER_NAME'}</b></td>
<td width='50%' valign='middle' align='right'  bgcolor="$iB::SKIN->{'TITLEBACK'}" width='100%' id="titlemedium">( <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=MSS;CODE=04;MID=$Profile->{'MEMBER_ID'}'>$Profile::lang->{'send_pm'}</a> � <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Msg;CODE=02;MID=$Profile->{'MEMBER_ID'}'>$Profile::lang->{'add_book'}</a> � $Profile->{'MEMBER_EMAIL'} )</td>
</tr>

<tr colspan='2'>
<td width='100%' valign='middle' align='center' bgcolor="$iB::SKIN->{'CAT_BACK'}" width='100%' id="category" colspan="2">$Profile->{'SEARCH'}</td>
</tr>

   <tr>
   <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' align='center' valign='middle' width='100%'colspan="2">$Profile->{'PHOTO'}</td>
   </tr>
<tr>
<td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' align='left' valign='top' width='100%' colspan="2">$Profile->{'AVATAR'}<br>$Profile->{'MEMBER_PIPS_IMG'}<br><b>&nbsp;&nbsp;$Profile::lang->{'gender'}:</b> $Profile->{'GENDER'}<br>&nbsp;&nbsp;<b>$Profile::lang->{'status'}:</b>&nbsp;$mem_stat</td>
</tr>

  <tr>
    <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%" valign="top">
    <!--begin Post Info -->
    <fieldset><legend><span id='highlight'><b>$Profile::lang->{'member_forum_header'}</b></span></legend>
     <table width="100%">
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%"><b>$Profile::lang->{'last_post_title'}:
  </b>$Profile->{'LAST'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%"><b>$Profile::lang->{'last_modification'}:
  </b>$Profile->{'LAST_UPDATE'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%"><b>$Profile::lang->{'post_average'}:</b> $Profile->{'POST_AVERAGE'} $Profile::lang->{'per_day'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%"><b>$Profile::lang->{'total_posts'}:
  </b>$Profile->{'MEMBER_POSTS'}</td>
      </tr>
      </table>
    </fieldset>
    <!--end Post Info -->
    </td>
    <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%" valign="top">
    <!--begin Contact Info -->
         <fieldset><legend><span id='highlight'><b>$Profile::lang->{'contact_header'}</b></span></legend>
          <table width="100%">
           <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%"><b>$Profile::lang->{'aol_name'}:</b> $Profile->{'AOLNAME'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%"><b>$Profile::lang->{'icq_number'}:</b> $Profile->{'ICQNUMBER'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%"><b>$Profile::lang->{'msn_name'}:</b> $Profile->{'MSNNAME'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%"><b>$Profile::lang->{'yahoo_name'}:</b> $Profile->{'YAHOONAME'}</td>
      </tr>
     </table>
    </fieldset>
    <!--end Contact Info -->
    </td>
  </tr>
  <tr>
    <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%" valign="top">
    <!--begin Membership Info -->
    <fieldset><legend><span id='highlight'><b>$Profile::lang->{'member_header'}</b></span></legend>
     <table width="100%">
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%" colspan="3"><b>$Profile::lang->{'member_group'}:</b> $Profile->{'MEMBER_GROUP'}->{'TITLE'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%" colspan="3"><b>$Profile::lang->{'member_level'}:</b> $Profile->{'MEMBER_TITLE'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%" colspan="3"><b>$Profile::lang->{'registration_date'}:
  </b>$Profile->{'MEMBER_JOINED'}</td>
      </tr>
      <tr>
      <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%" colspan="3"><b>$Profile::lang->{'last_login'}:
        </b>$Profile->{'LAST_LOG_IN'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%" colspan="3"><b>$Profile::lang->{'days_here'}:</b> $Profile->{'$days'} $Profile::lang->{'days'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%" colspan="3"><b>$Profile::lang->{'memnumber'}:
  </b>$Profile->{'MEMBER_NUM'}</td>
      </tr>
      $Profile->{'MEMBER_RATING'}
     </table>
    </fieldset>
    <!--end Membership Info -->
    </td>
    <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%" valign="top">
    <!--begin Personal Info -->
    <fieldset><legend><span id='highlight'><b>$Profile::lang->{'personal_header'}</b></span></legend>
     <table width="100%"> <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%"><b>$Profile::lang->{'memberrealname'}:</b> $Profile->{'MEMBER_NAME_R'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%"><b>$Profile::lang->{'location'}:</b> $Profile->{'LOCATION'}</td>
      </tr>
       <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%"><b>$Profile::lang->{'interests'}:</b> $Profile->{'INTERESTS'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%"><b>$Profile::lang->{'signature'}:</b> $Profile->{'SIGNATURE'}</td>
      </tr>
      <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="50%"><b>$Profile::lang->{'home_page'}</b>: $Profile->{'WEBSITE'}</td>
      </tr>
      <tr>
      <td bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' width="50%"><b>$Profile::lang->{'current_time'}:</b> $Profile->{'THEIR_TIME'}</td>
      </tr>
     </table>
    </fieldset>
    <!--end Personal Info -->
    </td>
  </tr>
</table>

<tr colspan='2'>
<td width='100%' valign='middle' align='center' bgcolor="$iB::SKIN->{'TITLEBACK'}" width='100%' id="titlemedium">� <a href='javascript:history.go(-1);'>Go Back</a></td>
</tr>


</td></tr></table>
~;
}

sub MemberRating {
        my $Profile = shift;
return qq~
                <tr>
       <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width="20%" nowrap><b>$Profile::lang->{'member_rating'}:</b> </td>
          <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}'width="50%"><span class="memrate"><img src='$iB::INFO->{'IMAGES_URL'}/images/$iB::SKIN->{'RATINGS_BAR'}' border='0' alt='' width="$Profile->{'MEMBER_RATING_PCT'}" height='11'></span></td>
           <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}'width="30%" align="center" nowrap>$Profile->{'MEMBER_RATING_NUM'}&nbsp;&nbsp;
           <select class='forminput' onchange="if(this.options[this.selectedIndex].value!=''){window.location.replace('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=Profile&CODE=13&MID=$Profile->{'MEMBER_ID'}&rating='+this.options[this.selectedIndex].value+'&dest=profile')}this.selectedIndex=0">
                    <option value=''>$Profile::lang->{'rate_this_member'}
                    <option value='1'>1 ($Profile::lang->{'rate_lowest'})
                    <option value='2'>2
                    <option value='3'>3
                    <option value='4'>4
                    <option value='5'>5 ($Profile::lang->{'rate_highest'})
                    </select>
                </td>
                </tr>
~;
}


sub show_authorise {
my ($member, $new_email) = @_;
return qq~
<table cellpadding=0 cellspacing=0 border=0 width=$iB::SKIN->{'TABLE_WIDTH'} bgcolor=$iB::SKIN->{'TABLE_BORDER_COL'} align=center>
<tr>
<td>
<table cellpadding=3 cellspacing=1 border=0 width=100%>
<tr>
<td bgcolor=$iB::SKIN->{'TITLEBACK'} valign='left'><font class='titlelarge'>$Profile::lang->{'registration_process'}</font></td>
</tr>
<tr>
<td bgcolor=$iB::SKIN->{'MEMBER_COL_ONE'}><font class='misc'>$Profile::lang->{'thank_you'} $member->{'MEMBER_NAME'}. $Profile::lang->{'auth_text'}  $new_email</font></td>
</tr>
</table>
</td>
</tr>
</table>
~;
}

sub contact_info {
   my ($Profile, $FIELDS) = @_;   #that should be all of teh changes..
return qq~

<script language="javascript" type="text/javascript">
  <!--
      function to_old_win(url)
      {
        opener.location.href = url;
      }
  //-->
</script>
<table cellpadding='3' cellspacing='3' border='0' width='100%' bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' align='center'>
<tr>
  <td valign='top'id='contactTop'>$Profile::lang->{'contact_info_title'} $Profile->{'MEMBER_NAME'}</td>
  </tr>
  <tr>
   <td id="contactBody">
    <img src="$iB::INFO->{'IMAGES_URL'}/images/pb_email.gif">
      <b>E-mail</b> : $Profile->{'MEMBER_EMAIL'}<br><br>
      <img src="$iB::INFO->{'IMAGES_URL'}/images/pb_email.gif">
      <b>$Profile::lang->{'pm_title'}</b> :&nbsp;
      <a href="javascript:to_old_win('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=MSS;CODE=04;MID=$Profile->{'MEMBER_ID'}')">$Profile::lang->{'send_pm'}</a>&nbsp;&nbsp;
      <a href="javascript:to_old_win('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Msg;CODE=02;MID=$Profile->{' MEMBER_ID'}')">$Profile::lang->{'add_book'}</a><br><br>
      <img src="$iB::INFO->{'IMAGES_URL'}/images/pb_aol.gif">
      <b>AOL</b> : $Profile->{'AOLNAME'}<br><br>
      <img src="$iB::INFO->{'IMAGES_URL'}/images/pb_icq.gif">
      <b>ICQ</b> : $Profile->{'ICQNUMBER'}<br><br>
      <img src="$iB::INFO->{'IMAGES_URL'}/images/pb_msn.gif">
      <b>MSN</b> : $Profile->{'MSNNAME'}<br><br>
      <img src="$iB::INFO->{'IMAGES_URL'}/images/pb_yahoo.gif">
      <b>YAHOO</b> : $Profile->{'YAHOONAME'}<br><br>
  </td>
</tr>
<tr>
 <td align="center" id="contactBottom">[ <a href="javascript:self.close();">$Profile::lang->{'close'}</a> ]
 </td></tr>
</table>

~;
}

1;