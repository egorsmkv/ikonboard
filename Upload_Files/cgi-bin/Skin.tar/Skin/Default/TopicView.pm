package TopicView;

use strict; my $img_button = $iB::INFO->{'ALLOW_IMAGES'}                            ? qq[<input type='button' accesskey='p' value=' Image ' onClick='IBCimage()' class='forminput' title="Picture: [Control or Alt] + p"> ]                            : ''; my $ibc_flash = $iB::INFO->{'ALLOW_FLASH'}                            ? qq[<input type='button'accesskey='f' value=' Flash ' onClick='IBCflash("$iB::INFO->{'MAX_W_FLASH'}","$iB::INFO->{'MAX_H_FLASH'}")' class='forminput'  title="FLASH: [Control or Alt] + f"> ]                            : '';




sub PageTop {
                                                            my $data = shift;
return qq~

    <script language='javascript'>
    <!--
    function delete_post(theURL) {
       if (confirm("$Topic::lang->{js_del_1}")) {
          window.location.href=theURL;
       }
       else {
          alert ("$Topic::lang->{js_del_2}");
       }
    }
    //-->
    </script>
    <a name="top"></a>
    <!-- Cgi-bot Start Forum page unique top -->
    <table cellpadding='1' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
      <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='Thread_Search'>
      <input type='hidden' name='act' value='Tsearch'>
      <input type='hidden' name='s' value='$iB::SESSION'>
      <input type='hidden' name='t' value='$iB::IN{'t'}'>
      <input type='hidden' name='f' value='$iB::IN{'f'}'>
      <tr>
        <td valign='middle' colspan='2' align='left' id="tSearch">
        <input type='text' size='14' maxlength='100' name='search_q' class='forminput'> <input type='submit' name='submit' value="$Topic::lang->{'search_thread'}" class='forminput'>
        </td>
      </tr>
      </form>
      <tr>
        <td valign='middle' width='50%' nowrap align='left'>$data->{'TOPIC'}->{'SHOW_PAGES'} <br><p align="left">[ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Subs;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'track_topic'}</a> :: <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Forward;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'forward'}</a> :: <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Print;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'print'}</a> ]</p></td>
        <td valign='middle' width='50%' nowrap align='right'>$data->{'TOPIC'}->{'REPLY_BUTTON'} <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=00;f=$data->{'FORUM'}->{'FORUM_ID'}" title='$Topic::lang->{'start_new_topic'}'>$iB::SKIN->{'A_POST'}</a> $data->{'TOPIC'}->{'POLL_BUTTON'}</td>
 </tr>
     </table>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='0' cellspacing='1' border='0' width='100%'>
                <tr>
                  <td bgcolor='$iB::SKIN->{'TITLEBACK'}'>
                    <table border='0' width='100%' cellspacing='0' cellpadding='0' bgcolor='$iB::SKIN->{'TITLEBACK'}'>
                      <tr>
                        <td valign='middle' align='left' id='titlemedium'>  <b>$Topic::lang->{'topic'}</b>: $data->{'TOPIC'}->{'TOPIC_TITLE'}$data->{'TOPIC'}->{'TOPIC_DESC'}</td><td valign='middle' align='right' id='titlemedium'>< <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'};view=old'>$Topic::lang->{'t_old'}</a> | <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'};view=new'>$Topic::lang->{'t_new'}</a> >  </td>
                      </tr>
                     </table>
                  </td>
                </tr>
  <!-- Cgi-bot End Forum page unique top -->
~;
}

sub mod_cp_link {
                                                            my $data = shift;
return qq~
<br>[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$data'>$Topic::lang->{'mod_cp'}</a> ]
~;
}

sub Show_attachments {
                                                            my $data = shift;
return qq~
    <br><br><img src="$iB::INFO->{'MIME_IMG'}/$data->{'IMG'}" border='0' alt=''><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Attach;ID=$data->{'ID'};f=$data->{'FORUM'};t=$data->{'TOPIC'};p=$data->{'POST'}" target='_blank'>$Topic::lang->{'attach_dl'} [ $data->{'NAME'} ]</a>
    <br>$Topic::lang->{'attach_hits'}: $data->{'HITS'}
~;
}

sub ip_show {
                                                            my $data = shift;
return qq~
<span id='highlight'>$Topic::lang->{'ip'}: $data</span>
~;
}

sub warn_link {
                                                            my ($data, $st) = @_;
return qq~
    <a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Warn;CODE=00;f=$data->{'FORUM_ID'};t=$data->{'TOPIC_ID'};st=$st;p=$data->{'POST_ID'};MID=$data->{'AUTHOR'}">$Topic::lang->{'warn'}
</a>
~;
}

sub TopicSummary_bottom {

return qq~

~;
}

sub Show_attachments_img {
                                                            my $data = shift;
return qq~
<br><br>$Topic::lang->{'pic_attach'}<br><img src="$iB::INFO->{'UPLOAD_URL'}/$data->{'NAME'}" border='0' onload="javascript:if(this.width > screen.width-300)this.width = (screen.width-300)" alt="$Topic::lang->{'pic_attach'}">
~;
}

sub Mod_Panel {
                                                            my $data = shift;
return qq~
    <br>
    <table cellpadding='3' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
          <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'><b>$Topic::lang->{'moderation_ops'}</b><br>$data</td>
        </tr>
    </table>
~;
}

sub Quick_Reply {
                                                my $data = shift;   if ($iB::MEMBER->{'MEMBER_ID'}){}
return qq~

<form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="POST" name='REPLIER' onSubmit='return ValidateForm()' enctype="multipart/form-data">
<input type='hidden' name='st' value='$iB::IN{'st'}'>
<input type='hidden' name='act' value='Post'>
<input type='hidden' name='CODE' value='03'>
<input type='hidden' name='s' value='$iB::SESSION'>
<input type='hidden' name='f' value='$data->{'FORUM'}->{'FORUM_ID'}'>
<input type='hidden' name='t' value='$data->{'TOPIC'}->{'TOPIC_ID'}'>
<table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
<tr>
<td bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
<table border='0' cellPadding='5' cellSpacing='1' width='100%' align='center'>
<tr>
<td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='40%' valign='middle' align='left' id='titlemedium'>&raquo; $Topic::lang->{'qr_title'}</td>
<td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan="2" width='60%' valign='middle' align='left' id='titlemedium'>$data->{'TOPIC'}->{'TOPIC_TITLE'}</td>
</tr>
   <tr>
        <td align='center' id='category' colspan='3'></td>
   </tr>
<script language="javascript">
<!--
// added by kevaholic00
var ie = navigator.appName == "Microsoft Internet Explorer" ? 1 : 0;
var ns = navigator.appName == "Netscape" ? 1 : 0;
// end addition
var MessageMax  = "$Post::lang->{'the_max_length'}";
var Override    = "$Post::lang->{'override'}";
function CheckLength() {
    MessageLength  = "document.REPLIER.Post.value.length";
    message  = "";
        if (MessageMax !=0) {
            message = "$Post::lang->{'js_post'}:\\n$Post::lang->{'js_max_length'} " + MessageMax + " $Post::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$Post::lang->{'js_used'} " + MessageLength + " $Post::lang->{'js_characters'}.");
}
function ValidateForm() {
    MessageLength  = "document.REPLIER.Post.value.length";
    errors = "";
    if (MessageLength < 2) {
         errors = "$Post::lang->{'js_no_message'}";
    }
    if (MessageMax !=0) {
        if (MessageLength > MessageMax) {
            errors = "Post:\\n$Post::lang->{'js_max_length'} " + MessageMax + " $Post::lang->{'js_characters'}.\\n$Post::lang->{'js_current'}: " + MessageLength;
        }
    }
    if (errors != "" && Override == "") {
        alert(errors);
        return false;
    } else {
        document.REPLIER.submit.disabled = true;
        return true;
    }
}
function emoticon(theSmilie) {
    //document.REPLIER.Post.value += ' ' + theSmilie + ' ';
    document.REPLIER.Post.focus();
    if (ie) {
        var rng = document.selection.createRange();
        rng.text = ' ' + theSmilie + ' ';
    } else if (ns) {
        var selStart = document.REPLIER.Post.selectionStart;
        var selEnd   = document.REPLIER.Post.selectionEnd;
        var before   = document.REPLIER.Post.value.substring(0, selStart);
        var after    = document.REPLIER.Post.value.substring(selEnd, document.REPLIER.Post.textLength);
        document.REPLIER.Post.value = before + ' ' + theSmilie + ' ' + after;
    } else {
        document.REPLIER.Post.value += ' ' + theSmilie + ' ';
    }
    document.REPLIER.Post.focus();
}
//-->
</script>
<script language='javascript' type='text/javascript' src='$iB::INFO->{'IMAGES_URL'}/ikoncode.js'>
</script>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='top'><b>$Topic::lang->{'buttons'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center'>
                <input type='button' accesskey='b' value=' B '       onClick='IBCbold()'   class='forminput' title="BOLD: [Control / Alt] + b"      name='bold'   style="font-weight:bold">
                <input type='button' accesskey='i' value=' I '       onClick='IBCitalic()' class='forminput' title="ITALIC: [Control / Alt] + i"    name='italic' style="font-style:italic">
                <input type='button' accesskey='u' value=' U '       onClick='IBCunder()'  class='forminput' title="UNDERLINE: [Control / Alt] + u" name='under' style="text-decoration:underline">
                <input type='button' accesskey='h' value=' http:// ' onClick='IBCurl()'    class='forminput' title="HYPERLINK: [Control / Alt] + h" style="text-decoration:underline;color:blue">
                <input type='button' accesskey='e' value='  @  '     onClick='IBCemail()'  class='forminput' title="EMAIL: [Control / Alt] + e"     style="text-decoration:underline;color:blue">
                <input type='button' accesskey='q' value=' Quote '   onClick='IBCquote()'  class='forminput' title="QUOTE: [Control / Alt] + q" name='quote'>
                <input type='button' accesskey='c' value=' Code '    onClick='IBCcode()'   class='forminput' title="CODE: [Control / Alt] + c"  name='code'>
                $img_button $ibc_flash<br><font class='misc'>$Post::lang->{'buttons_js'}</font>
</td>
                </tr>
<script language="javascript">
var MessageMax  = "$Topic::lang->{'the_max_length'}";
var Override    = "$Topic::lang->{'override'}";
function ValidateForm() {
MessageLength  = document.REPLIER.Post.value.length;
errors = "";
if (MessageLength < 2) {
     errors = "$Topic::lang->{'js_no_message'}";
}
if (MessageMax !=0) {
    if (MessageLength > MessageMax) {
        errors = "Topic:\\n$Topic::lang->{'js_max_length'} " + MessageMax + " $Topic::lang->{'js_characters'}.\\n$Topic::lang->{'js_current'}: " + MessageLength;
    }
}
if (errors != "" && Override == "") {
    alert(errors);
    return false;
} else {
    document.REPLIER.Submit.disabled = true;
    return true;
}
}
</script>
<tr>
<td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top' width='40%'>
$Topic::lang->{'posting'}<br>$data->{'TOPIC'}->{'QUICKREPLY_UNREG'}
<input type='checkbox' name='enablesig' value='yes' checked>$Topic::lang->{'qr_sig'}<br>
<input type='checkbox' name='enableemo' value='yes' checked>$Topic::lang->{'qr_emo'}<br>
<input type='checkbox' name='enablesubs' value='yes'>$Topic::lang->{'qr_track'}<br></b>
<!--
-->
<center><a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=Legends&CODE=emoticons','HelpCard','200','400','0','1','1','1')">$Topic::lang->{'help_emo'}</a><br>
<a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=Legends&CODE=ibcode','HelpCard','250','400','0','1','1','1')">$Topic::lang->{'ib_code'}</a></center>
<!--
--></b>  </td>
<td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' width='60%' align='center'>
<textarea rows="7" wrap="soft" name="Post" tabindex="3" class="textinput" style="width:95%;"></textarea>
<script language="JavaScript">
function InstaSmilie () {
return;
}
function AddSmile(SmileCode) {
emoticon(SmileCode);
}
</script>
<table cellpadding="0" cellspacing="3" width="60%" id="AutoNumber1" height="25">
<tr>$data->{EMOTE}</tr>
</table>
<BR>
<input type="submit" name="Submit" value="Quick Post" tabindex="4" class='forminput'>
<input type="submit" name="preview" value="Preview" tabindex="5" class='forminput'>
</td></tr>
   <tr>
        <td align='center' id='category' colspan='3'> </td>
   </tr>

</table></td></tr></table></form></center> <br>
~;
}

sub MemberRating {
                                                my $data = shift;
return qq~
<br>$Topic::lang->{'member_rating'}$data->{'MEMBER_RATING_NUM'}<br>
<table border='0' cellpadding='0' cellspacing='0' width='100'>
                    <tr>
                    <td width='100px' valign='middle'>
                        <table border='0' cellpadding='0' cellspacing='1' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'
width='100' height='11' align='center'>
                        <tr>
                        <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}'><img
src='$iB::INFO->{'IMAGES_URL'}/images/$iB::SKIN->{'RATINGS_BAR'}' border='0' alt=''
width="$data->{'MEMBER_RATING_PCT'}" height='11'></td>
                        </tr>
                        </table>
                    </td>
                    </tr>
                    </table>
~;
}

sub report_link {
                                                            my $data = shift;
return qq~
   <span id='highlight'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Report;f=$data->{'FORUM_ID'};t=$data->{'TOPIC_ID'};st=$iB::IN{'st'};p=$data->{'POST_ID'}'>$Topic::lang->{'snitch_geezer_to_a_copper'}</a></span>
~;
}

sub RenderRow {
                                                            my $data = shift;
return qq~

    <!--Begin Msg Number $data->{'POST'}->{'POST_ID'}-->
<tr>
                  <td colspan="2" valign='middle' align='left' id='posttop'> &nbsp;<a href="javascript:;" onclick="prompt('$Topic::lang->{'copy_link_js'}','$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST&f=$iB::IN{'f'}&t=$iB::IN{'t'}&st=$iB::IN{'st'}#entry$data->{'POST'}->{'POST_ID'}');this.blur();return false">$Topic::lang->{'copy_link_text'}: $data->{'POST'}->{'POST_NO'}</a>
<a name="postid$data->{'POST'}->{'POST_ID'}"></a>
<a name="entry$data->{'POST'}->{'POST_ID'}"></a>
</td>
                     </tr>
    <tr>
        <td bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
            <table width='100%' cellpadding='4' cellspacing='0' bgcolor='$data->{'POST'}->{'POST_BACK_COL'}' border='0'>
                <tr>
                    <td align="center" bgcolor='$data->{'POST'}->{'POST_BACK_COL'}' valign='top' width='20%'>
<span id='$data->{'POST'}->{'NAME_CSS'}'>
$data->{'POSTER'}->{'MEMBER_NAME'} $data->{'POSTER'}->{'SEARCH_ICON'}</span><br>
<span id="membertitle">$data->{'POSTER'}->{'MEMBER_TITLE'}</span><br>
$data->{'POSTER'}->{'MEMBER_AVATAR'}<br><br>
$data->{'POSTER'}->{'MEMBER_PIPS_IMG'}<span id='postdetails'><br>
$data->{'POSTER'}->{'WARN_GFX'}  <br>
$data->{'POSTER'}->{'MEMBER_GROUP'}<br>
$data->{'POSTER'}->{'MEMBER_POSTS'}<br>
$data->{'POSTER'}->{'MEMBER_JOINED'}<br>
$data->{'POSTER'}->{'MEMBER_RATING'}</span></td>
                    <td bgcolor='$data->{'POST'}->{'POST_BACK_COL'}' valign='top' width='100%' height='100%'>
                        <table width='100%' border='0'>
                            <tr>
                                <td valign='middle' align='left'>$data->{'POST'}->{'POST_ICON'}</td>
                                <td valign='middle' align='left' width='50%' id='postdetails'><b>$Topic::lang->{'posted_on'}</b> $data->{'POST'}->{'POST_DATE'}</td>
                                <td valign='middle' align='left' width='50%' id='postdetails'></td>
                                <td align='right' valign='bottom' nowrap>$data->{'POST'}->{'PREV'}&nbsp;$data->{'POST'}->{'NEXT'}&nbsp;$data->{'POST'}->{'IGNORE_ICON'}&nbsp;$data->{'POST'}->{'DELETE_ICON'}&nbsp;$data->{'POST'}->{'EDIT_ICON'}&nbsp;$data->{'POST'}->{'QUOTE_ICON'}</td>
                            </tr>
                        </table>
                        <hr size='1' style='border: 1px solid $iB::SKIN->{'TABLE_BORDER_COL'}'>
                        <span id='postcolor'>$data->{'POST'}->{'POST'} $data->{'POST'}->{'RENDER_ATTACHMENT'} $data->{'POST'}->{'SIGNATURE'}</span>
                    </td>
                </tr>
                <tr>
                <td valign="bottom" width="175" nowrap align="center">$data->{'POSTER'}->{'ONLINE'}</TD>
                <td class='bottom' bgcolor='$data->{'POST'}->{'POST_BACK_COL'}'>
                    <hr size='1' style='border: 1px solid $iB::SKIN->{'TABLE_BORDER_COL'}'>
                    <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                        <tr>
                            <td valign='middle' align='left'><span class="buttontext">$data->{'POSTER'}->{'UP_ICON'} $data->{'POSTER'}->{'PROFILE_ICON'}$data->{'POSTER'}->{'CONTACT_ICON'}$data->{'POSTER'}->{'WEBSITE_ICON'}</span></td>
                        </tr>
                        <tr>
                            <td valign='middle' align='right'>$data->{'POST'}->{'USER_IP'} $data->{'POST'}->{'REPORT_POST'} $data->{'POST'}->{'WARN_USER'}</td>
                        </tr>
                    </table>
                </td>
                </tr>
            </table>
        </td>
    </tr>
 <!-- end Message -->
~;
}

sub TableFooter {
                                                my $data = shift;
return qq~
<a name="bottom"></a>
             <tr>
               <td bgcolor='$iB::SKIN->{'TITLEBACK'}'>
                 <table border='0' width='100%' cellspacing='0' cellpadding='0' bgcolor='$iB::SKIN->{'TITLEBACK'}'>
                   <tr>
                     <td valign='middle' align='left' id='titlemedium'>  $Topic::lang->{'topic_stats'}</td>
                     <td valign='middle' align='right' id='titlemedium'>< <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'};view=old' class='titlemedium'>$Topic::lang->{'t_old'}</a> | <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'};view=new' class='titlemedium'>$Topic::lang->{'t_new'}</a> >  </td>
                   </tr>
                  </table>
               </td>
             </tr>
           </table>
        </td>
     </tr>
</table>
<br>
<table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'><tr>
       <td valign='top' width='50%' nowrap align='left'><p align="left">[ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Subs;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'track_topic'}</a> :: <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Forward;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'forward'}</a> ::
<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Print;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'print'}</a> ]</p><br>$data->{'TOPIC'}->{'SHOW_PAGES'} </td>
       <td valign='middle' width='50%' nowrap align='right'>$data->{'TOPIC'}->{'REPLY_BUTTON'} <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=00;f=$data->{'FORUM'}->{'FORUM_ID'}" title='$Topic::lang->{'start_new_topic'}'>$iB::SKIN->{'A_POST'}</a> $data->{'TOPIC'}->{'POLL_BUTTON'}</td>
</tr></table>
<table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
 <tr>
   <td valign='middle' align='right'>$data->{'FORUM'}->{'JUMP'}</td>
 </tr>
</table>
<br>
~;
}

sub Online {
                                                                my ($intopic_count, $intopic_list) = @_;
return qq~
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}'
bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' id='titlelarge'><b>$intopic_count</b>
$Topic::lang->{'topic_members_active'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$intopic_list</td>
               </tr>
   <tr>
        <td align='center' id='category'> </td>
   </tr>
               </table>
            </td>
      </tr>
   </table>
   <br>
~;
}



1;