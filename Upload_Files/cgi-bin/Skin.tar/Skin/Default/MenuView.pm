package MenuView;

my $img_button = $iB::INFO->{'ALLOW_IMAGES'}  ? qq[<input type='button' accesskey='p' value=' Image ' onClick='IBCimage()' class='forminput' title="Picture: [Control or Alt] + p"> ]  : ''; my $ibc_flash = $iB::INFO->{'ALLOW_FLASH'} ;

my $base_url = qq[$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=UserCP;CODE=];




sub CP_end {

return qq~

   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
    </table></td></tr></table>
<br />
~;
}

sub personal_splash {

return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlemedium'>� $UserCP::lang->{'personal_ops'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'personal_ops_txt'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'><span id='usermenu'><u><b><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01;MODE=2'>$UserCP::lang->{'edit_profile'}</a></b></u></span><br><br>$UserCP::lang->{'edit_profile_txt'}</td>
                 </tr>
~;
}

sub subs_end {

return qq~

</table></td></tr>
~;
}

sub personal_avatar_URL {
                                            my ($Profile, $avatar, $allowed_ext) = @_;
return qq~

   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
                <form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}' method='post' name='url_avatar'>
                <input type='hidden' name='act' value='Profile'><input type='hidden' name='CODE' value='11'><input type='hidden' name='s' value='$iB::SESSION'>
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� $UserCP::lang->{'avatar_url_title'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>$UserCP::lang->{'avatar_url_txt'}<br>$UserCP::lang->{'avatar_dims_txt'}<br> ($UserCP::lang->{'maximum'} $UserCP::lang->{'width'} = $iB::INFO->{'AV_WIDTH'} $UserCP::lang->{'pixels'} | $UserCP::lang->{'maximum'} $UserCP::lang->{'height'} = $iB::INFO->{'AV_HEIGHT'} $UserCP::lang->{'pixels'})</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'avatar'}<br>$UserCP::lang->{'avatar_url_ext'}<br><b>$allowed_ext</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='55' maxlength='80' name='useravatar' value='$avatar' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'avatar_dims'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>$UserCP::lang->{'width'}   <input type='text' size='3' maxlength='3' name='Avatar_width' value='$Profile->{'AVATAR_WIDTH'}' class='forminput'>  x   $UserCP::lang->{'height'}   <input type='text' size='3' maxlength='3' name='Avatar_height' value='$Profile->{'AVATAR_HEIGHT'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type="submit" value="$UserCP::lang->{'avatar_url_submit'}" name='URL' class='forminput'></td>
                </tr>
                </form>
~;
}

sub personal_splash_notepad {

return qq~

                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'><span id='usermenu'><u><b><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=NotePad;CODE=00'>$UserCP::lang->{'edit_notepad'}</a></b></u></span><br><br>$UserCP::lang->{'edit_notepad_txt'}</td>
                 </tr>
~;
}

sub email {
                                            my $Profile = shift;
return qq~

<form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
     <input type='hidden' name='act' value='Profile'>
     <input type='hidden' name='CODE' value='04'>
     <input type='hidden' name='s' value='$iB::SESSION'>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlemedium'>� $UserCP::lang->{'email_title'}</td>
                </tr>
   <tr>
        <td align='left' id='category' colspan='2'>$UserCP::lang->{'privacy_settings'}</td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b> $UserCP::lang->{'email_header'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='hide_email' value='1' $Profile->{'HIDE_EMAIL'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='100%'>$UserCP::lang->{'hide_email'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='admin_send' value='1' $Profile->{'ALLOW_ADMIN_EMAILS'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'  width='100%'>$UserCP::lang->{'admin_send'}</td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� $UserCP::lang->{'board_prefs'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='send_full_msg' value='1' $Profile->{'EMAIL_FULL_POST'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='100%'>$UserCP::lang->{'send_full_msg'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='send_once' value='1' $Profile->{'EMAIL_NOTIF'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='100%'>$UserCP::lang->{'send_once'}</td>
                </tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='pm_reminder' value='1' $Profile->{'PM_REMINDER'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='100%'>$UserCP::lang->{'pm_reminder'}</td>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='text' size='3' maxlength='3' name='end_subs' value='$Profile->{'CANCEL_SUBS'}' class='forminput'></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='100%'>$UserCP::lang->{'end_subs'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$UserCP::lang->{'submit_email'}" class='forminput'>
                </td></tr>
                </form>
~;
}

sub personal_avatar {
                                            my $data = shift;
return qq~

                <script langauge='javascript'>
                <!--
                  function showavatar(theURL) {
                    if (document.creator.useravatar.value == '*') {
                        return true;
                    }
                    document.images.useravatars.src=theURL+document.creator.useravatar.options[document.creator.useravatar.selectedIndex].value;
                  }
                //-->
                </script>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlemedium'>� $UserCP::lang->{'avatar_title'}</td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'avatar_sub'} $UserCP::lang->{'avatar_url_allowed'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' align='left' colspan='2' id='category'><b>$UserCP::lang->{'av_current'}</b></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%' valign='middle'>$UserCP::lang->{'this_avatar'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='60%' valign='middle'>$data->{'CUR_AV'}</td>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' valign='left' colspan='2' id='category'><a name='avadir'><b>$UserCP::lang->{'avatar_pre_title'}</b></a></td>
                </tr>
                <form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}' method='post' name='creator_dir'>
                <input type='hidden' name='act'  value='UserCP'>
                <input type='hidden' name='CODE' value='07'>
                <input type='hidden' name='MODE' value='1'>
                <input type='hidden' name='s'    value='$iB::SESSION'>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'><b>$UserCP::lang->{'avatar_dir_title'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>$data->{'AVATAR_DIR'}</td>
                </tr>
                </form>
                <form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}' method='post' name='creator'>
                <input type='hidden' name='act' value='Profile'><input type='hidden' name='CODE' value='10'><input type='hidden' name='s' value='$iB::SESSION'>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'avatar_pre_txt'} <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=Legends&CODE=avatars','HelpCard','200','400','0','1','1','1')"><strong>$UserCP::lang->{'avatar_show_all'}</strong></a></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='top'>$data->{'AVATARS'}     $data->{'SHOW_AVS'}  $UserCP::lang->{'current_avatar'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type="submit" value="$UserCP::lang->{'avatar_pre_submit'}" class='forminput'></td>
                </tr>
                </form>
~;
}

sub settings_skin {
                                                my $skin = shift;
return qq~

                 </tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'><b>$UserCP::lang->{'settings_skin'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_skin_txt'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'>$skin</td>
                 </tr>
~;
}

sub birthday {

return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><b>$UserCP::lang->{'birthday'}</b></td>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>
            <select name='month' class='forminput'>$iB::MEMBER->{'MONTH'}</select>
            <select name='day' class='forminput'>$iB::MEMBER->{'DAY'}</select>
            <select name='year' class='forminput'>$iB::MEMBER->{'YEAR'}</select>
            </td>
            </tr>
~;
}

sub settings_end {
                                            my ($data) = @_;
return qq~

   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� $UserCP::lang->{'settings_display'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_viewsig'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='70%' align='left'>$data->{'SIG'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_viewimg'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'>$data->{'IMG'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_viewava'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='70%' align='left'>$data->{'AVA'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_dopopup'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'>$data->{'POP'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' name='submit' value='$UserCP::lang->{'settings_submit'}' class='forminput'></form></td>
                 </tr>
~;
}

sub account {
                                            my $Profile = shift;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlemedium'>� $UserCP::lang->{'account_title'} $iB::MEMBER->{'MEMBER_NAME'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='left'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'account_text'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'>$UserCP::lang->{'account_email_title'}</td>
                 </tr>
                 <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='form1'>
                 <input type='hidden' name='act' value='Profile'>
                 <input type='hidden' name='CODE' value='06'>
                 <input type='hidden' name='s' value='$iB::SESSION'>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'account_email_txt'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'><input type='text' name='u_email' value='$Profile->{'MEMBER_EMAIL'}' class='forminput'></td>
                 </tr>
                 <tr>
                     <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='center' colspan='2'><input type="submit" name='s_email' value="$UserCP::lang->{'account_email_submit'}" class='forminput'></td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� $UserCP::lang->{'account_pass_title'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'account_pass_old'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><input type='password' name='u_o_pass' value='' class='forminput'></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'account_pass_new'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'><input type='password' name='u_new_pass_1' value='' class='forminput'></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'account_pass_new2'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><input type='password' name='u_new_pass_2' value='' class='forminput'></td>
                 </tr>
                 <tr>
                    <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type="submit" name='s_pass' value="$UserCP::lang->{'account_pass_submit'}" class='forminput'></td>
                 </tr>
                 </form>
~;
}

sub personal_panel {
                            my ($Profile, $sex, $sign) = @_;    my $color_choices = qq~<option style='background-color:#000000;color:#000000' value='#000000'>Black<option style='background-color:#FFFFFF;color:#FFFFFF' value='#FFFFFF'>White<option style='background-color:#FF0000;color:#FF0000' value='#FF0000'>Red<option style='background-color:#0000FF;color:#0000FF' value='#0000FF'>Blue<option style='background-color:#00FFFF;color:#00FFFF' value='#00FFFF'>Light Blue<option style='background-color:#FFFF00;color:#FFFF00' value='#FFFF00'>Yellow<option style='background-color:#00FF00;color:#00FF00' value='#00FF00'>Lime Green<option style='background-color:#32CD32;color:#32CD32' value='#32CD32'>Green<option style='background-color:#FF00FF;color:#FF00FF' value='#FF00FF'>Orchid<option style='background-color:#000080;color:#000080' value='#000080'>Navy<option style='background-color:#008080;color:#008080' value='#008080'>Teal<option style='background-color:#000F22;color:#000F22' value='#000F22'>Dark Navy<option style='background-color:#FF8040;color:#FF8040' value='#FF8040'>Light Orange<option style='background-color:#FF7F00;color:#FF7F00' value='#FF7F00'>Orange<option style='background-color:#CCCCCC;color:#CCCCCC' value='#CCCCCC'>Light Gray<option style='background-color:#A8A8A8;color:#A8A8A8' value='#A8A8A8'>Gray<option style='background-color:#F52887;color:#F52887' value='#F52887'>Pink<option style='background-color:#F660AB;color:#F660AB' value='#F660AB'>Light Pink<option style='background-color:#3BB9FF;color:#3BB9FF' value='#3BB9FF'>Aqua<option style='background-color:#FDD017;color:#FDD017' value='#FDD017'>Light Tan<option style='background-color:#ADA96E;color:#ADA96E' value='#ADA96E'>Khaki<option style='background-color:#E77471;color:#E77471' value='#E77471'>Peach<option style='background-color:#736AFF;color:#736AFF' value='#736AFF'>Purple<option style='background-color:#728FCE;color:#728FCE' value='#728FCE'>Sea Blue<option style='background-color:#810541;color:#810541' value='#810541'>Maroon<option style='background-color:#348781;color:#348781' value='#348781'>Teal<option style='background-color:#48CCCD;color:#48CCCD' value='#48CCCD'>Aqua<option style='background-color:#EE9A4D;color:#EE9A4D' value='#EE9A4D'>Light Tan<option style='background-color:#FA9B3C;color:#FA9B3C' value='#FA9B3C'>Tan<option style='background-color:#8D38C9;color:#8D38C9' value='#8D38C9'>Dark Purple    ~;    $color_choices =~ s!value='$iB::MEMBER->{'POST_FONT_COLOR'}'>!value='$iB::MEMBER->{'POST_FONT_COLOR'}' selected>!ig;
return qq~

<script language="javascript">
<!--
var LocationMax  = "$iB::INFO->{'MAX_LOCATION_LENGTH'}";
var InterestMax  = "$iB::INFO->{'MAX_INTEREST_LENGTH'}";
var SignatureMax = "$iB::INFO->{'MAX_SIG_LENGTH'}";
function CheckLength(Type) {
    LocationLength  = document.REPLIER.Location.value.length;
    InterestLength  = document.REPLIER.Interests.value.length;
    SignatureLength = document.REPLIER.Post.value.length;
    message  = "";
    if (Type == "location") {
        if (LocationMax !=0) {
            message = "$UserCP::lang->{'js_location'}:\\n$UserCP::lang->{'js_max'} " + LocationMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + LocationLength + " $UserCP::lang->{'js_so_far'}.");
    }
    else if (Type == "interest") {
        if (InterestMax !=0) {
            message = "$UserCP::lang->{'js_interests'}:\\n$UserCP::lang->{'js_max'} " + InterestMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + InterestLength + " $UserCP::lang->{'js_so_far'}.");
    }
    else if (Type == "signature") {
        if (SignatureMax !=0) {
            message = "$UserCP::lang->{'js_signature'}:\\n$UserCP::lang->{'js_max'} " + SignatureMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + SignatureLength + " $UserCP::lang->{'js_so_far'}.");
    }
}
function emoticon(theSmilie) {
   //document.REPLIER.Post.value += ' ' + theSmilie + ' ';
   document.REPLIER.Post.focus();
   if (ie) {
       var rng = document.selection.createRange();
       rng.text = ' ' + theSmilie + ' ';
   } else if (ns) {
       var selStart = document.REPLIER.Post.selectionStart;
       var selEnd   = document.REPLIER.Post.selectionEnd;
       var before   = document.REPLIER.Post.value.substring(0, selStart);
       var after    = document.REPLIER.Post.value.substring(selEnd, document.REPLIER.Post.textLength);
       document.REPLIER.Post.value = before + ' ' + theSmilie + ' ' + after;
   } else {
       document.REPLIER.Post.value += ' ' + theSmilie + ' ';
   }
   document.REPLIER.Post.focus();
}
function ValidateProfile() {
    LocationLength  = document.REPLIER.Location.value.length;
    InterestLength  = document.REPLIER.Interests.value.length;
    SignatureLength = document.REPLIER.Post.value.length;
    errors = "";
    if (LocationMax !=0) {
        if (LocationLength > LocationMax) {
            errors = "$UserCP::lang->{'js_location'}:\\n$UserCP::lang->{'js_max'} " + LocationMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + LocationLength;
        }
    }
    if (InterestMax !=0) {
        if (InterestLength > InterestMax) {
            errors = errors + "\\n$UserCP::lang->{'js_interests'}:\\n$UserCP::lang->{'js_max'} " + InterestMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + InterestLength;
        }
    }
    if (SignatureMax !=0) {
        if (SignatureLength > SignatureMax) {
            errors = errors + "\\n$UserCP::lang->{'js_signature'}:\\n$UserCP::lang->{'js_max'} " + SignatureMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + SignatureLength;
        }
    }
    if (errors != "") {
        alert(errors);
        return false;
    } else {
        return true;
    }
}
//-->
</script>

<script language='javascript' type='text/javascript' src='$iB::INFO->{'IMAGES_URL'}/ikoncode.js'>
</script>
<form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='REPLIER' onSubmit='return ValidateProfile()'>
     <input type='hidden' name='act' value='Profile'>
     <input type='hidden' name='CODE' value='02'>
     <input type='hidden' name='s' value='$iB::SESSION'>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlemedium'>� $UserCP::lang->{'profile_title'}</td>
                </tr>
   <tr>
        <td align='left' id='category' colspan='2'>$iB::MEMBER->{'MEMBER_NAME'}&nbsp;$UserCP::lang->{'profile_header'}</td>
   </tr>
                <!--{MEMBERTITLE}-->
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%'>$UserCP::lang->{'membernamereal'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%'><input type='text' size='40' maxlength='40' name='MEMBER_NAME_R' value='$Profile->{'MEMBER_NAME_R'}' class='forminput'></td>
                </tr>
                <!--{BIRTHDAY}-->
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$UserCP::lang->{'settings_sex_txt'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$sex</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$UserCP::lang->{'photo'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='120' name='Photo' value='$Profile->{'PHOTO'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>$UserCP::lang->{'website'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='1200' name='WebSite' value='$Profile->{'WEBSITE'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$UserCP::lang->{'location'}<br>(<a href='javascript:CheckLength("location");'>$UserCP::lang->{'check_length'}</a>)</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' name='Location' value='$Profile->{'LOCATION'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='top'>$UserCP::lang->{'interests'}<br>(<a href='javascript:CheckLength("interest");'>$UserCP::lang->{'check_length'}</a>)</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><!--NoCompression//--><textarea cols='60' rows='10' wrap='soft' name='Interests' class='textinput'>$Profile->{'INTERESTS'}</textarea><!--/NoCompression//--></td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� Your contact details</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%'>$UserCP::lang->{'icq'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='20' name='ICQNumber' value='$Profile->{'ICQNUMBER'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>$UserCP::lang->{'aol'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='30' name='AOLName' value='$Profile->{'AOLNAME'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$UserCP::lang->{'yahoo'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='30' name='YahooName' value='$Profile->{'YAHOONAME'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>$UserCP::lang->{'msn'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='30' name='MSNName' value='$Profile->{'MSNNAME'}' class='forminput'></td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� Signature setup and Post color</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' valign='top' align='left'>$UserCP::lang->{'signature'}<br /><br />$sign</td>
                </tr>
                <tr>
                <td rowspan='2' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>$UserCP::lang->{'signature'}<br>(<a href='javascript:CheckLength("signature");'>$UserCP::lang->{'check_length'}</a>)<br><br>
                    <table cellspacing='1' cellpadding='3' border='0' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' style="border-width:1px; border-style:inset; width:125px" align='left'>
                    <tr>
                    <td colspan='$iB::INFO->{'EMO_PER_ROW'}' align='center'>$Post::lang->{'click_smilie'}</td>
                    </tr>
                    <!--THE SMILIES-->
                    </table>
                </td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <input type='button' accesskey='b' value=' B '       onClick='IBCbold()'   class='forminput' title="BOLD: [Control / Alt] + b"      name='bold'   style="font-weight:bold">
                <input type='button' accesskey='i' value=' I '       onClick='IBCitalic()' class='forminput' title="ITALIC: [Control / Alt] + i"    name='italic' style="font-style:italic">
                <input type='button' accesskey='u' value=' U '       onClick='IBCunder()'  class='forminput' title="UNDERLINE: [Control / Alt] + u" name='under' style="text-decoration:underline">
                <input type='button' accesskey='h' value=' http:// ' onClick='IBCurl()'    class='forminput' title="HYPERLINK: [Control / Alt] + h" style="text-decoration:underline;color:blue">
                <input type='button' accesskey='e' value='  @  '     onClick='IBCemail()'  class='forminput' title="EMAIL: [Control / Alt] + e"     style="text-decoration:underline;color:blue">
                <input type='button' accesskey='q' value=' Quote '   onClick='IBCquote()'  class='forminput' title="QUOTE: [Control / Alt] + q" name='quote'>
                <input type='button' accesskey='c' value=' Code '    onClick='IBCcode()'   class='forminput' title="CODE: [Control / Alt] + c"  name='code'>
                $img_button<br><font class='misc'>$Post::lang->{'buttons_js'}</font>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><!--NoCompression//--><textarea cols='60' rows='10' wrap='soft' name='Post' class='textinput'>$Profile->{'SIGNATURE'}</textarea><!--/NoCompression//--></td>
                </tr>
<!-- added by kevaholic00 -->
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='top' width='30%'>$UserCP::lang->{'post_font_color'}<br>$UserCP::lang->{'post_font_color_desc'}
                <br><br>
                <select style='width:200px' class='forminput' onchange="this.form.POST_FONT_COLOR.value=this.options[this.selectedIndex].value">
                $color_choices
                </select>
                </td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>
                <input type='text' class='forminput' size='12' name='POST_FONT_COLOR' value='$iB::MEMBER->{'POST_FONT_COLOR'}' maxlength='15'>
                </td>
                </tr>
<!--/added by kevaholic00 -->
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='center' colspan='2'>
                <input type="submit" value="$UserCP::lang->{'submit_profile'}" class='forminput'>
                </td></tr>
                </form>
~;
}

sub member_title {

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$UserCP::lang->{'member_title'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='120' name='member_title' value='$iB::MEMBER->{'MEMBER_TITLE'}' class='forminput'></td>
                </tr>
~;
}

sub subs_header {

return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlemedium'>� $UserCP::lang->{'subs_title'} $iB::MEMBER->{'MEMBER_NAME'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'subs_text'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'><b>$UserCP::lang->{'subs_header'}</b></td>
                 </tr>
                 <tr>
                 <td valign='top' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' >
                 <table cellpadding='4' cellspacing='1' align='center' width='100%' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='5%'> </td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='40%'>$UserCP::lang->{'subs_topic'}</td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='5%'>$UserCP::lang->{'subs_replies'}</td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='5%'>$UserCP::lang->{'subs_view'}</td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='20%'>$UserCP::lang->{'subs_last_post'}</td>
                   <td id='titlemedium' bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='10%'>$UserCP::lang->{'subs_left'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='6'> &nbsp;</td>
   </tr>
~;
}

sub settings_header {
                                            my ($Profile, $time_select, $time, $lang_select) = @_;
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
     <input type='hidden' name='act' value='Profile'>
     <input type='hidden' name='CODE' value='05'>
     <input type='hidden' name='s' value='$iB::SESSION'>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlemedium'>�&nbsp;$UserCP::lang->{'settings_title'} $iB::MEMBER->{'MEMBER_NAME'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='left'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'settings_text'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='category'>$UserCP::lang->{'settings_time'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_time_txt'}</b></font>   <span id='highlight'>$time</span></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='70%' align='left'>$time_select   $UserCP::lang->{'settings_hour'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� $UserCP::lang->{'settings_lang'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_lang_txt'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'>$lang_select</td>
                 </tr>
~;
}

sub Menu_bar {
                                                my $Nav_color = shift;
return qq~

      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='6'>� Your Menu</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='6'>&nbsp; </td>
   </tr>
        <tr>
            <td bgcolor='$Nav_color->{'splash'}'    id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=00;MID=$iB::COOKIES->{$iB::INFO->{'COOKIE_ID'}.'iBMemberID'}'><strong>$UserCP::lang->{'splash'}</strong></a></td>
            <td bgcolor='$Nav_color->{'personal'}'  id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01'><strong>$UserCP::lang->{'personal'}</strong></a></td>
            <td bgcolor='$Nav_color->{'email'}'     id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=02'><strong>$UserCP::lang->{'email'}</strong></a></td>
            <td bgcolor='$Nav_color->{'subs'}'      id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=03'><strong>$UserCP::lang->{'subs'}</strong></a></td>
            <td bgcolor='$Nav_color->{'settings'}'  id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=04'><strong>$UserCP::lang->{'settings'}</strong></a></td>
            <td bgcolor='$Nav_color->{'account'}'   id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=05'><strong>$UserCP::lang->{'account'}</strong></a></td>
        </tr>
   <tr>
        <td align='center' id='category' colspan='6'> &nbsp;</td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
<br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
<tr>
~;
}

sub splash {
                                            my $member = shift;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlemedium'>� $UserCP::lang->{'welcome'} $iB::MEMBER->{'MEMBER_NAME'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'welcome_text'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� $UserCP::lang->{'stats_header'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='20%'><b>$UserCP::lang->{'email_address'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'>$member->{'MEMBER_EMAIL'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='20%'><b>$UserCP::lang->{'number_posts'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'>$member->{'MEMBER_POSTS'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='20%'><b>$UserCP::lang->{'registered'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'>$member->{'DATE_REGISTERED'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='20%'><b>$UserCP::lang->{'daily_average'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'>$member->{'DAILY_AVERAGE'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='20%'><b>$UserCP::lang->{'member_rating'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'>$member->{'MEMBER_RATING'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='20%'><b>$UserCP::lang->{'member_rating_count'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'>$member->{'MEMBER_RATING_COUNT'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� $UserCP::lang->{'quick_help'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$UserCP::lang->{'personal'}:</b> $UserCP::lang->{'personal_help'}<br><br><b>$UserCP::lang->{'email'}:</b> $UserCP::lang->{'email_help'}<br><br><b>$UserCP::lang->{'subs'}:</b> $UserCP::lang->{'subs_help'}<br><br><b>$UserCP::lang->{'settings'}:</b> $UserCP::lang->{'settings_help'}<br><br><b>$UserCP::lang->{'account'}:</b> $UserCP::lang->{'account_help'}</td>
                 </tr>
~;
}

sub subs_row {
                                        my $data = shift;if ($data->{'TOPIC_ID'} eq '') {$redir = "act=SF;f=$data->{'FORUM_ID'}";} else {$redir = "act=ST;f=$data->{'FORUM_ID'};t=$data->{'TOPIC_ID'}";}
return qq~

                 <tr>
                   <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' align='center' width='5%'><img src="$data->{'TOPIC_ICON'}" border='0'></td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align='left'><span id='linkthru'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?$redir'>$data->{'TOPIC_TITLE'} : $data->{'FORUM_NAME'}</a></span><br>$UserCP::lang->{'subs_start'} $data->{'DATE_START'} [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=UserCP;CODE=06;ID=$data->{'ID'}'>$UserCP::lang->{'subs_cancel'}</a> ]</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align='center'>$data->{'TOPIC_POSTS'}</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_FOUR'}" align='center'>$data->{'TOPIC_VIEWS'}</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" align='left'>$data->{'TOPIC_LAST_DATE'}<br>$UserCP::lang->{'subs_by'} $data->{'LAST_POSTER'}</td>
                   <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" align='left'><b>$data->{'DAYS_LEFT'}</b></td>
                 </tr>
~;
}

sub personal_splash_av {

return qq~

                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><span id='usermenu'><b><u><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01;MODE=1'>$UserCP::lang->{'avatar_ops'}</a></u></b></span><br><br>$UserCP::lang->{'avatar_ops_txt'}</td>
                 </tr>
~;
}

sub personal_avatar_upl {
                            my $allowed_ext = shift;
return qq~

   <tr>
        <td align='center' id='category' colspan='2'> &nbsp;</td>
   </tr>
 </table>
 </td>
 </tr>
 </table>
 <br />
                <form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}' method='post' enctype='multipart/form-data'>
                <input type='hidden' name='act' value='Profile'><input type='hidden' name='CODE' value='12'><input type='hidden' name='s' value='$iB::SESSION'>
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>� $UserCP::lang->{'avatar_upload_title'}</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'>&nbsp; </td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'avatar'}<br>$UserCP::lang->{'avatar_upload_ext'}<br><b>$allowed_ext</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='file' size='55' name='avatar_filename' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type="submit" value="$UserCP::lang->{'avatar_upl_submit'}" class='forminput'></td>
                </tr>
                </form>
~;
}



1;
