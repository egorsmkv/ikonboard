package PostersView;

use strict;

sub start {
    
return qq~
<center>
                <table width="100%" height="180" border="0" cellpadding='0' cellspacing='0' >
                <tbody>
                    <tr>
                        <td valign="middle" align="center">
                        <table cellpadding='2' cellspacing='1' border="1" width="90%" bgcolor="$iB::SKIN->{'MISCBACK_ONE'}">
                        <tbody>
                        <tr>
                        <td align="left" bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium'><b>$Pos::lang->{'poster'}</b></td>
                        <td align="center" bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium'><b>$Pos::lang->{'posts'}</b></td>
                        </tr>
<tr>
<td id='category' colspan='2'>&nbsp;</td>
</tr>
~;
}

sub end {
        my ($forum, $topic) = @_;   
return qq~
<tr>
<td id='category' colspan='2'>&nbsp;</td>
</tr>
    </tbody>
                </table>
                </td>
                </tr>
                </tbody>
                </table>
                <table cellpadding='3' cellspacing='1' border='0' width='100%' height="20" bgcolor="$iB::SKIN->{'MISCBACK_ONE'}" align='center'>
                    <tr>
                        <td align='center'><a href="javascript:opener.location=('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$forum;t=$topic'); self.close();"><font size=1>[$Pos::lang->{'close_win'}]</font></a></td>
                    </tr>
                </table>
            </center>
~;
}

sub do_row {
        my ($id, $name, $total) = @_;   
return qq~
    <tr>
                <td width="90%" valign="middle" align="left" bgcolor="$iB::SKIN->{'MISCBACK_ONE'}"><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$id" target="_blank">$name</a></td>
                <td valign="middle" align="center" bgcolor="$iB::SKIN->{'MISCBACK_TWO'}">$total</td>
                </tr>
~;
}



1;