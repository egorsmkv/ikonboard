package LostpassView;



sub unlock_box {
    
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
     <input type='hidden' name='act' value='LostPass'>
     <input type='hidden' name='CODE' value='02'>
     <table cellpadding=0 cellspacing='1' border=0 width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='0' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlelarge'>$Lostpass::lang->{'nav_title'}</td>
                </tr>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$Lostpass::lang->{'unlock_text'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='50' name='SID' value='' class='foruminput'></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' name='submit' value='$Lostpass::lang->{'submit_b'}' class='forminput'></td>
                 </tr>
                 </table>
                 </td></tr></table></form>
~;
}

sub email_sent {
    my ($title, $text) = @_;
return qq~

     <table cellpadding=0 cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='1' border=0 width=100%>
                <tr>
                <td bgcolor=$iB::SKIN->{'TITLEBACK'} align='left' colspan='2' id='titlelarge'>$Lostpass::lang->{'nav_title'}</td>
                </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='usermenu'><b>$title</b></td>
                 </tr>
                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' valign='middle' align='left'><b>$text</b></td>
                 </tr>
                 </table>
                 </td></tr></table>
~;
}

sub splash {
    
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
     <input type='hidden' name='act' value='LostPass'>
     <input type='hidden' name='CODE' value='01'>
     <table cellpadding=0 cellspacing='0' border=0 width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlelarge'>&raquo; $Lostpass::lang->{'nav_title'}</td>
                </tr>
<tr>
<td id='category' colspan='2'>&nbsp;</td>
</tr>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'><b>$Lostpass::lang->{'dont_email'}</b><br>$Lostpass::lang->{'text_a'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='category'><b>$Lostpass::lang->{'title'}</b></td>
                 </tr>
                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' valign='middle' align='left'><b>$Lostpass::lang->{'step_a'}</b></td>
                 </tr>
                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' valign='middle' align='left' id='highlight'>$Lostpass::lang->{'step_a_txt'} �� <input type='text' name='u_membername' class='forminput'></td>
                 </tr>
                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' valign='middle' align='left'>
                    <b>$Lostpass::lang->{'step_b'}</b>
                    <br>$Lostpass::lang->{'step_b_txt'}
                    <br><br><b>$Lostpass::lang->{'step_c'}</b>
                    <br>$Lostpass::lang->{'step_c_txt'}
                    <br><br><b>$Lostpass::lang->{'step_d'}</b>
                    <br>$Lostpass::lang->{'step_d_txt'}
                 </td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center' id='category'><input type='submit' name='submit' value='$Lostpass::lang->{'submit_form'}' class='forminput'></td>
                 </tr>
<tr>
<td id='titlemedium' colspan='2'>&nbsp;</td>
</tr>
                 </table>
                 </td></tr></table></form>
<br />
~;
}



1;