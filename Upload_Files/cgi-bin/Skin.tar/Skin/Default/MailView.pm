package MailView;

use strict;




sub send_form {
    my $data = shift;
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION" method="post" name='REPLIER'>
     <input type='hidden' name='act' value='Mail'>
     <input type='hidden' name='CODE' value='01'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     <input type='hidden' name='to' value='$data->{'TO'}'>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlelarge'>&raquo; $MailMember::lang->{'send_title'}</td>
                </tr>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='category'><b>$MailMember::lang->{'send_email_to'} $data->{'NAME'}</b></td>
                 </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='20%' valign='top'><b>$MailMember::lang->{'subject'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><input type='text' name='subject' value='' size='50' maxlength='50' class='forminput'>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='20%' valign='top'><b>$MailMember::lang->{'message'}</b><br><br>$MailMember::lang->{'msg_txt'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><textarea cols='60' rows='12' wrap='soft' name='message' class='textinput'></textarea>
                </td>
                </tr>
                <tr>
                <td id='category' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$MailMember::lang->{'submit_send'}" class='forminput'>
                </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'>&nbsp; </td>
     </tr>
               </table>
            </td>
         </tr>
      </table>
      </form>
~;
}

sub show_address {
    my $data = shift;
return qq~

     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='titlemedium'>&raquo; $MailMember::lang->{'send_email_to'} $data->{'NAME'}</td>
                 </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='category'> </td>
     </tr>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><img src='$iB::INFO->{'IMAGES_URL'}/images/pb_email.gif' border='0' height='18' width='27' alt=''></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$MailMember::lang->{'show_address_text'}</td>
                 </tr>
                    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>�</td>
                    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b><a href="mailto:$data->{'ADDRESS'}" class='misc'>$MailMember::lang->{'send_email_to'} $data->{'NAME'}</a></b></td>
                 </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='category'>&nbsp; </td>
     </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> &nbsp;</td>
     </tr>
               </table>
            </td>
         </tr>
      </table>
~;
}

sub sent_screen {
    my ($member_name) = @_;
return qq~

     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>&raquo; $MailMember::lang->{'email_sent'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='category'>$MailMember::lang->{'email_sent'}</td>
                 </tr>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='center'><img src='$iB::INFO->{'IMAGES_URL'}/images/msg_sent.gif' border='0' height='32' width='32' alt=''></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle'><b>$MailMember::lang->{'email_sent_txt'} $member_name</td>
                 </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='category'>&nbsp; </td>
     </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'>&nbsp; </td>
     </tr>
                </table>
            </td>
         </tr>
      </table>
~;
}



1;