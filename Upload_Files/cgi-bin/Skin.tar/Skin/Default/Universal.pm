package Universal;




sub Member_no_usepm_bar {
                                                                            my ($admin_link) = @_;
return qq~

     <!-- Cgi-bot Begin Panel-->
    <br>
    <table cellpadding='4' cellspacing='0' border='0'  width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr id='controlpanel'>
            <td bgcolor="$iB::SKIN->{'USER_BAR_BACK'}" valign='middle' align='left'>&raquo; <strong>$Universal::lang->{'welcome'} <b>$iB::MEMBER->{'MEMBER_NAME'}</b></strong><br>[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=00;MID=$iB::COOKIES->{$iB::INFO->{'COOKIE_ID'}.'iBMemberID'}'>$Universal::lang->{'your_cp'}</a> $admin_link :: <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Login;CODE=02;s=$iB::SESSION'> $Universal::lang->{'log_out'}</a> :: <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Search;CODE=03">$Universal::lang->{'new_posts'}</a> ]</td>
        </tr>
    </table>
    <!-- Cgi-bot End Panel -->
~;
}

sub admin_link {

return qq~

 :: ( <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;CP=1 'target="_blank">$Universal::lang->{'admin_cp'}</a> ) :: ( <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP'>$Universal::lang->{'mod_cp'}</a> )
~;
}

sub Guest_bar {

return qq~

    <!-- Cgi-bot Begin Panel-->
    <br>
    <table cellpadding='4' cellspacing='1' border='0'  width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr id='controlpanel'>
            <td bgcolor="$iB::SKIN->{'USER_BAR_BACK'}" valign='middle' align='left'>&raquo; <strong>$Universal::lang->{'guest_stuff'}</strong><br>[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Login;CODE=00'>$Universal::lang->{'log_in'}</a> :: <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Reg;CODE=00'>$Universal::lang->{'register'}</a> ]</td>
        </tr>
    </table>
    <!-- Cgi-bot End Panel -->
~;
}

sub start_nav {

return qq~

        <!-- Cgi-bot Begin Navigation -->
        <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'NAV_BORDER'}' align='center'>
            <tr>
                <td>
                    <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                        <tr>
                            <td bgcolor="$iB::SKIN->{'NAV_BACK'}" valign='middle' id='nav'>$iB::SKIN->{'F_NAV'}
~;
}

sub BoardHeader {
                                                                                    my $time = shift;
return qq~

    <!-- Cgi-bot Begin Header -->
    <a name="head"></a>
    <table cellpadding='0' cellspacing='0' border='0' width="$iB::SKIN->{'TABLE_WIDTH'}" align='center'>
        <tr>
            <td align='$iB::SKIN->{'LOGO_ALIGN'}' valign='middle' width='70%' rowspan='2'> <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" title="$Universal::lang->{'you_last_visit'} $time->{'last'}, $Universal::lang->{'you_running_time'} $time->{'current'}"><img src="$iB::INFO->{'IMAGES_URL'}/images/$iB::SKIN->{'BOARD_LOGO'}" border=0 alt=''></a></td>
            <td nowrap align='center' valign='bottom' width='30%' id='nav'><br><a href='$iB::INFO->{'HOME_URL'}'>$iB::INFO->{'HOME_NAME'}</a> :: <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}">$iB::INFO->{'BOARDNAME'}</a><br>$iB::INFO->{'BOARD_DESC'}</td>
        </tr>
        <tr>
            <td nowrap align='center' valign='middle'>
            <br><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Search;CODE=00;$iB::APPEND_SEARCH">$iB::SKIN->{'F_SEARCH'}</a>
                <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Members">$iB::SKIN->{'F_MEMBERS'}</a>
                <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Help;CODE=00">$iB::SKIN->{'F_HELP'}</a>
            </td>
        </tr>
    </table>
    <!-- Cgi-bot End Header -->
~;
}

sub Error {
                                                                                 my $message = shift;
return qq~

     <br><br>
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' id='titlemedium'>&raquo; $iBoard::lang->{'error_title'}</td>
                </tr>
   <tr>
        <td align='center' id='category'> </td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center'>
                $message
                <br><br>
                 $iBoard::lang->{'log_in_msg'}
                 <br><br>
                 <br><center><strong>� � <a href='javascript:history.go(-1);'>$iBoard::lang->{'error_back'}</a></strong></center>
                </td>
                </tr>
   <tr>
        <td align='center' id='category'> </td>
   </tr>
                <tr>
                <td align='center' id='titlemedium'>
                    <b>$iBoard::lang->{'error_not_registered'} <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=00' class='misc'>$iBoard::lang->{'reg_link'}</a>
                    | $iBoard::lang->{'forgot_pass'} <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=LostPass;CODE=00' class='misc'>$iBoard::lang->{'pass_link'}</a>
                    | $iBoard::lang->{'log_in'} <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Login;CODE=00' class='misc'>$iBoard::lang->{'log_in_now'}</a></b>
                </td>
                </tr>
                </table>
            </td>
         </tr>
      </table>
<br />
<br />
~;
}

sub Member_bar {
                                                                                my ($msg, $admin_link) = @_;
return qq~

    <!-- Cgi-bot Begin Panel-->
    <br>
    <table cellpadding='4' cellspacing='0' border='0'  width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr id='controlpanel'>
            <td bgcolor="$iB::SKIN->{'USER_BAR_BACK'}" valign='bottom' align='left'>&raquo; <strong>$Universal::lang->{'welcome'} <b>$iB::MEMBER->{'MEMBER_NAME'}</b></strong><br>[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=00;MID=$iB::COOKIES->{$iB::INFO->{'COOKIE_ID'}.'iBMemberID'}'>$Universal::lang->{'your_cp'}</a> $admin_link :: <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Login;CODE=02;s=$iB::SESSION'>$Universal::lang->{'log_out'}</a> :: <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=NotePad;CODE=00">$Universal::lang->{'notes'}</a> :: <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Search;CODE=03">$Universal::lang->{'new_posts'}</a> ]</td>
            <td bgcolor="$iB::SKIN->{'USER_BAR_BACK'}" valign='middle' align='right'>$msg->{'ICON'}&nbsp;&nbsp;<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Msg;CODE=00;s=$iB::SESSION'>$Universal::lang->{'your_messenger'}</a> (<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Msg;CODE=01;s=$iB::SESSION'>$msg->{'TEXT'}</a>)</td>
        </tr>
    </table>
    <!-- Cgi-bot End Panel -->
~;
}

sub Redirect {
                                                                                    my ($Text, $Url) = @_;    $Url =~ s!;!&!g;
return qq~

<html>
<head>
<title>$Universal::lang->{'stand_by'}</title>
<meta http-equiv="refresh" content="0; url=$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}$Url">
<link type="text/css" href="$iB::INFO->{'IMAGES_URL'}/ikonboard.css" rel="stylesheet">
</head>
<body bgcolor='$iB::SKIN->{'HTML_BACK_COL'}'>
<table cellpadding='0' cellspacing='0' border='0' width="$iB::SKIN->{'TABLE_WIDTH'}" align='center' height='85%'>
  <tr align='center' valign='middle'>
    <td>
    <table cellpadding='10' cellspacing='0' border='0' width="80%" align='center'>
    <tr>
       <td valign='middle' align='center' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' id='redirect'>
        $Universal::lang->{'thanks'}, $Text
        <br><br>
        $Universal::lang->{'transfer_you'}
        <br><br>
        (<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}$Url'>$Universal::lang->{'dont_wait'}</a>)
       </td>
    </tr>
    </table>
    </td>
  </tr>
</table>
</body>
</html>
~;
}

sub end_nav {

return qq~

                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <br>
        <!-- Cgi-bot End Navigation -->
~;
}

sub PM_popup {

return qq~

  <script language="JavaScript">
  <!--
    newmessage_q = confirm("$Universal::lang->{'popup_one'}");
    if (newmessage_q == true) {
       window.location="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Msg;CODE=01;s=$iB::SESSION";
    } else {
        newWindow.location.replace(url);
    }
  //-->
  </script>
~;
}

sub Offline {
                                                                                my $data = shift;
return qq~

<html>
<head>
<title>iB::$Universal::lang->{'offline_title'}</title>
<link type="text/css" href="$iB::INFO->{'IMAGES_URL'}/ikonboard.css" rel="stylesheet">
</head>
<body bgcolor='$iB::SKIN->{'HTML_BACK_COL'}'>
<form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}' method='post'>
<input type='hidden' name='s' value='$iB::SESSION'>
<br />
<br />
<br />
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>&raquo; Board Off-line</td>
   </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
    <tr>
       <td valign='middle' colspan=2 align='center' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' id='redirect'>
        <b>$Universal::lang->{'offline'}</b>
         <br><br>
         $data
       </td>
    </tr>
    <!-- Log in -->
    <tr>
    <td colspan=2 bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' id='category' align='left'>
    <b>$Universal::lang->{'admin_login'}</b>
    </td>
    </tr>
    <tr>
    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'><b>$Universal::lang->{'name'}</b></td>
    <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><input type='text' class='forminput' name='UserName' value=""></td>
    </tr>
    <tr>
    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'><b>$Universal::lang->{'pass'}</b></td>
    <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><input type='password' class='forminput' name='PassWord' value=""></td>
    </tr>
    <tr>
    <td colspan='2'  id='category' align='center'><input type='submit' value='$Universal::lang->{'submit_li'}'></td>
    </tr>
    <!-- End log in -->
   <tr>
        <td align='center' id='titlemedium' colspan='2'> </td>
   </tr>
    </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>
~;
}



1;
