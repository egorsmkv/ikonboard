package ForwardView;



sub send_form {
	my $data = shift;
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION" method="post" name='REPLIER'>
     <input type='hidden' name='act'  value='Forward'>
     <input type='hidden' name='CODE' value='01'>
     <input type='hidden' name='s'    value='$iB::SESSION'>
     <input type='hidden' name='st'   value='$iB::IN{'st'}'>
     <input type='hidden' name='f'    value='$iB::IN{'f'}'>
     <input type='hidden' name='t'    value='$iB::IN{'t'}'>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>&raquo; $Forward::lang->{'title'}</td>
                </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='category'> </td>
     </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'  width='30%' valign='top'><b>$Forward::lang->{'logged_in'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><b>$iB::MEMBER->{'MEMBER_NAME'}</b></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='30%' valign='top'><b>$Forward::lang->{'to_name'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'><input type='text' class='forminput' name='to_name' value='' size='30' maxlength='100'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='30%' valign='top'><b>$Forward::lang->{'to_email'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'><input type='text' class='forminput' name='to_email' value='' size='30' maxlength='100'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'  width='30%' valign='top'><b>$Forward::lang->{'subject'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><input type='text' class='forminput' name='subject' value='$data->{'SUBJECT'}' size='30' maxlength='120'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='30%' valign='top'><b>$Forward::lang->{'message'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><textarea cols='60' rows='12' wrap='soft' name='message' class='textinput'>$data->{'BODY_TEXT'}</textarea>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2' ID='category'>
                <input type="submit" value="$Forward::lang->{'submit_send'}" class='forminput'>
                </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
               </table>
            </td>
         </tr>
      </table>
      </form>
~;
}



1;