package TsearchView;

sub Page_Links {
    my ($pages, $Data) = @_;
return qq~
<table border='0' cellpadding='0' cellspacing='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
  <tr>
    <td>
    <table border='0' cellpadding='5' cellspacing='1' width='100%' align='center'>
      <tr>
        <td align='left'>$pages $Data</td>
        <td align='right'>$Tsearch::lang->{'showing_results'}</td>
      </tr>
    </table>
    </td>
  </tr>
</table>
~;
}

sub SearchInfo {
return qq~
<br>
<table border='0' cellpadding='5' cellspacing='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
  <tr>
    <td id='titlemedium' width='100%' align='left'>$Tsearch::lang->{'search_results'}</td>
  </tr>
</table>
~;
}

sub RenderRow {
    my ($searchposts, $forumid, $topicid, $mem_tot, $TOPIC, $pagenumber, $keywordsoutput) = @_;
return qq~
<br>
<table border='0' cellpadding='0' cellspacing='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor="$iB::SKIN->{'TABLE_BORDER_COL'}" align='center'>
    <tr>
        <td>
            <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                    <td bgcolor="$iB::SKIN->{'MISCBACK_TITLE'}" align='left' colspan='2' id='titlemedium'>$searchposts->{'POST_DATE'}</td>
                </tr>
                <tr>
                    <td bgcolor="$iB::SKIN->{'MISCBACK_ONE'}" align='left' width='50%'>$searchposts->{'POST_ICON'} $searchposts->{'RATINGS'} <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$forumid;t=$topicid;st=$pagenumber;hl=$keywordsoutput;#entry$searchposts->{'POST_ID'}">$TOPIC->{'TOPIC_TITLE'}</a></font>
                    <br>$Tsearch::lang->{'posted_by'} <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$searchposts->{'AUTHOR'}" >$mem_tot->{'MEMBER_NAME'}</a>
                    </td> 
                    <td bgcolor="$iB::SKIN->{'MISCBACK_ONE'}" align='right' width='50%'>
                    $Tsearch::lang->{'replies'} <b>$TOPIC->{'TOPIC_POSTS'}</b><br>$Tsearch::lang->{'views'} <b>$TOPIC->{'TOPIC_VIEWS'}</b>
                    </td>
                </tr>
                <tr>
                    <td bgcolor="$iB::SKIN->{'MISCBACK_ONE'}" colspan='2' align='left' width='100%'>$searchposts->{'POST'}</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
~;
}

sub PageBottom {
    my ($pages, $Data) = @_;
return qq~
<br>
<table border='0' cellpadding='0' cellspacing='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
  <tr>
    <td>
    <table border='0' cellpadding='5' cellspacing='1' width='100%' align='center'>
      <tr>
        <td align='left'>$pages $Data</td>
        <td align='right'>$Tsearch::lang->{'showing_results'}</td>
      </tr>
    </table>
    </td>
  </tr>
</table>
~;
}


1;