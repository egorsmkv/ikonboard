package LegendsView;

use strict;
















sub ibc_row {
		my $data = shift;
return qq~
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$data->{'TYPE'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$data->{'USED'}</td>
              </tr>
~;
}

sub end_table {
	
return qq~

            <!-- End content Table -->
            </table>
            </td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2'>&nbsp;</td>
            </tr>
            </table>
~;
}

sub emo_row {
		my $data = shift;
return qq~
<script language="javascript">
<!--
function emoticon(theSmilie) {
opener.document.REPLIER.Post.value += ' ' + theSmilie + ' ';
 }
-->
</script>             
            <tr>
              <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'><b>$data->{'TYPE'}</b></td>
              <td name="theSmilie" bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'><a href="javascript:;" onClick="emoticon('$data->{'TYPE'}');this.blur();return false"><img src="$iB::INFO->{'EMOTICONS_URL'}/$data->{'USED'}" border="0" valign="middle" alt=''>
            </tr>
~;
}

sub ava_row {
		my $data = shift;
return qq~
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'><b>$data->{'TYPE'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'><img src="$iB::INFO->{'AVATARS_URL'}/$data->{'USED'}" border="0" valign="middle" alt=''></td>
              </tr>
~;
}

sub start_table {
		my ($type, $used) = @_;
return qq~
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center'><b>$type</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center'><b>$used</b></td>
              </tr>
~;
}

sub card_header {
		my ($title, $text) = @_;
return qq~
       <table cellpadding='0' cellspacing='0' border='0' width='100%' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='4' cellspacing='0' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' align='center' id='titlemedium'>$Legends::lang->{'help_card'}: $title</td>
                </tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='center'>$text</td>
~;
}



1;