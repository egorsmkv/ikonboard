package ModCPView;

sub header_sep {

return qq~
</table>
</td>
</tr>
</table>
<br>
<table cellspacing='0' cellpadding='0' border='0' width='100%'
align='center'>
<tr>
<td bgcolor="$iB::SKIN->{'TABLE_BORDER_COL'}">
<table cellspacing='1' cellpadding='4' border='0' width='100%'
align='center'>
~;
}


sub show_move_results {
                    my $data = shift;
return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_topic_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_topic_d_left'} $data->{'leave'}<br><br>
                $ModCP::lang->{'a_topic_moved'} $data->{'move'}<br><br>
            </td>
            </tr>
~;
}

sub topic_footer {

    return qq~

        <tr>
          <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='4' align='center'><input type='submit' value='$ModCP::lang->{'process_records'}' class='forminput'></td>
        </tr>
       </table>
      </td>
     </tr>
    </table>
~;
}

sub show_set_forum {
                    my $data = shift;       my $choice = $ModCP::lang->{'set_pm'};      if ($data->{'CHOICE'} eq '1') {         $choice = $ModCP::lang->{'set_email'};      }       if ($data->{'WHENE'} eq '1') {          $choice .= " / $ModCP::lang->{'once'}";     } else {            $choice .= " / $ModCP::lang->{'all'}";      }
return qq~

     <tr>
       <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="left" valign='middle'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$data->{'FORUM_ID'}">$data->{'FORUM_NAME'}</a></td>
       <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><span id='highlight'>$choice</span></td>
       <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><span id='linkthru'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'MEMBER_ID'}">$data->{'MEMBER_NAME'}</a></span></td>
     </tr>
~;
}

sub forum_rules_applied {

return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'forum_rules_title'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'forum_rules_txt'}
            </td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
            $ModCP::lang->{'forum_rules_applied'}
            </td>
            </tr>

~;
}

sub topic_form_header {
                my $count = shift;
return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'q_topics'} $count</td>
            </tr>
~;
}

sub topic_form {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='topic_search'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' name='TOPICS' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
~;
}

sub render_watched {
                    my $data = shift;
return qq~

                    <tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'>$ModCP::lang->{'ss_topic_title'} <b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'TOPIC'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$data->{'TOPIC'}->{'TOPIC_TITLE'}</a></b></td>
                    </tr>
            <tr><td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>
                        <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                        <tr>
                          <td valign='top' width='100%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$ModCP::lang->{'w_last_posted_on'}</b> $data->{'TOPIC'}->{'TOPIC_LAST_DATE'} $ModCP::lang->{'by'} $data->{'TOPIC'}->{'TOPIC_LASTP_N'}</td>
                        </tr>
                        </table>
                      </td>
                    </tr>
~;
}

sub topic_none {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><i>$ModCP::lang->{'q_t_n'}</i></td>
            </tr>
~;
}

sub end_forum_splash {

    return qq~

       </table>
      </td>
     </tr>
    </table>
~;
}

sub main_splash {

    return qq~

            <tr>
             <td><b>$ModCP::lang->{'mod_forum_t'}</b><br>$ModCP::lang->{'mod_forum'}</td>
            </tr>
            <tr>
              <td>
               <table cellspacing='1' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                       <td width='54%' bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium'>$ModCP::lang->{'forum_name'}</td>
                       <td width='6%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'forum_topics'}</td>
                       <td width='5%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'forum_posts'}</td>
                       <td width='35%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'last_post'}</td>
                     </tr>
~;
}

sub render_opentopic {
                    my $data = shift;    my $eventl;    if ($data->{'CALENDAR'} ne '') {              $eventl = " <font color='$iB::INFO->{'EVENT_FORUM'}'>[$data->{'CALENDAR'} $data->{'YEAR'}\-$data->{'MONTH'}\-$data->{'DAY'}]</font>";    }
return qq~

                 <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'>$data->{'SELECT'}</td>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><span id="linkthru"><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM_ID'};t=$data->{'TOPIC_ID'}" target='_blank'>$data->{'TOPIC_TITLE'}</a>$eventl</span><br>$data->{'TOPIC_DESC'}</td>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' valign='middle'>$data->{'TOPIC_POSTS'}</td>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><span id='highlight'>$data->{'TOPIC_LAST_DATE'}</span><br>$ModCP::lang->{'st_by'} $data->{'LAST_POSTER'}</td>
                 </tr>
~;
}

sub read_post {
                    my $data = shift;
return qq~

               <table cellspacing='1' cellpadding='0' border='0' width='100%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$data->{'POST'}</td>
                     </tr>
                    </table>
                   </td>
                 </tr>
                </table>
~;
}

sub startcp {

    return qq~

     <script langauge="javascript">
     <!--
        function check_prune() {
            var message = "$ModCP::lang->{'prune_confirm'} "+document.theForm.DAYS.value+"\\n$ModCP::lang->{'prune_confirm_b'}";
            if ( confirm( message ) ) {
                document.theForm.submit();
            } else {
                return false;
            }
        }
        function PopUp(url, name, width,height,center,resize,scroll,posleft,postop) {
            if (posleft != 0) { x = posleft }
            if (postop  != 0) { y = postop  }
            if (!scroll) { scroll = 1 }
            if (!resize) { resize = 1 }
            if ((parseInt (navigator.appVersion) >= 4 ) && (center)) {
              X = (screen.width  - width ) / 2;
              Y = (screen.height - height) / 2;
            }
            if (scroll != 0) { scroll = 1 }
            var Win = window.open( url, name, 'width='+width+',height='+height+',top='+Y+',left='+X+',resizable='+resize+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no');
        }
     //-->
     </script>
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
      <tr>
        <td width='20%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
          <table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlemedium'>$ModCP::lang->{'menu'}</td>
            </tr>
          <!--menu goes here-->
          </table>
        </td>
        <td width='80%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
          <table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlemedium'>$ModCP::lang->{'display'}</td>
            </tr>
          <!--main content-->
~;
}

sub show_post_results {
                    my $data = shift;
return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_topic_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_topic_deleted'} $data->{'DELETED'}<br><br>
                $ModCP::lang->{'a_topic_approved'} $data->{'APPROVED'}<br><br>
                $ModCP::lang->{'a_topic_left'} $data->{'LEFT'}<br><br>
            </td>
            </tr>
~;
}

sub endcp {

    return qq~

      </td>
     </tr>
    </table>
   </td>
  </tr>
 </table>
~;
}

sub delete_form_header {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_delete'} $count</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='process_delete'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
~;
}

sub online_menu {

    return qq~

    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' id='controlpanel'>$ModCP::lang->{'m_moderate'}</td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'IMAGES_URL'}/mod_help.html' target='_blank'>$ModCP::lang->{'help'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'}'>$ModCP::lang->{'m_approve'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=prune'>$ModCP::lang->{'m_prune'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=delete'>$ModCP::lang->{'m_delete'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=open'>$ModCP::lang->{'m_open'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=move'>$ModCP::lang->{'m_move'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=merge'>$ModCP::lang->{'m_merge'}</a></td>
    </tr>
    <!-- added by kevaholic00 -->
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=forum_rules'>$ModCP::lang->{'m_rules'}</a></td>
    </tr>
    <!-- end add -->
   <!-- <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' id='controlpanel'>$ModCP::lang->{'setti_prefs_hed'}</td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
      <UL>
        <LI><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet;f=$iB::IN{'f'}'>$ModCP::lang->{'m_prefs'}</a>
        <LI><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet;CODE=add;f=$iB::IN{'f'}'>$ModCP::lang->{'m_email_add'}</a>
        <LI><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet;CODE=del;f=$iB::IN{'f'}'>$ModCP::lang->{'m_email_edit'}</a>
      </UL></td>
    </tr> -->
~;
}

sub watched_search_footer {

    return qq~

        </tr>
       </table>
      </td>
     </tr>
    </table>
~;
}

sub move_ops {
                my ($html, $forum_name) = @_;
return qq~

                <tr>
                  <td><table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'move_topics_from'} <b>$forum_name</b> $Moderate::lang->{'to'}:
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='do_move'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
                </td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$html</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$Moderate::lang->{'delete_old'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                  <select name='leave' class='forminput'>
                  <option value='leave_full'  selected>$Moderate::lang->{'leave_locked'}
                  <option value='leave_empty'>$Moderate::lang->{'leave_empty'}
                  <option value='delete'>$Moderate::lang->{'dont_leave'}
                  </select>
                </td>
                </tr>
                </table>
                </td>
                </tr>
~;
}

sub show_open_results {
                    my $data = shift;
return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_topic_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_topic_open'} $data->{'open'}<br><br>
                $ModCP::lang->{'a_topic_close'} $data->{'closed'}<br><br>
            </td>
            </tr>
~;
}

sub render_add_email {
                    my $data = shift;       my $queued = $ModCP::lang->{'queued'};      if ($data->{'MODERATE'} == 0) {        $queued = $ModCP::lang->{'not_queued'};      }
return qq~

                 <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'>$data->{'SELECT'}</td>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><span id="linkthru"><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF;f=$data->{'FORUM_ID'}" target='_blank'>$data->{'FORUM_NAME'}</a></td>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' valign='middle'>$queued</td>
                 </tr>
~;
}

sub watched_form {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='watched_search'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'w_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option selected value='desc'>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' name='TOPICS' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
~;
}

sub prune_form_header {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_prune'}</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='process_prune'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_prune_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_prune_perpage'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='PAGE' size='5' maxlength='10' value='20' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='button' class='forminput' value='$ModCP::lang->{'prune_forum'}' onClick='check_prune();'></form></td>
            </tr>
~;
}

sub forum_rules {
        my ($forum, $rules) = @_;    my $select_show_link = qq~<option value='2'>$ModCP::lang->{'rules_yes_show_link'}<option value='1'>$ModCP::lang->{'rules_no_display_text'}<option value='0'>$ModCP::lang->{'rules_disable'}    ~;    $select_show_link =~ s!value=\'$forum->{'SHOW_RULES'}\'!value=\'$forum->{'SHOW_RULES'}\' selected!ig;
return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'forum_rules_title'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'forum_rules_txt'}
            </td>
            </tr>
            <form method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}'>
            <input type='hidden' name='act' value='ModCP'>
            <input type='hidden' name='CODE' value='do_forum_rules'>
            <input type='hidden' name='s' value='$iB::SESSION'>
            <input type='hidden' name='f' value='$iB::IN{'f'}'>
            <input type='hidden' name='SHOW_ALL' value='0'>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
            <table border='0' cellpadding='0' cellspacing='0' bgcolor='transparent' width='100%'>
              <tr>
              <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='40%'>
              </td>
              <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='60%'>
              $ModCP::lang->{'rules_show_link'}<br><select name='SHOW_RULES' class='forminput'>
              $select_show_link
              </select>
              </td>
              </tr>
              <tr>
              <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='40%'>
              </td>
              <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='60%'>
              <br><br>$ModCP::lang->{'rules_title'}<br><input class='forminput' type='text' name='RULES_TITLE' value='$rules->{'RULES_TITLE'}'>
              </td>
              </tr>
              <tr>
              <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='40%'>
              </td>
              <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='60%'>
              <br><br>$ModCP::lang->{'rules_text'}<br><textarea name='RULES_TEXT' class='textinput' rows='6' cols='65'>$rules->{'RULES_TEXT'}</textarea>
              <br><input type='submit' value='$ModCP::lang->{'rules_submit'}' class='forminput'>
              </td>
             </tr>
             <tr>
              <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle' align='left' colspan='2'>
              </td>
             </tr>
            </table>
            </td>
            </tr>

~;
}

sub watched_search_header {
                    my $data = shift;
return qq~

            <tr>
              <td>
               <table cellspacing='1' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                       <td width='100%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'tt_details'}</td>
                     </tr>
~;
}

sub preview {
                my $data = shift;
return qq~

     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' valign='top' align='left'><b>$ModCP::lang->{'welcome_preview'}</b><hr noshade size='1' color='$iB::SKIN->{'TABLE_BORDER_COL'}'><span id='postcolor'>$data</span></td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
    <br>
~;
}

sub post_form {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='post_search'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_posts_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' name='POSTS' value='$ModCP::lang->{'submit_posts'}' class='forminput'></form></td>
            </tr>
~;
}

sub show_topic_results {
                    my $data = shift;
return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_post_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_post_deleted'} $data->{'DELETED'}<br><br>
                $ModCP::lang->{'a_post_approved'} $data->{'APPROVED'}<br><br>
                $ModCP::lang->{'a_post_left'} $data->{'LEFT'}<br><br>
            </td>
            </tr>
~;
}

sub topic_header {
                    my $data = shift;
return qq~

            <tr>
             <td><b>$ModCP::lang->{'f_moderate'} $data->{'FORUM_NAME'}</b><br>$ModCP::lang->{'f_moderate_t'}
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='$data->{'search_type'}'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
              <td>
               <table cellspacing='1' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                       <td width='15%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'tt_action'}</td>
                       <td width='45%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'st_topic'}</td>
                       <td width='5%'  bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'st_posts'}</td>
                       <td width='35%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'st_last'}</td>
                     </tr>
~;
}

sub merge_form_header {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_merge'}</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='select_merge'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
~;
}

sub render_cat {
                my $data = shift;
return qq~

     <tr>
       <td bgcolor="$iB::SKIN->{'CAT_BACK'}" id='category' colspan='4'>$data->{'CAT_NAME'}</td>
     </tr>
~;
}

sub render_newtopic {
                    my $data = shift;
return qq~

                    <tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'>$ModCP::lang->{'ss_topic_title'} <b>$data->{'TOPIC'}->{'TOPIC_TITLE'}</b></td>
                    </tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><input type='hidden' name='R_POST_$data->{'TOPIC'}->{'TOPIC_ID'}' value='$data->{'POST'}->{'POST_ID'}'><input type='hidden' name='POST_$data->{'TOPIC'}->{'TOPIC_ID'}' value='$data->{'POST'}->{'ID'}'><select name='CHOICE_$data->{'TOPIC'}->{'TOPIC_ID'}' class='forminput'><option value='APPROVE' selected>$ModCP::lang->{'c_approve'}</option>$data->{'TOPIC'}->{'DELETE'}<option value='LEAVE' selected>$ModCP::lang->{'c_leave'}</option></select></td>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
                        <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                        <tr>
                          <td valign='top' width='15%'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'TOPIC'}->{'TOPIC_STARTER'}" target='_blank'><b>$data->{'TOPIC'}->{'TOPIC_STARTER_N'}</b></a></td>
                          <td valign='top' width='85%'><b>$ModCP::lang->{'ss_posted_on'}</b> $data->{'TOPIC'}->{'TOPIC_START_DATE'}<hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>$data->{'POST'}->{'POST'} ( <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=ModCP&f=$iB::IN{'f'}&CODE=readpost&ID=$data->{'POST'}->{'ID'}','ViewPost','400','200','0','1','1','1')">$ModCP::lang->{'ss_read_more'}</a> )</td>
                        </tr>
                        </table>
                      </td>
                    </tr>
~;
}

sub render_topic_title {
                    my $data = shift;
return qq~

                    <tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'>$ModCP::lang->{'ss_topic_title'} <b>$data->{'TOPIC_TITLE'}</b></td>
                    </tr>
~;
}

sub search_header {
                    my $data = shift;
return qq~

            <tr>
             <td><b>$ModCP::lang->{'f_moderate'} $data->{'FORUM_NAME'}</b><br>$ModCP::lang->{'f_moderate_t'}
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='$data->{'search_type'}'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
              <td>
               <table cellspacing='1' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                       <td width='15%' bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium'>$ModCP::lang->{'tt_action'}</td>
                       <td width='85%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'tt_details'}</td>
                     </tr>
~;
}

sub CheckBoxes {

    return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' align='left' colspan='3' id='titlemedium'>$ModCP::lang->{'options'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%' valign='top' colspan='2'>$ModCP::lang->{'sett_type'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='radio' name='PM' value='0' checked> $ModCP::lang->{'set_pm'}<br><input type='radio' name='PM' value='1'> $ModCP::lang->{'set_email'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%' valign='top' colspan='2'>$ModCP::lang->{'choice_set'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='checkbox' name="ONCE" value='once' checked></td>
                </tr>
                <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='4' align='center'><input type='submit' value='$ModCP::lang->{'submit'}' class='forminput'></form></td>
                </tr>
               </table>
              </td>
             </tr>
            </table>
~;
}

sub offline_menu {

return qq~


  <tr>
     <td bgcolor='$iB::SKIN->{'CAT_BACK'}' id='category'>$ModCP::lang->{'menu_off'}
     </td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
          <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ModCP"> $ModCP::lang->{'forumidxlink'}</a>
    </td>
        </tr>
  <tr>
     <td bgcolor='$iB::SKIN->{'CAT_BACK'}' id='category'>$ModCP::lang->{'memedit_menu'}</td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
         <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ModCP;CODE=memedit">$ModCP::lang->{'memedit_link'}</a>
    </td>
        </tr>
        <tr>
     <td bgcolor='$iB::SKIN->{'CAT_BACK'}' id='category'>$ModCP::lang->{'setti_prefs_hed'}</td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet;f=$iB::IN{'f'}'>$ModCP::lang->{'m_prefs'}</a>
      <UL>
        <LI><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet;CODE=add;f=$iB::IN{'f'}'>$ModCP::lang->{'m_email_add'}</a>
        <LI><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet;CODE=del;f=$iB::IN{'f'}'>$ModCP::lang->{'m_email_edit'}</a>
      </UL></td>
        </tr>


~;
}

sub end_main_splash {

    return qq~

       </table>
      </td>
     </tr>
    </table>
~;
}

sub show_merge_results {
                    my $result = shift;
return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$result</b>
            </td>
            </tr>
~;
}

sub post_form_header {
                my $count = shift;
return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'q_posts'} $count</td>
            </tr>
~;
}

sub edit_email_header {
                my ($data, $set) = @_;      my $choice = $ModCP::lang->{'set_pm'};      if ($data->{'CHOICE'} eq '1') {         $choice = $ModCP::lang->{'set_email'};      }       if ($data->{'WHENE'} eq '1') {          $choice .= " / $ModCP::lang->{'once'}";     } else {            $choice .= " / $ModCP::lang->{'all'}";      }
return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='3'>$set</td>
            </tr>
            <TR>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="left" valign='middle'><b>$ModCP::lang->{'forum_name'}</b></TD>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><b>$ModCP::lang->{'notif_type'}</b></TD>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><b>$ModCP::lang->{'mod_name'}</b></TD>
            </TR>
            <tr>
            <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="left" valign='middle'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$data->{'FORUM_ID'}">$data->{'FORUM_NAME'}</a></td>
            <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><span id='highlight'>$choice</span></td>
            <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><span id='linkthru'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'MEMBER_ID'}">$data->{'MEMBER_NAME'}</a></span></td>
            </tr>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModSet'>
               <input type='hidden' name='CODE' value='do_edit'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
               <input type='hidden' name='i' value='$iB::IN{'i'}'>
          <!--main content-->
~;
}

sub show_del_set {
                    my $data = shift;       my $choice = $ModCP::lang->{'set_pm'};      if ($data->{'CHOICE'} eq '1') {         $choice = $ModCP::lang->{'set_email'};      }       if ($data->{'WHENE'} eq '1') {          $choice .= " / $ModCP::lang->{'once'}";     } else {            $choice .= " / $ModCP::lang->{'all'}";      }
return qq~

     <tr>
       <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="left" valign='middle'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$data->{'FORUM_ID'}">$data->{'FORUM_NAME'}</a></td>
       <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><span id='highlight'>$choice</span></td>
       <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><span id='linkthru'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet;CODE=do_del;f=$data->{'FORUM_ID'};i=$data->{'ID'}">[$ModCP::lang->{'c_delete'}]</a> <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModSet;CODE=edit_e;f=$data->{'FORUM_ID'};i=$data->{'ID'}">[$ModCP::lang->{'edit'}]</a></span></td>
     </tr>
~;
}

sub open_form_header {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_openclose'} $count</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='process_open'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
~;
}

sub message_box {
                    my $data = shift;                       $data =~ s!<br>!\012!ig;
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' align='left' colspan='3' id='titlemedium'>$ModCP::lang->{'edit_notifi'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='3'>$ModCP::lang->{'edit_tags'}</td>
                </tr>
                </tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='3' align='center'><!--NoCompression//--><textarea cols='80' rows='12' wrap='soft' name='Post' class='textinput'>$data</textarea><!--/NoCompression//--><br></td>
                </tr>
~;
}

sub move_form_header {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_move'}</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='process_move'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
~;
}

sub startcp_merge {

    return qq~

     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
      <tr>
        <td width='20%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
          <table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlemedium'>$ModCP::lang->{'menu'}</td>
            </tr>
          <!--menu goes here-->
          </table>
        </td>
        <td width='80%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
          <table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlemedium' colspan='2'>$ModCP::lang->{'display'}</td>
            </tr>
           <TR>
            <TD colspan='2' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>$ModCP::lang->{'merge_title'}</TD>
          </TR>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='do_merge'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
          <!--main content-->
~;
}

sub merge_close_form {

    return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' class='forminput' value='$ModCP::lang->{'merge_topics'}'></form></td>
            </tr>
~;
}

sub add_email_header {
                my $set = shift;
return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='3'>$set</td>
            </tr>
            <TR>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="left" valign='middle'><b>$ModCP::lang->{'tt_action'}</b></TD>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><b>$ModCP::lang->{'forum_name'}</b></TD>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" valign='middle'><b>$ModCP::lang->{'queued'} ?</b></TD>
            </TR>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModSet'>
               <input type='hidden' name='CODE' value='do_add'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
          <!--main content-->
~;
}

sub search_footer {

    return qq~

        <tr>
          <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' value='$ModCP::lang->{'process_records'}' class='forminput'></td>
        </tr>
       </table>
      </td>
     </tr>
    </table>
~;
}

sub startcp_set {
        my $data = shift;
return qq~

     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
      <tr>
        <td width='20%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
          <table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlemedium'>$ModCP::lang->{'menu'}</td>
            </tr>
          <!--menu goes here-->
          </table>
        </td>
        <td width='80%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
          <table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' valign='middle' id='titlemedium' colspan='3'>$data</td>
            </tr>
           <TR>
            <TD colspan='3' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'> </TD>
          </TR>
~;
}

sub render_forum {
                my $data = shift;
return qq~

     <tr>
       <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}"><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$data->{'FORUM_ID'}">$data->{'FORUM_NAME'}</a></b></span><br>$ModCP::lang->{'topic_to_mod'} <b>$data->{'TOPICS_NOT_APPROVED'}</b><br>$ModCP::lang->{'topics_watched'} <b>$data->{'TOPICS_WATCHED'}</b></td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align='center' valign='middle'>$data->{'FORUM_TOPICS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align='center' valign='middle' id='highlight'>$data->{'FORUM_POSTS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="left" valign='middle'><span id='highlight'>$data->{'FORUM_LAST_POST'}</span>
     </tr>
~;
}

sub show_delete_results {
                    my $data = shift;
return qq~

            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_topic_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_topic_d_delete'} $data->{'delete'}<br><br>
            </td>
            </tr>
~;
}

sub edit_happybd_header {
        my $data = shift;
return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='3'>$ModCP::lang->{'birt_editor'}</td>
            </tr>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='Happybd'>
               <input type='hidden' name='CODE' value='do_edit'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
               <input type='hidden' name='i' value='$data'>
          <!--main content-->
~;
}

sub edit_welcome_header {
        my $data = shift;
return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='3'>$ModCP::lang->{'edit_welcome_editor'}</td>
            </tr>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='Welcome'>
               <input type='hidden' name='CODE' value='do_edit'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
               <input type='hidden' name='i' value='$data'>
          <!--main content-->
~;
}

sub post_none {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><i>$ModCP::lang->{'q_p_n'}</i></td>
            </tr>
~;
}

sub show_setings {
                my ($set, $del) = @_;
return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='3'>$set</td>
            </tr>
            <TR>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="left" valign='middle'><b>$ModCP::lang->{'forum_name'}</b></TD>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="center" valign='middle'><b>$ModCP::lang->{'notif_type'}</b></TD>
            <TD bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="center" valign='middle'><b>$del</b></TD>
            </TR>
~;
}

sub watched_form_header {
                my $count = shift;
return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'w_topics'} $count</td>
            </tr>
~;
}

sub render_topic_post {
                    my $data = shift;
return qq~

                     <tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><input type='hidden' name='POST_$data->{'POST'}->{'ID'}' value='$data->{'POST'}->{'POST_ID'}'><input type='hidden' name='TOPIC_$data->{'POST'}->{'ID'}' value='$data->{'TOPIC'}->{'TOPIC_ID'}'><select name='CHOICE_$data->{'POST'}->{'ID'}' class='forminput'><option value='APPROVE' selected>$ModCP::lang->{'c_approve'}</option>$data->{'TOPIC'}->{'DELETE'}<option value='LEAVE' selected>$ModCP::lang->{'c_leave'}</option></select></td>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
                        <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                        <tr>
                          <td valign='top' width='15%'>$data->{'POST'}->{'MEMBER_NAME'}</td>
                          <td valign='top' width='85%'><b>$ModCP::lang->{'ss_posted_on'}</b> $data->{'POST'}->{'POST_DATE'}<hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>$data->{'POST'}->{'POST'} ( <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=ModCP&f=$iB::IN{'f'}&CODE=readpost&ID=$data->{'POST'}->{'ID'}','ViewPost','400','200','0','1','1','1')">$ModCP::lang->{'ss_read_more'}</a> )</td>
                        </tr>
                        </table>
                      </td>
                    </tr>
~;
}

sub watched_none {

    return qq~

            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><i>$ModCP::lang->{'watched_none'}</i></td>
            </tr>
~;
}

sub forum_splash {
                my $data = shift;
return qq~

            <tr>
             <td><b>$ModCP::lang->{'f_moderate'} $data->{'FORUM_NAME'}</b><br>$ModCP::lang->{'f_moderate_t'}</td>
            </tr>
            <tr>
              <td>
               <table cellspacing='0' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
~;
}

sub mem_search_field {

return qq~
                    <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'edit_member'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
            </td>
            </tr>
                        <form method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}'>
            <input type='hidden' name='act' value='ModCP'>
            <input type='hidden' name='CODE' value='edit_mem'>
            <input type='hidden' name='s' value='$iB::SESSION'>
          <tr>
            <td >
             <table cellpadding='0' cellspacing='0' border='0' width='95%' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
                <tr>
            <td>
            <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                                                  <tr>
                                                <td colspan=2 align=left id=titlelarge width='5%' >$ModCP::lang->{'mem_search'}</td>
                                                </tr>
                                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='100%'><b>$ModCP::lang->{'find_user'}:</b> <b><input class='forminput' type='text' name='USER_KEY' >
               by
                <select name='KEY_TYPE' class='forminput' style="width:100px">
                <option value='NAME'>$ModCP::lang->{'m_name'}
                <option value='EMAIL'>$ModCP::lang->{'m_email'}
                <option value='IP'>$ModCP::lang->{'m_ip'}
                <option value='ID'>$ModCP::lang->{'m_id'}</select></b></td>

                        </tr>

                <tr>
                                <td  bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='center' >

<input type='submit' value='$ModCP::lang->{'find_user'}' class='forminput'>
                                </td>
                                </tr>
                </table></td></tr></table>
                 </form>
            </td>
            </tr>


~;
}

sub mem_search_header {

return qq~
                    <tr>
            <td colspan=6 bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'memedit_link'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
            </td>
            </tr>


            <form method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}'>
            <input type='hidden' name='act' value='ModCP'>
            <input type='hidden' name='CODE' value='edit_mem'>
            <input type='hidden' name='s' value='$iB::SESSION'>
                            <input type='hidden' name='KEY_TYPE' value='ID'>
          <tr>
            <td >
             <table cellpadding='0' cellspacing='0' border='0' width='95%' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>

            <table cellpadding='3' cellspacing='1' border='0' width='100%'>

                        <tr>

                        <td align=left id=titlelarge width='5%' >&nbsp;</td>
                        <td align=left id=titlelarge  width='30%'><b>$ModCP::lang->{'l_name'}</b></font></td>
                        <td align=left id=titlelarge width='15%' ><b>$ModCP::lang->{'l_group'}</b></font></td>
                        <td align=left id=titlelarge width='13%' ><b>$ModCP::lang->{'l_email'}</b></font></td>
                        <td align=left id=titlelarge width='8%' ><b>$ModCP::lang->{'l_posts'}</b></font></td>                        </tr>


~;
}

sub mem_search_row {
                my ($this_mem,$this_mem_g) = @_;
return qq~
                                <tr>
                                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width=5% align=center ><input type='radio' name='USER_KEY' value='$this_mem->{'MEMBER_ID'}' style='border:none'></td>
                                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width=30% >$this_mem->{'MEMBER_NAME'}</font></td>
                                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width=15% >$this_mem_g->{'TITLE'}</font></td>
                                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width=13% >$this_mem->{'MEMBER_EMAIL'}</font></td>
                                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width=8%  >$this_mem->{'MEMBER_POSTS'}</font></td>
                                </tr>

~;
}
sub mem_search_footer {

return qq~
                                <tr>
                                <td  bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='6' align='center' ><input class=forminput type='submit' value='$ModCP::lang->{'sel_member'}'></td>
                                </tr>
                </table></td></tr></table>
            </td>
            </tr>


            </table>
            </td>
            </tr>

~;
}


sub mem_edit {
        my ($member,$width, $height,$sel_allow_no,$sel_allow_yes,$sel_ng,$sel_male,$sel_fem,$sel_email_yes,$sel_email_no,$sel_0,$sel_1,$sel_2,$sel_3,$sel_4,$sel_5) = @_;
return qq~
                    <tr>
            <td colspan=6 bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'memedit_link'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
            </td>
            </tr>

            <form method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}'>
            <input type='hidden' name='act' value='ModCP'>
            <input type='hidden' name='CODE' value='do_edit_mem'>
            <input type='hidden' name='s' value='$iB::SESSION'>
                            <input type='hidden' name='ID' value='$member->{'MEMBER_ID'}'>
                            <input type='hidden' name='NAME' value='$member->{'MEMBER_NAME'}'>

          <tr>
            <td >
             <table cellpadding='0' cellspacing='0' border='0' width='95%' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>

                <tr>
            <td>

            <table cellpadding='3' cellspacing='1' border='0' width='100%'>

                        <tr>

                        <td colspan=2 align=left id=titlelarge width='5%' >$ModCP::lang->{'p_title'}</td>

                        </tr>


                        <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'><b>$ModCP::lang->{'p_act'}</b></td>
                        <td align=left  bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='60%' ><b>$member->{'LAST_ACTIVITY'}</b></td>

                        </tr>

                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_rname'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='MEMBER_NAME_R' value='$member->{'MEMBER_NAME_R'}' class='forminput'>
                        </td>
                </tr>

                                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_gen'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <select name='GENDER'   class='forminput' >
                         <option value="0" $sel_ng></option>
                         <option value="1" $sel_male>Male</option>
                         <option value="2" $sel_fem>Female</option>
                        </select>
                        </td>
                </tr>

                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_tit'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='MEMBER_TITLE' value='$member->{'MEMBER_TITLE'}' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_email'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='MEMBER_EMAIL' value='$member->{'MEMBER_EMAIL'}' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_avatar'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='MEMBER_AVATAR' value='$member->{'MEMBER_AVATAR'}' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_aw'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='AVATAR_W' value='$width' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_ah'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='AVATAR_H' value='$height' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_posts'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='MEMBER_POSTS' value='$member->{'MEMBER_POSTS'}' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_photo'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='PHOTO' value='$member->{'PHOTO'}' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_aim'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='AOLNAME' value='$member->{'AOLNAME'}' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_icq'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='ICQNUMBER' value='$member->{'ICQNUMBER'}' class='forminput'>
                        </td>
                </tr>                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_yahoo'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='YAHOONAME' value='$member->{'YAHOONAME'}' class='forminput'>
                        </td>
                </tr>                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_msn'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='MSNNAME' value='$member->{'MSNNAME'}' class='forminput'>
                        </td>
                </tr>
                        <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_loc'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='LOCATION' value='$member->{'LOCATION'}' class='forminput'>
                        </td>
                </tr>                <tr>
                        <td align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_ws'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
                        <input type='text' name='WEBSITE' value='$member->{'WEBSITE'}' class='forminput'>
                        </td>
                </tr>
                <tr>
                        <td  valign=top align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_sig'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
        <textarea rows='6' cols='55' wrap='virtual' class='forminput' name='SIGNATURE'>$member->{'SIGNATURE'}</textarea>
                        </td>
                </tr>                <tr>
                        <td valign=top align=left bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'   width='40%'>
                        <b>$ModCP::lang->{'p_int'}</b>
                        </td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align=left  width='60%' >
        <textarea rows='6' cols='55' wrap='virtual' class='forminput' name='INTERESTS'>$member->{'INTERESTS'}</textarea>
                        </td>
                </tr>


                                <tr>
                                <td  bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='center' ><input class=forminput type='submit' value='$ModCP::lang->{'sel_member'}'></td>
                                </tr>
                </table></td></tr></table>
                 </form>
            </td>
            </tr>

~;
}
sub mem_edit_sucess {

return qq~
                    <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'edit_member'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
            </td>
            </tr>
            <form method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}'>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
            <table border='0' cellpadding='0' cellspacing='0' bgcolor='transparent' width='100%'>
              <td colspan=2 bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='100%'>
              <br><b>$ModCP::lang->{'p_sucess'}</b>


              </td>
              </tr>

            </table>
            </td>
            </tr>

~;
}


1;