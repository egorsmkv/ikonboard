package RegisterView;




sub ShowICQ {
                    my $data = shift;
                    my $req  = $iB::INFO->{'ICQ_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'icq'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='20' name='ICQNUMBER' value='' class='forminput'> $req</td>
                </tr>
~;
}

sub ShowGender {
                    my $data = shift;
                    my $req  = $iB::INFO->{'GENDER_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_sex_txt'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$data->{'TEXT'} $req</td>
                </tr>
~;
}



sub ShowWeb {
  my $data = shift;
  my $req  = $iB::INFO->{'WEB_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

               <tr>
               <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$UserCP::lang->{'website'}</td>
               <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='1200' name='WEBSITE' value='' class='forminput'> $req</td>
               </tr>
~;
}

sub ShowLocal {
                    my $data = shift;
                    my $req  = $iB::INFO->{'LOCAL_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'location'}<br>(<a href='javascript:CheckLength("location");'>$UserCP::lang->{'check_length'}</a>)</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' name='LOCATION' value='' class='forminput'> $req</td>
                </tr>
~;
}

sub MemberNameReal {
                    my $data = shift;
              my $req  = $iB::INFO->{'MEMBER_NAME_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'membernamereal'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' name='MEMBER_NAME_R' value='' class='forminput'> $req</td>
                </tr>
~;
}

sub show_rules {
                    my $rules = shift;
return qq~

   <!-- Show Board Rules -->
    <br>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$Register::lang->{'board_rules'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$rules->{'RULES_TEXT'} <br><br>>><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Login;CODE=00'>$Register::lang->{'intro_proceed'}</a></td>
               </tr>
               </table>
            </td>
      </tr>
   </table>
   <!-- End Board Rules -->
~;
}

sub ShowMSN {
                    my $data = shift;
                    my $req  = $iB::INFO->{'MSN_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$UserCP::lang->{'msn'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='30' name='MSNNAME' value='' class='forminput'> $req</td>
                </tr>
~;
}

sub ShowMail {
                    my $data = shift;
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'hide_email'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$data->{'TEXT'}</td>
                </tr>
~;
}

sub show_dumb_form {
                    my $data = shift;
return qq~

    <script language='javascript'>
    <!--
    function Validate() {
        // Check for Empty fields
        if (document.REG.EmailAddress.value == "" || document.REG.SID.value == "") {
            alert ("$Register::lang->{'js_blanks'}");
            return false;
        }
    }
    //-->
    </script>
     <br>
     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='REG' onSubmit='return Validate()'>
     <input type='hidden' name='act' value='Reg'>
     <input type='hidden' name='CODE' value='03'>
     <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
        <td valign='middle' align='left'><b>$Register::lang->{'dumb_header'}</b><br><br>$Register::lang->{'dumb_text'}</td>
     </tr>
     </table>
     <br>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>&raquo; $Register::lang->{'complete_form'}</td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$Register::lang->{'dumb_code'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='password' size='32' maxlength='32' name='SID' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$Register::lang->{'dumb_email'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='32' maxlength='50' name='EmailAddress' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$Register::lang->{'dumb_submit'}" class='forminput'>
                </td></tr></table>
                </td></tr></table>
                </form>
~;
}

sub show_preview {
                    my $member = shift;
return qq~

     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$Register::lang->{'registration_process'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$Register::lang->{'thank_you'} $member->{'MEMBER_NAME'}. $Register::lang->{'preview_reg_text'}</td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
~;
}

sub ShowForm {
                    my $data = shift;
return qq~

    <script language='javascript'>
    <!--
    function Validate() {
        // Check for Empty fields
        if (document.REG.UserName.value == "" || document.REG.PassWord.value == "" || document.REG.PassWord_Check.value == "" || document.REG.EmailAddress.value == "") {
            alert ("$Register::lang->{'js_blanks'}");
            return false;
        }
        // Have we checked the checkbox?
        if (document.REG.agree.checked == true) {
            return true;
        } else {
            alert ("$Register::lang->{'js_no_check'}");
            return false;
        }
    }
//-->
</script>
<script language='javascript'>
<!--
var LocationMax  = "$iB::INFO->{'MAX_LOCATION_LENGTH'}";
var InterestMax  = "$iB::INFO->{'MAX_INTEREST_LENGTH'}";
var SignatureMax = "$iB::INFO->{'MAX_SIG_LENGTH'}";
var local = "$iB::INFO->{'LOCAL_R'}";
var signat = "$iB::INFO->{'SIGN_R'}";
var inter = "$iB::INFO->{'INTER_R'}";
function CheckLength(Type) {
if (local !=0) {
    LocationLength  = document.REG.LOCATION.value.length;
}
if (inter !=0) {
    InterestLength  = document.REG.INTERESTS.value.length;
}
if (signat !=0) {
    SignatureLength = document.REG.SIGNATURE.value.length;
}
    message  = "";
    if (Type == "location") {
        if (LocationMax !=0) {
            message = "$UserCP::lang->{'js_location'}:\\n$UserCP::lang->{'js_max'} " + LocationMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + LocationLength + " $UserCP::lang->{'js_so_far'}.");
    }
    else if (Type == "interest") {
        if (InterestMax !=0) {
            message = "$UserCP::lang->{'js_interests'}:\\n$UserCP::lang->{'js_max'} " + InterestMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + InterestLength + " $UserCP::lang->{'js_so_far'}.");
    }
    else if (Type == "signature") {
        if (SignatureMax !=0) {
            message = "$UserCP::lang->{'js_signature'}:\\n$UserCP::lang->{'js_max'} " + SignatureMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + SignatureLength + " $UserCP::lang->{'js_so_far'}.");
    }
}
function ValidateProfile() {
if (local !=0) {
    LocationLength  = document.REG.LOCATION.value.length;
}
if (inter !=0) {
    InterestLength  = document.REG.INTERESTS.value.length;
}
if (signat !=0) {
    SignatureLength = document.REG.SIGNATURE.value.length;
}
    errors = "";
    if (LocationMax !=0) {
        if (LocationLength > LocationMax) {
            errors = "$UserCP::lang->{'js_location'}:\\n$UserCP::lang->{'js_max'} " + LocationMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + LocationLength;
        }
    }
    if (InterestMax !=0) {
        if (InterestLength > InterestMax) {
            errors = errors + "\\n$UserCP::lang->{'js_interests'}:\\n$UserCP::lang->{'js_max'} " + InterestMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + InterestLength;
        }
    }
    if (SignatureMax !=0) {
        if (SignatureLength > SignatureMax) {
            errors = errors + "\\n$UserCP::lang->{'js_signature'}:\\n$UserCP::lang->{'js_max'} " + SignatureMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + SignatureLength;
        }
    }
    if (errors != "") {
        alert(errors);
        return false;
    } else {
        return true;
    }
}
//-->
</script>
     <br>
     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='REG' onSubmit='return Validate()'>
     <input type='hidden' name='act' value='Reg'>
     <input type='hidden' name='CODE' value='02'>
     <input type='hidden' name='COPPA' value="$iB::IN{'COPPA'}">
     <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
        <td valign='middle' align='left'>$Register::lang->{'reg_header'}</b><br><br>$data->{'TEXT'}</td>
     </tr>
     </table>
     <br>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>&raquo; $Register::lang->{'complete_form'}</td>
                </tr>
   <tr>
        <td align='right' id='category' colspan='2'><font color="red">$Register::lang->{'req_fields'}</font></td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$Register::lang->{'user_name'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='32' maxlength='64' name='UserName' class='forminput'> <font color="red">*</font></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$Register::lang->{'pass_word'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='password' size='32' maxlength='32' name='PassWord' class='forminput'> <font color="red">*</font></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$Register::lang->{'re_enter_pass'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='password' size='32' maxlength='32' name='PassWord_Check' class='forminput'> <font color="red">*</font></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$Register::lang->{'email_address'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='32' maxlength='50' name='EmailAddress' class='forminput'> <font color="red">*</font></td>
                </tr>
~;
}

sub show_authorise {
                    my $member = shift;
return qq~

     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$Register::lang->{'registration_process'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$Register::lang->{'thank_you'} $member->{'MEMBER_NAME'}. $Register::lang->{'auth_text'}  $member->{'MEMBER_EMAIL'}</td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
~;
}

sub ShowAIM {
                    my $data = shift;
                    my $req  = $iB::INFO->{'AIM_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$UserCP::lang->{'aol'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='30' name='AOLNAME' value='' class='forminput'> $req</td>
                </tr>
~;
}

sub SecureReg {
  my $data = shift;
  my ($int, $images);

  #Had to rebuild paths here because ikonboard.cgi
  #hoses up the paths when loading skins
  require "Boardinfo.cgi";
  $iB::DAT = Boardinfo->new();

       #This makes sure that the required imaging module is installed before we try and import it.
  unless (defined(eval { require Image::Magick })) {
     return qq~
                     <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$Register::lang->{'reg_key'}</td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='60%' valign='top'>$Register::lang->{'mod_missing'}</td>
                     </tr>
     ~;
  }

  #This is it, the generator! Thought it would be a little more impressive huh?
  #Increase the right operator in the for loop to increase the number of digits
  #for the key. Decrease to decrease....
  $int .= (0..9)[rand 10] for (1..6);
  my @dat = split('', $int);

  #This encrypts the generated string so we can pass it as a
  #hidden parameter and keep the true value secret.
  $int = crypt($int, "gen");
  #This creates the html image tags.
  my $it = 0;
  for (@dat) {
    my $cnt = make($_, $it);
    $images .=  "<img src=\"$iB::DAT->{'IMAGES_URL'}/$cnt.gif\">";
    $it++;
  }

  #Return html page to browser
  return qq~
                  <tr>
                     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$Register::lang->{'reg_key'}</td>
                     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='60%' valign='top'>
                        <table background="$iB::DAT->{'IMAGES_URL'}/nums/woodgrain.jpg" cellspacing="0" cellpadding="0" width="20%">
                           <tr>
                              <td>
                                 $images
                              </td>
                           </tr>
                        </table>
                        <br>
                        <input type='hidden' name='GEN_KEY' value=$int>
                        <input type='text' size='32' maxlength='32' name='REG_KEY' value='' class='forminput'> <font color="red">*</font>
                     </td>
                  </tr>
  ~;

  #This is the meat and potatoes of the image generation

  sub make {
     my ($num, $it) = @_;
     my $image = Image::Magick->new;

     #Here we set path for reading images and then
     #read in binary image data.
     my $path = $iB::DAT->{'HTML_DIR'}."nums/".$num.".gif";
     my $x    = $image->Read($path);
     warn "$x" if ($x);  #Sends warning if binary read was unsuccessful

     #Here we set path for writing images and then
     #write the renamed image for security reasons.
     my $file = $iB::DAT->{'HTML_DIR'}.$it.".gif";
     $x       = $image->Write($file);
     warn "$x" if ($x);  #Sends warning if binary write was unsuccessful

     #This is a must to keep our module variable clean and valid
     undef($image);
     return $it;
  }
}


sub Close_Form {
                    my $data = shift;
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$Register::lang->{'terms_service'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <textarea readonly cols='50' rows='12' wrap='soft' name='Post' class='textinput' style='font-size:10px'>$data->{'RULES'}</textarea>
                <br><br><b>$Register::lang->{'agree_submit'}</b> <input type='checkbox' name='agree' value='1'>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$Register::lang->{'submit_form'}" class='forminput'>
                </td></tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
</table>
                </td></tr></table>
                </form>
~;
}

sub ShowInter {
                    my $data = shift;
                    my $req  = $iB::INFO->{'INTER_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%' valign='top'>$UserCP::lang->{'interests'}<br>(<a href='javascript:CheckLength("interest");'>$UserCP::lang->{'check_length'}</a>)</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><textarea cols='50' rows='5' wrap='soft' name='INTERESTS' class='forminput'></textarea> $req</td>
                </tr>
~;
}

sub ShowYAHO {
                    my $data = shift;
                    my $req  = $iB::INFO->{'YAHO_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'yahoo'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='30' name='YAHOONAME' value='' class='forminput'> $req</td>
                </tr>
~;
}

sub ShowSign {
                    my $data = shift;
                    my $req  = $iB::INFO->{'SIGN_R'} == 2 ? "<font color='red'>*</font>" : '';

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'signature'}<br>(<a href='javascript:CheckLength("signature");'>$UserCP::lang->{'check_length'}</a>)</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><textarea cols='50' rows='5' wrap='soft' name='SIGNATURE' class='forminput'></textarea> $req</td>
                </tr>
~;
}

sub ShowSkinLang {
                    my $data = shift;
return qq~

                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_lang_txt'}</b></td>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$data->{'LANG'}</td>
                 </tr>
                 <tr>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_skin_txt'}</b></td>
                 <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$data->{'SKIN'}</td>
                 </tr>
~;
}

sub Show_COPPA {

return qq~
<script language='javascript'>
<!--
function PopUp(url, name, width,height,center,resize,scroll,posleft,postop) {
    if (posleft != 0) { x = posleft }
    if (postop  != 0) { y = postop  }

    if (!scroll) { scroll = 1 }
    if (!resize) { resize = 1 }

    if ((parseInt (navigator.appVersion) >= 4 ) && (center)) {
        X = (screen.width  - width ) / 2;
        Y = (screen.height - height) / 2;
    }
    if (scroll != 0) { scroll = 1 }

    var Win = window.open( url, name, 'width='+width+',height='+height+',top='+Y+',left='+X+',resizable='+resize+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no');
}
//-->
</script>

     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' id='titlemedium' colspan='2'>$iB::INFO->{'BOARDNAME'} $Register::lang->{'COPPA_info'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='2'>$Register::lang->{'COPPA_age_correspond'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><table cellpadding='0' cellspacing='0' border='0' width='100%'><tr><td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='2'>[ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=12">$Register::lang->{'COPPA_younger'}</a> ] :: [ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=01;COPPA=false">$Register::lang->{'COPPA_13andover'}</a> ]</td></tr></table></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='2'>$Register::lang->{'COPPA_privacy_info'} $iB::INFO->{'BOARDNAME'} <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=11','Pager','500','500','0','1','1','1')">$Register::lang->{'COPPA_state_link'}</a></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' id='titlemedium' colspan='2'>$iB::INFO->{'BOARDNAME'} $Register::lang->{'COPPA_permis_form'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='2'>$Register::lang->{'COPPA_mail_or_fax'} <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=10','Pager','500','500','0','1','1','1')">$Register::lang->{'COPPA_permis_form'}</a> $Register::lang->{'COPPA_to_admin_of'} $iB::INFO->{'BOARDNAME'} $Register::lang->{'COPPA_before_regallow'}
                <br>$Register::lang->{'COPPA_further_info'} <a href="mailto:$iB::INFO->{'ADMIN_EMAIL_IN'}">$iB::INFO->{'ADMIN_EMAIL_IN'}</a>.</td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
~;
}


sub Show_COPPA_underage {

return qq~
<script language='javascript'>
<!--
function PopUp(url, name, width,height,center,resize,scroll,posleft,postop) {
    if (posleft != 0) { x = posleft }
    if (postop  != 0) { y = postop  }

    if (!scroll) { scroll = 1 }
    if (!resize) { resize = 1 }

    if ((parseInt (navigator.appVersion) >= 4 ) && (center)) {
        X = (screen.width  - width ) / 2;
        Y = (screen.height - height) / 2;
    }
    if (scroll != 0) { scroll = 1 }

    var Win = window.open( url, name, 'width='+width+',height='+height+',top='+Y+',left='+X+',resizable='+resize+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no');
}
//-->
</script>

     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' id='titlemedium' colspan='2'>$iB::INFO->{'BOARDNAME'} $Register::lang->{'COPPA_info'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='2'>$Register::lang->{'COPPA_continue_parent'} <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=10','Pager','500','500','0','1','1','1')">$Register::lang->{'COPPA_permis_form'}</a> $Register::lang->{'COPPA_to_admin_of'} $iB::INFO->{'BOARDNAME'}
                <br>$Register::lang->{'COPPA_further_info'} <a href="mailto:$iB::INFO->{'ADMIN_EMAIL_IN'}">$iB::INFO->{'ADMIN_EMAIL_IN'}</a>.</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='2'>[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Reg;CODE=01;COPPA=true'>$Register::lang->{'COPPA_register'}</a> ] :: [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}'>$Register::lang->{'COPPA_cancel'}</a> ]</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='2'>$Register::lang->{'COPPA_privacy_info'} $iB::INFO->{'BOARDNAME'} <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=11','Pager','500','500','0','1','1','1')">$Register::lang->{'COPPA_state_link'}</a>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' id='titlemedium' colspan='2'> </td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
~;
}



sub Show_COPPA_permission {

return qq~
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>$Register::lang->{'COPPA_title_permis'} $iB::INFO->{'BOARDNAME'}</title>
</head>
<script language='javascript'>
<!--
function PopUp(url, name, width,height,center,resize,scroll,posleft,postop) {
    if (posleft != 0) { x = posleft }
    if (postop  != 0) { y = postop  }

    if (!scroll) { scroll = 1 }
    if (!resize) { resize = 1 }

    if ((parseInt (navigator.appVersion) >= 4 ) && (center)) {
        X = (screen.width  - width ) / 2;
        Y = (screen.height - height) / 2;
    }
    if (scroll != 0) { scroll = 1 }

    var Win = window.open( url, name, 'width='+width+',height='+height+',top='+Y+',left='+X+',resizable='+resize+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no');
}
//-->
</script>
<body bgcolor="#FFFFFF">
<table border="0" width="100%">
    <tr>
        <td align='$iB::SKIN->{'LOGO_ALIGN'}' valign='middle' width='50%' rowspan='2'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" title="$Register::lang->{'COPPA_return_to_board'}"><img src="$iB::INFO->{'IMAGES_URL'}/images/$iB::SKIN->{'BOARD_LOGO'}" border=0 alt=''></a></td>
        <td valign="middle" align="center" nowrap></td>
    </tr>
</table>
<center>
<font face="verdana, arial, helvetica" size="2"><b><a href="javascript:void(window.print())">Print Form</a></b></font><br>
<font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_permis_partic'} $iB::INFO->{'BOARDNAME'}</b></font>
</center>
<font face="verdana, arial, helvetica" size="2" >
<p><b>$Register::lang->{'COPPA_parent_instruct'}</b></p>
<p><br>
$iB::INFO->{'COPPA_FAX_NAME'} $Register::lang->{'COPPA_at'} $iB::INFO->{'COPPA_FAX_NUMBER'}</p>
<p>$Register::lang->{'COPPA_or_mail_to'}:<br>
$iB::INFO->{'COPPA_MAIL_ADDR'}
</p>
<p>$Register::lang->{'COPPA_7_days_or_bust'}</p>
</font>
<table width="100%" border="1" cellpadding="4" cellspacing="1">
    <tr>
        <td colspan="2"><p><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_required_info'}</b></font></p></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_username'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_password'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_email'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td colspan="2"><p><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_optional_info'}</b></font></p></td>
    </tr>
    <tr>
        <td colspan="2"><font face="verdana, arial, helvetica" size="2">$Register::lang->{'COPPA_to_make_changes'}<br>
        <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=00'>$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=UserCP;CODE=00</a></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_homepage'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>http://</b></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_signature'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_privacy'}:</b></font><br>
        <font face="verdana,arial,helvetica" size="1">$Register::lang->{'COPPA_form_privacytxt'}</font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_icq'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_aol'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_yahoo'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td colspan="2"><p><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_sign_form_send'}</b></font></p>
        <p><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_review_read'} <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=11','Pager','500','500','0','1','1','1')">$Register::lang->{'COPPA_priv_state_link'}</a> $Register::lang->{'COPPA_can_be_changed'}</font></p></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_parentname'}:</b></font></td>
        <td width="80%">&nbsp;</td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_parentsig'}:</b></font></td>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_relation'}:</b></font></td>
        <td width="80%">&nbsp;</td>
    </tr>
    <tr>
        <td width="20%"><p><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_telephone'}:</b></font></td>
        <td width="80%">&nbsp;</td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_parentmail'}:</b></font></td>
        <td width="80%"><font face="verdana, arial, helvetica" size="2"><b>&nbsp;</b></font></td>
    </tr>
    <tr>
        <td width="20%"><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_form_parentdate'}</b></font></td>
        <td width="80%">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2"><p><font face="verdana, arial, helvetica" size="2"><b>$Register::lang->{'COPPA_please_contact'} <a href="mailto:$iB::INFO->{'ADMIN_EMAIL_IN'}">$iB::INFO->{'ADMIN_EMAIL_IN'}</a> $Register::lang->{'COPPA_with_questions'}</font></b></p></td>
    </tr>
</table>
</body>
</html>
~;
}

sub Show_Privacy {

return qq~
<HTML>
<HEAD>
<TITLE>Sample Privacy Statement</TITLE>
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#0000FF" ALINK="#000000" VLINK="#339933">
<p class="MsoNormal" align="center" style="margin-bottom:6.0pt;text-align:center"><b style="mso-bidi-font-weight:normal"><span style="font-size:11.0pt;mso-bidi-font-size:
10.0pt"><font face="Arial, Helvetica, sans-serif">MODEL PRIVACY STATEMENT<o:p>
</o:p>
</font></span></b></p>
<p class="MsoNormal" style="margin-bottom:6.0pt"><span style="font-size:11.0pt;
mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">This
confirms that $iB::INFO->{'BOARDNAME'} is a licensee of the TRUSTe Privacy Program.<span style="mso-spacerun: yes">&nbsp;
</span>This privacy statement discloses the privacy practices for $iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}. <o:p>
</o:p>
</font></span></p>
<p class="MsoBodyText2"><font face="Arial, Helvetica, sans-serif">TRUSTe is an
independent, non-profit organization whose mission is to build users� trust
and confidence in the Internet by promoting the use of fair information
practices.<span style="mso-spacerun: yes">&nbsp; </span>Because this web site
wants to demonstrate its commitment to your privacy, it has agreed to disclose
its information practices and have its privacy practices reviewed for compliance
by TRUSTe.<span style="mso-spacerun:
yes">&nbsp; </span>By displaying the TRUSTe trustmark, this web site has agreed
to notify you of:</font></p>
<p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:6.0pt;
margin-left:.25in;text-indent:-.25in;mso-list:l0 level1 lfo1;tab-stops:list .25in"><font face="Arial, Helvetica, sans-serif"><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt">1.</span><span style="font-size: 11.0pt; mso-bidi-font-size: 10.0pt; font-style: normal; font-variant: normal; font-weight: normal">&nbsp;&nbsp;
</span><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt">What personally
identifiable information of yours or third party personally identification is
collected from you through the web site<o:p>
</o:p>
</span></font></p>
<p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:6.0pt;
margin-left:.25in;text-indent:-.25in;tab-stops:.25in"><span style="font-size:
11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">2.<span style="mso-tab-count:1">&nbsp;&nbsp;
</span>The organization collecting the information <o:p>
</o:p>
</font></span></p>
<p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:6.0pt;
margin-left:.25in;text-indent:-.25in;tab-stops:.25in"><span style="font-size:
11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">3.<span style="mso-tab-count:1">&nbsp;&nbsp;
</span>How the information is used <o:p>
</o:p>
</font></span></p>
<p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:6.0pt;
margin-left:.25in;text-indent:-.25in;tab-stops:.25in"><span style="font-size:
11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">4.<span style="mso-tab-count:1">&nbsp;&nbsp;
</span>With whom the information may be shared <o:p>
</o:p>
</font></span></p>
<p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:6.0pt;
margin-left:.25in;text-indent:-.25in;tab-stops:.25in"><span style="font-size:
11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">5.<span style="mso-tab-count:1">&nbsp;&nbsp;
</span>What choices are available to you regarding collection, use and
distribution of the information <o:p>
</o:p>
</font></span></p>
<p class="MsoBodyTextIndent"><span style="font-size: 11.0pt; mso-bidi-font-size: 10.0pt"><font face="Arial, Helvetica, sans-serif">6.<span style="mso-tab-count:1">&nbsp;&nbsp;
</span>The kind of security procedures that are in place to protect the loss,
misuse or alteration of information under $iB::INFO->{'BOARDNAME'} control <o:p>
</o:p>
</font></span></p>
<p class="MsoNormal" style="margin-top:0in;margin-right:0in;margin-bottom:6.0pt;
margin-left:.25in;text-indent:-.25in;tab-stops:.25in"><span style="font-size:
11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">7.<span style="mso-tab-count:1">&nbsp;&nbsp;
</span>How you can correct any inaccuracies in the information. <o:p>
</o:p>
</font></span></p>
<h1><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">If
you feel that this company is not abiding by its posted privacy policy, you
should first contact <a href="mailto:$iB::INFO->{'ADMIN_EMAIL_IN'}">$iB::INFO->{'ADMIN_EMAIL_IN'}</a> by e-mail
If you do not receive acknowledgment of your inquiry or your inquiry has not
been satisfactorily addressed, you should then contact TRUSTe at http://www.truste.org.<span style="mso-spacerun: yes">&nbsp;
</span>TRUSTe will then serve as a liaison with the Web site to resolve your
concerns.<o:p>
</o:p>
</font></span></h1>
<h1><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">&nbsp;<br>
Information Collection and Use<o:p>
</o:p>
</font></span></h1>
<p class="MsoNormal"><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">$iB::INFO->{'BOARDNAME'} is the sole owner of the information collected on this site.<span style="mso-spacerun: yes">&nbsp;
</span>We will not sell, share, or rent this information to others in ways
different from what is disclosed in this statement.<span style="mso-spacerun: yes">&nbsp;
</span>$iB::INFO->{'BOARDNAME'} collects information from our users at several different points
on our website.<br>
&nbsp;<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><b>Registration</b><br>
In order to use this website, a user must first complete the registration form.<span style="mso-spacerun: yes">&nbsp;
</span>During registration a user is required to give their contact information
(such as name and email address).<span style="mso-spacerun: yes">&nbsp; </span>This
information is used to contact the user about the services on our site for which
they have expressed interest.<span style="mso-spacerun: yes">&nbsp; </span>It is
optional for the user to provide demographic information (such as income level
and gender), and unique identifiers (such as social security number), but
encouraged so we can provide a more personalized experience on our site.<span style="mso-spacerun:
yes">&nbsp; </span><o:p>
</o:p>
</font></span></p>
<p class="MsoNormal"><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">&nbsp;<b><br>
Order</b><br>
We request information from the user on our order form.<span style="mso-spacerun:
yes">&nbsp; </span>Here a user must provide contact information (like name and
shipping address) and financial information (like credit card number, expiration
date).<span style="mso-spacerun: yes">&nbsp; </span>This information is used for
billing purposes and to fill customer�s orders.<span style="mso-spacerun: yes">&nbsp;
</span>If we have trouble processing an order, this contact information is used
to get in touch with the user.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
<b>Cookies</b><br>
A cookie is a piece of data stored on the user�s hard drive containing
information about the user.<span style="mso-spacerun: yes">&nbsp; </span>Usage
of a cookie is in no way linked to any personally identifiable information while
on our site.<span style="mso-spacerun: yes">&nbsp; </span>Once the user closes
their browser, the cookie simply terminates.<span style="mso-spacerun: yes">&nbsp;
</span>For instance, by setting a cookie on our site, the user would not have to
log in a password more than once, thereby saving time while on our site.<span style="mso-spacerun: yes">&nbsp;
</span>If a user rejects the cookie, they may still use our site.<span style="mso-spacerun: yes">&nbsp;
</span>The only drawback to this is that the user will be limited in some areas
of our site.<span style="mso-spacerun: yes">&nbsp; </span>For example, the user
will not be able to participate in any of our Sweepstakes, Contests or monthly
Drawings that take place. Cookies can also enable us to track and target the
interests of our users to enhance the experience on our site.<o:p>
</o:p>
</font></span></p>
<p class="MsoNormal"><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">Some
of our business partners use cookies on our site (for example, advertisers).<span style="mso-spacerun: yes">&nbsp;
</span>However, we have no access to or control over these cookies.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
<b>Log Files</b><br>
We use IP addresses to analyze trends, administer the site, track user�s
movement, and gather broad demographic information for aggregate use.<span style="mso-spacerun: yes">&nbsp;
</span>IP addresses are not linked to personally identifiable information.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
<b>Sharing<br>
</b>We will share aggregated demographic information with our partners and
advertisers. This is not linked to any personal information that can identify
any individual person.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">We
use an outside shipping company to ship orders, and a credit card processing
company to bill users for goods and services. These companies do not retain,
share, store or use personally identifiable information for any secondary
purposes.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">We
partner with another party to provide specific services. When the user signs up
for these services, we will share names, or other contact information that is
necessary for the third party to provide these services.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">These
parties are not allowed to use personally identifiable information except for
the purpose of providing these services.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
<b>Links<br>
</b>This web site contains
links to other sites. Please be aware that we $iB::INFO->{'BOARDNAME'} are not responsible
for the privacy practices of such other sites.<span style="mso-spacerun: yes">&nbsp;
</span>We encourage our users to be aware when they leave our site and to read
the privacy statements of each and every web site that collects personally
identifiable information.<span style="mso-spacerun:
yes">&nbsp; </span>This privacy statement applies solely to information
collected by this Web site.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
<b>Newsletter<br>
</b>If a user wishes to subscribe to our newsletter, we ask for contact
information such as name and email address. <o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
<b>Surveys &amp; Contests<br>
</b>From time-to-time our site
requests information from users via surveys or contests.<span style="mso-spacerun: yes">&nbsp;
</span>Participation in these surveys or contests is completely voluntary and
the user therefore has a choice whether or not to disclose this information.<span style="mso-spacerun: yes">&nbsp;
</span>Information requested may include contact information (such as name and
shipping address), and demographic information (such as zip code, age level).<span style="mso-spacerun: yes">&nbsp;
</span>Contact information will be used to notify the winners and award prizes.<span style="mso-spacerun: yes">&nbsp;
</span>Survey information will be used for purposes of monitoring or improving
the use and satisfaction of this site.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
<b>Tell-A-Friend<br>
</b>If a user elects to use our
referral service for informing a friend about our site, we ask them for the
friend�s name and email address.<span style="mso-spacerun: yes">&nbsp; </span>$iB::INFO->{'BOARDNAME'} will automatically send the friend a one-time email inviting them to visit
the site.<span style="mso-spacerun: yes">&nbsp; </span>$iB::INFO->{'BOARDNAME'} stores this
information for the sole purpose of sending this one-time email.<span style="mso-spacerun: yes">&nbsp;
</span>The friend may contact $iB::INFO->{'BOARDNAME'} at $iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'} to request the removal
of this information from their database.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;layout-grid-mode:
line"><font face="Arial, Helvetica, sans-serif"><br>
<b>Security<br>
</b></font></span><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">This website
takes every precaution to protect our users� information.<span style="mso-spacerun: yes">&nbsp;
</span>When users submit sensitive information via the website, your information
is protected both online and off-line.&nbsp;<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">When our
registration/order form asks users to enter sensitive information (such as
credit card number and/or social security number), that information is encrypted
and is protected with the best encryption software in the industry - SSL.<span style="mso-spacerun: yes">&nbsp;
</span>While on a secure page, such as our order form, the lock icon on the
bottom of Web browsers such as Netscape Navigator and Microsoft Internet
Explorer becomes locked, as opposed to un-locked, or open, when you are just
�surfing�.<span style="mso-spacerun: yes">&nbsp; </span>To learn more about
SSL, follow this link <a href='http://wp.netscape.com/security/techbriefs/ssl.html'>http://wp.netscape.com/security/techbriefs/ssl.html</a>.<span style="mso-spacerun: yes">&nbsp;&nbsp;&nbsp;
</span>&nbsp;<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">While we use
SSL encryption to protect sensitive information online, we also do everything in
our power to protect user-information off-line.<span style="mso-spacerun: yes">&nbsp;
</span>All of our users� information, not just the sensitive information
mentioned above, is restricted in our offices.<span style="mso-spacerun: yes">&nbsp;
</span>Only employees who need the information to perform a specific job (for
example, our billing clerk or a customer service representative) are granted
access to personally identifiable information.<span style="mso-spacerun: yes">&nbsp;
</span>Our employees must use password-protected screen-savers when they leave
their desk.<span style="mso-spacerun: yes">&nbsp; </span>When they return, they
must re-enter their password to re-gain access to your information.<span style="mso-spacerun: yes">&nbsp;
</span>Furthermore, ALL employees are kept up-to-date on our security and
privacy practices.<span style="mso-spacerun:
yes">&nbsp; </span>Every quarter, as well as any time new policies are added,
our employees are notified and/or reminded about the importance we place on
privacy, and what they can do to ensure our customers� information is
protected.<span style="mso-spacerun: yes">&nbsp; </span>Finally, the servers
that we store personally identifiable information on are kept in a secure
environment, behind a locked cage.&nbsp;<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">If you have any
questions about the security at our website, you can send an email to <a href="mailto:security\@thiswebsite.com">security\@thiswebsite.com.</a><o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">&nbsp;</font></span><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;layout-grid-mode:
line"><font face="Arial, Helvetica, sans-serif"><br>
<b>Supplementation of Information<br>
</b></font></span><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">In order for
this website to properly fulfill its obligation to our customers, it is
necessary for us to supplement the information we receive with information from
3rd party sources.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">For example, to
determine if our customers qualify for one of our credit cards, we use their
name and social security number to request a credit report.<span style="mso-spacerun: yes">&nbsp;
</span>Once we determine a user�s credit-worthiness, this document is
destroyed. <o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">(or)<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;
layout-grid-mode:line"><font face="Arial, Helvetica, sans-serif">In order for
this website to enhance its ability to tailor the site to an individual�s
preference, we combine information about the purchasing habits of users with
similar information from our partners, Company Y &amp; Company Z, to create a
personalized user profile.<span style="mso-spacerun: yes">&nbsp; </span>When a
user makes a purchase from either of these two companies, the companies collect
and share that purchase information with us so we can tailor the site to our
users� preferences.<o:p>
</o:p>
</font></span></p>
<p><b style="mso-bidi-font-weight:normal"><font face="Arial, Helvetica, sans-serif"><span style="font-size: 11.0pt; mso-bidi-font-size: 10.0pt"><br>
Special Offers<br>
</span></font></b><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">We
send all new members a welcoming email to verify password and username.
Established members will occasionally receive information on products, services,
special deals, and a newsletter. Out of respect for the privacy of our users we
present the option to not receive these types of communications. Please see our
choice and opt-out below.<o:p>
</o:p>
</font></span></p>
<p><b style="mso-bidi-font-weight:normal"><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">&nbsp;<br>
</font></span><font face="Arial, Helvetica, sans-serif"><span style="font-size: 11.0pt; mso-bidi-font-size: 10.0pt">Site
and Service Updates<br>
</span></font></b><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">We
also send the user site and service announcement updates. Members are not able
to un-subscribe from service announcements, which contain important information
about the service. We communicate with the user to provide requested services
and in regards to issues relating to their account via email or phone.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
</font></span><b style="mso-bidi-font-weight:normal"><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">Correction/Updating
Personal Information:<br>
</font></span></b><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">If
a user�s personally identifiable information changes (such as your zip code),
or if a user no longer desires our service, we will endeavor to provide a way to
correct, update or remove that user�s personal data provided to us.<span style="mso-spacerun: yes">&nbsp;
</span>This can usually be done at the member information page<b style="mso-bidi-font-weight:normal">
</b>or by emailing our Customer Support<b style="mso-bidi-font-weight:normal">.</b><span style="mso-spacerun: yes">&nbsp;
</span>[Some sites may also provide telephone or postal mail options for
updating<b style="mso-bidi-font-weight:normal"> </b>or correcting<b style="mso-bidi-font-weight:normal">
</b>personal information].<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt;font-weight:normal"><font face="Arial, Helvetica, sans-serif"><br>
</font></span><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><b>Choice/Opt-out<o:p>
</o:p>
<br>
</b>Our users are given the
opportunity to �opt-out� of having their information used for purposes not
directly related to our site at the point where we ask for the information.<span style="mso-spacerun: yes">&nbsp;
</span>For example, our order form has an �opt-out� mechanism so users who
buy a product from us, but don�t want any marketing material, can keep their
email address off of our lists.<span style="mso-spacerun: yes">&nbsp; </span><o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">Users
who no longer wish to receive our newsletter or promotional materials from our
partners may opt-out of receiving these communications by replying to
unsubscribe in the subject line in the email or email us at <a href="mailto:support\@thiswebsite.com">support\@thiswebsite.com</a><span style="mso-spacerun: yes">&nbsp;
</span>[Some sites are able to offer opt-out mechanisms on member information
pages and also supply a telephone or postal option as a way to opt-out.]<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">Users
of our site are always notified when their information is being collected by any
outside parties.<span style="mso-spacerun: yes">&nbsp; </span>We do this so our
users can make an informed choice as to whether they should proceed with
services that require an outside party, or not.<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif"><br>
<b>Notification of Changes<br>
</b>If we decide to change our
privacy policy, we will post those changes on our Homepage so our users are
always aware of what information we collect, how we use it, and under
circumstances, if any, we disclose it.<span style="mso-spacerun: yes">&nbsp; </span>If
at any point we decide to use personally identifiable information in a manner
different from that stated at the time it was collected, we will notify users by
way of an email.<span style="mso-spacerun: yes">&nbsp; </span>Users will have a
choice as to whether or not we use their information in this different manner.
We will use information in accordance with the privacy policy under which the
information was collected. <o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">&nbsp;<o:p>
</o:p>
</font></span></p>
<p><span style="font-size:11.0pt;mso-bidi-font-size:10.0pt"><font face="Arial, Helvetica, sans-serif">&nbsp;<o:p>
</o:p>
</font></span></p>
<p>&nbsp;</p>
</BODY>
</HTML>
~;
}



1;