package NotePadView;



sub pad_text_area {
       my $notepad_text = shift;   
return qq~
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>&raquo; $NotePad::lang->{'your_note_pad'}</td>
   </tr>
   <tr>
        <td align='left' id='category' colspan='2'>$NotePad::lang->{'note_pad_description'}</td>
   </tr>
               <form method='post' action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}">
               <!-- hidden -->
               <input type='hidden' name='act' value='NotePad'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='CODE' value='01'>
               <!-- hidden -->
               <tr>
               <TD bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign="top" align="left" width="120" rowspan="2" nowrap><br /><strong>$NotePad::lang->{'notes'}</strong><br /><br /><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=NotePad;CODE=02">$NotePad::lang->{'s_post'}</a><br><br><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=NotePad;CODE=04">$NotePad::lang->{'s_mess'}</a></TD>
               <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle' align='center'><!--NoCompression//--><textarea name='NOTEPAD_TEXT' cols='54' rows='9' class='textinput' style="width:100%">$notepad_text</textarea><!--/NoCompression//--></td>
               </tr>
               <tr>
               <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle' align='center'><input type='submit' value='$NotePad::lang->{'submit'}' class='forminput'><br><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01'><b>$NotePad::lang->{'back_to_usercp'}</b></a></td>
               </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
               </form>
               </table>
           </td>
       </tr>
    </table>
  <br /> 
~;
}

sub post_text_area {
       my $notepad_text = shift;   
return qq~
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>&raquo; $NotePad::lang->{'your_note_pad'}</td>
   </tr>
   <tr>
        <td align='left' id='category' colspan='2'>$NotePad::lang->{'saved_post'}</td>
   </tr>
               <form method='post' action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}">
               <!-- hidden -->
               <input type='hidden' name='act' value='NotePad'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='CODE' value='03'>
               <!-- hidden -->
               <tr>
               <TD bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign="top" align="left" width="120" rowspan="2"><br><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=NotePad;CODE=00">$NotePad::lang->{'notes'}</a><br><BR><b>$NotePad::lang->{'s_post'}</b><br><br><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=NotePad;CODE=04">$NotePad::lang->{'s_mess'}</a></TD>
               <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle' align='center'><!--NoCompression//--><textarea name='NOTEPAD_TEXT' cols='54' rows='9' class='textinput' style="width: 100%">$notepad_text</textarea><!--/NoCompression//--></td>
               </tr>
               <tr>
               <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle' align='center'><input type='submit' value='$NotePad::lang->{'submit'}' class='forminput'><br><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01'><b>$NotePad::lang->{'back_to_usercp'}</b></a></td>
               </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
               </form>
               </table>
           </td>
       </tr>
    </table>
   <br />
~;
}

sub mess_text_area {
       my $notepad_text = shift;   
return qq~
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
   <tr>
        <td align='left' id='titlemedium' colspan='2'>&raquo; $NotePad::lang->{'your_note_pad'}</td>
   </tr>
   <tr>
        <td align='left' id='category' colspan='2'>$NotePad::lang->{'saved_mess'}</td>
   </tr>
               <form method='post' action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}">
               <!-- hidden -->
               <input type='hidden' name='act' value='NotePad'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='CODE' value='05'>
               <!-- hidden -->
               <tr>
               <TD bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign="top" align="left" width="120" rowspan="2"><br><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=NotePad;CODE=00">$NotePad::lang->{'notes'}</a><br><BR><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=NotePad;CODE=02">$NotePad::lang->{'s_post'}</a><br><br><b>$NotePad::lang->{'s_mess'}</b></TD>
               <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle' align='center'><!--NoCompression//--><textarea name='NOTEPAD_TEXT' cols='54' rows='9' class='textinput' style="width: 100%">$notepad_text</textarea><!--/NoCompression//--></td>
               </tr>
               <tr>
               <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='middle' align='center'><input type='submit' value='$NotePad::lang->{'submit'}' class='forminput'><br><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01'><b>$NotePad::lang->{'back_to_usercp'}</b></a></td>
               </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='2' id='titlemedium'> </td>
     </tr>
               </form>
               </table>
           </td>
       </tr>
    </table>
<br />
~;
}



1;