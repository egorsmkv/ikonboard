package TeamView;

sub admin_header {
  
return qq~
	  <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
		<tr>
		  <td>
			<table cellpadding='4' cellspacing='0' border='0' width='100%'>
			  <tr>
				<td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='90%' id="titlemedium" colspan='2'>Administrators</td>
				<td bgcolor="$iB::SKIN->{'TITLEBACK'}" align="center" width='10%' id="titlemedium"> </td>
			  </tr>
			</table>
			<table cellpadding='4' cellspacing='1' border='0' width='100%'>
~;
}

sub admin_row {
	my $data = shift;   
return qq~
	  <tr>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="left" width='45%'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'MEMBER_ID'}">$data->{'MEMBER_NAME'}</a></td>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align="center" width='45%'><span id="linkthru"><b>All forums</b></td>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align="center" width='10%'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSS;CODE=04;MID=$data->{'MEMBER_ID'}">$iB::SKIN->{'P_MSG'}</a></td>
	  </tr>
~;
}

sub admin_footer {
   
return qq~
			</table>
		  </td>
		</tr>
	  </table>
~;
}

sub sup_mod_header {

return qq~
		  <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
			<tr>
			  <td>
				<table cellpadding='4' cellspacing='0' border='0' width='100%'>
				  <tr>
					<td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='90%' id="titlemedium" colspan='2'>Super Moderators</td>
					<td bgcolor="$iB::SKIN->{'TITLEBACK'}" align="center" width='10%' id="titlemedium"> </td>
				  </tr>
				</table>
				<table cellpadding='4' cellspacing='1' border='0' width='100%'>
~;
}

sub sup_mod_row {
	my $data = shift;
return qq~
	  <tr>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="left" width='45%'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'MEMBER_ID'}">$data->{'MEMBER_NAME'}</a></td>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align="center" width='45%'><span id="linkthru"><b>All forums</b></td>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align="center" width='10%'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=MSS;CODE=04;MID=$data->{'MEMBER_ID'}">$iB::SKIN->{'P_MSG'}</a></td>
	  </tr>
~;
}

sub sup_mod_footer {
   
return qq~
			</table>
		  </td>
		</tr>
	  </table>
~;
}

sub moderator_header {

return qq~
	  <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
		<tr>
		  <td>
			<table cellpadding='4' cellspacing='0' border='0' width='100%'>
			  <tr>
				<td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='45%' id="titlemedium">Moderators</td>
				<td bgcolor="$iB::SKIN->{'TITLEBACK'}" align="center" width='45%' id="titlemedium">Forum</td>
				<td bgcolor="$iB::SKIN->{'TITLEBACK'}" align="center" width='10%' id="titlemedium"> </td>
			  </tr>
			</table>
			<table cellpadding='4' cellspacing='1' border='0' width='100%'>
~;
}

sub moderator_row {
	my ($data, $forum_name, $forum_desc, $pm_link) = @_;
return qq~
	  <tr>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="left" width='45%'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'MEMBER_ID'}">$data->{'MEMBER_NAME'}</a></td>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align="center" width='45%'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF;f=$data->{'FORUM_ID'}">$forum_name</a></td>
		<td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align="center" width='10%'>$pm_link</td>
	  </tr>
~;
}

sub moderator_footer {
   
return qq~
			</table>
		  </td>
		</tr>
	  </table>
~;
}


1;