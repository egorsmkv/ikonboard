package ForumView;

use strict;



sub PageTop {
    my $Data = shift;
return qq~

<!-- Cgi-bot Start Forum page unique top -->
<form
action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SF;f=$Data->{'FORUM_ID'}'
method='POST'>
<table cellpadding='0' cellspacing='4' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
        <td valign='middle' width='50%' nowrap
align='left'>$Data->{'SHOW_PAGES'}</td>
        <td valign='middle' width='50%' nowrap align='right'><a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Post;CODE=00;f=$Data->{'FORUM_ID'}">$iB::SKIN->{'A_POST'}</a>
$Data->{'POLL_BUTTON'}</td>
     </tr>
    </table>
~;
}

sub PageTop_pinned {
    my $Data = shift;
return qq~

<table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}'
bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
     <tr>
         <td>
             <table cellpadding='2' cellspacing='1' border='0' width='100%'>
             <tr>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2'
id='titlemedium'>
                 <!-- Tuck away hidden form elements -->
                    <input type='hidden' name='act' value='SF'>
                    <input type='hidden' name='f'
value='$Data->{'FORUM_ID'}'>
                    <input type='hidden' name='s' value='$iB::SESSION'>
                    <input type='hidden' name='st' value='$iB::IN{'st'}'>
                 <!-- End of tucking :D -->
                 </td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='45%'
align='left' id='titlemedium' valign='middle'>
$Forum::lang->{'h_topic_title_p'}</td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='14%'
align='center' id='titlemedium'
valign='middle'>$Forum::lang->{'h_topic_starter'}</td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='5%' id='titlemedium'
valign='middle'><center>$Forum::lang->{'h_replies'}</center></td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='5%' id='titlemedium'
valign='middle'><center>$Forum::lang->{'h_hits'}</center></td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='25%' id='titlemedium'
valign='middle'>$Forum::lang->{'h_last_action'}</td>
             </tr>
     <!-- Cgi-bot End Forum page unique top -->
~;
}

sub TableEnd {
                            my $Data = shift;
return qq~

<tr>
        <td align='center' id='category' colspan='7'>[ <a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Cookies&f=$iB::IN{f}">$Forum::lang->{'mark_as_read'}</a>
]</td>
</tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center'
colspan='7'
id='titlemedium'>$Forum::lang->{'showing_text'}$Forum::lang->{'sort_text'}
<input type='submit' value='$Forum::lang->{'sort_submit'}'
class='forminput'></td>
     </tr>
</table>
</td>
</tr>
</table>
</form>
     <table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
         <td valign='middle' width='33%' nowrap
align='left'>$Data->{'SHOW_PAGES'}</td>
         <td valign='middle' width='34%' align='center'></td>
         <td valign='middle' width='33%' nowrap align='right'> <a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Post;CODE=00;f=$Data->{'FORUM_ID'}">$iB::SKIN->{'A_POST'}</a>
$Data->{'POLL_BUTTON'} </td>
     </tr>
     </table>
<script language='javascript'>
<!--
    function jumpMenu(targ,selObj,restore){
        eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
        if (restore) selObj.selectedIndex=0;
    }
    //-->
    </script>
<br>
<table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
         <td valign='middle' align='right'>$Data->{'FORUM_JUMP'}</td>
     </tr>
</table>
<br>
<table cellpadding='0' cellspacing='4' border='0' width='50%'
align='center'>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NEW'}
$Forum::lang->{'pm_open_new'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT'}
$Forum::lang->{'pm_hot_new'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL'}
$Forum::lang->{'pm_poll'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_LOCKED'}
$Forum::lang->{'pm_locked'}</td>
     </tr>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NORM'}
$Forum::lang->{'pm_open_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT_NN'}
$Forum::lang->{'pm_hot_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL_NN'}
$Forum::lang->{'pm_poll_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_MOVED'}
$Forum::lang->{'pm_moved'}</td>
     </tr>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NORM_IN'}
$Forum::lang->{'pm_open_no_in'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT_NN_IN'}
$Forum::lang->{'pm_hot_no_in'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL_NN_IN'}
$Forum::lang->{'pm_poll_no_in'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_LOCKED_IN'}
$Forum::lang->{'pm_locked_in'}</td>
     </tr>
</table>
~;
}

sub PageTop_normal {
    my $Data = shift;
return qq~

<table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}'
bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
     <tr>
         <td>
             <table cellpadding='2' cellspacing='1' border='0' width='100%'>
             <tr>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2'
id='titlemedium'>
                 <!-- Tuck away hidden form elements -->
                    <input type='hidden' name='act' value='SF'>
                    <input type='hidden' name='f'
value='$Data->{'FORUM_ID'}'>
                    <input type='hidden' name='s' value='$iB::SESSION'>
                    <input type='hidden' name='st' value='$iB::IN{'st'}'>
                 <!-- End of tucking :D -->
                 </td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='45%'
align='left' id='titlemedium'
valign='middle'>$Forum::lang->{'h_topic_title'}</td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='14%'
align='center' id='titlemedium'
valign='middle'>$Forum::lang->{'h_topic_starter'}</td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='5%' id='titlemedium'
valign='middle'><center>$Forum::lang->{'h_replies'}</center></td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='5%' id='titlemedium'
valign='middle'><center>$Forum::lang->{'h_hits'}</center></td>
                 <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='25%' id='titlemedium'
valign='middle'>$Forum::lang->{'h_last_action'}</td>
             </tr>
     <!-- Cgi-bot End Forum page unique top -->
~;
}

sub TableEndTrackF {
                                 my $Data = shift;
return qq~

    <tr>
        <td align='center' id='category' colspan='7'>[ <a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Cookies&f=$iB::IN{f}">$Forum::lang->{'mark_as_read'}</a>
]  [ <a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Subs;f=$Data->{'FORUM_ID'};t=0">$Forum::lang->{'track_forum'}</a>
]</td>
</tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center'
colspan='7'
id='titlemedium'>$Forum::lang->{'showing_text'}$Forum::lang->{'sort_text'}
<input type='submit' value='$Forum::lang->{'sort_submit'}'
class='forminput'></td>
     </tr>
</table>
</td>
</tr>
</table>
</form>
     <table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
         <td valign='middle' width='50%' nowrap
align='left'>$Data->{'SHOW_PAGES'}</td>
         <td valign='middle' width='50%' nowrap align='right'><a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Post;CODE=00;f=$Data->{'FORUM_ID'}">$iB::SKIN->{'A_POST'}</a>
$Data->{'POLL_BUTTON'}</td>
     </tr>
     </table>
<script language='javascript'>
<!--
    function jumpMenu(targ,selObj,restore){
        eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
        if (restore) selObj.selectedIndex=0;
    }
    //-->
    </script>
<br>
<table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
         <td valign='middle' align='right'>$Data->{'FORUM_JUMP'}</td>
     </tr>
</table>
<br>
<table cellpadding='0' cellspacing='4' border='0' width='50%'
align='center'>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NEW'}
$Forum::lang->{'pm_open_new'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT'}
$Forum::lang->{'pm_hot_new'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL'}
$Forum::lang->{'pm_poll'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_LOCKED'}
$Forum::lang->{'pm_locked'}</td>
     </tr>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NORM'}
$Forum::lang->{'pm_open_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT_NN'}
$Forum::lang->{'pm_hot_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL_NN'}
$Forum::lang->{'pm_poll_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_MOVED'}
$Forum::lang->{'pm_moved'}</td>
     </tr>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NORM_IN'}
$Forum::lang->{'pm_open_no_in'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT_NN_IN'}
$Forum::lang->{'pm_hot_no_in'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL_NN_IN'}
$Forum::lang->{'pm_poll_no_in'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_LOCKED_IN'}
$Forum::lang->{'pm_locked_in'}</td>
     </tr>
</table>
~;
}

sub show_no_matches {

return qq~

     <tr>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align='center'
colspan='7'><br><br><b>$Forum::lang->{'no_topics'}</b><br><br> </td>
     </tr>
~;
}

sub show_rules {
                             my $rules = shift;
return qq~

<!-- Show Forum FAQ/Rules -->
    <br>
     <table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}'
bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0'
width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left'
id='titlelarge'>$rules->{'RULES_TITLE'}</td>
                </tr>
                <tr>
                <td
bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$rules->{'RULES_TEXT'}<br><br>$Forum::lang->{'last_updated'}
$rules->{'LAST_UPDATE'}<br><br><a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SF;f=$iB::IN{'f'}">$Forum::lang->{'back_to_forum'}</td>
             </tr>
             </table>
            </td>
     </tr>
</table>
<!-- End Forum FAQ/Rules -->
~;
}

sub Mod_Panel {
                             my $data = shift;
return qq~
    <br />
    <table cellpadding='3' cellspacing='1' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
         <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'>[ <a
href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ModCP;f=$data'>$Forum::lang->{'mod_cp'}</a>
]</td>
        </tr>
    </table>
    <br />
~;
}

sub Render_p_Row {
                                my $Data = shift;                     my
$eventl;                     if ($Data->{'EVENT'}->{'MEMBER_NAME'})
{                                    $eventl = " <font
color='$iB::INFO->{'EVENT_FORUM'}'>[$Data->{'EVENT'}->{'MEMBER_NAME'}
$Data->{'EVENT'}->{'DATE'}]</font>";    }
return qq~

    <!-- Begin Topic Entry $Data->{'TOPIC_ID'} -->
    <tr>
    <td bgcolor='$iB::SKIN->{'PIN_COL_ONE'}' width='4%'
align='center'>$Data->{'FOLDER_ICON'}</td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_ONE'}' width='4%'
align='center'>$Data->{'TOPIC_ICON'}</td>
    <td
onclick="location.href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'}'"
onmouseover="style.cursor='pointer';style.cursor='hand';style.backgroundColor='$iB::SKIN->{'M_OVER_T'}';
window.status='$Forum::lang->{'enter_topic_pinned'}';return true"
onmouseout="style.cursor='';style.backgroundColor='';
window.status='';return true" bgcolor='$iB::SKIN->{'PIN_COL_TWO'}'
width='40%'>$Data->{'WATCHED_ICON'}<span
id="linkthru">$iB::INFO->{'PRE_PINNED'} <a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'}"
title='$Forum::lang->{'topic_started_on'}
$Data->{'TOPIC_START_DATE'}'>$Data->{'TOPIC_TITLE'}</a></span>
$Data->{'PAGES'}<br><span id='desc'>$Data->{'TOPIC_DESC'}$eventl</span></td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_THREE'}' align='center'
valign='middle'>$Data->{'STARTER'}</td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_FOUR'}' align='center'
valign='middle'><a
href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Posters;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'}','Pager','350','200','0','1','1','1')">$Data->{'TOPIC_POSTS'}</a></td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_FIVE'}' align='center'
valign='middle'>$Data->{'TOPIC_VIEWS'}</td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_SIX'}' valign='middle'
align='left'><span id='highlight'>$Data->{'TOPIC_LAST_DATE'}</span><br
/>$Data->{'LASTPOST_LINK'} $Data->{'LAST_TEXT'} $Data->{'LAST_POSTER'}</td>
    </tr>
    <!-- End Topic Entry $Data->{'TOPIC_ID'} -->
<!--<tr>
<td id="category" colspan='7'> </td>
</tr>-->
~;
}

sub After_p_Rows {

return qq~

</table>
</td>
</tr>
</table>
<table cellpadding='0' cellspacing='4' border='0' width='50%'
align='center'>
<tr>
    <td colspan='7' height='10'> </td>
</tr>
</table>
<table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}'
bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
     <tr>
     <td>
         <table cellpadding='2' cellspacing='1' border='0' width='100%'>
         <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2'
id='titlemedium'> </td>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='45%'
align='left' id='titlemedium'
valign='middle'><b>$Forum::lang->{'h_topic_title'}</td>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='14%'
align='center' id='titlemedium'
valign='middle'>$Forum::lang->{'h_topic_starter'}</td>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='5%' id='titlemedium'
valign='middle'><center>$Forum::lang->{'h_replies'}</center></td>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='5%' id='titlemedium'
valign='middle'><center>$Forum::lang->{'h_hits'}</center></td>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center'
width='25%' id='titlemedium'
valign='middle'>$Forum::lang->{'h_last_action'}</td>
         </tr>
~;
}

sub show_rules_full {
                                 my $rules = shift;
return qq~

    <!-- Show FAQ/Forum Rules -->
    <table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
         <td align='left'
><b>$rules->{'RULES_TITLE'}</b><br><br>$rules->{'RULES_TEXT'}</td>
     </tr>
</table>
<!-- End FAQ/Forum Rules -->
~;
}

sub Online {
                             my ($inforum_count, $inforum_list) = @_;
return qq~
     <table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}'
bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='1' border='0'
width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left'
id='titlelarge'><b>$inforum_count</b>
$Forum::lang->{'forum_members_active'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'
align='left'>$inforum_list</td>
             </tr>
    <tr>
        <td align='center' id='category'> </td>
</tr>
             </table>
            </td>
     </tr>
</table>
<br />
~;
}

sub show_rules_link {
                                 my $rules = shift;
return qq~

    <!-- Show FAQ/Forum Rules -->
    <table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
         <td align='left' valign='middle'><b>� <a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SR;f=$iB::IN{'f'}">$rules->{'RULES_TITLE'}</a></b></td>
     </tr>
</table>
<!-- End FAQ/Forum Rules -->
~;
}

sub RenderRow {
                             my $Data = shift;                 my
$eventl;                 if ($Data->{'EVENT'}->{'MEMBER_NAME'})
{                                 $eventl = " <font
color='$iB::INFO->{'EVENT_FORUM'}'>[$Data->{'EVENT'}->{'MEMBER_NAME'}
$Data->{'EVENT'}->{'DATE'}]</font>";    }
return qq~

    <!-- Begin Topic Entry $Data->{'TOPIC_ID'} -->
    <tr>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' width='4%'
align='center'>$Data->{'FOLDER_ICON'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' width='4%'
align='center'>$Data->{'TOPIC_ICON'}</td>
    <td
onclick="location.href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'}'" class="forumclick"
width='40%'>$Data->{'WATCHED_ICON'}<span id="linkthru">$Data->{'PREFIX'}
<a
href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'}"
title='$Forum::lang->{'topic_started_on'}
$Data->{'TOPIC_START_DATE'}'>$Data->{'TOPIC_TITLE'}</a></span>
$Data->{'PAGES'}<br><span id='desc'>$Data->{'TOPIC_DESC'}$eventl</span></td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_SIX'}' align='center'
valign='middle'>$Data->{'STARTER'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_FOUR'}' align='center'
valign='middle'><a
href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Posters;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'}','Pager','350','200','0','1','1','1')">$Data->{'TOPIC_POSTS'}</a></td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_SEVEN'}' align='center'
valign='middle'>$Data->{'TOPIC_VIEWS'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_FIVE'}' valign='middle'
align='left'><span
id='highlight'>$Data->{'TOPIC_LAST_DATE'}</span><br>$Data->{'LASTPOST_LINK'}
$Data->{'LAST_TEXT'} $Data->{'LAST_POSTER'}</td>
    </tr>
    <!-- End Topic Entry $Data->{'TOPIC_ID'} -->
~;
}

sub Forum_log_in {
                                my $Data = shift;
return qq~

     <form
action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SF;f=$Data"
method="post">
     <input type='hidden' name='act' value='SF'>
     <input type='hidden' name='f' value='$Data'>
     <input type='hidden' name='L' value='1'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     <table cellpadding='0' cellspacing='0' border='0'
width='$iB::SKIN->{'TABLE_WIDTH'}'
bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='1' border='0'
width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left'
colspan='2' id='titlelarge'>� $Forum::lang->{'need_password'}</td>
                </tr>
<tr>
        <td align='center' id='category' colspan='2'> </td>
</tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'
colspan='2'>$Forum::lang->{'need_password_txt'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'
width='40%'><b>$Forum::lang->{'enter_pass'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input
type='password' size='20' name='f_password' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center'
colspan='2'><input type="submit" value="$Forum::lang->{'f_pass_submit'}"
class='forminput'></td>
                </tr>
<tr>
        <td align='center' id='category' colspan='2'> </td>
</tr>
     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center'
colspan='2' id='titlemedium'> </td>
     </tr>
                </table>
            </td>
     </tr>
    </table>
    </form>
<br />
~;
}



1;