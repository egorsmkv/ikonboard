package ReportView;



sub sent_screen {
    my ($member_name) = @_;
return qq~

     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>&raquo; $MailMember::lang->{'email_sent'}</b></td>                
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='usermenu'><img src='$iB::INFO->{'IMAGES_URL'}/images/cp_redtri.gif' border='0' height='15' width='15' align='middle' alt=''>&nbsp;<b>$MailMember::lang->{'email_sent'}</b></td>
                 </tr>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><img src='$iB::INFO->{'IMAGES_URL'}/images/msg_sent.gif' border='0' height='32' width='32' alt=''></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><b>$MailMember::lang->{'email_sent_txt'} $member_name</td>
                 </tr>
                </table>
            </td>
         </tr>
      </table>
~;
}

sub header {
    my $data = shift;
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION" method="post" name='REPLIER'>
     <input type='hidden' name='act' value='Report'>
     <input type='hidden' name='SEND' value='1'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     <input type='hidden' name='f' value='$iB::IN{'f'}'>
     <input type='hidden' name='t' value='$iB::IN{'t'}'>
     <input type='hidden' name='st' value='$iB::IN{'st'}'>
     <input type='hidden' name='p' value='$iB::IN{'p'}'>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlemedium'>&raquo; $Report::lang->{'title'}</td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='20%' valign='top'><b>$Report::lang->{'in_forum'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'><b>$data->{'FORUM'}->{'FORUM_NAME'}</b></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'  width='20%' valign='top'><b>$Report::lang->{'in_topic'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><b>$data->{'TOPIC'}->{'TOPIC_TITLE'}</b></td>
                </tr>
      
~;
}

sub body {
        
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>$Report::lang->{'message'}<br><br><span style='font-size:12px;color:red;font-weight:bold'>$Report::lang->{'warn'}</span></td> 
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><textarea cols='60' rows='12' wrap='soft' name='Post' tabindex='3' class='textinput'></textarea></td>
                </tr>
  
~;
}

sub guest {
        
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'  width='20%' valign='top'><b>$Report::lang->{'name'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><input type='text' name='name' value='' size='50' maxlength='50' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='20%' valign='top'><b>$Report::lang->{'email'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><input type='text' name='email' value='' size='50' maxlength='50' class='forminput'></td>
                </tr>
    
~;
}

sub foot {
        
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2' id='category'>
                <input type="submit" value="$Report::lang->{'send'}" class='forminput'>
                </tr>
   <tr>
        <td align='center' id='titlemedium' colspan='2'> </td>
   </tr>
               </table>
            </td>
         </tr>
      </table>
      </form>
<br />
~;
}



1;