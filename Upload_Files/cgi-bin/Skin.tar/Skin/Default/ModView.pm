package ModView;

use strict;





sub edit_js {

    
return qq~
<script language='JavaScript'>
<!--
function ValidateForm() {
    TitleLength  = document.REPLIER.TopicTitle.value.length;
    errors = "";
    if (TitleLength < 2) {
         errors = "You must enter a topic title!";
    }
    if (errors != "") {
        alert(errors);
        return false;
    } else {
        document.REPLIER.submit.disabled = true;
        return true;
    }
}
//-->
</script>
~;
}

sub mod_exp {
        my $words = shift;
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>$words</td>
                </tr>
~;
}

sub move_form {
        my ($html, $forum_name) = @_;
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$Moderate::lang->{'move_from'} <b>$forum_name</b> $Moderate::lang->{'to'}:</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$html</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$Moderate::lang->{'delete_old'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                  <select name='leave' class='forminput'>
                  <option value='leave_full'  selected>$Moderate::lang->{'leave_locked'}
                  <option value='leave_empty'>$Moderate::lang->{'leave_empty'}
                  <option value='delete'>$Moderate::lang->{'dont_leave'}
                  </select>
                </td>
                </tr>
~;
}

sub topictitle_fields {
        my ($title, $desc, $ename, $eyear, $emonth, $eday) = @_;
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'edit_f_title'}</b></font></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='50' name='TopicTitle' value='$title' class='forminput' tabindex='1'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'edit_f_desc'}</b></font></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='40' name='TopicDesc' value='$desc' class='forminput' tabindex='2'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'ename'}</b></font></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='15' maxlength='15' name='ename' value='$ename' class='forminput' tabindex='3'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'eyear'}</b></font></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='4' maxlength='4' name='eyear' value='$eyear' class='forminput' tabindex='4'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'emonth'}</b></font></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='2' maxlength='2' name='emonth' value='$emonth' class='forminput' tabindex='5'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'eday'}</b></font></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='2' maxlength='2' name='eday' value='$eday' class='forminput' tabindex='6'></td>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'enablevent'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='checkbox' name='enablevent' value='1' checked tabindex='7'></td>
                </tr>
~;
}

sub end_form {
        my $action = shift;
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" name="submit" value="$action" class='forminput' tabindex='8'>
                </td></tr></table>
                </td></tr></table>
                </form>
~;
}

sub table_top {
        my $posting_title = shift;
return qq~
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>$posting_title</td>
                </tr>
~;
}

sub delete_js {

    
return qq~
          <script language='JavaScript'>
          <!--
          function ValidateForm() {
             document.REPLIER.submit.disabled = true;
             return true;
          }
          //-->
          </script>
~;
}



1;