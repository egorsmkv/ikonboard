package WarnView;



sub Body {
    
return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>$Warn::lang->{'message'}<br><br><span style='font-size:12px;color:red;font-weight:bold'>$Warn::lang->{'warn'}</span></td> 
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><textarea cols='60' rows='12' wrap='soft' name='Message' tabindex='3' class='textinput'></textarea></td>
                </tr>
~;
}

sub Header {
                my $data = shift;   
return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION" method="post" name='REPLIER' style="margin:0">
     <input type='hidden' name='act' value='Warn'>
     <input type='hidden' name='CODE' value='01'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     <input type='hidden' name='f' value='$iB::IN{'f'}'>
     <input type='hidden' name='t' value='$iB::IN{'t'}'>
     <input type='hidden' name='p' value='$iB::IN{'p'}'>
     <input type='hidden' name='MID' value='$iB::IN{'MID'}'>
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' colspan='2' id='titlemedium'>&raquo; $Warn::lang->{'title'}</td>
                </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='20%' valign='top'><b>$Warn::lang->{'curr_level'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'><b>$data->{'MEMBER'}->{'WARN_LEVEL'}</b></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'  width='20%' valign='top'><b>$Warn::lang->{'inc_level'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'><input type="checkbox" name="inc"></b></td>
                </tr>
~;
}

sub DoneWarn {
                my $name = shift;   
return qq~

     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>&raquo; $Warn::lang->{'warned'}</b></td>                
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' id='usermenu'><img src='$iB::INFO->{'IMAGES_URL'}/images/cp_redtri.gif' border='0' height='15' width='15' align='middle' alt=''> <b>$Warn::lang->{'warned'}</b></td>
                 </tr>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><img src='$iB::INFO->{'IMAGES_URL'}/images/msg_sent.gif' border='0' height='32' width='32' alt=''></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><b>$name $Warn::lang->{'warned_txt'}</td>
                 </tr>
   <tr>
        <td align='center' id='category' colspan='2'> </td>
   </tr>
   <tr>
        <td align='center' id='titlemedium' colspan='2'> </td>
   </tr>
                </table>
            </td>
         </tr>
      </table>
~;
}

sub Footer {
    
return qq~

                    <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2' id='category'>
                <input type="submit" value="$Warn::lang->{'send'}" class='forminput'>
                </tr>
   <tr>
        <td align='center' id='titlemedium' colspan='2'> </td>
   </tr>
               </table>
            </td>
         </tr>
      </table>
      </form>
~;
}



1;