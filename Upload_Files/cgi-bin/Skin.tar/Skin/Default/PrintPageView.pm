package PrintPageView;

use strict;




sub pp_header {
                my ($forum_name, $topic_title, $topic_starter) = @_;
return qq~
   <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
    <html>
    <head>
    <title>$iB::INFO->{'BOARDNAME'} &raquo; $Print::lang->{'title'} &raquo; $topic_title</title>
<style type="text/css">
body {font-size: 8.5pt; font-family: Verdana; background-color: #ffffff}
table {border:1px solid #000000; font-size: 8.5pt;}
.forminput     {font-size: 10px; font-family: verdana; vertical-align:middle; color: #666666; background-color: #dfdfdf; border: 1px solid #666666;}
</style>
    </head>
    <body>
    <table width='100%' border='1' cellpadding=6 cellspacing=0 align='center'>
    <tr>
    <td>
      <font face='arial' size='2' color='#000000'>
     <b>  $Print::lang->{'forum'}: $forum_name<br>
    $Print::lang->{'topic'}: $topic_title<br>
 $Print::lang->{'start'}: $topic_starter</b>
    </font><hr noshade size='1'>

~;
}

sub pp_postentry_m {
                my ($mess) = @_;
return qq~
    <br>     $mess->{'MESSAGE'}
  <hr noshade size='1'>
~;
}

sub pp_header_m {
                my ($from, $date, $subj) = @_;  #----->> END OF ROUTINE, do not edit this line
return qq~
   <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
    <html>
    <head>
    <title>$iB::INFO->{'BOARDNAME'} &raquo; $Print::lang->{'message_title'}</title>
<style type="text/css">
body {font-size: 8.5pt; font-family: Verdana; background-color: #ffffff}
table {border:1px solid #000000;}    
.forminput     {font-size: 10px; font-family: verdana; vertical-align:middle; color: #666666; background-color: #dfdfdf; border: 1px solid #666666;}
</style>
    </head>
    <body>
    <table width='100%' border='1' cellpadding=6 cellspacing=0 align='center'>
    <tr>
    <td>
      <font face='arial' size='2' color='#000000'>
     <b>  $Print::lang->{'subject'} $subj<br>
    $Print::lang->{'from'} $from<br>
 $Print::lang->{'on'}: $date</b>
    </font><hr noshade size='1'>
 
~;
}

sub pp_end {

    return qq~

    </td>
    </tr>
    </table>
~;
}

sub pp_postentry {
                my ($poster, $entry) = @_;
return qq~
   <div align="right"> <b><i>$Print::lang->{'by'} $poster->{'MEMBER_NAME'} $Print::lang->{'on'} $entry->{'POST_DATE'}</i></b></div>
        $entry->{'POST'}
  <hr noshade size='1'>
~;
}



1;