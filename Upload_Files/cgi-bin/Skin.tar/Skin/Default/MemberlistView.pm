package MemberlistView;

sub end_show_row {
        my $member = shift;
return qq~
              </tr>
~;
}

sub group {
        my $member = shift;
return qq~
  <td width='10%' bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}'><center>$member->{'MEMBER_GROUP'}</center></td>
~;
}

sub title_end_show_row {
                my $links = shift;
return qq~

                </tr>
   <tr>
        <td align='center' id='category' colspan='10'> </td>
   </tr>
~;
}

sub title_aim {
                my $links = shift;  my $aim = "$member->{'AOLNAME'}";
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='8%'>$Memberlist::lang->{'member_aol'}</td>
~;
}

sub msn {
        my $member = shift;
return qq~

                <td width='8%' bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' align='center'>$member->{'MSNNAME'}</td>
~;
}

sub aim {
        my $member = shift; my $aim = "$member->{'AOLNAME'}";
return qq~

                <td width='8%'  bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' align='center'>
$aim
</td>
~;
}

sub title_posts {
                my $links = shift;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='8%'>$Memberlist::lang->{'member_posts'}</td>
~;
}

sub Page_end {

    return qq~
   <tr>
        <td align='center' id='category' colspan='10'> </td>
   </tr>
<tr>
            <td id='titlemedium' bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='10' align='center'><form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Members' method='POST'>
              <input type='hidden' name='act' value='Members'>
              <input type='hidden' name='s'   value='$iB::SESSION'>
              $Memberlist::lang->{'sorting_text'}  <input type='submit' value='$Memberlist::lang->{'sort_submit'}' class='forminput'></td>
            </tr>
            </table>
            </td>
            </tr>
            </table>
</form>
~;
}

sub posts {
        my $member = shift;
return qq~

                <td width='8%' bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' align='center'>$member->{'MEMBER_POSTS'}</td>
~;
}

sub Page_header {
                my $links = shift;
return qq~

 <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr id='titlemedium'>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='left'>$Memberlist::lang->{'member_name'}</td>
~;
}

sub title_yahoo {
                my $links = shift;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='8%'>$Memberlist::lang->{'member_yim'}</td>
~;
}

sub title_joined {
                my $links = shift;
return qq~
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='12%'>$Memberlist::lang->{'member_joined'}</td>
~;
}

sub title_icq {
                my $links = shift;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='8%'>$Memberlist::lang->{'member_icq'}</td>
~;
}

sub title_pips {
                my $links = shift;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='10%'>$Memberlist::lang->{'member_level'}</td>
~;
}

sub joined {
        my $member = shift;
return qq~
 <td width='12%' bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' align='center'>$member->{'MEMBER_JOINED'}</td>
~;
}

sub yahoo {
        my $member = shift;
return qq~

                <td width='8%'  bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' align='center'>$member->{'YAHOONAME'}</td>
~;
}

sub end {
                my $links = shift;
return qq~

          <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
            <tr>
              <td valign='middle' align='left'>$links->{'SHOW_PAGES'}</td>
            </tr>
          </table>
~;
}

sub title_email {
                my $links = shift;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' width='8%' align='center'>$Memberlist::lang->{'member_email'}</td>
~;
}

sub no_results {

    return qq~
    <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'><tr>
     <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' width='8%' align='center'>&nbsp;</td>
     </tr>
    <tr>
           <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' width='8%' align='center'><p><br>$Memberlist::lang->{'no_results'}<br><br><strong>� � <a href='javascript:history.go(-1);'>$Memberlist::lang->{'error_back'}</a></strong><br><br></p></td>
    </tr>
    <tr>
         <td id="category">&nbsp;</td>
    </tr>
    </table>

           ~;
}

sub icq {
        my $member = shift;
return qq~

  <td width='8%' bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}' align='center'>$member->{'ICQNUMBER'}</td>
~;
}

sub pips {
        my $member = shift;
return qq~
<td width='10%' bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}'>$member->{'MEMBER_PIPS_IMG'}</td>
~;
}

sub start {

    return qq~

          <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
            <tr>
              <td valign='middle' align='center'>
              </td>
            </tr>
          </table>
~;
}

sub title_msn {
                my $links = shift;
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='8%'>$Memberlist::lang->{'member_msn'}</td>
~;
}

sub email {
        my $member = shift;
return qq~

                <td width='8%' bgcolor='$iB::SKIN->{'MEMBER_COL_ONE'}' align='center'>$member->{'MEMBER_EMAIL'}</td>
~;
}

sub title_group {
                my $links = shift;
return qq~
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='10%'>$Memberlist::lang->{'member_group'}</td>
~;
}

sub show_row {
        my $member = shift;
return qq~

  <tr>
 <td bgcolor='$iB::SKIN->{'MEMBER_COL_TWO'}'><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$member->{'MEMBER_ID'}">$member->{'MEMBER_NAME'}</a></b></td>
~;
}



1;