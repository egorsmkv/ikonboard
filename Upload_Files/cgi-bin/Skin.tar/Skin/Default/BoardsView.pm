package BoardsView;




sub PageTop {
                                                                                                                                                my $Data = shift;if ($iB::INFO->{'MOD_DROP_DOWN'}){ $span='2' } else { $span='1'};
return qq~

      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
            <tr>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='5%' id="titlemedium"> </td>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='50%' id="titlemedium">$Boards::lang->{'cat_name'}</td>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='1%' align='center' id="titlemedium">$Boards::lang->{'topics'}</td>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='1%' align='center' id="titlemedium">$Boards::lang->{'replies'}</td>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" colspan='$span' width='15%' align='center' id="titlemedium">$Boards::lang->{'last_post_info'}</td>
            </tr>
~;
}

sub Web_Ring {
                                                                                                                                    return undef unless $iB::INFO->{'WEB_RING'};    my @web_ring = split /\|\^\|/, $iB::INFO->{'WEB_RING'};    my ($url, $title, @new_web_ring);    for (@web_ring) {        ($url, $title) = split /\|\&\|/, $_;        next unless $url and $title;        $title = $url if $title eq '';        $url   = qq!http://$url! if $url !~ m#^http\://#i;        push @new_web_ring, qq!<option value='$url'>$title!;    }        my $options = join /\n/, @new_web_ring;
return qq~

    <!-- Cgi-bot Web Ring -->
    <tr>
        <td bgcolor='$iB::SKIN->{'MISCBACK_SIX'}' width='100%' colspan='$iB::INFO->{'CN'}'>
        <fieldset><p><legend>$Boards::lang->{'binfo_webring'} <img src="$iB::INFO->{'IMAGES_URL'}/images/webring.gif" /></legend>
            <table cellspacing='4' cellpadding='1' border='0' width='100%'>
            <tr>
                <td bgcolor="$iB::SKIN->{'MISCBACK_SIX'}" width='95%' align='center'>$Boards::lang->{'web_ring_txt'}</td>
            </tr>
            <tr>
               <td bgcolor="$iB::SKIN->{'MISCBACK_SIX'}" width="30%" align='center' valign='middle'>
               <select onchange="window.open(this.options[this.selectedIndex].value,'_blank','menubar=1,toolbar=1,location=1,status=1,resizable=1,maximizeable=1,scrollbars=1'); this.selectedIndex=0" class='forminput'>
               <option value='about:blank' selected>$Boards::lang->{'web_ring_choose'}
               $options
               </select>
               </td>
            </tr>
            </table>
            </p> </fieldset>
        </td>
    </tr>
    <!-- Cgi-bot End Web Ring -->
~;
}

sub Invite_Friend {

return qq~

    <!-- Cgi-bot Invite Friend -->
    <tr>
        <td bgcolor='$iB::SKIN->{'MISCBACK_FIVE'}' align='center' width='100%' colspan='$iB::INFO->{'CN'}'>
        <script language="javascript">
        <!--
        function DoDisplay(element) {
            MyName  = "$iB::MEMBER->{'MEMBER_NAME'}";
            MyEmail = "$iB::MEMBER->{'MEMBER_EMAIL'}";
            if (MyEmail == "") {
                MyEmail = "you\@domain.com";
            }
            if (element == "NAME") {
                document.REPLIER.SenderName.value = MyName;
                return true;
            }
            if (element == "EMAIL") {
                document.REPLIER.SendersEmail.value = MyEmail;
                return true;
            }
        }
        //-->
        </script>
        <fieldset><p>
          <legend>$Boards::lang->{'binfo_invite'} <img src="$iB::INFO->{'IMAGES_URL'}/images/email.gif" /></legend>
            <table cellspacing='4' cellpadding='1' border='0' width='100%'>
            <tr>
                <td width="95%" align='center' colspan='4'>$Boards::lang->{'invite_txt_a'} $iB::INFO->{'BOARDNAME'}$Boards::lang->{'complete_form'}</td>
            </tr>
            <tr>
               <form name='REPLIER' method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}'>
               <input type='hidden' name='act' value='Invite'>
               <td width="30%" align='center' valign='middle'>
               <input type='text' name='SenderName' size='25' maxlength='80' value="$Boards::lang->{'your_name'}" class='forminput' onMouseOver="this.focus()" onFocus="DoDisplay('NAME')">
               <input type='text' name='SendersEmail' size='25' maxlength='80' value="$Boards::lang->{'email_addy_from'}" class='forminput' onMouseOver="this.focus()" onFocus="DoDisplay('EMAIL')">
               <input type='text' name='RecipientEmail' size='25' maxlength='80' value="$Boards::lang->{'email_addy_to'}" class='forminput' onMouseOver="this.focus()" onFocus="this.select()">
               <input type='submit' name='submit' value="$Boards::lang->{'invite_submit'}" class='forminput'>
               </td>
               </form>
            </tr>
            </table><br>
            </p></fieldset>
        </td>
    </tr>
    <!-- Cgi-bot End Invite Friend -->
~;
}

sub CatHeader_Collapsed {
                                my $Data = shift;if (!$iB::INFO->{'MOD_DROP_DOWN'}){    $cat_mods =qq~~;}else { $cat_mods =qq~<br>$Data->{'MODERATOR'}~;}if ($iB::INFO->{'MOD_DROP_DOWN'}){  $cat_column6 = qq~ <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" width='15%' align='center' valign='middle'> </td>       ~;} else {  $cat_column6 ='';}
return qq~

<!-- Category $Data->{'CAT_ID'} entry -->
 <tr>
    <td bgcolor="$iB::SKIN->{'EXP_CAT_ONE'}" align="center" width="5%">$Data->{'NEW_POST_IMG'}</td>
    <td onclick="location.href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SC;c=$Data->{'CAT_ID'}'" onmouseover="style.cursor='pointer';style.cursor='hand';style.backgroundColor='$iB::SKIN->{'M_OVER_F'}'; window.status='$Boards::lang->{'enter_subcat'}';return true" onmouseout="style.cursor='';style.backgroundColor=''; window.status='';return true" bgcolor="$iB::SKIN->{'EXP_CAT_TWO'}" align="left" width='45%'><span id='linkthru'><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SC;c=$Data->{'CAT_ID'}">$Data->{'CAT_NAME'}</a></b></span><br>$Data->{'CAT_DESC'}<br>$mods<br><table border="0" cellpadding="2" cellspacing="0" width='100%' align='center'><tr><td valign='middle' align='left' width='50%'>$Boards::lang->{'subcat_active'}: $Data->{'FORUM_USERS'}</td><td valign='middle' align='left' width='50%'>$Boards::lang->{'total_forums'} $Data->{'TOTAL_FORUMS'}</td></tr></table></td>
    <td bgcolor="$iB::SKIN->{'EXP_CAT_THREE'}" align='center' valign='middle' width='10%'>$Data->{'TOPICS'}</td>
    <td bgcolor="$iB::SKIN->{'EXP_CAT_FOUR'}" align='center' valign='middle' width='10%' id='highlight'>$Data->{'POSTS'}</td>
    <td bgcolor="$iB::SKIN->{'EXP_CAT_FIVE'}" align="left" valign='middle' width='35%'><span id='highlight'>$Data->{'LAST_POST'}</span><br>$Boards::lang->{'in'}: $Data->{'N_LINK'}<br>$Boards::lang->{'by'}: $Data->{'P_LINK'}</td>
    $cat_column6
 </tr>
<!-- Category $Data->{'CAT_ID'} entry -->
~;
}

sub CatHeader_Expanded {
                                                                                                                                                my $Data = shift;
return qq~

<tr>
             <td bgcolor="$iB::SKIN->{'CAT_BACK'}" colspan='$iB::INFO->{'CN'}' id='category'>
               <table cellspacing='0' cellpadding='0' align='center' width='100%'>
                <tr>
                  <td align='left'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SC;c=$Data->{'CAT_ID'}"><strong>$Data->{'CAT_NAME'}</strong></a></td>
                  <td align='right'><strong>$Data->{'CAT_SPONSOR'}</strong></td>
                </tr>
               </table>
             </td>
            </tr>
~;
}

sub ActiveUsers {
                                                                                                                                                my ($names, $link, $teamlist, $members, $guests, $anon, $total) = @_;
return qq~

   <tr>
        <td align='center' id='category1' colspan='$iB::INFO->{'CN'}'></td>
   </tr>
            <tr>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}"align='center' id="titlemedium" colspan='$iB::INFO->{'CN'}'>[ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Cookies">$Boards::lang->{'d_delete_cookies'}</a> ] :: [ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=PMarkers;MID=$iB::MEMBER->{'MEMBER_ID'}">$Boards::lang->{'d_post_read'}</a> ]</td>
</tr>
 </table>
 </td>
 </tr>
 </table>
 <br><br>
    <!-- Cgi-bot Active Users -->
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='0' border='0' width='100%' class="boardinfo">
   <tr>
        <td align='left' id='titlemedium' colspan='$iB::INFO->{'CN'}'>&raquo; $Boards::lang->{'board_info'}</td>
   </tr>
    <tr>
        <td bgcolor="$iB::SKIN->{'CAT_BACK'}" colspan='$iB::INFO->{'CN'}'  id='boardinfocat'>$link $teamlist</td>
    </tr>
<tr>
        <td bgcolor="$iB::SKIN->{'MISCBACK_TWO'}" align='left' colspan='$iB::INFO->{'CN'}' >
       <fieldset><legend>$Boards::lang->{'binfo_user'} <img src="$iB::INFO->{'IMAGES_URL'}/images/empl.gif" /></legend>
<ul>
<li><b>$guests</b> $Boards::lang->{'guests'}, <b>$members</b> $Boards::lang->{'public_members'} <b>$anon</b> $Boards::lang->{'anon_members'}<br>
$names</li>
<li>$total $Boards::lang->{'active_users'}
<li><!--BIRTHDAY HTML--></li>
</ul>
<ul>
<li><!--EVENT HTML--></li>
</ul></fieldset></td>
</tr>
    <!-- Cgi-bot End of Active Users -->
~;
}

sub Board_footer {

return qq~

    <tr>
        <td width="100%" bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='$iB::INFO->{'CN'}' id='titlemedium'>&nbsp; </td>
     </tr>
<!-- End Board legend -->
<!-- Cgi-bot Script page footer -->
 </table>
 </td>
 </tr>
 </table>
 <br />
<!-- Cgi-bot End of script page footer -->
~;
}

sub ShowStats {
                                                                                                                                               my $Stats = shift;   my $total = $Stats->{'TOTAL_TOPICS'} + $Stats->{'TOTAL_REPLIES'};
return qq~

    <!-- Cgi-bot Board Stats -->
    <tr>
<td bgcolor='$iB::SKIN->{'MISCBACK_FIVE'}' width="100%" colspan='$iB::INFO->{'CN'}'>
<fieldset><legend>$Boards::lang->{'binfo_stats'} <img src="$iB::INFO->{'IMAGES_URL'}/images/stats_sm.gif" valign="bottom" /></legend>
<ul>
<li>$iB::INFO->{'BOARDNAME'} $Boards::lang->{'newest_member'} <span id='highlight'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Profile;CODE=03;MID=$Stats->{'LAST_REG_MEMBER_ID'}'>$Stats->{'LAST_REG_MEMBER_N'}</a></span> $Boards::lang->{'making_total'} <span id='highlight'>$Stats->{'TOTAL_MEMBERS'}</span> $Boards::lang->{'registered_mems'}.</li>
<li>$iB::INFO->{'BOARDNAME'} $Boards::lang->{'total_of'} <span id='highlight'><b>$total</b> $Boards::lang->{'posts'} ($Stats->{'TOTAL_REPLIES'} $Boards::lang->{'replies_to'} $Stats->{'TOTAL_TOPICS'} $Boards::lang->{'topics'})</span></li>
<li>$Boards::lang->{'most_online'}</li>
</ul>
<ul>
<li>$Boards::lang->{'ext_stats'} [<span id='highlight'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Statistics'>$Boards::lang->{'ext_stats_link'}</a></span>]
</li></ul></fieldset>
</td>
</tr>
    <!-- Cgi-bot End of Board Stats -->
~;
}

sub ForumRow {
                                    my $Data = shift;    if (!$iB::INFO->{'MOD_DROP_DOWN'}) {        $forum_mods = qq~$Data->{'MODERATOR'}~;    } else {        $forum_mods = qq~~;    }    if ($iB::INFO->{'MOD_DROP_DOWN'}) {        my ($select1, $select2);        if ($iB::INFO->{'MOD_DROP_DOWN'} == 1) {            $select1 = qq~    <select name='jump' onchange="jumpMenu('parent',this,0)" class='forminput'>    <option selected>$Boards::lang->{'forum_leader'}</option>~;            $select2 = qq~</select>~;        }        $cat_column6 = qq~    <script language='javascript'>    <!--    function jumpMenu(targ,selObj,restore){ eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");    if (restore) selObj.selectedIndex=0;    }    //-->    </script>    <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" width='15%' align='center' valign='middle'>    $select1    $Data->{'MODERATOR'}    $select2    </td>        ~;    } else {        $cat_column6 = qq~~;    }
return qq~

    <!-- Forum $Data->{'FORUM_ID'} entry -->
    <tr>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="center" width="5%">$Data->{'NEW_POST_IMG'}</td>
        <td onclick="location.href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SF;f=$Data->{'FORUM_ID'}'" class="forumclick" bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' align="left" width='40%'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=SF;f=$Data->{'FORUM_ID'}">$Data->{'FORUM_NAME'}</a></b></span><br>$Data->{'FORUM_DESC'} $forum_mods<br>$Boards::lang->{'forum_users'}: $Data->{'FORUM_USERS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_THREE'}" align='center' valign='middle' width='10%'>$Data->{'FORUM_TOPICS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_FOUR'}" align='center' valign='middle' width='10%' id='highlight'>$Data->{'FORUM_POSTS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_FIVE'}" align="left" valign='middle' width='35%'><span id='highlight'>$Data->{'FORUM_LAST_POST'}</span><br>$Boards::lang->{'in'}: $Data->{'N_LINK'}<br>$Boards::lang->{'by'}: $Data->{'P_LINK'}</td>
        $cat_column6
    </tr>
    <!-- End of Forum $Data->{'FORUM_ID'} entry -->
~;
}

sub events {
                                                                                                                                            my ($activity, $totalA, $l_event) = @_;
return qq~

<b>$totalA</b> $l_event   [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Calendar;CODE=1'>$Boards::lang->{'calendar'}</a> ]<br />$activity
~;
}

sub birthday {
                                                                                                                                                my ($birthusers, $total, $birth_lang) = @_;
return qq~

<b>$total</b> $birth_lang<br>$birthusers
~;
}

sub BoardInformation {
                                                                                        my $Data = shift;
return qq~

   <!-- Begin Board Legend -->
 <tr><td bgcolor='$iB::SKIN->{'MISCBACK_FOUR'}' colspan='$iB::INFO->{'CN'}'>
 <fieldset>
 <legend>$Boards::lang->{'binfo_legend'} <img src="$iB::INFO->{'IMAGES_URL'}/images/legend.gif" /></legend>
 <table bgcolor='$iB::SKIN->{'MISCBACK_FOUR'}' cellspacing='3' cellpadding='0' width='100%' height="90" align='center' colspan='$iB::INFO->{'CN'}'>
 <tr>
 <td align="center" nowrap><img src="$iB::INFO->{'IMAGES_URL'}/images/sm_a.gif" align="middle" border=0 alt='' /> <br />$Boards::lang->{'new_posts'}</td>
 <td align="center" nowrap><img src="$iB::INFO->{'IMAGES_URL'}/images/sm_b.gif" align="middle" border=0 alt='' /><br /> $Boards::lang->{'no_new'}</td>
 <td align="center" nowrap><img src="$iB::INFO->{'IMAGES_URL'}/images/sm_c.gif" align="middle" border=0 alt='' /><br /> $Boards::lang->{'new_cat_posts'}</td>
 <td align="center" nowrap><img src="$iB::INFO->{'IMAGES_URL'}/images/sm_d.gif" align="middle" border=0 alt='' /><br /> $Boards::lang->{'no_new_cat_posts'}</td>
 <td align="center" nowrap><img src="$iB::INFO->{'IMAGES_URL'}/images/sm_e.gif" align="middle" border=0 alt='' /> <br />$Boards::lang->{'new_restricted'}</td>
 <td align="center"' nowrap><img src="$iB::INFO->{'IMAGES_URL'}/images/sm_f.gif" align="middle" border=0 alt='' /><br /> $Boards::lang->{'no_new_restricted'}</td>
 <td align="center" nowrap><img src="$iB::INFO->{'IMAGES_URL'}/images/sm_g.gif" align="middle" border=0 alt='' /> <br />$Boards::lang->{'forum_off'}</td>
 </tr>
 </table></fieldset>
</td></tr>
~;
}



1;